import os,json,subprocess,time,traceback
from pathlib import Path
base=Path('/media/PM982/onestepfold');r=base/'diffusion_dense_fresh_evaluation_v1_20260930';cache=base/'diffusion_dense_fresh_cache_v1_20260930';source=base/'diffusion_dense_fresh_sources_v1_20260930'
assert not (r/'pipeline.json').exists();assert json.loads((source/'audit.json').read_text())['verified_sources']
py='/home/pc/anaconda3/envs/fold/bin/python';state=dict(pid=os.getpid(),complete=False,started=time.time(),phase='starting')
def env(root,gcd=''):
 return dict(os.environ,PROTENIX_ROOT_DIR=str(base/'protenix_stage0_pkg/v1_1/runtime'),LAYERNORM_TYPE='torch',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',ROCR_VISIBLE_DEVICES=gcd,PYTHONPATH=f'{root}/code/scripts:{root}/code:{root}/code/src:{base}/independent32_v2_20260930/deps_offline')
def save():
 p=r/'pipeline.tmp';p.write_text(json.dumps(state,indent=2));p.replace(r/'pipeline.json')
def run(root,script,*args):
 state['phase']=root.name+':'+script+':'+','.join(args);save()
 p=subprocess.Popen([py,str(root/'code/scripts'/script),'--root',str(root),*args],env=env(root),stdout=open(root/(script+'.'+str(len(state['phase']))+'.log'),'w'),stderr=subprocess.STDOUT)
 state['phase_pid']=p.pid;save();rc=p.wait();assert rc==0,(script,rc)
def workers(root,script):
 state['phase']='workers:'+root.name;save();start=time.time();ps=[];ws=[]
 for i in range(8):
  p=subprocess.Popen([py,str(root/'code/scripts'/script),'--root',str(root),'--mode','worker','--index',str(i)],env=env(root,str(i)),stdout=open(root/f'worker_{i}.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
  ps.append(p);ws.append(dict(index=i,pid=p.pid))
 (root/'execution.json').write_text(json.dumps(dict(controller=os.getpid(),started=start,workers=ws),indent=2))
 for p,w in zip(ps,ws):w['exit_code']=p.wait()
 e=dict(controller=os.getpid(),started=start,seconds=time.time()-start,workers=ws,complete=all(w['exit_code']==0 for w in ws));(root/'execution.json').write_text(json.dumps(e,indent=2));assert e['complete']
save()
try:
 run(cache,'prepare_dense_confirmation.py','--mode','cache')
 workers(cache,'cache_diffusion_learning.py')
 run(cache,'prepare_dense_confirmation.py','--mode','audit-cache')
 run(r,'prepare_dense_confirmation.py','--mode','evaluation')
 workers(r,'evaluate_diffusion_learning.py')
 run(r,'score_diffusion_learning.py','--workers','16')
 state.update(phase='finished',complete=True)
except Exception:state['error']=traceback.format_exc()
state['seconds']=time.time()-state['started'];save()
