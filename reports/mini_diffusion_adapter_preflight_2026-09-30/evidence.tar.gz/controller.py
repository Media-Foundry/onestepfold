import os,json,time,subprocess
from pathlib import Path
root=Path('/media/PM982/onestepfold/diffusion_adapter_preflight_v1_20260930')
env=os.environ.copy();env.update(PROTENIX_ROOT_DIR='/media/PM982/onestepfold/protenix_stage0_pkg/v1_1/runtime',LAYERNORM_TYPE='torch',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',ROCR_VISIBLE_DEVICES='0',PYTHONPATH=f'{root}/code/scripts:{root}/code:{root}/code/src:/media/PM982/onestepfold/independent32_v2_20260930/deps_offline')
command=['/home/pc/anaconda3/envs/fold/bin/python',str(root/'code/scripts/run_diffusion_adapter_preflight.py'),'--root',str(root)]
start=time.monotonic()
with (root/'worker.log').open('w') as f:
 p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);(root/'worker.pid').write_text(str(p.pid))
 try:rc=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=30);rc=-999
(root/'execution.json').write_text(json.dumps(dict(command=command,returncode=rc,seconds=time.monotonic()-start,worker_pid=p.pid),indent=2))
