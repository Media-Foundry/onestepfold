#!/bin/bash
set -euo pipefail
BASE=/data/user/shuang886/Folding
ROOT="$BASE/folding_alternate_sources_v1_20260930_retry1"
export CUDA_VISIBLE_DEVICES='' ROCR_VISIBLE_DEVICES=''
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 LAYERNORM_TYPE=torch
export PROTENIX_ROOT_DIR="$BASE/protenix_stage0_pkg/v1_1/runtime"
export PYTHONPATH="$ROOT/code/src:$ROOT/code/scripts"
PY=/data/user/shuang886/.conda/envs/fold/bin/python
cd "$ROOT"
sha256sum -c code.sha256
if [[ "$1" == prepare ]]; then
  "$PY" -u code/scripts/prepare_folding_source_variants.py --root "$ROOT" --mode prepare
  exec "$PY" -u code/scripts/prepare_folding_source_variants.py --root "$ROOT" --mode search
elif [[ "$1" == qualify ]]; then
  exec "$PY" -u code/scripts/prepare_folding_source_variants.py --root "$ROOT" --mode qualify
else exit 2
fi
