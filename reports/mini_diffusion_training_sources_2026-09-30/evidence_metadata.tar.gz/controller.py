from pathlib import Path
import os,subprocess,json,time
root=Path('/media/PM982/onestepfold/diffusion_training_sources_v1_20260930');env=os.environ.copy()
env.update(ROCR_VISIBLE_DEVICES='',LAYERNORM_TYPE='torch',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PROTENIX_ROOT_DIR='/media/PM982/onestepfold/protenix_stage0_pkg/v1_1/runtime',PYTHONPATH=f'{root}/code/scripts:{root}/code:{root}/code/src:/media/PM982/onestepfold/independent32_v2_20260930/deps_offline')
command=['/home/pc/anaconda3/envs/fold/bin/python',str(root/'code/scripts/prepare_diffusion_training_sources.py'),'--root',str(root),'--base',str(root.parent)]
start=time.monotonic()
with (root/'worker.log').open('w') as f:
 p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);(root/'worker.pid').write_text(str(p.pid))
 try:rc=p.wait(timeout=7200)
 except subprocess.TimeoutExpired:
  import signal
  os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=30);rc=-999
(root/'execution.json').write_text(json.dumps(dict(command=command,returncode=rc,seconds=time.monotonic()-start,worker_pid=p.pid),indent=2))
