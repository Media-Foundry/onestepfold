import os,json,subprocess,time
from pathlib import Path
r=Path('/media/PM982/onestepfold/diffusion_dense_learning_v1_20260930');assert not (r/'lock.json').exists()
py='/home/pc/anaconda3/envs/fold/bin/python';script=str(r/'code/scripts/train_dense_diffusion.py')
env=dict(os.environ,PROTENIX_ROOT_DIR=str(r.parent/'protenix_stage0_pkg/v1_1/runtime'),LAYERNORM_TYPE='torch',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=f'{r}/code/scripts:{r}/code:{r}/code/src:{r.parent}/independent32_v2_20260930/deps_offline')
subprocess.run([py,script,'--root',str(r),'--mode','prepare'],env=dict(env,ROCR_VISIBLE_DEVICES=''),check=True)
workers=[];ps=[];start=time.time()
for i,scope in enumerate(['token_dense','diffusion_dense']):
 p=subprocess.Popen([py,script,'--root',str(r),'--mode','train','--arm',scope],env=dict(env,ROCR_VISIBLE_DEVICES=str(i)),stdout=open(r/f'{scope}.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
 workers.append(dict(scope=scope,gcd=i,pid=p.pid));ps.append(p)
(r/'execution.json').write_text(json.dumps(dict(controller=os.getpid(),started=start,workers=workers),indent=2))
for p,w in zip(ps,workers):w['exit_code']=p.wait()
(r/'execution.json').write_text(json.dumps(dict(controller=os.getpid(),started=start,workers=workers,complete=all(w['exit_code']==0 for w in workers),seconds=time.time()-start),indent=2))

if all(w['exit_code']==0 for w in workers):
 rc=subprocess.run([py,str(r/'code/scripts/audit_dense_diffusion.py'),'--root',str(r)],env=dict(env,ROCR_VISIBLE_DEVICES=''),stdout=open(r/'audit.log','w'),stderr=subprocess.STDOUT).returncode
 (r/'audit_execution.json').write_text(json.dumps(dict(exit_code=rc)))
