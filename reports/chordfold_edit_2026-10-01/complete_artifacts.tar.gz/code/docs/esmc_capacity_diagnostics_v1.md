# Descriptive local-geometry diagnostics for the capacity run

Declared while task631201 is running, before its selected-checkpoint or
second-seed predictions are available. This supplement does not change the
training protocol, checkpoint selection, stopping rules or capacity threshold.
It runs on CPU using already saved experimental GT and prediction coordinates.

For each condition (initial, selected seed12345, selected seed54321), retain
the same observed masks and fixed residue/atom names. Report FP64 errors against
GT for intrarezidue N-CA, CA-C and C-O distances, and separately for consecutive
observed residue C-N distances. Do not assume every observed consecutive pair is
an intact chemical bond; also record GT mean/max distances. Never join across
an unobserved residue, impute atoms, realign atom identities or compare masked
placeholders.

For residues with observed N/CA/C/CB, compute signed triple product
cross(N-CA, C-CA) dot (CB-CA). Exclude and count GT magnitudes <=1e-6 A³ as
degenerate. Among remaining GT sites count predicted magnitudes <=1e-6 A³
separately, opposite signs separately, and matching nondegenerate signs as
agreement. This compares local handedness to the observed GT rather than
assuming an absolute sign convention for every residue.

Aggregate squared and absolute distance errors by actual observed pair count;
aggregate chirality counts by actual evaluable residue count. Preserve per-protein
records and source/GT/prediction hashes. Tests must distinguish proper rotations
from reflections, detect a local distortion, and exclude missing or degenerate
sites correctly. Require final prediction metric QA before final diagnostic
reporting; initial-only analysis is explicitly provisional.

These limited local checks are not full stereochemical validation: side-chain
bonds/angles, clashes, disulfides and alternative symmetric atom naming remain
outside their scope. They cannot certify a physically valid protein, prediction
generalization, confidence calibration or a thermodynamic sample distribution.
