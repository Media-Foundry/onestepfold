# Pretrained folding core with an ESMC input bridge

The tensor compatibility and native-coordinate replay gates passed. The next
single diagnostic initializes ESMC conditioning while preserving the mature
folding weights. This is a starting point for the user-authorized8192-protein
training, not a claim that a small feature regression completes folding training.

Use exactly the existing endpoint512 TRAIN/128 DEV groups and paired cached
features, with sequence/residue order and accepted file hashes verified. Require
the512 TRAIN groups to lie within the original2048 TRAIN before fitting, so both
future2048/8192 experiments can share this initialization without asymmetric
training-data exposure. If that membership check fails, stop and declare a
corrected TRAIN-only protocol before fitting. DEV128 never enters fitted moments.

Fit one affine1152→449 projection to the frozen native target
`W_ESM2 @ E_ESM2`, computed in FP32. Use protein-equal residue-mean squared error,
TRAIN-only per-channel centering/scaling (variance floor1e-8), and a single fixed
ridge coefficient1e-3 on standardized input coefficients. Solve in FP64, store
FP32 weights/bias. No hyperparameter or checkpoint selection on DEV; no GT
coordinates are used to fit the bridge. All folding-core weights stay unchanged.
The added449-dimensional bias is an explicit interface parameter; it is not a
silent unmatched checkpoint key. No inference-time ESM2 extraction is needed by
the learned bridge. Native ESM2 remains a matched diagnostic reference only.

First verify synthetic affine recovery, protein weighting and constant-channel
stability, then fit once and report TRAIN/DEV residual distributions relative to
the TRAIN mean predictor. A low feature residual alone is not the scientific gate:
subsequent matched native-conditioned versus ESMC-conditioned coordinate evaluation
must report mean and tails, chemistry and per-target changes under c1/s1/K1.
Keep two fixed independent K1 noise views12345/54321; do not choose best-of-two.
The controlled native path has dropout0 and schedule[2560,0]; re-evaluate that
reference rather than silently reusing historical MC-dropout teacher scores.

Coordinate evaluation will use the same accepted prepared chemical inputs and
observed GT masks for each condition, with no geometry projection. Save complete
per-target outputs for independent QA. Report512 full-TRAIN and128 DEV results,
not only a32-protein probe. Existing reused DEV and pretraining overlap still limit
generalization claims. No frozen temporal test use.

If the affine bridge has poor structural retention, that rejects this initialization,
not ESMC's information content or all possible adapters. Do not automatically open
a bridge architecture grid. Use the result to choose between a bounded GT-supervised
adaptation and improving the conditioning interface before larger training.
Current structural loss/noise/geometry ablations remain separate from this test.

## Fit result and coordinate-export resources

HPC3 job654849 completed in5m24s; three focused fitting tests passed. TRAIN512
and DEV128 protein-mean residual/mean-predictor-MSE ratios are0.63735 and0.66215.
These leave substantial feature error and are not folding-quality results.
Report/checkpoint hashes were verified after archiving. All512 fitting targets
belong to originalTRAIN2048; DEV128 is exactly the fixed development view.

Use four of the user-authorized DiamondHill GCDs for one coordinate comparison,
160 targets per worker. This shards the same640-target/two-condition/two-noise
evaluation; it adds no candidate selection or method variants. Before full export,
run loader tests and a longest-TRAIN deterministic replay on one GCD, with a
10-minute bound. Full workers have30-minute bounds, one visible GCD each,
same torch/ROCm runtime and model/source/input hashes. Record actual sampler
parameters, schedule and call counts. Native and ESMC outputs for a target remain
on the same GCD. Independent CPU scoring/QA follows prediction export; no
cross-H100/ROCm coordinate equality or end-to-end speedup claim.
