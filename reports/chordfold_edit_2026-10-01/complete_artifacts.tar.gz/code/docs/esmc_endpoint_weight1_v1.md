# Endpoint 权重 1.0：单一跟进实验（2026-09-26）

## 问题与选择

用户要求继续推进一次计算追回质量与尾部。权重0.1的8192更新pilot没有确认
均值/尾部收益；固定8 TRAIN探针的全参数教师梯度约为GT的12%–18%，多数同向。
因此只新增 **权重1.0**，检验教师终点信号达到相近梯度量级是否有效。
这是有依据的单次剂量检验，不是最佳权重搜索；诊断没有证明提高权重必然有效。

## 不变条件和节约计算

复用原已验收 GT-only 与 endpoint0.1 作为匹配对照，不重训它们，也不重生成教师。
从原 control512/best.pt 重新开始，不从endpoint0.1最后权重继续。固定原512 TRAIN、
128开发验证、ESMC-600M缓存、固定原子图、缺失GT mask、完整canonical teacher
原子对应、optimizer初始化、训练顺序与噪声、lr1e-4、AdamW wd1e-4、clip10、batch1。
新目标仅由 A+0.1F+R+10D+0.1T 改为 A+0.1F+R+10D+1.0T。

教师仍为旧缓存 Protenix-Mini/ESM2-3B c4_s2、seed103、K1，无MSA/templates；
gamma0=0、eta=1、lambda=1.003，噪声序列和来源使用原缓存验收记录。
学生 model config、单步实际noise schedule/solver及几何输出代码与原snapshot一致；
不是新采样器、consistency训练或新架构。部署依旧c1/s1/K1。

新增训练最多8192次更新或4小时优化/评估软上限，Slurm预留7小时。
每1024更新评价；两噪声12345/54321分别K1，按目标平均，不best-of-K。
先GPU预检，然后训练、GPU产物重放、CPU独立验收和匹配汇总自动依赖。
单条训练串行更新是保持optimizer/batch条件所必需；不增加无信息量的并行重复。
全部实验和测试在HPC3；本地仅编辑、锁定和归档。

## 预先锁定验收和比较

新followup lock绑定原父权重、教师/数据验收、两对照report/contract/history/QA、
新源码manifest和本协议。旧code_v1、lock和结果不修改。新schema明确区别于旧pilot。
正式首个optimizer更新前，全部256个初始开发预测（128×两噪声）必须与原GT-only
的raw/几何输出逐位相同，独立分数/原GT损失相同；否则停止，不能宣称匹配对照。

精度验收在运行前即采用既有 precision-v2：所有保存GPU FP32几何输出完全重放，
独立Torch/NumPy FP64公式atol1e-8，原跨精度1e-4结果另报不改名；保留数据、
来源、checkpoint、损失、指标、mask和实际trunk1/structure1调用计数检查。

主要终点固定为第8192更新，相对GT-only的开发集lDDT/TM均值及worst5%均值。
按目标配对bootstrap5000次、seed20260926；四项差值的区间下界都>0才标为
**本开发pilot联合质量/尾部通过**。否则仅报告不确定或负结果，不通过挑中间checkpoint
改变判定。相对endpoint0.1为次要剂量比较；同时报告P05、退化>0.05目标数、
原教师c1_s1/c4_s2参照、geometry、train512和完整收敛曲线。
这些区间为探索性target-bootstrap，不是独立训练seed或跨实验多重检验校正。
即使本gate通过，仍需独立确认，不能宣称总体一步目标完成。

若软时间上限导致未达8192，仅报告双方实际共同更新点，主要终点标为预算未完成。
最佳checkpoint辅助报告，与最终相同预算严格分开。GPU小时/样本曝光/更新数均记录；
不把cached-ESMC warm core计时说成端到端速度。

无尾部权重、循环增加、更多采样配置、冻结测试使用、扩大数据或新种子搜索。
新结果出来前不自动追加训练树。
