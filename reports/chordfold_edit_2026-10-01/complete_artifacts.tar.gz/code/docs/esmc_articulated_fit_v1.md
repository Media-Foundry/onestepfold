# Bounded observed-GT inverse fit of articulated cached references

Declared after the accepted fixed-graph prerequisite report
82b1a7f10bc32f46fe33e11ae0df5e2a5df18c9a2045e1d653d567e862ac960d.
Use its pinned CCD-induced inventories/bridge rotations and the exact32 TRAIN
reference artifacts from the accepted rigid-fit report40909d6d. No held-out data,
network forward, optimizer update to model weights, atom-name permutations,
imputed targets or chemical graph changes.

For each residue with observed atoms, minimize observed mean Euclidean squared
error over the declared internal angles. At each evaluation eliminate its rigid
pose by optimal proper Kabsch alignment on observed atoms only. Use FP64 and the
envelope derivative through the coordinate builder, holding this optimal pose
fixed in the derivative. Verify this derivative with finite differences on a
nondegenerate synthetic example; do not differentiate the SVD.

Exactly two initializations: all angles zero; and sequential observed-dihedral
matching where both axis endpoints and suitable proximal/distal atoms are
observed and noncollinear. Choose immediate bonded neighbors first, then other
fixed-name atoms in each component, in inventory order. Unavailable angles stay
zero. These GT-dependent angles and poses are exclusively diagnostic fit variables,
never inference inputs or training labels for missing atoms. Skip identical starts.

Each distinct start uses SciPy L-BFGS-B, max80 iterations, a hard cap of200 function
evaluations, max20 line-search steps, ftol1e-12, gtol1e-8. Keep the best actual
evaluation, including zero-angle baseline, even if termination is unsuccessful.
Log starts, counts, termination and per-residue errors. No retries or additional
multistarts based on disappointing quality. For zero-angle error <1e-20 skip
unnecessary optimization. Residues with no observed atoms are excluded from fits.

Execute one CPU-only HPC3 job,4 workers/4 CPUs/12GB/20min hard walltime; no GPU
requested, CUDA visibility empty. Independent per-protein fits may run in parallel.
Archive immutable source, input/source hashes, all angle/pose variables and only
observed fitted coordinates. Independently reconstruct saved coordinates with
NumPy rotation matrices, check masks/identity/hashes, proper rotations, reference
bond/angle/ring preservation, eligible CA/ILE/THR chirality, and errors/aggregation.
Report observed consecutive-C/N distance error separately: poses are independent
and chain connectivity is not constrained by this fit. Missing target coordinates
must never enter initialization, pose fitting, scalar evaluation or output labels.

Report pooled/per-protein/AA-type errors versus the accepted rigid baseline,
including <=1 A counts. A pooled fit <=1 A only establishes that these observed
targets are representable to that tolerance under this permissive pose model.
Numerical attained errors are upper bounds on the representation's minimum;
failure above a threshold is not a proven lower bound. No learned folding quality,
generalization, physically valid global structure, calibrated confidence or speed
claim follows. Use the result to decide the next output-representation work while
keeping the original frozenESMC/all-heavy-atom/one-evaluation objective intact.
