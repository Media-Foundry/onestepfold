# CPU attribution of the existing local-frame loss

Declared while coefficient0.1 job631592 is running, before this attribution is
computed. This diagnoses the accepted coefficient0.001 run631506 and, only after
its final independent QA, the controlled coefficient0.1 run. No GPU forwards,
weight updates, new labels, coefficient trials or changes to the live experiment.

Use all32 selected TRAIN proteins, the selected checkpoint and both declared
evaluation seeds. Verify accepted report/QA/contract, GT, inventory, prediction and
supervision hashes; rebuild observed supervision from the fixed labels and masks.

Partition existing frame-point pairs by whether the point and frame CA belong to
the same residue. Report counts, mean squared error within each partition and its
contribution to the original scalar, retaining the original TOTAL pair denominator.
The partition describes pair identity, not a causal separation of chemistry from
folding: cross-residue terms also differentiate frame-anchor coordinates.

On CPU FP64 compute each partition's coordinate gradient and the original total
gradient. Verify scalar and gradient additivity, independent NumPy scalars and a
central directional finite difference for each partition on the shortest protein
at seed12345. Report gradient norms and cosine, explicitly not parameter gradients
or AdamW updates. Preserve missing atoms as excluded masks with zero gradients.

Report predicted frame C-CA lengths and projected N-CA lengths, their minimum,
median and counts at/below the existing1e-4 A normalization floor. This checks
whether the explicit degeneracy stabilizer is active; no threshold sweep.

Archive per-protein results, summaries, actual source hashes and a readable report.
Interpret together with coordinate/geometry gates. Do not choose new loss weights
or promote a checkpoint from this diagnostic alone. The original ESMC-conditioned
all-heavy-atom predictor, confidence, held-out quality and full inference cost
remain the goal.

## Extension for the recorded same-residue objective

Declared while job631737 remains live, before its final attribution. After final
independent QA, apply the same32-protein/two-seed saved-coordinate analysis and the
existing residue-shape diagnostic to its selected predictions. No new GPU work.

Retain the original unweighted global-frame partition fields, and separately
report the actual geometry objective `w_global * F + w_same * R` using weights
from the immutable training contract (absent w_same means0). If f is the same-
residue pair fraction in F, its original scalar/gradient contribution is multiplied
by `w_global + w_same/f`, while the cross-residue contribution is multiplied by
`w_global`. Verify this weighted sum against a direct CPU FP64 objective/backward.
Report scalar fractions and coordinate norms explicitly as geometry-only, excluding
aligned atom loss. Do not describe the old~0.12% share of F as the share of the new
geometry objective. These calculations choose no new weights or training settings.
Preserve prior accepted results and their archived source snapshots unchanged.
