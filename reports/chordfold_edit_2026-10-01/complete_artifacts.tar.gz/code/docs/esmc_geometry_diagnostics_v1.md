# CPU diagnosis of local shape and sampler-seed agreement

Declared while geometry-capacity task631506 is running, before its selected
final coordinates are available. These diagnostics do not alter training,
checkpoint selection, stopping criteria or the capacity gate.

Use only the accepted32 TRAIN inputs/observed experimental labels and saved
initial/selected predictions for seeds12345/54321. Wait for accepted final
independent QA. No extra model forwards, optimization, held-out access or GPU.

For each prediction, after one proper all-observed-atom GT-to-prediction rigid
alignment, decompose coordinate SSE into residue-centroid and residue-centered
components. The two terms must add to total SSE. Report atom-weighted RMS radii
within each residue for prediction and GT. The centered coordinate error includes
local orientation under the common alignment; it is not a pure bond-length error.
This tests whether similar aggregate RMSDs conceal atom collapse.

Compare the two seeds directly on identical observed atom identities: proper
all-atom aligned RMSD, independently aligned CA RMSD, and CA pair-distance RMSE.
Report macro/pooled and per-protein values. Low disagreement means the two saved
predictions agree, not that either is correct or that all sampler seeds generalize.
Compare with the accepted failed fixed-RNG capacity checkpoint's best/second-seed
predictions, preserving its original selection and negative gate. Its initial
second-seed coordinates were not saved, so no paired initial comparison is claimed.

Bind every input to accepted report/GT/prediction hashes. Archive source and
CPU-only diagnostic output. No new loss weight, GPU experiment or production
quality claim follows automatically from these measurements.
