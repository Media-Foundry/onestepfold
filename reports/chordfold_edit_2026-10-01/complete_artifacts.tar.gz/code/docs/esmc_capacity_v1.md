# Direct experimental-GT capacity gate v1

Status: complete, capacity gate failed. HPC3 task631201 completed0:0 in35:00,
100epochs/3,200updates; best epoch85. Independent CPU final artifact/checkpoint/
FP64 metric audit passed. Report reports/esmc_capacity_2026-09-18.md.
The archived execution protocol preserves the pre-training declaration. The
initialization correction below followed task631181's pre-optimizer failure.

Purpose: determine whether the fresh ESMC all-heavy-atom core can fit a small
fixed training subset through its actual one-cycle, one-structure-call sampler.
This is a bounded optimization/capacity gate, not held-out quality or calibrated
confidence. It follows the accepted interface gate, not the failed teacher-state
emulator. No teacher coordinates, states, or pretrained folding weights are inputs.

## Frozen inputs and model

- Select the first 32 training groups after sorting the accepted 128-group training
  selection by (sequence_length, group_id): lengths 35–166. Preserve parent split,
  sequences, chemical inventories, observed/missing masks and raw-CIF provenance.
  Rebuild all 32 experimental labels exactly from raw mmCIF before optimization.
- Reuse pinned cached frozen ESMC-600M final embeddings. No ESM extraction,
  additional held-out selection, temporal-test access, or GT imputation.
- Random seed101 for Python, NumPy/SciPy and PyTorch, same134,584,255-parameter
  Mini topology as the interface gate. Pin the reproducible CPU-audited initial
  tensor hash `baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea` before the corrected launch. The prior interface gate seeded only
  PyTorch; its saved random checkpoint remains valid but cannot be reconstructed
  from that seed alone. Do not claim the new initialization matches those weights.
- Capacity-only configuration explicitly sets Pairformer/MSA/template dropout
  to zero, with unchunked trunk in both train and eval. Preserve train mode for
  upstream trunk gradients. Assert exact initial train/eval coordinates with
  fixed RNG on the shortest sample before training. Both TF32 flags False.
- Train coordinate path; freeze unused confidence and distogram heads. Confidence
  training/calibration remains a later required goal, not a result of this gate.
- Native one-step schedule [2560, 0], one sample, seed12345 reset per forward.
  Fixed noise isolates capacity. A final second seed54321 diagnoses sensitivity;
  it does not select checkpoints or count as a generalization result.

## Objective, optimizer, and budget

For each protein, rigidly fit experimental observed heavy atoms into detached
prediction coordinates using FP64 Kabsch with determinant +1. Minimize the mean
squared Euclidean distance per observed atom (A², sum over xyz). No scale fit,
reflection, side-chain symmetry renaming, missing-atom imputation, distance term,
teacher loss, or gradient through SVD. Fixed atom identity is a limitation.

AdamW lr1e-4, weight_decay1e-4, default betas/eps, gradient norm clip10,
batch one protein, independently seed101-shuffled order each epoch. Maximum
100 epochs / 3,200 updates. One HPC3 H100, 8 CPU, 96G, two-hour scheduler limit;
soft budget 75 minutes of optimization/evaluation, finishing the current epoch
before saving final artifacts. No concurrent hyperparameter grid.

Initial evaluation and then every five epochs, always eval mode/no_grad:
aligned heavy-atom RMSD, independently aligned CA RMSD, and CA pair-distance RMSE
to observed experimental labels. Save per-protein values plus macro/pooled
aggregates. Select best by pooled all-heavy-atom RMSD, including epoch0 as a
failure-safe candidate. Save atomic best weights and latest resumable optimizer
state at evaluation points, with source/config/selection provenance.

Stop at the first evaluation satisfying pooled heavy-atom RMSD <=1 A, pooled CA
distance RMSE <=1 A, and at least29/32 proteins having heavy-atom RMSD <=2 A.
This threshold only establishes small-set capacity. Stop for futility at epoch20
if both principal metrics remain above90% of their initial values. From epoch30,
stop for plateau when best pooled atom RMSD has not improved by1% over the best
value available twenty epochs earlier. Otherwise stop at the fixed budget.
Nonfinite loss/gradient/output is a failed run, never a pass.

## Final evidence

Reload best weights and repeat all32 same-seed eval predictions exactly. Save
initial/best coordinates and metric histories. Evaluate the predeclared second
noise seed once at best weights. Audit frozen heads, input hashes, actual forward
call counts, parameter/gradient finiteness, optimizer steps, peak GPU memory and
wall time. Independent CPU FP64/SciPy metric recomputation must agree with saved
metrics (2e-5 A absolute tolerance); this does not repeat GPU optimization.

Keep heavy checkpoints/features on HPC3 and archive compact predictions, GT,
provenance, curves, source snapshots and QA locally. Any next larger-data run
requires interpreting this result first. The original trained-model, confidence,
full held-out quality and end-to-end inference-cost requirements remain open.
