# Capacity-C: exposure-controlled single / four / 32 TRAIN proteins

Declared 2026-09-19 after all five Capacity-B arms passed artifact QA. User
approved starting 4/32 comparisons and requested informative parallel HPC3 jobs.
No new data, held-out inspection, folding weights, teacher features, or scope expansion.

## Matrix and selection

Ten independent one-H100 training jobs, one shared fresh initialization seed101:

- control and raw, each on four proteins (two jobs).
- control and raw, each on all original 32 TRAIN proteins (two jobs).
- control and raw, each separately on three new singleton controls (six jobs).

Four-protein subset = indices [0, 7, 15, 31] in the existing length/group ordered
32 TRAIN selection. This covers the shortest, lower quartile, previous median
singleton, and longest. Select without errors. New singleton jobs use indices
0, 7, 31. Existing Capacity-B index15 results/curves are reused, not retrained.
These six cheap jobs distinguish intrinsic sample difficulty from shared-model
interference on the exact same samples. They are not independent training seeds.
Do not automatically extend allframe, oracle, c4, or a new architecture grid.

control = unchanged articulated adapter; raw = remove adapter only. Both use
unchanged c1 ESMC-conditioned scratch model and A + .1 F + R + 10 D. Frozen ESMC
features, BF16 trunk / FP32 structure, dropout0, TF32 off, one structure call,
confidence/distogram frozen and disabled. AdamW lr1e-4, wd1e-4, clip10, batch1.
No warm starts. INITIAL_HASH baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea.

## Exposure, compute and stopping

An epoch means exactly one update per selected protein. Each example receives
at most **1000 exposures**: 1000 / 4000 / 32000 total updates for size1/4/32.
Within epoch e shuffle indices with Python Random(101+e), matching the old32
schedule. Noise = training_sampler_seed(group_id,e), independent of subset size
and arm. Audit actual schedule and seed collisions; collisions are recorded,
not silently resampled. Evaluation noise seeds12345/54321 excluded from training.

Evaluate initial and every50 exposures, and at any soft-time stop. Preserve all
per-protein metrics; compare 100,300,650,950,1000 exposures where runs reach them,
as well as total optimizer updates and measured wall time. Early-stopped runs
are censored past their stopping point, never extrapolated to the common budget.
Index15 B curves use atom-based checkpoint selection; C uses joint score, so
compare matched exposure curves and first threshold crossings, not a misleading
best-checkpoint ranking across selection rules. New four/32 comparisons use
identical selection and cadence within each size.

Predeclare gates at BOTH noise seeds:
- size1: atom <0.5 A and the Capacity-B chemistry/CA gate.
- size4: all four atom RMSDs <1 A, pooled CA-distance <=1 A, pooled bond RMSEs
  N-CA/CA-C/C-O <=0.15 A and C-N <=0.30 A, pooled handedness agreement >=95%.
- size32: preserve old joint gate: pooled atom RMSD <=1 A, pooled CA-distance
  <=1 A, >=29/32 atom RMSDs <=2 A, same pooled bond/handedness gate.

Checkpoint = minimum maximum normalized gate violation across both noises;
earliest tie. Record atom statistics and per-example curves separately. Stop
only on gate pass, 1000 exposures, numerical failure, or soft wall limit. No
plateau stop, ad hoc extension, or learning-rate changes. Soft wall limits:
10 hours for32, 2 hours for1/4; hard Slurm12 hours for32,3 hours for4,1 hour for1
(singleton soft limit overridden to45 minutes, leaving QA/finalization time).
Time-censored results cannot be called a matched-exposure capacity failure.
Save best and optimizer-containing last checkpoint every evaluation.

## Preflight and acceptance

Two short arm-specific size32 GPU preflight jobs (no optimizer updates) verify
all64 raw initial coordinates against accepted parent, adapted <=5e-5 A,
longest input train/eval identity, actual c1/one-structure/zero-confidence calls,
and longest-input finite nonzero front/decoder gradients. Launch training with
Slurm afterok dependencies on the corresponding successful preflight. No failed
preflight is counted as a model-capacity result.

Bind immutable source manifest, runtime sources, parent QA/report, initial model,
experimental targets/masks/fixed atom names, chemical references and adapters.
No missing-label imputation or GT in inputs. At completion require exact best
GPU reload/coordinate/metric replay, unchanged inputs/adapter/frozen weights,
and CPU acceptance of all initial/best/last saved outputs. CPU verification uses
independent NumPy chemical reconstruction <=1e-4 A; independently evaluated losses
atol1e-3/rtol2e-5; independent RMSD error <1e-5 A. Recheck every actual training
update's group/exposure/noise and all subset/gate/selection decisions. CPU QA is
inside each job with CUDA hidden, included in reservation cost. Preserve failure
logs/sources; no automatic training resubmission.

Root cause remains open: existing loss is SE(3)-invariant; internal Cartesian
conditioning is distinct. Comparing subset sizes at fixed per-example exposure
changes total AdamW updates and weight-decay applications, so it is evidence on
this training setup, not an isolated mathematical test of model capacity.
Generalization, learned confidence, direct frame/torsion heads and full
ESMC-inclusive inference cost remain separate future objectives.
