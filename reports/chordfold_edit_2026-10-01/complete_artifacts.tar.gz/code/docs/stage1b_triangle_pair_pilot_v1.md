# Single shared-neighbor branch pilot v1

Status: complete, including longest GPU checks, training 630661, decoding
630663_[0-3] and independent QA 630664. Selected epoch 20 has decoded all-atom/
CA-distance ratios to c1 1.018139/1.024451; the candidate fails the structural
criteria. Preserve the negative result and do not extend this configuration.
Report: reports/stage1b_triangle_pair_2026-09-18.md. The pre-run contract below
is retained in immutable code_triangle_pair_v1_20260918 and its training hashes.

The hypothesis is that the pointwise c1 MLP lacks useful pair-specific
shared-neighbor information. Its inputs include local z[i,j], endpoint singles
and additive row/column means. Component controls motivate testing interaction
information; they do not demonstrate that this branch can learn the required
correction. Do not replace the failed previous validation result.

Freeze one architectural change, no width/depth/loss grid. Retain the baseline
MLP's inputs, state-channel LayerNorms, endpoint/context projections, hidden
layers, zero-initialized output and c1 single/input states. Add a 16-channel
outgoing triangle feature:

`T[i,j,r] = mean_k tanh(A(LN(z1[i,k])))_r * tanh(B(LN(z1[j,k])))_r`.

Use independent bias-free A/B projections, the existing local pair LayerNorm,
and all k including diagonal positions. Compute the batched matrix products
under BF16 autocast, divide by length in FP32, LayerNorm the 16 channels, then
apply a bias-free 16-to-256 projection added to the first hidden preactivation.
No symmetry enforcement, gating or extra pair/single updates. Keep the final
projection/addition FP32 and convert outputs to BF16 exactly as before.
Initialize all shared parameters first so seed 101 yields identical baseline
shared weights; only then initialize the new branch. Total parameters: 195,568.
Additional triangle arithmetic grows as O(16 L^3); actual end-to-end speed must
be measured before any cycle-saving claim.

Keep the accepted nested 128/64 cache, twenty epochs, 4,096 uniformly sampled
ordered pairs per training protein, seed 101, AdamW 0.0003/0.0001, clipping 10
and raw pair-state MSE unchanged. Full context is computed from c1 alone.
Select by the same full-pair macro MSE after BF16 conversion with identity
epoch 0 eligible. Compare the result against both c1/c2 and the completed
pointwise MLP using identical groups. An architecture change does not by itself
make state MSE a sufficient quality criterion.

Before training, require matching shared initialization, exact zero identity,
disabled-branch equality, an off-pair perturbation with unchanged row/column
means that is visible to the new branch, finite triangle gradients, bounded
chunk/reload equivalence, and an actual longest-input BF16 GPU forward/backward
check. These checks have now passed, including the longest 951-residue GPU case.

Decode all 64 validation proteins and repeat independent atom/state/coordinate
QA. Retain both pooled <=0.95-of-c1 structure criteria, c2 quality parity and
measured lower end-to-end inference cost for a useful saving, plus the separate
formal 1,600 gate before scaling. No epoch extension merely because state MSE
falls, and no automatic full-data run. No temporal-test read or target-derived
inference feature is permitted. This remains a teacher-side compatibility
pilot; ESMC-600M adaptation, experimental-GT evaluation and one structure
evaluation remain unfinished requirements of the original objective.
