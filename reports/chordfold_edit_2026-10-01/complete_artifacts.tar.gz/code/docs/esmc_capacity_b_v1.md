# Capacity-B: bounded single-protein discrimination

Declared 2026-09-19 following the user's request. This supersedes the earlier
single-intervention restriction, not the original deployment target. No held-out
data, pretrained folding weights, teacher states or larger-data training.

## What is already controlled

Current A is proper-Kabsch-aligned observed atom MSE. F is an unclamped squared
local-frame error over observed atoms within 15 A of a GT frame; R restricts
that supervision to the same residue. D is observed four-category distance MSE.
All are invariant to a common proper rigid transform of nondegenerate predictions.
The accepted 3–4x derivative differences concern redundant raw internal coordinates,
not whole-protein rotation. Existing articulated output already reconstructs fixed
chemical geometry from predicted frames/dihedrals, but extracts these from raw xyz.

## First wave (independent HPC3 jobs)

Select index 15 of the accepted length-ordered 32 TRAIN set, length 128, group
36e538543c24414069b77ac1a24e0597ea526b6c77eb19f02ef2c671db700f37.
Selection uses length/order only, never model error. Five arms:

* control: accepted one-cycle core, articulated output, A + .1 F + R + 10 D.
* raw: same core/loss, remove only the articulated adapter.
* allframe: same as control, replace only F's 15 A neighborhood with every
  observed atom in every eligible observed frame (exclude its own CA). Keep
  squared Euclidean error and coefficient .1. This tests supervision coverage,
  not introducing SE(3) invariance, not canonical clamped AlphaFold FAPE.
* oracle: same decoder/adapter/loss, bypass input embedder/Pairformer with freely
  learned native-shaped s_inputs[L,449], s[L,384], z[L,L,128]. Initialize them
  from this fresh core's c1 output using chemical/sequence inputs only, then
  freeze the whole upstream core and train these tensors plus the same scratch
  diffusion decoder. FP32 master tensors cast to original native dtypes. This
  is a deliberately permissive conditioning oracle, NOT a compact protein-ID
  embedding and NOT a usable sequence predictor. Exact initial output equality
  is required. Failure under one optimizer/budget cannot prove decoder incapacity.
* c4: same as control except N_cycle=4, retaining native Protenix recycling:
  only the final cycle has gradients, previous cycle states are detached.
  This is a recycle diagnostic, not a fully unrolled capacity upper bound.

Fresh shared initialization seed101/hash baad41...; no warm start. AdamW 1e-4,
weight_decay1e-4, clip10, batch1, dropout0, BF16 trunk/FP32 structure and adapter,
TF32 off. One structure evaluation/sample, confidence/distogram frozen/disabled.
1600 updates maximum, 45-minute optimization soft ceiling, 65-minute Slurm limit.
Per-update noise training_sampler_seed(group, update), shared across arms.
Evaluate initial and every50 updates on fixed seeds12345/54321; these are sampler
noise checks, not two independently trained models. No plateau stop. Every arm
uses one training initialization. Compare matched update AND actual wall time.

Primary selection: lowest worst-of-two-noise all-heavy-atom RMSD (earliest tie).
Desired memorization <.5 A, minimum <1 A at both noise seeds. Track CA-distance,
all four bond categories, handedness and fallback counts separately; atom gate
does not imply chemistry gate. Early stop only if both noise seeds atom<.5 A,
CA-distance<=1 A, bond RMSEs<=.15/.15/.15/.30 A and hand agreement>=95%.
Report best and last; retain optimizer in last checkpoint. No ad hoc extensions.

## Verification and interpretation

Preserve accepted sources. Bind input, mapped GT, masks, atom names, chemical refs,
source snapshot, installed runtime and initial weights by hashes. Before training:
exact control/raw/allframe/oracle raw replay against accepted initial output;
adapter replay <=5e-5 A; oracle learnable conditions must initially replay exactly;
c4 counted 4 trunk executions /1 structure/0 confidence, initial output need not
match c1. Audit actual forward cycle gradient flags. Check finite nonzero upstream
or oracle and decoder gradients. At finish: reload best, exact coordinate/metric
replay at both noise seeds, unchanged inputs/adapters/frozen modules. Save raw and
adapted coordinates, targets/masks and metrics for independent CPU verification.
CPU tests verify all-frame label masks, rigid-motion invariance and derivatives.
Final CPU tolerances fixed before submission: independent NumPy reconstruction
maxabs <=1e-4 A, scalar losses atol1e-3/rtol2e-5, independent aligned RMSD <1e-5 A.
The validator runs after training in the same job with CUDA hidden; its short
CPU acceptance tail is included in the reserved job cost.

No negative tiny-set result alone establishes a structural impossibility; learning
rate, latent conditioning, optimization budget and noise remain alternative causes.
Successful oracle fitting establishes existence under relaxed conditioning, not
that a compact ID or sequence can learn those states. A c4 win is evidence for
this native recycle intervention, not proof recurrent depth is mathematically
necessary. No sequence-optimization/BindCraft gradient claim is tested here.

## Adaptive subsequent wave

Choose 4/32-protein matched comparisons only after first-wave QA; record a new
protocol before launching. Carry forward both winning treatment and its relevant
control. Do not select on held-out data. A direct frame+torsion head is a distinct
pending implementation requiring expressivity, geometry and derivative checks;
the current adapter must not be relabeled as a direct latent head. Deeper c1 and
32-protein c4 are conditional follow-ups, not an automatic grid. Keep original
32-protein joint gate (including >=29/32 atom<=2 A), formal held-out/confidence and
full ESMC-inclusive inference cost objectives intact.

## Dispatch repair before any oracle/c4 optimizer update

First oracle632530 failed exact initial replay; c4_632531 failed first backward
with checkpoint metadata mismatch, both before any optimizer update. Preserve
their v1 snapshots/logs. No optimizer/hyperparameter change and no rerun of the
three working arms. GPU diagnosis632537 measured exact native condition tensors
but different decoder RNG; native one-row sequence-only MSA sampling consumes RNG
even without evolutionary MSA. Oracle v2 reproduces only this cheap sampling call.
C4 v2 restores the RNG state after the first cycle before decoder sampling, so
extra dummy-MSA draws do not change decoder noise relative to c1.

Diagnosis632537 also obtained finite nonzero c4 upstream gradients with autocast
weight caching disabled. No-grad early cycles otherwise contaminate cached casts
used in the last grad-enabled cycle/checkpoint recomputation. C4 v2 disables only
autocast weight caching (same BF16 arithmetic and native final-cycle-only graph),
leaving accepted c1 code unchanged. Verify exact initial oracle replay, shared
decoder noise and c4 backward before submitting replacement training jobs.

Confirmatory632547 passes exact frozen/unfrozen oracle outputs and CPU/CUDA RNG,
exact initial c4 output/RNG, and finite nonzero c4 upstream gradients. C4 replacement
632549 starts normally. Oracle632548 then stops before optimizer update because
the preflight incorrectly required every native condition tensor to have nonzero
gradient at initialization. V3 records every condition's gradient norm throughout
training, requires a nonzero combined conditioning gradient and finite gradients,
and preserves the decoder's original parameter trainability (including fixed
Fourier features). V2's blanket requires_grad_(True) would have unfrozen those
features; it performed no update. Do not reinterpret zero initial condition
gradients as a failed capacity result. Preserve both stopped oracle attempts.
