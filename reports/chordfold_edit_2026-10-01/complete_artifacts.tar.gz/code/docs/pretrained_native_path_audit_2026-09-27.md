# Native coordinate-path audit

Result: HPC3 job654809 COMPLETED0:0 in58seconds. Both selected TRAIN lengths
128/256 passed both chemical-input views: all four comparisons were exactly
equal (maximum coordinate difference0), with c1/s1/no-confidence calls and
schedule[2560,0]. Weights remained unchanged. Archived report SHA256
`b73fee876f4e52a01e4e05274d3bb1600e9ca87b1ee05fd854fc96b1acfdad73`
matches the remote file. This is native-conditioning path compatibility, not
ESMC adapter quality. The two examples' native ESM2 embedding RMS values were
0.27564/0.26275 versus ESMC0.04371/0.04423; differing feature scales reinforce
the need for an explicitly fitted interface, not direct weight substitution.

Follow the completed checkpoint tensor audit with a functional check before
fitting an ESMC adapter. Final deployment remains ESMC-600M/c1/s1/K1. ESM2 is
only the native conditioning reference of the retained pretrained folding core.

Job654809 runs on HPC3/H100 with a10-minute bound and no optimizer updates.
Select two existing TRAIN targets before inference: closest length to128 and
longest (group-ID tie breaks), from the intersection of accepted teacher512 TRAIN
and scaling2048 TRAIN. No DEV or frozen-test coordinates are accessed.

For each target compare two execution paths with identical pretrained weights,
native ESM2 conditioning, seed12345, no dropout, no chunking, torch kernels and
inplace_safe=False. Repeat separately with native sequence chemical inputs and
the accepted prepared chemical inputs. Match native residue order1..L against
the prepared ESMC packet; verify accepted packet and source hashes.

The reference runs upstream `_main_inference_loop`, intercepted immediately
after `sample_diffusion` returns coordinates, before distogram/confidence work.
The comparison runs the existing frozen ESMCFoldCore forward with an explicit
oracle projection supplying W_ESM2 E_ESM2 in place of its input projection.
The oracle does not use ESMC semantics and is not an adapter or quality result.
This checks the current coordinate execution path under controlled native
conditioning, not every CLI/default setting or historical stochastic teacher run.

Require one trunk/one structure/zero confidence calls on each path, finite
coordinates, max absolute coordinate difference <=1e-4 A, unchanged weights,
and report exact equality separately. Record actual schedule, input/cache hashes,
embedding dtypes and RMS values, runtime/config and selection. Native and prepared
chemical-input views are individually replayed; this does not require their
predictions to be equal or establish native/prepared quality equivalence.

Source: `scripts/audit_pretrained_native_path.py`.
Remote: `/data/user/shuang886/Folding/esmc_pretrained_compatibility_v1_20260927`.
If the gate fails, preserve the report and locate the discrepancy before fitting
any adapter; do not relax the threshold in place.

## X570 resource and cache decision

User additionally authorized X570 for ESMC extraction. This is the current
`husrcf-X570` host: AMD Radeon AI PRO R9700,34208743424 VRAM bytes, observed0%
GPU use. Existing `/home/husrcf/anaconda3/envs/Fold` has torch2.9.1+ROCm7.2,
GPU available, but no `esm` package. No package installation or extraction run
has been performed.

The existing accepted final-layer ESMC-600M cache contains38400 sequences.
Fresh manifest coverage checks found zero missing sequences in both the2176
scaling targets and640 paired teacher targets, with sequence hash/length and
shard existence checks. This was metadata inspection, not a repeat tensor QA.
Therefore extraction would currently duplicate work. Reserve X570 for missing
sequence-only features if the next frozen target list requires them; retain the
same pinned model/code revisions, final layer, BOS/EOS removal, BF16 and residue
alignment. A different ROCm runtime needs a bounded cache-compatibility check
before newly extracted features can be accepted or mixed into a comparison.

Coverage artifact: `reports/esmc_pretrained_compatibility_2026-09-27/esmc_cache_coverage.json`.
