# Experimental-coordinate assessment of the fixed 64-group pilot

Status: five-condition baseline assessment and independent QA completed as
CPU-only steps 630851.0 (40 seconds) and 630851.1 (12 seconds), both 0:0, inside
the existing training allocation. All 64 raw GT rebuilds are exact and all
metrics independently recompute in FP64. Report/figure/archive:
reports/stage1b_experimental_validation_2026-09-18.* and its directory.
Selected response-model assessment is also complete, after accepted full-decoder
QA 631039. Local CPU append verifies unchanged GT members, all 64 identity
metrics and independent FP64 response metrics. Response all-atom/CA-distance
errors are 4.797496/3.107093 A; small improvements over c1 do not overturn the
failed original teacher-relative gate or match c2. No GT checkpoint selection.
The contract below was fixed before evaluation and its original source is
preserved in code_experimental_assessment_v1_20260918.

This is a parallel
CPU evaluation task supporting the original experimental-GT objective; it does
not change the running loss, epoch selection, models, data split or teacher
quality gates. No new training configuration is introduced.

Use exactly the 64 validation groups in the accepted c1/c4 pair-state cache.
Resolve each group through its original teacher-input shard metadata, checking
group/sample ID, sequence, sequence SHA256 and declared length. Read only these
selected GT members from the existing Stage-B shards; do not open temporal-test
manifests or evaluate temporal-test coordinates. Keep the GT source immutable.
The teacher-input metadata carries old HPC2 paths; rebase only their contained
shard basenames to the verified HPC3 Stage-B shard directory.

Create an isolated 64-group GT assessment cache retaining the original NPZ and
metadata member bytes and hashes. Verify single-chain sequence/aatype, one-based
label residue indices, chain indices, observed atom/residue masks, experimental
method/model, source mmCIF checksum and assembly/modified-residue provenance.
Preserve all missing-atom and missing-residue masks; do not impute coordinates
or select different PDB representatives. Do not change the frozen chemical
graphs or convert modified side chains into canonical experimental labels.

Predictions are matched strictly by one-based sequence residue ID and canonical
atom name. Reject duplicate/out-of-range/unknown prediction keys and nonfinite
coordinates; never fall back to row position. Require identical prediction
inventories for native c1/c2/c4 and every learner. Evaluate the common observed
canonical atoms under one fixed mask shared by all conditions. Report observed
GT coverage, common atom and CA counts, and missing observations explicitly.

Report independently rigid-aligned common-heavy-atom RMSD, independently
CA-aligned RMSD, and CA-pair distance RMSE. Pool squared errors using the actual
common atom/CA/pair counts, and also report protein-macro statistics and paired
per-protein differences/harms. These named-atom metrics are not symmetry-aware
side-chain matching or thermodynamic calibration. No lDDT/TM-score shortcut or
substitution for the declared metrics is introduced.

Compute native c1/c2/c4 and the accepted raw-state pointwise/triangle baselines
while training proceeds. Add the selected response-supervised checkpoint only
after its existing full-decoder independent QA passes. Never choose a checkpoint
or tune the ongoing pilot using these experimental-coordinate metrics. Verify
all GT/prediction/source hashes and independently recompute exported metrics.
Do not drop difficult or incomplete targets; a mapping failure must be reported
and resolved before aggregate quality claims.

This is an exploratory assessment of the existing held-out teacher-pilot groups,
drawn from the pre-cutoff source training pool. It is not the frozen temporal
test, the formal 1,600-group gate, or proof that pretrained ESM2/Protenix never
saw these structures. ESMC-600M adaptation and the eventual one-cycle/one-structure
evaluation model remain unfinished.
