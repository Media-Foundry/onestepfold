# Controlled observed-distance capacity experiment

Declared after accepted631737 negative capacity result and completed631888
explicit-distance derivative audit with independent CPU QA. The current network
can receive finite nonzero distance gradients, but no trained quality gain has yet
been shown. One controlled test adds direct observed-distance supervision.

Use the same32 TRAIN proteins, observed atom masks/identities, frozen ESMC600M,
fresh random initialization and one-trunk/one-structure/one-sample architecture as
631737. No folding weights, teacher states, new targets, ideal bond constants,
imputation or validation/test read. Confidence/distogram heads stay frozen.

The only training change is

`L = aligned_atom_MSE +0.1 global_frame_MSE +1 same_residue_frame_MSE +10 D`,

where D is exactly the audited equal-category mean MSE of observed N-CA, CA-C,
C-O and consecutive-residue C-N distances. Within each category use only its
observed pairs, exactly matching existing evaluation; empty categories are omitted
by the function, but all four must be present for every selected protein. C-N
observations are not certified bonds. No chirality/side-chain/angle claim for D.

Fix distance weight10 once before training. In accepted631888, unit D/B parameter
norm ratios at selectedepoch35 are0.171419/0.084900 for35/166 residues. Arithmetic
rescaling gives1.71419/0.84900; initial ratios become4.03610/4.27366 with positive
component cosines0.8646/0.9493. This is a round scale giving comparable trained
parameter norms, not an optimum, a sweep or proof of AdamW/quality improvement.
Actual audit B+D reconstruction rounding was0.008–0.55%; B+10D was not separately
backpropagated. Do not describe scaled moment estimates as a measured new update.

Bind accepted631737 reportSHA
eb1ee70815f0b6c009879a1db6ea0f6f07c6c4d27b6549ca6928c7b81f746cbb,
accepted631888 reportSHA
3428d1af5978de4b132ee8a01e0bc6cba4adbfa6a1bc8485f8aad36450a24587,
their independent QA, and unchanged shared source/config/input/frame provenance.
Require64 exact initial-coordinate matches to631737 before any optimizer update.
Initial model tensor SHA remainsbaad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea.

Same AdamW1e-4/wd1e-4, batch1, clip10, dropout0, BF16 trunk/FP32 structure,
TF32 bothFalse, group/epoch sampler seeds, Random(101+epoch) shuffle. At most
100epochs/3200updates; evaluate seeds12345/54321 every5epochs. Keep original
joint max-normalized-error checkpoint selection (earliest tie), futility20,
plateau20 from epoch30,75min soft/2h hard limits. No warmstart or extension.
Each seed must pass atom<=1 Å, CA-distance<=1 Å,29/32 atom<=2 Å,
NCA/CAC/CO each<=0.15 Å,CN<=0.3 Å and handedness>=95%; degenerate predictions
remain wrong. D logging cannot alter selection summary or thresholds.

Log all four loss components and total separately. Archive distance labels/counts/
hashes and recompute them independently from atom37 in final CPU QA. Require all
initial/selected128 predictions,64 exact selected reload replays, unchanged model
inputs/frozen heads, actual1trunk/1structure/0confidence, heavy checkpoints/features
and independent FP64 coordinate/geometry/four-scalar/selection/stopping/source QA.
Use scalar rtol1e-4,atol1e-3 Å² as in the audit; no relaxed geometry gates.

Run one HPC3 H100/8CPU/96G. Reuse cached inputs/ESMC and accepted baselines.
No concurrent coefficient grid. Passing a TRAIN capacity gate does not establish
held-out quality, calibrated confidence or ESMC-inclusive cost. Failure triggers
interpretation of the direct-constraint test, not another automatic coefficient
scan. Original end-state requirements stay open.
