# Geometry repair v1 — COMPLETE

Final update (2026-09-29): all99 repairs/coordinate audits/analyses completed,
controllers exit0.99zero severe collisions and99preservation passes;49absolute
geometry passes,50fail CAchirality. Both proposal arms:0/16confirmedutility and
0/16full acceptance after repair. Y38T's prior task benefit is lost relative to
the repaired parent.360files/99cases archive verification passed;9tests passed.
See [overall report](onestepfold_overall_report_2026-09-29.md) and
[final analysis](../reports/mini_geometry_repair_2026-09-29/final/outcome_analysis.json).
No related jobs remain. Earlier partial snapshots below are retained as history.

Earlier partial analysis: 6/99 complete, all6 with zero severe collisions and
preserved structure;3/6 pass absolute geometry,3/6 fail chirality. Across these
cases,7 new CA-centre flips and3 corrected flips. This is a completion-order
subset, not a rate estimate. An independent lightweight collector is attached:
when the original full report appears, it runs `summarize_repair_outcomes.py`
exactly once, writes `outcome_analysis.json/.md`, then stops. It never launches
repair/inference or alters parameters. Nine focused tests pass.

Earlier update: cases000/002 completed and independently audited. Both remove
all severe overlaps and meet displacement bounds; case000 passes absolute geometry,
but case002 flips H41/L163 and fails chirality (.988827<.99). Controller has advanced
to four parallel workers. Full99 results remain pending; no tuning/retry/expansion.
See [collision findings](mini_collision_localization_2026-09-29.md).

The following submission snapshot is retained as execution history.

The new locked protocol is [mini_geometry_repair_v1.md](mini_geometry_repair_v1.md).
The prior mutation batch remains closed. Code/protocol backup: `70499f76`.

DiamondHill root: `/media/PM982/onestepfold/geometry_repair_v1_20260929`.
OpenMM 8.6.1 and PDBFixer 1.12.0 installed under its isolated `deps/`; original
fold environment unchanged. Downloads were transferred locally after the remote
package connection failed. Four CPU workers, two OpenMM threads each; no folding
or GPU work. Eight focused tests passed.

Lock binds the 99 existing input structures, source files, force-field XMLs and
software versions. First case is already running; detached controller PID39918
waits for that case and then starts the remaining batch without duplicating it.
Each case has a 1800-second ceiling. Completed cases and failures are retained,
not rerun. The controller automatically executes independent coordinate scoring
and produces `exit.json`, `report.json`, per-case reports/coordinates/full PDBs.
The original input root is read-only to these scripts.

At this status snapshot, scientific outcomes are pending. A process returning
finite coordinates is not evidence of geometry acceptance or minimizer convergence.
The recorded `force_rms` is RMS vector magnitude per atom (not RMS per Cartesian
component); `force_tolerance_met` is a conservative diagnostic against10, not an
OpenMM termination code. Energy is never used to rank different sequences.

Reports separate absolute geometry, preservation, and paired task/utility/full
acceptance against the repaired parent. Both confirmation noises are required.
The old thresholds and old failed results remain unchanged. These are already
seen development examples, not independent validation or a differentiable oracle.
