# GT-free articulated Cartesian-output interface

Declared after accepted inverse fit632103 (pooled attained0.150398 A). This
interface test does not use fitted GT poses/angles or change a training protocol.

Prepare a per-input immutable specification from chemical reference coordinates,
fixed atom names/residue IDs/sequence, and the pinned CCD-induced graph variants.
Require N/CA/C in every chemical residue and full valid chemical references. No
observed mask, target coordinates or optimizer result enters this specification.
Batch residues sharing an inventory variant; preserve the original atom order.

Define residue pose from predicted CA translation and the proper frame whose first
axis is predicted CA->C, second axis is the perpendicular part of CA->N and third
is their cross product. Canonicalize the cached chemical reference in its own
N/CA/C frame. For every previously declared bridge choose proximal/distal probe
atoms using only its chemical reference: bonded neighbors first, then fixed atom
order; require nondegenerate reference projections. Extract predicted dihedral
phase as normalized cosine/sine; compare with the currently articulated reference
phase, rotate the entire distal component, and continue root-to-leaf. Finally
apply the predicted proper pose. No iterative fitting is performed at inference.

Use FP32 or FP64 geometry. For predicted axis/perpendicular vector norms below
1e-4 A, use explicit finite fallbacks: first frame axis is world x, second uses
the least-aligned world basis projected perpendicular to the first. Invalid
dihedrals retain the current reference angle (zero additional rotation). Count
all fallbacks. Guard divisions before torch.where so inactive branches cannot
produce NaN derivatives. Such discontinuous orientation fallbacks cannot be
rotation-equivariant at fully collapsed inputs; verify equivariance only away
from declared degeneracies and do not describe fallback gradients as learned
orientation recovery. All outputs still use proper rotations/preserved chemistry.

CPU acceptance: known admissible conformations reconstruct; output is idempotent;
nondegenerate proper-pose equivariance; branched/ring/handedness invariants;
finite-difference derivatives; finite fully collapsed/collinear outputs and
backward; original atom ordering and batched/single equivalence. Run additional
fixed-seed generated conformations for all32 accepted chemical inventories,
including residues lacking GT, checking both FP64 and runtime FP32 precision.
Reference extraction/canonicalization and tests must not depend on observed masks.

Then check the actual adapter on saved631937 initial/selected predictions using
unchanged observed metrics/masks. This is a deterministic postprocessing diagnosis,
not a trained improvement, model-selection change or permission to bypass the
capacity gate. Archive raw/input/artifact/source hashes, geometry and fallback
counts. Do not modify accepted saved predictions, labels or core source.

A later bounded HPC3 actual-core derivative/memory/replay protocol must be declared
before GPU work. Keep one trunk/one structure evaluation and eventually run the
confidence head on the final reconstructed coordinates. Adapter cost must be
included in total inference cost. No teacher states/pretrained folding weights,
additional loss grid, held-out reads or production-quality claim.
