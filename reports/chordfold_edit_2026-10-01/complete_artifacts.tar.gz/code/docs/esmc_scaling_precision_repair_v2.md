# 既有 scaling 结果的精度分离补验 — 2026-09-26

范围仅为已完成训练的 control_2048（原633798）和 control_128_cosine（原633800）。
它们在独立 CPU 验收的 saved CUDA FP32 vs NumPy FP64 坐标 maxabs<=1e-4
处失败。此次是事后产物验收修订，不改变模型、数据、指标、checkpoint选择或训练预算。
不把 endpoint 两臂通过补验当作这两个不同实验也已通过的证据。

采用 endpoint 已使用的两项独立义务：全部唯一已保存输出必须能从已保存raw坐标
通过原几何builder在CUDA FP32逐位重放；原Torch公式与独立NumPy公式在FP64下
必须在1e-8内一致。保持原数据/来源/权重/训练顺序/mask/损失/独立RMSD/lDDT/
geometry/TM固定实现检查。保留原跨精度1e-4门槛的结果、每个超差产物、最大误差
与指标敏感性，绝不称原门槛通过。任何新重放/公式/指标检查失败仍阻止补验通过。

补验开始前绑定原report、contract、history、training、best/last权重、数据验收、
原source manifest、新验收source manifest及本修订的hash。新import路径复制原源码，
全部原文件必须逐个hash相同；仅增加补验工具。旧训练目录只读；所有新验收报告写入
独立repair目录，不覆盖旧independent_validation.json或旧失败日志。

HPC3两个GPU几何重放作业可并行，每个最多30分钟，然后各一个独立CPU验收作业
（2CPU、64GB、90分钟上限）。只有参数无关的几何重建，不调用folding网络、ESMC或
教师，不更新参数，不重新推理、不生成新候选、不查看冻结测试、不新增科学配置。
当前teacher权重1.0训练与8192预定判断不变。这是补齐先前已授权scaling实验的验收。

补验通过后才将这两项称为precision-v2接受，并保留原门槛失败限定。完成八组scaling
汇总仍须区分匹配更新、墙钟预算、开发最佳、化学几何与同源性分层；补验通过不是
泛化科学结论通过。原raw_2048已获其自身独立QA，本次不重复它的GPU工作。

## CPU资源修订（提交前冻结）

查询确认debug分区MaxTime=30分钟；最初90分钟CPU请求未被接受，没有创建CPU作业。已有原始锁定654201及GPU重放654202继续原任务。CPU阶段现将control2048按group_id十六进制值mod2分成两份，cosine128单份，各2CPU/64GB/30分钟；聚合器必须证明原report中所有(group,prediction hash)无重叠、无遗漏地被验证，并与GPU检查数量一致后，才接受完整QA。单分片不能标为完整验收。数值门槛、原报告和GPU程序不变；新CPU源码/分片计划另行锁定于cpu_validation_v2。
