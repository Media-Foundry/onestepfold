# Frozen-decoder response-supervised pair emulator pilot v1

Status: complete, negative structural result. Training 630851 (49:11), decoding
630855_[0-3] (2:15–2:34) and corrected independent QA 631039 (2:11) completed
0:0. Selected epoch2 response ratios are 0.958219/0.948078, but full-sampler
all-atom/CA-distance ratios to c1 are 1.012301/1.007847; both structure gate and
c2 parity fail. Experimental-GT all-atom/CA-distance errors are 4.797496/3.107093 A,
modestly better than c1 but worse than c2 and the raw-state learner. No promotion.
Reports: reports/stage1b_response_supervision_2026-09-18.{md,png,json} and
reports/stage1b_experimental_validation_2026-09-18.{md,png,json}.

QA 630856 and diagnostic 631028 failed because the generic validator disabled
cuDNN TF32 in addition to matmul TF32, unlike the actual response training and
decoder. A same-pair policy toggle proves the discrepancy; restoring actual
matmul=False/cuDNN=True yields exact 64-response revalidation and all original
artifact/structure checks. No training, coordinates or tolerances were changed.
The contract below was fixed before export; preserve its original immutable
snapshot and this explicit correction to the actual backend-policy description.

The four training-only gradient controls support differentiability and memory
feasibility, including 951 residues at 14.410 GiB. They do not establish that
response supervision improves held-out structures. Test this one objective
change using the original pointwise architecture; do not expand architectures,
loss mixtures, noise schedules or hyperparameter grids.

## Inputs and derived response cache

Use exactly the accepted pair-state cache's 128 train / 64 validation groups,
parent states, atom identities and deterministic protocol. Preserve original
corpora, split assignment and temporal-test freeze. Create a separate response
cache containing the first actual c1 decoder-call packet and two responses:
native c1 pair, and c4 pair with c1 input/single states. Both responses must use
the identical actual noisy coordinates and noise level (2560 in the accepted
runtime). These are target-aware teacher labels, not experimental coordinates.

Cache targets under no-grad with seeds 101/12345, MC off, two-step sampler,
the pinned Mini-ESM checkpoint, torch kernels and sampling autocast disabled.
For every group, verify c1 full-sampler coordinates atom-exact against accepted
native c1 and verify c1/c4 state, prepared-feature, sampler-RNG and source hashes.
Require independent cache artifact/atom/split checks plus first-response direct
replay for the longest train and validation targets before training. Store
actual sampler configuration, decoder NFE, packet/response and parent hashes.

The learner consumes c1 singles and pair states only. No noisy coordinates,
c4 states, response targets, group identity or label-derived feature may enter
the pair predictor. No c4 state is needed at deployment. Saved packets supply
fixed decoder conditioning during training/evaluation, not learner inputs.

## Model, loss and optimization

Use the original 187,344-parameter pointwise PairStateEmulator, initialized
fresh with seed 101 and exactly matching the accepted baseline's initial
weights. Keep its zero output initialization, c1 features, all dimensions,
directionality and full row/column contexts. No triangle branch or warm start.

For every protein, predict all ordered pair entries, cast the corrected pair
to BF16 as at deployment, then rebuild pair_z and p_lm with gradients connected
to the learner. Keep teacher parameters frozen and inplace_safe=False, actual
sampling autocast disabled, blocks_per_ckpt=1 and fine-grained checkpointing.
Call the first denoiser directly at its saved noise/conditioning. Optimize only
mean squared denoised-coordinate error to the c1-single/c4-pair target, with
FP64 reduction. No raw-state or geometry auxiliary loss. BF16 conversion uses
PyTorch's cast backward; continuous-state audit success does not establish a
smooth quantized objective. Record actual rounded corrections and gradients.

Use AdamW learning rate 0.0003, weight decay 0.0001, gradient clipping 10,
twenty epochs, BF16 learner autocast and seeded (101) shuffled protein order.
Each epoch visits all 128 proteins once, one optimizer step per protein,
balancing proteins by their coordinate mean. Unlike raw-state training's
4,096 sampled pairs, this objective necessarily evaluates the full pair state.
Document that compute/workload difference rather than calling budgets matched.
Chunk/checkpoint learner computation only for execution memory; preserve full
gradients through endpoint and row/column context and verify equivalence.

Before optimization, verify exact identity initialization, full-pair chunk
forward/backward equivalence, finite learner gradients and no teacher gradients.
Use the longest training target for a complete forward/backward/optimizer smoke
on a disposable model, then restore the fresh seeded initialization for training.
Record peak memory for the combined learner/decoder; the prior 14.410 GiB audit
did not include learner activations. If execution fails, version the repair
and rerun equivalence checks without changing data, model or objective.

## Selection, decoded evaluation and limits

Validate all 64 fixed first-response packets every epoch using BF16 predicted
states. Select minimum mean per-protein response MSE; epoch-zero identity is
eligible and ties retain the earlier checkpoint. Report both macro and
atom-coordinate-pooled response errors relative to own-c1 baselines. Preserve
train/validation curves, pre-clipping norms, clipping rate, rounded-correction
statistics, selected/last checkpoints and source/optimizer/contract hashes.

After selection, decode all 64 validation proteins through the unchanged native
two-step sampler with c1 singles and learned pairs; record actual NFE and exact
c1 replays. Independently reconstruct all predicted pairs, checkpoint response
validation and all-atom/CA/CA-distance metrics versus native c4. Compare against
c1, c2 and the accepted pointwise raw-state-MSE model, with per-protein harms
and length strata. Do not select epochs by this post-selection decoder result.

Retain both pooled all-atom and CA-distance <=0.95 of c1 as the exploratory
structure gate. A useful cycle-saving result additionally requires c2 parity
on both metrics and measured lower end-to-end inference cost. Response-loss
improvement alone is not success; fixed first-noise response supervision may
fail to improve the complete sampler. A 64-group pilot cannot replace the
formal 1,600-group gate. No automatic full-data promotion follows.

This is still Mini-ESM/ESM2 teacher-side compatibility research. The primary
frozen ESMC-600M, MSA-free all-heavy-atom objective, experimental-GT evaluation
and eventual one-cycle/one-structure-evaluation model remain unfinished.
