# Actual-core articulated-output derivative audit

Prerequisite: completed GT-free CPU interface report and generated32-inventory
checks, including finite degeneracy handling. Deterministic postprocessing of
the old selected checkpoint worsens atom4.18->4.66 A and CN1.14->1.94 A despite
correct local geometry/handedness. Do not promote postprocessing as learned gain.

One bounded HPC3 H100 job,8CPU/96GB/20min cap, no optimizer updates. Construct the
unchanged fresh ESMCFoldCore(seed101,deterministic_capacity=True); verify initial
state hash baad41b4 and unchanged accepted model/runtime/loss sources. No pretrained
folding checkpoint loads. Freeze confidence/distogram heads as before.

Use accepted35-residue original capacity input and951-residue interface input,
TRAIN only, fixed sampler12345. Verify original inputs/features/GT mapping and
full valid reference masks. Prepare the parameter-free adapter only from chemical
references, inventory/sequence and pinned CCD graph variants. Execute one trunk,
one structure evaluation, then FP32 articulated output. Confidence stays disabled
for this gradient audit; eventual confidence must consume final adapted coordinates.

Differentiate the unchanged631937 scalar atom+.1globalframe+same-residue+10distance
with observed targets/masks. Save raw/adapted coordinate gradients; check projected
coordinate gradients zero outside observations, finite nonzero raw gradients and
finite parameter gradients including ESMC and final atom projection. Raw gradients
may reach unobserved predicted atoms used in pose/angle extraction: this is valid
model dependency, not using missing GT as labels. Record that count explicitly.

Require exact train/eval replay, exact accepted35 raw-initial replay, unchanged
model weights and features, actual forward counts, no nonfinite outputs/fallbacks,
and longest peak memory. Record adapter timing separately and include it in audited
core-plus-adapter forward time; these two cases are not an end-to-end ESMC benchmark.
Save chemical references/inventory/GT/supervision/raw/adapted coordinates and both
coordinate gradients. Independent CPU QA must reconstruct raw->adapted output,
check observed labels and four scalars, FP64 raw-input derivative versus saved
GPU derivative and central directional differences, identity/masks/source hashes.
No training launch follows until this final QA passes and one controlled protocol
is declared. No extra loss-weight or architecture grid.
