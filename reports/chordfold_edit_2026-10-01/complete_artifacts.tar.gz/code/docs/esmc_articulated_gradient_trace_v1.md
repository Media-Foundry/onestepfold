# Gradient transmission and root-cause diagnosis after 632192

Read-only investigation requested by the user. No training, checkpoint selection,
loss weights, observed labels, atom identities or inference inputs change.

CPU: use all 32 TRAIN proteins, initial and selected100 coordinates, both saved
evaluation seeds (128 cases). Independently reconstruct four FP64 weighted losses:
A + 0.1F + R + 10D. Verify labels/source/artifact hashes and scalar agreement.
Record four gradients at adapted output and raw input, their Gram matrices,
negative-total directional derivatives, masks, and exact chain-rule decomposition
into translation, frame orientation and internal shape. Decomposition uses
detached factors of y = local @ frame.T + origin; its three VJPs must sum to the
original VJP. It is a computational decomposition, not an energy attribution.

Measure raw frame/probe vector scales and structural input coverage. Re-evaluate
the adapter Jacobian at its own projected coordinates (same physical output,
different raw representation) to expose sensitivity to the redundant Cartesian
parameterization. This is a diagnostic counterfactual, not an inference change.
Require branch additivity relative error <=1e-8, no nonfinite gradients, projected
output masked-gradient zeros, independent NumPy forward agreement <=1e-8 A,
idempotent counterfactual output agreement <=1e-5 A. Central finite differences
of the independent NumPy projection/loss on shortest35 and longest166, initial
and selected, seed12345, at steps1e-5/1e-6 along normalized total raw gradient:
relative error <=1e-4 with denominator max(abs(analytic),1e-8).

GPU: one bounded HPC3 H100 audit, selected100 only, shortest35 and longest166,
seed12345. Load own accepted checkpoint, exact saved raw/adapted replay, one
trunk/structure call, confidence disabled, unchanged features/weights. Backprop
each actual weighted loss and combined loss separately through the actual model;
record component Gram matrices by module and ESMC/final-head norms. Compare
FP32 coordinate gradients to independent FP64 CPU results (relative <=1e-3),
parameter combined-vs-sum relative <=0.02 for BF16 accumulation. No optimizer
step. Report clipping scale and first-order derivatives along negative combined
parameter gradient; these are not predictions of AdamW's history-dependent step.
No full-length memory rerun or extra training. CPU/GPU tasks may overlap because
they answer distinct required parts using fixed artifacts.

Separate confirmed implementation facts and measured mechanisms from hypotheses
about long-run convergence. Do not call a scalar imbalance proof of gradient
conflict, a coordinate direction an optimizer update, or GT inverse fitting
learned inference. Produce a Chinese report, plots and reproducible artifacts;
retain original full folding/held-out/confidence/end-to-end-cost objective.
