# ESMC 一步终点蒸馏 pilot v1 — 2026-09-22

用户授权尝试文献建议，并要求本轮及后续实验全部在 HPC3。固定部署 c1/s1/K1；本轮没有尾部权重、架构/采样器搜索、冻结测试访问或多候选选择。

## 数据与初始化

复用已验收 scaling-v1 的前512 TRAIN 和固定128开发验证（32..256 residues），选择清单/GT/ESMC/化学图不变。验证为已用于开发的集合，近同源未去重，不宣称新折叠泛化。两个学生均从已通过独立QA的 control_512/best.pt 开始，重置相同 AdamW；旧run数据与checkpoint不修改。这是有基础训练的一步模型的继续训练实验，不是从头初始化比较。

CPU锁定作业先核对源代码、父数据验收、父checkpoint和report哈希，再写不可变 lock.json。所有GPU预检和测试也在HPC3；本地仅编辑和归档。

## 固定教师与缓存

Protenix-Mini ESM2-3B，c4_s2/K1，teacher seed103，确定性内核，原MC配置0.4/0.4（该seed分支关闭）。无MSA/templates，BF16，torch内核，matmulTF32关闭；gamma0=0/eta=1/lambda=1.003。捕获实际噪声序列、循环/denoiser调用计数、软件和权重哈希。固定seed101生成序列特征。8个独立GPU分片，每组先完成无钩子/有钩子的完全相同坐标重放检查。

512训练目标生成最终教师坐标，另128验证目标生成c4_s2与未训练c1_s1参照，合计768正式预测。教师输入仅sequence；学生ESMC特征不会由教师状态替换。教师坐标严格按(residue_id, atom_name)映射到完整学生canonical inventory，有限值及覆盖必须100%。GT先保持原缺失掩码，教师伪标签另存，绝不伪装为实验观测。固定一个教师构象，不平均xyz、不按GT挑seed、不按置信度挑候选。教师与学生噪声不是同轨迹，故本轮是终点伪标签蒸馏，不称consistency训练。

## 两个匹配条件

- gt_only：原 A+0.1F+R+10D。
- endpoint：相同目标，加0.1 × 对完整canonical atom集合的proper-SE(3)-aligned teacher终点MSE。

全folding trunk、ESMC投影、decoder可训练；ESMC缓存及confidence/distogram冻结。几何重建器不变。每蛋白损失先归一；teacher权重固定，不筛掉困难训练目标。原子名称固定匹配，未实施侧链对称重命名，作为限制报告。

双方相同父checkpoint、顺序、学生训练噪声和lr=1e-4、AdamW wd1e-4、clip10、batch1。各8192更新（512目标约16次新增曝光）或4小时优化+周期评估墙钟上限，先到者止；Slurm7h容纳初始化、最终评分与QA。每1024更新评估，相同2048更新点和1/2/4h点留checkpoint。此预算是有界继续训练pilot，未通过不能宣称容量不足或已收敛。

梯度预检验证teacher项可回到前端与decoder，实际forward计数为trunk1/structure1/confidence0；验证labels和teacher缓存从不进入backward。数据loader拒绝任何验证group作为teacher训练目标。保存初始/最终/最佳checkpoint预测及重放证据。

## 评分及验收

主比较为匹配更新预算的endpoint−gt_only；开发集最佳checkpoint结果辅助报告，不混为相同预算。继承固定对应TM-align、跨残基全原子lDDT、RMSD、化学几何及两个独立评估噪声12345/54321；它们不是独立训练seeds，更不是best-of-K。教师参照使用相同指标。

按目标聚合两个噪声后做5000次配对bootstrap（seed20260922），同时报告均值、P05、最差5%均值和ΔQ<−0.05比例、化学几何变化。分别比较原始一步参照、两个学生初始/最后/开发最佳和c4_s2教师。所有128目标进入分母，失败不得静默过滤。正式进展需平均质量与尾部同时改善，不能仅凭teacher loss下降。结果仅探索性；边界区间跨零标为未确认。

warm core计时与训练GPU-hours单列；本轮使用预计算ESMC，不声称已完成包含ESMC的端到端速度验收。GPU输出重放与独立CPU指标/损失重算后才接受产物。所有验证和汇总作业通过Slurm依赖提交，不自动扩展到尾部权重实验。
