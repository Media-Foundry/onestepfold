# Controlled geometry-weight correction, coefficient0.1

Predeclared after accepted gradient audit631551 and before training. This is ONE
controlled follow-up to the failed coefficient0.001 geometry/noise experiment631506,
not a parameter grid, epoch extension or reuse of its trained weights.

## Evidence and hypothesis

The accepted four-case audit at best25/last40, lengths35/166, measures weighted
frame/atom parameter-gradient ratios0.01747/0.002119/0.005741/0.006425 with the
old coefficient0.001. The simultaneous coordinate ratios are0.1263/0.0542/
0.1445/0.1335; the earlier coordinate-only scale choice understated attenuation
through the network. Actual combined-vs-component gradient discrepancies are
0.49%–0.69% globally, concentrated in BF16 trunk modules. One of four cases has
opposing global component directions; this is not universal conflict or proof
about the AdamW update direction.

Choose fixed coefficient0.1 as one fixed100-fold coefficient correction toward
comparable parameter gradients: simple rescaling at the existing measured states
gives ratios0.212–1.747, median0.608. This estimate does not prove the new random
model's gradients, an optimal coefficient, valid chemistry or a quality gain.
Test the hypothesis rather than treating it as established.

## Exactly one experimental change

Use the full frozen design in `docs/esmc_geometry_capacity_v1.md`, changing only
the frame coefficient from0.001 to0.1:

`L = observed_aligned_mse + 0.1 * local_frame_mse`.

Preserve the exact32 TRAIN groups, accepted cached ESMC/chemical inventories/
experimental labels and masks, same random initialization tensor hash
baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea, native one-cycle/
one-structure/one-sample path, dropout-disabled capacity configuration, both
TF32 flags False and existing BF16/FP32 boundaries. Confidence/distogram frozen.
No teacher inputs, symmetry remapping, new target, imputation or held-out reads.

The per-group/epoch sampler seeds, protein shuffle, fixed evaluation seeds12345/
54321, AdamW lr1e-4/wd1e-4/default betas/eps, gradient clip10 and batch1 remain
identical. Match all64 initial predictions exactly to631506 before optimization.
Require accepted631506 final QA and631551 gradient QA, source/input/checkpoint
lineage and label checks before starting. No warm-start or optimizer continuation.

## Unchanged budget, selection and gates

Maximum100epochs/3,200updates, one HPC3 H100/8CPU/96G,75min soft optimization/
evaluation budget,2h scheduler cap. Initial and every5epoch dual-seed evaluations.
Same joint maximum-normalized-error score, earlier checkpoint retained on ties,
same futility20 and20epoch/1% plateau-from30 stopping rules. Actual stopping epoch
can differ from631506's40 under the unchanged rule; report that explicitly.

For each evaluation seed, retain every original criterion: pooled atom RMSD<=1 A,
pooled CA-distance RMSE<=1 A, at least29/32 atom RMSD<=2 A, N–CA/CA–C/C–O
distance RMSE each<=0.15 A, consecutive observed C–N RMSE<=0.30 A, and>=95%
GT-relative CA handedness agreement with degenerate predictions counted wrong.
Consecutive observed C–N is a distance comparison, not a certified chemical bond;
the gate remains incomplete stereochemical validation and small-set capacity only.

## Acceptance and interpretation

Use the same independent CPU heavy-artifact/source/GT/FP64/local-geometry/selection/
stopping QA and exact selected-checkpoint reload/replay requirements. Archive
initial/selected predictions for both seeds, per-epoch loss components and gradient
norms, histories, immutable actual source and all hashes; keep heavy checkpoints
and input packets on HPC3. Compare final selected conditions and full curves with
the accepted0.001 run without changing either selection rule after seeing results.

Do not automatically scan nearby coefficients, extend epochs or scale data.
Interpret the accepted result first. Confidence calibration, formal held-out
quality, and full ESMC-inclusive inference cost remain required unfinished goals.
