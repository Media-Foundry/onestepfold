# TRAIN2048 → TRAIN8192: data expansion

Update01:43 HKT: matched pretrained ESMC runs are now RUNNING on the same HPC3
H100 node, four GPUs each: TRAIN2048 job654978 and TRAIN8192 job654980. Both initial320-coordinate
replay gates passed;32 real optimizer updates were observed by01:45. Same4096-update,
16384-sample budget; this means8 versus2 exposures per protein, not convergence.
DiamondHill lost connectivity before training, so the fixed initial reference
was re-exported and independently scored onH100. See
[training protocol](esmc_pretrained_gt_v1.md).

Update01:07 HKT: all64 preparation workers completed successfully. Combined
acceptance654890 COMPLETED0:0 in8m14s and verified all8320 packet files.
Acceptance SHA256 `e221458f2a539700f8c2a0bae1b031508b915c4ffe281e791bdf8d12def2ba45`
matches the local archive. Sequence-only homology audit654923 completed in1m38s;
DEV targets with identity≥0.8 to TRAIN at shorter-sequence coverage≥0.8 increased
from47/128 to79/128. No targets are below0.3 in either view. All original2048 audit
entries reproduce exactly. Dataset readiness does not establish generalization
or mean that8192-protein model training has started.

00:33 HKT status: selection frozen and remote/local hashes verified. The eligible
pool under the original training-quality policy is13537 groups, of which8192
were selected. Existing TRAIN2048 and DEV128 rows are unchanged. HQ-evaluation
flag counts are1258/2048 previously and4982/8192 after expansion; this flag is
reported separately from training eligibility. All8320 selected sequences have
ESMC cache entries; no X570 extraction is currently necessary.

Preparation job654833 is RUNNING with four CPU workers, each handling96 of the
6144 new proteins (workers0–3 of64). After successful initial packet checks (~36 packets per worker by69seconds),
additional jobs654834/654835/654836 were submitted for workers4–15.
The remaining48 worker shards await scheduler slots. No8192-protein
model training has started. Report and selection are archived under
`reports/esmc_expansion_2026-09-27/`.

The user explicitly requested a larger training set on2026-09-27. Expand the
number of distinct exact-sequence groups while retaining the ESMC-600M, no-MSA, c1/s1/K1
deployment objective and the pretrained-core interface work. The small interface
diagnostic is a prerequisite, not the final training scale. Existing warm-start
runs finish under their original protocol.

## Frozen selection

-8192 unique exact-sequence groups, nested around the unchanged2048 training rows.
-Same32–256 residue interval; no new crop or longer-chain policy in this comparison.
-Keep the exact128 development rows and reserve all1600 original development
  groups, including those outside the128 view, from expanded training.
-Use only the existing valid pre-cutoff TRAIN manifest, canonical sequences and
  representatives released by2021-09-30. Do not read frozen test manifests or
  coordinates. The global sequence catalog is read to recover sequence strings.
-Select new groups by a fixed SHA256 rank with namespace
  `esmc-expansion-v1:train:101`. Never select by model errors or cache presence.
-Keep original teacher representatives where available; otherwise choose the
  lowest-resolution-value eligible TRAIN representative, then deterministic
  sample/shard/name tie breaks. Record the resulting quality and length mix.

The first selector incorrectly required `hq_eval_valid` for every TRAIN row and
stopped before writing a selection:790 of the existing2048 do not meet that
stricter evaluation-only gate. Source `quality_policy.py` separates valid training
data from the HQ subset; the original scaling selector did not require HQ status.
The corrected selector preserves that training policy. This does not diagnose
label noise or explain the current model's low scores; missing-atom masks and
raw-mmCIF reconstruction checks remain required. Preserve the failed selector
as `select_esmc_expansion.py` on HPC3; corrected execution uses `_v2.py`.

8192 refers to unique training proteins, not8192 optimizer updates. Current
raw-warmstart's8192 label still means additional updates on2048 proteins.

## Preparation and acceptance

Reuse2176 accepted packets (2048 TRAIN+128 DEV) through immutable links and
verify their acceptance hashes. Prepare only6144 new TRAIN packets in a separate
root, using the existing raw-mmCIF rebuild, mask, ESMC alignment, chemical-graph,
projection and gradient checks. No synthetic geometry labels or graph expansion.
The only preparation-code extension is an explicit metadata input-root argument;
the existing path remains its default. Stage that change in a separate source
snapshot, without modifying any running experiment's frozen source.

First run four independent CPU work shards to verify preparation correctness and
cost. Use bounded CPU jobs and extend concurrency within scheduler limits after
observing actual runtime; do not consume GPU slots for packet preparation.
No training can read this root until a combined acceptance report verifies all
8320 selected packets, source hashes and selection identity. Do not call frozen
selection or partial preparation a completed8192-protein training run.

## Training and resources

Complete native-coordinate replay and ESMC interface adaptation before launching
the larger model run. Use one retained folding-core/ESMC recipe; do not open a
loss/noise/geometry method grid at the same time. Freeze the actual update budget,
schedule and hardware comparison after runtime and memory preflight. Compare
2048 and8192 with the same starting checkpoint and fixed DEV view; report updates,
samples/residues seen, exposure distribution and GPU hours, plus training curves
and final full-training quality. A smaller number of exposures at larger N must
not be called converged fitting. Audit train–dev homology against the expanded
set; greater overlap cannot be reported as novel-fold generalization.

DiamondHill's8GCD are available for the new model work, subject to per-job memory
and execution checks. HPC3 finishes current H100 comparisons and supports data
preparation/independent QA. X570/R9700 is additionally authorized for missing ESMC
features. Coverage is checked on the newly frozen8192 list; extract only genuinely
missing sequences with the pinned cache contract. Current640-pair and2176-scaling
views already have complete coverage. Do not equate8GCD with eightfold speedup.

Selection code: `scripts/select_esmc_expansion.py`.
Remote data root: `/data/user/shuang886/Folding/esmc_expansion_data_v1_20260927`.
No claim that ESMC always exceeds ESM2 on folding follows from representation
benchmarks; ESMC is the chosen final conditioner, and native ESM2 is the diagnostic
reference needed to measure successful transfer of the pretrained folding prior.
