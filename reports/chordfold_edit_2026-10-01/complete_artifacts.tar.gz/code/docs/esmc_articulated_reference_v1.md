# Fixed-graph articulated-reference feasibility

Declared after accepted negative capacity run631937 and accepted rigid-reference
floor diagnostic631937.0. This is a representation prerequisite, not a new model
training protocol. Keep the same32 TRAIN examples, observed atom names and masks.
No held-out reads, atom permutations, label imputation or reference-as-GT losses.

First pin the installed Protenix CCD connectivity. Stream its configured
`common/components.cif`, hash the full source and save only the20 standard amino
acid blocks verbatim. Record installed `ccd.py` and `configs_data.py` hashes.
Parse that subset with Biotite's component reader, retaining heavy leaving atoms
until matching each saved inventory. Require every inventory atom and element to
match and the induced heavy-atom graph to be connected. No radius-based bond
inference or use of the model's polymer bond_mask as full chemical connectivity.

Candidate internal degrees of freedom are single-bond graph bridges, oriented
away from CA. Exclude N-CA (part of the pose anchors); require at least one atom
beyond the distal axis endpoint. Rotate the complete distal component by a proper
Rodrigues rotation, ordered from root to leaves. Ring bonds cannot be bridges and
remain uncut. CA-C can rotate O/OXT. Branched distal groups rotate together; fixed
names are never swapped. Independent proper residue poses remain allowed, so
inter-residue peptide connectivity is not structurally guaranteed by this test.

Before inverse fitting, verify zero-angle identity, bond-length/bond-angle and
ring-distance preservation, proper-pose equivariance, finite analytic derivatives
against finite differences, and handedness against the original cached references
and eligible observed GT. Include branched and cyclic synthetic test graphs.
Use saved, hash-verified reference-shape artifacts; every observed reference must
be valid. Geometry checks include the full chemical reference inventory; target
metrics use observed labels only. Fail on unsupported or disconnected inventories.

Subsequent bounded GT inverse fitting needs its own declared solver/budget before
execution. A numerically attained error is an upper bound on the best possible
fit, not a global lower bound. Even a successful fit is neither trained folding
quality nor evidence of learned angles, confidence, chain connectivity or speed.
No GPU training, extra loss-weight grid or model replacement follows automatically.
