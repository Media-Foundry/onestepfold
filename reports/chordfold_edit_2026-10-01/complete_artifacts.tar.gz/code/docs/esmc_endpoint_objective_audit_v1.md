# Endpoint objective audit — 2026-09-26

目的：解释已完成 endpoint-v1 的有限预算负结果，决定是否值得改变教师监督强度。
保留 ESMC-600M、固定化学图、c1/s1/K1；仅诊断，不训练新配置、不使用冻结测试。

原两臂各完成 8192 次新增更新（16 次曝光）。精度分离 QA 643804/643805 和
汇总 643806 均 COMPLETE；原跨精度 1e-4 验收失败仍保留。
最终 endpoint−GT lDDT −0.000565，95% CI [−0.003817,+0.002772]；
TM +0.003870 [−0.003024,+0.010661]。未确认平均质量与尾部同时改善。

## 冻结诊断边界

从原合同的 32 个 TRAIN probe 按 (sequence length, group_id) 排序，取索引
2,6,10,14,18,22,26,30，覆盖八个长度层。选择只依赖原合同，不依赖坏样本或梯度。
三个固定 checkpoint：相同初始父权重、GT-only best、endpoint best；两个 best
均为最后第 8192 更新。每目标分别噪声 12345/54321，总计 48 次带梯度前向。
HPC3 三个 GPU worker 并行，每个上限 30 分钟；不更新任何参数，不写新权重。

分离原 GT 总目标 A+0.1F+R+10D 与已有 0.1×终点对齐 MSE，记录二者对全部
可训练参数、各参数模块、raw xyz、articulated xyz 的范数、内积、夹角、
weighted-teacher/GT 范数比，以及沿负合成梯度的局部方向导数。
这些是欧氏空间、裁剪前梯度，不等于 AdamW 更新，不足以证明泛化根因。
不把 0.1 系数当作实际梯度占比，不凭 loss 标量大小下结论。

必须绑定旧数据/teacher/cache/checkpoint/QA/source 哈希；两个最终 checkpoint
逐目标按原噪声 bit-exact 重放已验收 TRAIN probe 预测。实际前向必须一次 trunk、
一次 structure、零 confidence。诊断前后权重完全相同；所有梯度有限。
初始权重没有保存 TRAIN probe 坐标，故不宣称该检查点做过产物逐位重放。
数值统计 focused tests 也只在 HPC3 运行。

随后只重分析已有 train/validation 曲线、paired 尾部和 teacher 参照，生成独立
补充报告；不覆盖原 comparison.json。若梯度并不弱，不盲目提高教师权重；
若发现冲突，区分 raw/几何输出与前端模块，先定位再决定训练。
整个诊断是探索性的，不能把单 seed 小 probe 结果包装为新方法成功。
