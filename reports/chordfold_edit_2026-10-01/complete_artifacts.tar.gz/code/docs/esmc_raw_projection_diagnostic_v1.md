# 保存raw输出的几何投影诊断 v1

2026-09-26锁定；动机为匹配预算raw2048的质量优势及endpoint权重1.0未通过联合门槛。
目的：分离raw输出含有的折叠信息与现有局部几何构建器造成的质量变化，不作泛化确认。

唯一输入为已验收esmc_scaling_raw_2048_v1_20260919的best_train_probe：原先固定32个
TRAIN目标、noise12345/54321全部64个输出，不能按本轮分数或坏样本筛选。该best checkpoint
历史上由开发集选择，此诊断不能称为独立于开发选择的实验。只读取TRAIN坐标，不访问新dev/test。

原ArticulatedOutput、reference、variants及其FP32 buffer不变，执行CPU FP32投影。
不优化坐标，不训练，不调用ESMC/trunk/structure网络，不生成多候选；仅使用固定化学图。
先完成投影，GT仅用于评分。不得据此宣称额外结构网络调用或多步采样是必要的。

绑定原report/contract/QA、source manifest及依赖、prepared文件、64个输入预测hash。
所有原raw指标重算必须与旧report一致。新投影逐位重放；native Torch FP64与独立NumPy
FP64公式差<=1e-8，计数相等。CPU32与独立64误差如实报告，不要求原跨精度1e-4门槛。
投影后lDDT用独立dense实现复核；两精度质量敏感性另报。CA最大位移和TM变化直接测量，
不以CA应保持的代码推理替代结果。新NPZ及逐目标结果只写入新根目录。

报告32目标的两噪声均值分布、mean、p05、worst5%mean（ceil(32*.05)=2）、lDDT/TM
下降>0.05计数；局部N–CA/CA–C/C–O及consecutive C–N MAE、可评估CA手性一致率。
同时报告位移、fallback和单次CPU投影时间；此时间不是GPU部署或端到端折叠计时。
不作p值、bootstrap或独立训练seed结论，不调新参数。完整化学接受仍需额外侧链/角度/clash检查。

运行前既有构建器测试和新汇总测试必须通过。最多单个HPC3 CPU作业30分钟、2核16GB；
若未完成保留部分产物，查明实际原因后再决定如何续接，不自动重复整个实验。
判断只用于下一研究决策：质量保留且局部几何改善可支持继续研究此组合；C–N未改善则明确
不能把“投影修复化学”当结论。无论结果如何，原c1/s1/K1整体目标保持未完成。
