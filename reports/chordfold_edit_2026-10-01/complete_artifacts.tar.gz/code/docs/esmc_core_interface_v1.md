# ESMC all-atom core implementation gate v1

Status: complete. HPC3 631114 completed 0:0 in 2:06; independent CPU artifact,
cache and observed-label auditing passes. The fresh 134,584,255-parameter core
has actual one-cycle/one-structure-call/confidence outputs, exact replay/reload
and finite gradients on 35/951-residue training inputs. Longest backward peak
is 47.155 GiB. Reports/archive: reports/esmc_core_interface_2026-09-18.md and its
directory. No trained-quality claim follows. The predeclared protocol below is
also preserved in immutable code_esmc_core_interface_v1_20260918.
This is a bounded implementation gate toward the original predictor, not a
quality experiment or a replacement for its eventual training/evaluation.

The pointwise raw-state, triangle and first-response-supervised teacher pilots
do not pass their declared structural gates. Their experimental-GT comparisons
remain useful but do not justify another teacher-only architecture/loss grid.
Preserve those results. Advance the missing ESMC-conditioned folding path next.

Use the installed Protenix 1.1.0 Mini topology as an explicit implementation
baseline: 16 Pairformer blocks per cycle, eight diffusion-transformer blocks,
one atom-encoder and one atom-decoder block. Construct fresh random core weights
with seed 101, using a 1152-to-449 ESMC projection and the existing 384/128
single/pair widths. Do not load a released folding checkpoint or inject saved
teacher c1/c2/c4 states. Pin the exact resolved configuration and installed
source hashes. The topology is a starting implementation choice, not a claim
that its capacity or efficiency is sufficient.

Reuse the accepted frozen ESMC-600M final cache and verified canonical-monomer
adapter. Disable ESM2 preprocessing and external MSA/template retrieval. Retain
sequence-derived atom identities/reference chemistry, exact residue mapping
and existing GT masks; reference conformers are not experimental target atoms.
This introduces no graph, substitution, split or cache change.

The disposable check uses the same shortest/longest training sequences already
verified at the ESMC boundary (35/951 residues). First validate construction and
the shortest example; only then check longest-input memory. Any GT input must
come from those training groups' original Stage-B members with the same strict
sequence/atom/observed-mask checks as the accepted GT assessment. No validation
checkpoint tuning or temporal-test access.

Required evidence before any performance-training run:

1. No folding checkpoint load, no ESM2 extraction, and pinned ESMC features
   remain detached; record fresh core state hash and parameter counts.
2. Exact sequence-to-token-to-heavy-atom mapping and experimentally observed
   loss masks. Never substitute generated reference positions for missing GT.
3. Instrument actual one Pairformer-stack call, one structure-network evaluation
   and one output sample; configuration values alone are insufficient evidence.
4. Finite heavy-atom coordinates and confidence outputs, deterministic replay,
   and separately measured core/confidence time and peak allocated memory.
5. Verify a differentiable path to the structure output and ESMC projection.
   Zero initialization can hide conditioning at the initial forward: distinguish
   the initialized model from a disposable nonzero-projection/updated probe.
   Report which parameters receive gradients; do not claim a random core uses
   ESMC based solely on its input tensor shape.
6. Preserve checkpoint roundtrip, source/configuration and actual matmul/cuDNN
   precision flags. Keep any synthetic derivative probe distinct from the
   subsequently declared experimental-coordinate training objective.

Use one HPC3 GPU only when a real forward/backward is required; CPU construction
and data checks precede it. Preserve isolated code/output roots. No dataset
rebuild, parallel model grid or full-data training follows automatically.
After this implementation gate, specify a bounded direct experimental-GT
capacity/training test before attempting the formal 1,600-group quality gate.
The eventual deliverable remains a trained efficient MSA-free ESMC predictor
with all-heavy-atom coordinates, confidence and measured end-to-end cost.

Implementation probe details: explicitly disable both matmul and cuDNN TF32;
retain the native one-step sampler and existing dropout configuration. The
backward check uses observed-atom, unaligned coordinate MSE purely as a derivative
probe. On the shortest example, apply one disposable negative-gradient change
of fixed L2 norm 0.1 to the initially zero ESMC projection, then compare actual
versus zero ESMC inputs with identical sampling RNG. Restore the saved initial
weights before the longest case. Neither this scalar nor the disposable update
is a selected training objective or evidence of learned structure quality.
One allocation performs CPU preparation before CUDA forward/backward; no
separate GPU job is reserved only for CPU work.
