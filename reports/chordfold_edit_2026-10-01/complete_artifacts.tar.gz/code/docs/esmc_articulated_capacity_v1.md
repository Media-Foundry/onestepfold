# Controlled capacity training through the articulated output interface

Declared after accepted CPU interface checks and actual-core CUDA audit632148
with independent CPU QA. The inverse fit632103 established an attainable0.1504 A
representation error on these observed TRAIN targets. The old selected model
becomes worse under deterministic postprocessing (atom4.18->4.66 A), so the
next question is learning through this interface from the same fresh initialization.

Only experimental change versus accepted631937: pass its raw FP32 Cartesian
output through the parameter-free ArticulatedOutput before all losses and metrics.
Compile the adapter once per chemical input from cached reference positions,
sequence and fixed CCD inventory; no GT coordinates/masks/fitted variables enter
adapter preparation or inference. Use the exact audited interface source, explicit
degeneracy fallbacks/counts and original atom order. No pretrained folding weights,
teacher states, extra trainable parameters or extra structure evaluations.

Keep all32 TRAIN proteins, GT atom names/observed masks, frozenESMC600M features,
fresh initial tensorSHAbaad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea,
one trunk/one structure/one sample, dropout0, BF16trunk/FP32structure+adapter,
TF32 bothFalse, AdamW1e-4/wd1e-4/batch1/clip10, original epoch/group sampler seeds
and Random(101+epoch) shuffle. Confidence/distogram heads remain frozen/disabled;
future confidence training must consume final adapted coordinates.

Loss remains exactly aligned_atom_MSE +0.1global_frame_MSE +same_residue_frame_MSE
+10observed_distance_MSE. No fitted-angle or pose supervision, no new target values,
no idealized-reference losses and no coefficient grid. The first three distance
categories become largely fixed by reference geometry; retain the same loss and
weights to isolate the interface change. Consecutive C-N still depends on predicted
poses; the interface does not enforce peptide connectivity or clash avoidance.

Before updates require all64 raw initial predictions exactly match accepted631937,
all64 adapted initial predictions agree with the saved CPU-interface results within
max absolute5e-5 A (CPU/GPUFP32), and unchanged source/config/input/label/mask/
parameter/optimizer controls. Initial training/eval replay must be exact onGPU.
Bind accepted631937 report and QA, CPU interface report07d2b5f5, CUDA audit report
a91dea42 and independent QA, plus actual adapter source and pinned graph report.

Same at most100epochs/3200updates, dual-seed12345/54321 evaluation every5epochs,
earliest-tie joint max-normalized-error selection, futility20, plateau20 from30,
75minsoft/2hhard. Everyseed requires atom<=1 A, CA-distance<=1 A,29/32atom<=2 A,
NCA/CAC/CO each<=.15 A,CN<=.3 A,handedness>=95%; degenerate predictions count wrong.
Report fallback counts as diagnostics, without changing selection or stopping.
No warmstart, post-hoc gate changes or extension to rescue a failed candidate.

Log four losses, full total, gradient norms and adapter fallbacks. Save raw and
adapted initial/selected coordinates for all64 conditions, exact final selected
checkpoint replays, unchanged frozen heads/features/adapters, source/graph/label
provenance and actual execution counts/memory/timing. Independent final CPU QA must
reconstruct the adapter from chemical inputs, verify raw->adapted coordinates and
all four observed scalars/geometry/selection/stopping, plus heavy checkpoint/input
hashes. Include adapter in measured core cost; this is not full ESMC-inclusive cost.

One HPC3H100/8CPU96GB job. No parallel GPU grid. A TRAIN capacity pass still leaves
formal held-out quality, calibrated confidence and ESMC-inclusive end-to-end cost
unfinished; failure requires interpretation, not automatic weight/model scanning.
