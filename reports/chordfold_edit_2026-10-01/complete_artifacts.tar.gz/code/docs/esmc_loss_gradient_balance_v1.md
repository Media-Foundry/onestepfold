# Parameter-gradient balance audit after failed geometry capacity

Predeclared before execution, 2026-09-18. Accepted task631506 stops for its
declared plateau at40epochs/1,280updates, selectedepoch25. Both evaluation seeds
give about9.11 A all-atom RMSD, local-distance errors about1.1 A, and handedness
about50%. Direct two-seed disagreement is1.026 A, so seed agreement alone does
not imply accuracy. Do not extend this configuration or launch a coefficient grid.

The0.001 frame coefficient was chosen from coordinate-gradient norms, which do
not determine parameter-gradient balance after the network Jacobian. The earlier
accepted derivative audit measured the summed objective, not its two components
through individual modules. Measure that missing quantity before selecting a
new loss or architecture change.

## Fixed scope and resource cap

One HPC3 H100,8CPU,96G,1h hard limit. No optimizer, parameter update, new training
epochs, ESMC extraction or held-out structures. Use existing35/166-residue TRAIN
inputs, saved epoch25 best and epoch40 last checkpoints from631506, seed12345.
Four checkpoint/input cases. The951-residue memory boundary is already audited
and does not need another run for this question.

Use the unchanged deterministic capacity core, frozen heads, native one-cycle/
one-structure/one-sample path and both TF32 flags False. Construct without external
folding weights, then load only the corresponding own-training checkpoint.
Verify accepted report/QA, sources, input/GT/checkpoint hashes and masks. Best
checkpoint predictions must replay saved coordinates exactly. Last-checkpoint
predictions must reproduce their stored epoch40 per-protein evaluation metrics.
Save resulting coordinates. Require exact train/eval replay and unchanged final
weights/input features for each case.

## Measurements

On the same forward graph, compute aligned observed-atom MSE and local-frame MSE.
Obtain each component's coordinate gradients and parameter gradients separately,
then the actual combined objective gradients with coefficient0.001. All present
gradients and coordinates must be finite. Require nonzero gradients for each
component globally, and record rather than hide zero/unused module gradients.
No extra random seeds or trial coefficients are used.

For all trainable parameters and for disjoint module groups (ESMC projection,
remaining input/trunk, pairformer, diffusion conditioning, atom encoder,
diffusion transformer, atom decoder, any remaining parameters), report:
- Component L2 norms and the weighted frame/atom norm ratio.
- Dot products and cosine between component gradients; undefined zero-norm cosine
  is explicitly null. Negative cosine indicates local first-order conflict only.
- Actual combined norm, norm of the component-sum reconstruction, and relative
  difference. BF16 backward rounding can prevent exact numerical linearity;
  record its size rather than silently assuming equality.
- Parameter/tensor counts and finite/nonzero counts.

Archive per-tensor sufficient statistics (squared norms and dot products), not
full gradient tensors. Independent CPU QA recomputes all module/global sums,
ratios/cosines and scalar/coordinate metrics from saved artifacts, validates
partition coverage, and checks source/checkpoint/label provenance. It does not
repeat GPU backpropagation or claim that moment checks independently prove a
derivative. The earlier numerical derivative evidence remains separate.

Record runtime/memory and actual call counts. This diagnostic alone does not
select a new coefficient, certify chemistry or establish quality/generalization.
Interpret the result before predeclaring any additional training experiment.
The original trained ESMC all-heavy-atom model, confidence, formal held-out
quality and full end-to-end inference cost remain unfinished.
