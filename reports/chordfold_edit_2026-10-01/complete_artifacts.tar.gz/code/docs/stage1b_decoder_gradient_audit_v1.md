# Frozen-decoder output-gradient feasibility audit v1

Status: complete. HPC3 audit 630782 (2:57) and independent saved-result QA
630783 (0:35) completed 0:0. All four responses replay exactly, both pair paths
have finite nonzero gradients, teacher weights remain unchanged and the
951-residue peak allocation is 14.410 GiB. Shortest finite-difference errors
are 0.0002032 and 0.00005409. QA independently checks artifacts, scalar results
and learner predictions; it does not repeat decoder backward. Report:
reports/stage1b_decoder_gradients_2026-09-18.md. The contract below was fixed
before execution; its original source remains in the immutable run snapshots.

Execution v1 (HPC3 630777) stopped because Protenix's gradient branch references
torch.utils.checkpoint without importing that submodule. Execution v2 explicitly
imports it; model, inputs, loss, derivative gates and checkpoint settings are
unchanged. Preserve the v1 snapshot and failure. No new loss training or model
search has been launched.

Both pointwise and single-triangle raw-state-MSE models reduce latent error
without improving held-out structures. Stop extending these configurations.
The next question is whether actual denoised atom outputs provide a usable,
verifiable gradient to c1 pair states at acceptable memory cost. This is an
interface/numerical feasibility check, not a learned model or a quality gate.

Use four training-only groups from the accepted 128 cache: shortest and longest
(tie-break by group ID), plus two length-stratified remaining groups with seed
107. Process shortest first, longest last. No validation/test selection and no
residual-based sampling. Keep accepted teacher/checkpoint/features/atom identities
and seeds 101/12345. Retain c1 input/single states throughout pair-gradient work.

Capture the first actual diffusion call's noisy coordinates, noise level,
feature hash and denoised output from exact c1 replay. At the identical noisy
input, compare c1 pair with the target c4 pair while retaining c1 singles.
The latter is a supervised diagnostic target, not an inference feature. Verify
that regenerated frozen-decoder calls match captured responses before computing
gradients. Final sampler coordinates and a denoiser response are distinct:
the sampler applies an Euler update after the response. Record actual runtime
noise levels, sampler coefficients and module NFE rather than assuming defaults.

Freeze all teacher parameters and call DiffusionModule.forward directly with
gradients enabled and inplace_safe=False; do not use runner.predict's no-grad
wrapper for the backward pass. Rebuild both diffusion-conditioning pair_z and
atom-attention p_lm/c_l from a differentiable FP32 z leaf, with no detached
pair-dependent cache. Retain the verified torch kernels and deterministic
settings. The accepted runtime disables sampling autocast and creates FP32
pair_z, but all actual dtype/gradient flags must be checked again.

Use mean squared denoised-coordinate error at the common noisy input, with
FP64 loss reduction for numerical checking. Verify finite nonzero pair gradients,
no teacher-parameter gradients or weight changes, and sufficient graph coverage
through both pair-dependent cache builders. Compare the raw-state descent,
pointwise learned update and triangle learned update with the coordinate-loss
gradient using directional derivatives; these comparisons use training labels
and do not define a deployment rule.

On the shortest target, independently check central finite differences along
the unit-Frobenius negative gradient at fixed total-L2 steps 0.25 and 1.0. Report
both errors; a usable numerical check requires at least one relative derivative
error <=0.05, with any failure investigated rather than silently dropping the
target. Preserve the difference between the continuous FP32 state derivative
and BF16-rounded deployment states; report rounded perturbation changes
separately, without treating the cast derivative as proof of smooth quantized
behavior. Probe only these predeclared steps; no held-out step-size tuning.

Record synchronized forward/backward time and peak GPU memory at every selected
length, including the longest 951-residue example. If memory or inplace-gradient
failure requires checkpointing or another execution-only change, version it
explicitly and recheck functional equivalence. Do not remove long proteins or
claim feasibility from the shortest example alone. Save replay/input/output/
gradient hashes and independently verify saved scalar/coordinate results.

Only a successful interface and memory audit can motivate a separately specified
decoder-output-supervised training pilot. A one-call response audit is not a
one-evaluation folding model. The primary ESMC-600M, MSA-free all-heavy-atom,
eventual one-cycle/one-structure-evaluation objective, experimental-GT evaluation,
formal 1,600 validation gate and end-to-end timing requirements remain intact.
