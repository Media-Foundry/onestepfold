# DiamondHill 当前核心兼容性预检

用户于9月26日深夜明确表示DiamondHill的8个GCD可用，并授权考虑切换计算资源。这更新了此前仅用HPC3的资源偏好。当前锁定的H100配对实验及其验收仍在HPC3完成；此预检单独记录，不改动该实验的硬件、预算或比较规则。

只读检查确认：8个gfx90a GCD（rocm-smi标为AMD Instinct MI250X / MI250），每个约64 GiB显存，观察时利用率0%、显存占用约11 MB。可复用环境为`/home/pc/anaconda3/envs/fold`，PyTorch `2.12.0a0+git78258b9`、HIP `7.14.60850`、Protenix1.1.0。版本不同于HPC3，不能默认数值或性能相同。

预检边界：

- 仅使用一个GCD、10分钟进程上限；零优化器更新。
- 使用已验收2048 TRAIN中长度最接近128的样本（group ID排序打破并列）和最长样本，实际长度128/256；不访问开发或冻结测试坐标。
- 复制当前冻结的108文件源码清单、两个prepared packet和同一个raw父checkpoint；核对清单、checkpoint、上游关键源码、配置及数据hash。
- 现有raw与几何输出各做一次前向／反向，检查有限损失和梯度、前端与输出head梯度、一次trunk／一次structure／零confidence调用，以及权重不变。
- 使用原torch三角模块和`LAYERNORM_TYPE=torch`，不修改已冻结模型算法；确定性算法检查保持开启，失败须记录，不能静默放宽。
- 时间与显存只作为这四个预检case的诊断记录，不是充分预热、匹配硬件或完整训练的性能测量。随机数实现可能跨后端不同，此检查不声称相同seed得到相同坐标。

若预检通过，DiamondHill可作为后续必要实验/评估的候选资源；仍需根据工作量和实测速率决定分配。8个GCD不会自动把当前batch1优化轨迹加速8倍。此预检不启动新的方法、损失权重或训练规模搜索，也不证明正式质量达标。

执行脚本：[probe_diamondhill_core.py](../scripts/probe_diamondhill_core.py)。本地记录目录：`reports/diamondhill_runtime_2026-09-27/`；远端隔离目录：`/media/PM982/onestepfold/diamondhill_runtime_v1_20260927/`。
# Completed probe: 00:20 HKT

The first invocation (v1) exited before GPU execution because the launcher omitted
`PROTENIX_ROOT_DIR`. All23 configuration differences were derived global data-path
strings. Preserve its report and config differences under
`reports/diamondhill_runtime_2026-09-27/v1/`.

The isolated v2 invocation used the unchanged probe and immutable v1 inputs,
restoring the same `PROTENIX_ROOT_DIR` value as HPC3. These legacy global paths
are not read by this prepared-packet probe; its two packets are hash-checked at
the DiamondHill staging path. No configuration check was relaxed, and no installed
package or global filesystem path was changed.

V2 completed all four cases:128/256 residues, raw/geometry, one trunk and one
structure evaluation, zero confidence calls, finite front/head gradients,
unchanged weights and zero optimizer updates. The checkpoint,108 frozen source
files, five upstream source files and model configuration passed their checks.
Reports and launch/exit metadata were copied and SHA256-verified against the host;
see `reports/diamondhill_runtime_2026-09-27/archive_integrity.json`.

Forward/backward seconds in execution order were9.98,0.93,1.91,1.93; the first
case includes cold runtime work. These are not a matched H100 comparison and
do not establish multi-GCD scaling or optimizer-training stability. The largest
peak allocated memory was3159566336 bytes. DiamondHill is usable for bounded
next-stage work; the current locked H100 experiment remains on HPC3.
