# 既有 scaling 八组结果的完整汇总

2026-09-26：补齐原 scaling-v1 已要求的匹配预算、逐目标、化学几何和同源性分析。
仅读取旧训练结果与精度分离补验；全部数值分析和测试在 HPC3 CPU 作业中执行。
不增加训练、配置、候选数或测试集访问，不改变当前 endpoint 权重1.0实验。

沿用原汇总已指定的8192、16384、24576、32768更新，以及原训练保存的
2/4/8小时 crossing checkpoints。未达到预算明确记缺失，绝不以最佳或最近
checkpoint替代。报告真实更新、样本/残基数、训练时间、评估时间和墙钟；
wall crossing可能超过阈值，不能称严格等FLOPs或端到端计时。最佳开发checkpoint、
完整TRAIN和最后checkpoint另列，不能替代预算比较或作为收敛证明。

128开发目标固定，每目标两个固定noise先平均，K仍为1，不选最佳noise。
比较两个表示各自512−128、2048−512、2048−128，以及各规模raw−geometry；
lr3/cosine仅与128默认配置比较，单列为优化器诊断。
每项报告lDDT/TM均值、5%分位、最差5%均值、逐目标差与下降>0.05比例。
沿用原汇总10000次配对target bootstrap、seed101；尾部每次重采样重新排序。
这些区间不包括训练seed不确定性，未做多重比较校正，不据此宣布全局成功。

同源性沿用已保存的high-gap-cost global alignment：aligned-residue identity，
shorter-sequence coverage>=0.8。报告每规模分布；比较分层统一使用相对最大2048
TRAIN的身份，以保持目标子集一致。描述性分箱<0.3、[0.3,0.5)、[0.5,0.8)、>=0.8，
另列无合格match。分箱是事后报告规则，不是新数据划分或最终泛化门槛；
该coverage只针对较短序列，低identity分层也不证明新fold泛化。

化学几何报告按目标/noise平均的CA手性一致率与连续C–N MAE，保留各指标可评估
目标数；不能用局部几何摘要声称所有化学约束达标。checkpoint来源、report/history/
contract/QA/data/homology/source hashes绑定于独立分析产物。所有八组必须拥有对应
完整QA后才生成正式汇总。中间history分数标为worker历史记录；最终产物QA不能
冒充每个中间checkpoint已独立重算。旧失败和事后precision-v2接受分开记载。
