# Training-only pair-component / decoder-response audit v1

Predeclared after the failed raw-state-MSE pilot; no new optimization or
held-out data selection. Objective: identify whether loss reduction occurs in
pair-state components that change the frozen decoder's actual input or output.

Use the longest of the accepted 128 training groups plus seven length-stratified
remaining training groups, selector seed 105. Keep group IDs, atoms, checkpoint,
c1/c4 caches and the selected learned epoch-20 checkpoint fixed. Use HPC3,
BF16, deterministic features seed 101 and sampler seed 12345; two decoder NFE.
Four independent workers use L-squared-balanced partitions. This is a small diagnostic,
not a validation gate or deployable target-aware inference policy.

For each 128-channel ordered-pair residual D[i,j], including the diagonal,
decompose in FP32 as global mean G, row mean minus G, column mean minus G,
and remaining interaction I. Define A = G + row + column. These components
are orthogonal under uniform ordered-pair squared error. Compare component
energies, prediction-target cosines and error ratios before final BF16 rounding.

Decode eleven fixed conditions: native c4 replay, c1 identity, learned pair,
oracle full pair, oracle G, oracle A, oracle I, learned A, learned I,
oracle I + learned A, and oracle A + learned I. Except the native c4 replay,
all retain c1 single/input embeddings. Add each intervention to native z1 in
FP32 and cast once to BF16. Keep exact full-pair identity/oracle endpoints.
No interpolation sweep or best-condition selection for deployment.

Measure raw pair-state MSE and the actual decoder conditioning `pair_z` MSE to
the c4-pair reference, plus all-atom RMSD, CA RMSD and CA-distance RMSE to native
c4 coordinates. Native c2 remains a structural reference. Capture `pair_z`
from the first actual diffusion call; verify independently by reconstructing
the same frozen `diffusion_conditioning.prepare_cache(relp,z,False)` calculation
with the recorded autocast setting. Do not call raw LayerNorm(z) the decoder
input: the source concatenates z with a learned relative-position representation
before LayerNorm, projection and two residual transitions.

Require exact c1/c4 atom replays, fixed c1 singles, same input/sampler hashes,
zero trunk-stack calls, two decoder NFE, independent component/prediction/cache
recomputation and source/artifact/coordinate QA. Interpret only after QA.
Results may motivate a separately predeclared decoder-related objective; they
do not establish its learnability, experimental accuracy or end-to-end speed.
The original ESMC-600M, MSA-free all-heavy-atom, one-cycle/eventually one-structure-
evaluation objective remains unchanged.
