# Post-acceptance articulated coordinate diagnosis

Prepared while632192 trains; no change to its execution, losses, selection or
budget. Run only after its selected checkpoint and independent heavy CPU QA are
accepted. Use the saved64 selected predictions, fixed observed labels/masks and
accepted32 reference/inverse-fit reports; no model forward or optimizer run.

For each prediction retain the existing global proper-fit atom RMSD and its
centroid/centered-internal SSE decomposition. Then independently optimize only a
proper rigid pose for each predicted residue against its observed GT atoms. This
second closed-form calculation cannot change the predicted residue's internal
shape, names or graph. Report the residual RMSD and the reduction in SSE when
independent poses are allowed. That reduction measures available pose correction,
not an orthogonal physical energy decomposition or a model-gradient attribution.

Compare the residual shape error with the accepted cached-rigid reference floor
1.046758 A and articulated numerical attainable fit0.150398 A on the same atoms.
The first is a true proper-rigid-fit floor for exact cached references; the latter
is an attained numerical error, not a global lower bound. Do not confuse a
GT-dependent pose correction with learned folding quality or usable inference.

Verify all64 prediction hashes, exact input inventory/GT label mapping, original
observed masks and row/global metric consistency. Check global aligned SSE is no
smaller than the independently fitted residue SSE within numerical tolerance.
Save only observed pose-adjusted coordinates as diagnostic artifacts, along with
their hashes and actual diagnostic source. Reuse the already tested proper-fit
implementation/spectral-optimum check; do not rerun earlier accepted inverse fits.
Summarize both seeds and AA types. Keep raw pre-adapter coordinates out of physical
quality claims: they are latent geometric inputs, not the delivered structure.

Write articulated_shape_diagnostic.json and a matching Markdown report with both
seed summaries and per-amino-acid residual RMSDs in the accepted training archive.
