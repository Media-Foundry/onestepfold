# Local-frame supervision and sampler-RNG derivative audit

Predeclared before GPU execution, 2026-09-18. This verifies a proposed loss path;
it is not another performance-training run or a promotion of the failed model.

The accepted32-protein capacity result shows within-residue RMS radius0.553 A
versus GT2.196 A,49% handedness agreement, and marked sampler-seed sensitivity.
Preserve its negative result, input/GT contract, atom identities and masks.

## Proposed geometric label and scalar

For each residue with observed, nondegenerate N/CA/C, define a proper local
frame: CA origin, first axis along C-CA, second axis the component of N-CA
orthogonal to the first, third axis their cross product. Exclude GT frames whose
first or orthogonal second vector norm is <=1e-4 A. Predicted vector norms are
clamped below1e-4 A for stable normalization; degenerate predicted frames are
never silently removed and are not claimed to be orthonormal.

Each GT frame selects all observed atom labels within15 A of its CA, excluding
that origin CA itself. These sparse frame/point indices and GT local coordinates
are loss-only labels, never sequence/chemical/model inputs. Compare predicted
and GT local coordinates by mean squared Euclidean distance per frame-point pair
(A²), without clamping, symmetry renaming, imputation or reference-conformer
targets. Proper rotations/translations cancel, while reflected side-chain
handedness changes signed local coordinates. This is a deliberately defined
local-frame objective, not a claim of exact equivalence to a published FAPE loss.

## CPU checks

Verify exact-target/proper-pose invariance, reflection sensitivity, missing-atom
exclusion, degenerate-frame handling and numerical gradients. Evaluate all32
saved initial/best/second-seed coordinate sets, compute loss/coordinate gradients
and independently recompute frame-point values in NumPy FP64. Check a central
directional derivative for the shortest trained example. Record component
scales rather than selecting a hyperparameter grid.

Introduce stateless sampler seeds from SHA256 of version/base_seed/group/epoch/
repeat, mapped to[1,000,000,2^31). Check all3,200 planned group/epoch keys for
uniqueness and exclusion of diagnostic seeds12345/54321. This changes future
training's sampler realizations, not its sequence or target labels. No claim of
generalization or a thermodynamic distribution follows from seed variation.

## One bounded GPU audit

One HPC3 H100,8CPU,96G,one-hour hard limit. Use the accepted trained checkpoint
only to probe the diagnosed collapsed state, and restore it after any disposable
perturbation. No optimizer state/epochs, new teacher states, or pretrained folding
checkpoint are introduced. Test existing training inputs35/166 residues from the
capacity run and951 residues from the accepted interface gate (memory/derivative
boundary only). Verify all input/GT/checkpoint lineage hashes.

For the two capacity inputs replay saved seed12345 predictions exactly. For each
of the three inputs, use its deterministic epoch1 training sampler seed; require
actual one trunk/one structure call, finite coordinates and finite nonzero
gradients through the core. For this derivative check only, backpropagate the
sum of existing rigid-aligned atom MSE and local-frame MSE, recording both
components and coordinate-gradient norms. Equal coefficients here are not a
selected production training objective.

On the shortest input only, apply one disposable negative-gradient perturbation
to the final atom-coordinate output projection with weight L2 displacement1e-5.
Require the same-RNG combined scalar to decrease, then restore the exact weights.
Replay all three unperturbed outputs exactly in eval mode; measure peak memory,
save coordinates/labels/source hashes and verify no input or final weight changes.

Independent CPU artifact/FP64 scalar checks must pass before interpreting the
GPU audit as usable. Next training budget, loss weights and quality/geometry/noise
criteria require a separate declaration informed by these checks. The original
trained-model/confidence/held-out-quality/end-to-end-cost goals remain open.
