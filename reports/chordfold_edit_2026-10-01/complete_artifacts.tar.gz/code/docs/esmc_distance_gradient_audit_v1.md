# Explicit observed distances: bounded gradient audit

Declared after accepted training631737 and independent CPU diagnoses. Adding
same-residue frames improves handedness but still fails local distances and global
accuracy. The actual geometry objective has substantial same-residue contribution;
another frame-weight sweep is not justified. Check a directly targeted distance
signal before spending on another controlled training run. This audit can establish
gradient availability and conflict, not whether Cartesian outputs can learn valid
chemistry or whether a constrained output head is necessary.

Use accepted631737 initial and selectedepoch35 states, shortest35/longest166 TRAIN
inputs, seed12345: four cases, no held-out inputs, optimizer or parameter updates.
Require reportSHA eb1ee70815f0b6c009879a1db6ea0f6f07c6c4d27b6549ca6928c7b81f746cbb
and completed heavy QA; preserve source/runtime/input/GT/checkpoint hashes and all
existing atom identities, masks, frozen ESMC and confidence heads.

- B = aligned atom MSE +0.1 global-frame MSE +1 same-residue frame MSE, the actual
  accepted training objective.
- D = arithmetic mean of the four category MSEs for observed N-CA, CA-C, C-O and
  consecutive-residue C-N distances. Each category averages its own observed pairs;
  omit empty categories (all four must be present in these four audit cases).
  Targets are the actual experimental distances, never idealized constants.
  Match existing gate pair sets exactly. Consecutive C-N is not a certified bond.
- P = B+D, a unit-coefficient derivative probe only. In the reused gradient-moment
  schema the field `local` denotes D, explicitly recorded in loss_definitions.

Distances use the ordinary Euclidean norm. Exactly coincident predicted endpoints
have its zero subgradient; report their counts rather than silently perturbing or
removing them. Missing atoms cannot contribute; excluded atom gradients stay zero.
No side-chain or angle/chirality constraint is claimed for D. Labels never enter
the model. Fixed graph and missing-atom policy remain unchanged.

One HPC3 H100,8CPU,96G,20min hard cap. One graph per case with separate B/D/P
backwards; exact saved and train/eval prediction replay, unchanged weights/features,
actual1trunk/1structure/0confidence, existing BF16/FP32 boundaries and TF32=False.
Record all trainable tensor moments, module/global norms/cosines/directional
derivatives and actual mixed-precision gradient reconstruction error. No weight
or training budget is selected by this document.

Before GPU execution require focused mask/gap/identity/denominator/rigid-invariance/
zero-distance/finite-difference tests and CPU agreement with existing geometry
metrics on all32 selected predictions. Independently rebuild pair labels from
atom37 observed GT in CPU QA; recompute scalars, coordinate derivatives and moment
identities/module aggregation. Fix scalar rtol1e-4,atol1e-3 Å²; coordinate-gradient
relative L2 tolerance1e-3 versus independent FP64 graph. Source and all artifacts
must hash-match. CPU QA does not repeat the GPU network backward; full parameter
gradients are not archived. Stop on provenance/replay/nonfinite/required-gradient
failure. No grid, warmstart, epoch extension or scale-up is implied.

Interpret the result before declaring the next training experiment. Efficient
MSA-free ESMC all-heavy-atom prediction, calibrated confidence, formal held-out
quality and full ESMC-inclusive cost remain the original unfinished objectives.
