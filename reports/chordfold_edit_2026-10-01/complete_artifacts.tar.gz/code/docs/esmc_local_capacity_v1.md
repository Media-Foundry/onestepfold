# Controlled addition of same-residue frame supervision

Declared after accepted GPU audit631704 and before training. The original target
remains a fresh ESMC-600M-conditioned all-heavy-atom predictor with one trunk cycle
and one structure evaluation, trained/calibrated confidence, formal held-out quality
and full inference cost. This is one necessary TRAIN32 capacity experiment.

## Evidence and single change

The accepted coefficient0.1 run631592 fails the joint geometry gate. Same-residue
frame pairs contribute about0.12% of its global frame scalar. Accepted audit631704
shows that giving those same observed pairs their own denominator supplies finite
network parameter gradients: unit local/existing-loss norm ratios0.789/0.672 at
initial35/166 and0.777/0.233 at selected35/166. Four exact replays, unchanged weights/
inputs, independent CPU coordinate gradients/scalars and moment QA pass. This
supports testing a term of comparable gradient scale, not a quality guarantee.

Change only the loss by adding that separately normalized term with fixed weight1:

`L = observed_aligned_mse + 0.1 * local_frame_mse + same_residue_frame_mse`.

`same_residue_frame_mse` is exactly the existing local-frame calculation restricted
to existing supervised pairs whose point and frame CA share a residue ID, averaged
over those pairs. Retain original observed masks, chemical inventory, fixed atom
names, proper frame axes and1e-4 A floor. The original global term remains unchanged.
No new labels, reference-conformer target, imputation or direct chirality/bond loss.
This term alone does not enforce inter-residue C-N distances or all chemistry.

## Matched controls

Use exactly the32 TRAIN inputs, frozen ESMC cache, model/configuration, fresh initial
weight hash baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea,
sampler/shuffle schedule, precision and optimizer from631592. Require its accepted
reportSHAff534b92b7f3275aac03bd4ccd02a574f0eee3c02edaf67d036a9edcfccfd8d9 and
accepted gradient auditSHAbe50f3383d595fec58dc74aab7c35d79dbdb6cfc5d3782589a5127316f2c2c63.
Check exact shared model/global-loss/gate source hashes and all declared controls.
Match all64 initial predictions and original joint summaries before optimization.
No warm start or optimizer continuation. One model forward/sample per update.

Preserve confidence/distogram freezing, both TF32 flags False, BF16 trunk/FP32
structure boundary, dropout-disabled capacity configuration, AdamW lr1e-4/wd1e-4,
clip10, batch1, Random(101+epoch) shuffle and accepted group/epoch sampler seeds.

## Unchanged budget, selection, stopping and assessment

Retain the full protocol from docs/esmc_geometry_capacity_v1.md: maximum100epochs/
3200updates,75min soft limit,2h Slurm cap, one HPC3 H100/8CPU/96G. Evaluate both
12345/54321 seeds every5epochs, select the minimum maximum-normalized joint score
with earlier ties, stop on the gate, declared epoch20 futility,20-epoch/1% plateau
from30, or budget. Do not modify gates or stop rules after inspecting this run.

For EACH seed: pooled atom RMSD<=1 A, CA-distance RMSE<=1 A,29/32 atom RMSD<=2 A,
N-CA/CA-C/C-O RMSE each<=0.15 A, consecutive observed C-N RMSE<=0.30 A, and
GT-relative handedness>=95% with predicted degeneracy counted wrong. This is a
small-set capacity gate and incomplete stereochemistry, not held-out validation.

Log atom/global-frame/same-residue loss components separately. Keep existing
selection summaries unchanged; report extra local scalars separately. Require
final selected64 exact replays, frozen heads/input hashes, source/checkpoint/GT
provenance and independent CPU FP64 metrics, all three loss scalars, seed/order,
selection/stopping and heavy-artifact QA. Same scalar tolerances as accepted frame
QA: rtol1e-4/atol1e-3 A². Archive compact predictions, curves, labels and actual source.

Compare against accepted631592 at protocol-selected checkpoints and common epochs.
No automatic coefficient grid, epoch extension, held-out reads or scale-up. Interpret
the completed result before the next experiment; all original final goals remain open.
