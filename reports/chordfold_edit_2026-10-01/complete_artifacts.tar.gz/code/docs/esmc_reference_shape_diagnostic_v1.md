# Cached reference conformer: rigid-residue representational lower bound

Declared during631937 after source inspection, with no change to live training.
Installed Protenix1.1 provides CCD reference conformers, local-frame projection
and chi-angle atom indices, but inspected output path emits unconstrained Cartesian
updates. Reference conformers are transformed independently by residue in input
featurization; they are not experimental GT. Do not substitute them for labels.

Bounded CPU question: could a decoder that only independently rotates/translates
each exact cached reference residue even represent the observed32 TRAIN targets
accurately enough? For each observed residue perform the optimal proper rigid fit
of the cached reference coordinates to observed experimental coordinates using
fixed atom names. Report aggregate/per-protein/per-residue errors and reference
coverage. Require valid reference coordinates for every observed atom; fail on
missing coverage rather than silently shrinking evaluation or imputing targets.
Exclude missing atoms from every fit/output; only save observed fitted coordinates.

This is a target-aware representational lower bound for those exact rigid
conformers. Every residue receives an independently optimal GT-dependent pose;
inter-residue connectivity is not enforced. It is neither an inference method nor
a model-quality result, and it does not bound a torsion-capable head. A low floor
does not prove successful learning or compatible peptide connectivity. A high
floor can rule out that overly rigid simplification without training it.

Reuse accepted631737's32 fixed input/GT provenance and original cached input.pt
packets. Verify accepted report/heavy QA/contract, input feature hashes and GT
labels. Use spare1CPU in live631937 with CUDA visibility empty aftersrun; no extra
GPU job/forward. Archive input reference positions/masks and observed GT/masks/
inventory, fitted observed coordinates, source/runtime hashes and metrics. Validate
proper rotation, spectral minimum formula and focused rigid/mask/reflection tests;
independently recompute saved per-residue RMSDs locally. No architecture/loss/data
contract is changed or new training selected by this diagnosis.
