# Same-residue frame supervision: bounded parameter-gradient audit

Declared after coefficient0.1 training631592 and its independent QA are complete,
before another GPU experiment. The two controlled geometry coefficients both fail
the capacity gate. Existing same-residue frame-point pairs contribute only about
0.12% of the frame scalar and median0.13–0.17% of cross-residue coordinate-gradient
norms. Those ratios do not establish network parameter-gradient balance. Cross-
residue terms also act on frame anchors; no causal isolation claim follows.

The next bounded question is whether separately normalizing the already observed
same-residue local-frame term gives finite, usable gradients through the actual
one-cycle/one-structure ESMC core. This is a derivative audit, not another training
run or a coefficient search. No new chemical inventory, target atom, GT imputation,
reference-conformer supervision, teacher input or held-out read is introduced.

## Fixed cases and scalars

Use only accepted631592 initial and selectedepoch35 checkpoint states, at the same
shortest35 and longest166-residue TRAIN inputs, evaluation seed12345: four cases.
Require accepted heavy QA/report hash
ff534b92b7f3275aac03bd4ccd02a574f0eee3c02edaf67d036a9edcfccfd8d9,
the saved contract, exact input/GT/mask/frame provenance and source hashes.

For one unchanged forward graph per case, define:

- `B = observed_aligned_mse + 0.1 * local_frame_mse`, the actual existing loss.
- `R = local_frame_mse` restricted to the existing frame-point pairs whose point
  and frame CA belong to the same residue, averaged over ONLY those pairs.
- `P = B + R`, a unit-coefficient derivative probe only.

R retains all existing observed masks, fixed atom names, proper frame conventions
and1e-4 A normalization floor. The original supervision is never modified in
place. R is not asserted to constrain inter-residue C-N distances or every chemical
degree of freedom. Existing CPU partition scalar/gradient/finite-difference tests
cover its normalization; rebuild labels and repeat scalar checks for audit inputs.

## Execution and acceptance

One HPC3 H100,8CPU,96G,20min hard limit. No optimizer or persistent parameter
updates. Frozen heads and cached ESMC stay unchanged. Preserve actual training
BF16/FP32 boundaries and both TF32=False. Require exact initial/selected prediction
replay, train/eval equality, and one trunk/one structure/zero confidence calls.

Separate backwards reuse the same graph to obtain parameter gradients of B, R and
P. Record every trainable tensor's presence, finite values and norm/moment evidence,
global and existing disjoint-module norm ratios/cosines, and reconstruction error
between actual P gradient and B+R gradients. Record coordinate gradients/scalars
for independent CPU validation and zero gradients at excluded atoms. No parameter
coefficient is selected by this document, and P is not a new training objective.

Verify no changes to checkpoint/input/ESMC/chemical features, preserve actual
source, runtime flags, artifacts and hashes. Independent CPU checks recompute
scalars, coordinate derivatives, moment identities and module aggregation; clearly
state that CPU checks do not repeat GPU parameter backward. BF16 reconstruction
rounding is measured, not silently treated as exact. Stop on nonfinite values,
missing expected supervision/gradient or replay/provenance failure.

Before execution, fix scalar CPU-FP64/GPU-FP32 agreement tolerance at rtol1e-4,
atol1e-3 A² as in the accepted frame audit. For each saved coordinate gradient,
require relative L2 difference <=1e-3 against an independent CPU FP64 graph using
NumPy proper alignment and explicit frame axes. This checks coordinate derivatives,
not the mixed-precision network backward. Retain measured errors in QA artifacts.

Interpret this audit before declaring a training loss/budget. No grid, warm-start
continuation, epoch extension or data scale-up. The original trained all-heavy-atom
ESMC core, confidence calibration, formal held-out quality and ESMC-inclusive total
cost remain required unfinished goals.
