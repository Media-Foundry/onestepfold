# Saved-coordinate diagnosis of the recorded distance objective

Declared while631937 is running, after its epoch5 assessment. The early distance
gains accompany worse handedness; this is provisional and changes no live controls.
After final independent heavy QA, reuse selected64 coordinates and existing labels
to measure B versus10D at coordinates, alongside the existing residue-shape/seed
agreement diagnostic. No extra GPU forwards, new checkpoint selection or training.

B is actual aligned atom MSE+0.1globalframe+same-residue frame MSE. D is the audited
equal-category observed-distance MSE. Bind contract weights exactly0.1/1/10.
Rebuild pair labels independently from atom37 and verify saved labels/coordinates/
sources/hashes. Use the accepted audit's independent FP64 coordinate graph for B/D;
check distance derivatives independently with the analytic Euclidean-distance
formula. Report scalar contributions, weighted coordinate-gradient norm ratios,
cosines and first-order derivatives of B and10D along the negative combined
coordinate gradient, both per protein and by seed. Exactly coincident endpoints
retain the defined zero subgradient and are counted.

This is a coordinate-space diagnostic, not parameter-gradient/AdamW evidence or a
postprocessing algorithm. A gradient descent direction does not prove finite-step
or trained quality. It cannot distinguish all architectural causes, and it selects
no new coefficient. In particular, the older frame-attribution tool must reject a
nonzero distance weight rather than label its incomplete frame-only sum as the
entire recorded geometry objective. Preserve prior accepted reports/source copies.

Acceptance: final heavy QA and source lineage; scalar NumPy/recordedFP32 agreement
rtol1e-4/atol1e-3 Å²; FP64 analytic/autograd distance derivative relative L2<=1e-10;
zero excluded-atom derivatives; finite values and component-gradient additivity
relative L2<=1e-10. Run on all32 selected TRAIN proteins and both evaluation seeds.
Fail rather than overwrite an existing accepted diagnostic. No held-out reads or
new data/chemical inventory. Full original model/confidence/quality/cost goals stay
open regardless of this diagnosis.
