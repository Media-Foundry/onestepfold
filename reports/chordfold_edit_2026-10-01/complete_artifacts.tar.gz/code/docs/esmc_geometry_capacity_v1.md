# Scaled local-frame and varied-sampler capacity experiment v1

Predeclared before execution, 2026-09-18. One bounded experiment on the same32
TRAIN proteins as the failed direct-GT capacity run. This tests the joint remedy
for observed atom collapse and sampler-seed dependence; it does not separately
identify the contribution of either change. No concurrent hyperparameter grid.

## Inputs and initialization

Reuse the accepted capacity contract, exact32 selections (35–166 residues),
input packets, native atom inventories, experimental labels/masks and cached
frozen ESMC-600M embeddings. Verify old accepted report/QA, packet and GT hashes,
and label remapping before optimization. Do not rerun raw data extraction or ESMC.
No teacher coordinates/states, held-out/temporal structures or imputed GT inputs.

Construct a new random core with seed101 in Python/NumPy/PyTorch and require
initial tensor hash baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea.
Do not warm-start from the failed trained checkpoint. Same Mini topology,
dropout-disabled capacity configuration, native one-cycle/one-structure-evaluation/
one-sample schedule[2560,0], both TF32 flags False. Confidence/distogram heads
stay frozen. Assert one trunk/one structure/zero confidence per forward and exact
initial train/eval replay. Preserve the accepted derivative audit631479.

## Loss and noise

`L = observed_aligned_mse + 0.001 * local_frame_mse`, with both scalars defined
exactly by the accepted implementations. The frame term uses observed N/CA/C
frames and observed neighbors within15 A, norm floor1e-4 A, fixed atom names,
unclamped squared local-coordinate error. These frame/neighbor labels enter only
the loss, never model inputs. No other geometry, distogram, confidence or teacher
loss is enabled.

The fixed coefficient0.001 is an order-of-magnitude gradient scale choice from
existing TRAIN diagnostics, not a search result or an optimality claim: unweighted
coordinate-gradient ratio has median654 at the collapsed trained predictions,
so0.001 gives median0.654 (range0.433–2.263). At random initialization the median
ratio becomes0.00362; at the second diagnostic noise seed0.153. These are coordinate
gradient scales, not guarantees about full parameter-gradient contributions.
Weights remain fixed throughout; no adaptive tuning from curves.

Each training group/epoch uses `training_sampler_seed(group_id, epoch)` from
the accepted SHA256 schedule. All3,200 keys are unique and disjoint from the
two evaluation seeds12345/54321. Protein order uses Random(101+epoch). No extra
samples per update. Both evaluation seeds are used for checkpoint selection and
capacity assessment; neither is a held-out protein benchmark or unseen-seed claim.

## Budget and selection

Same AdamW lr1e-4, weight_decay1e-4, default betas/eps, clip global gradient norm10,
one protein per update, maximum100epochs/3,200updates. One HPC3 H100,8CPU,96G,
2h scheduler limit; soft75min optimization/evaluation budget, finish current epoch.
Nonfinite coordinates, losses, parameter gradients or parameters fail the run.

Evaluate all32 proteins at epoch0 and every5epochs for each fixed evaluation seed.
Record per-protein and pooled all-atom/CA/CA-distance metrics, local-frame MSE,
observed N–CA/CA–C/C–O/consecutive C–N distance errors, and GT-relative signed
N/CA/C/CB handedness agreement. Consecutive C–N comparison does not assert an
intact peptide bond. This remains an incomplete stereochemical check.

For EACH evaluation seed require all of:
- Pooled all-atom RMSD <=1 A; pooled CA pair-distance RMSE <=1 A.
- At least29/32 proteins with all-atom RMSD <=2 A.
- Pooled N–CA,CA–C,C–O distance RMSE each <=0.15 A.
- Pooled consecutive observed C–N distance RMSE <=0.30 A.
- At least95% handedness agreement among observed nondegenerate GT centers;
  degenerate predicted centers count as failures.

Select checkpoint by the lowest maximum normalized violation across BOTH seeds:
atom RMSD/1, CA-distance RMSE/1,29th-smallest protein atom RMSD/2,
each local-distance RMSE/its threshold, handedness-failure fraction/0.05.
Epoch0 is eligible, ties retain the earlier checkpoint. The score covers the
entire declared gate; it does not substitute a scalar-loss decrease for geometry.
This strict small-set gate is a capacity diagnostic, not authorization to claim
formal generalization or promote a trained predictor.

Stop on the joint gate. At epoch20 stop for futility only if selection score AND
worst-seed pooled atom RMSD both exceed90% of initial. From epoch30 stop if best
score has not improved by1% over the best available20epochs earlier. Otherwise
stop at budget. Save atomic best weights and latest optimizer state at evaluations,
per-epoch loss components/gradient norms/seed digest, and full metric histories.

## Acceptance and follow-up

Reload best and save/replay all64 selected predictions exactly, verify unchanged
inputs and frozen heads, record actual call counts/memory/sources/checkpoints.
Save initial predictions for both seeds. Keep heavy checkpoints and existing
input packets on HPC3; archive compact GT/inventory/predictions/history/source.
Independent CPU FP64/SciPy coordinate and local-geometry recomputation must pass
(2e-5 A absolute coordinate-metric tolerance); independently check selection,
gate/stopping logic and all declared artifact hashes. Local-frame FP32 scalars
are compared to NumPy FP64 with rtol1e-4/atol1e-3 A², as in the accepted audit.

Interpret the completed result before any additional training. No automatic
epoch extension, coefficient grid or scale-up. The original trained ESMC core,
confidence calibration, formal held-out quality and ESMC-inclusive inference cost
remain required unfinished goals.
