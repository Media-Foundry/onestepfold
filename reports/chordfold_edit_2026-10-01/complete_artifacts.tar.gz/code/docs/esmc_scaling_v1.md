# Scaling-v1: fixed-budget generalization ladder

Declared 2026-09-19 after accepted Capacity-C. User requests generalization as
priority, parallel128/512/2048 scaling, raw baseline, isolated optimizer tuning,
matched budgets, and no frozen temporal test use. No architecture/recycle changes.

## Data contract

Only existing16000 pre-cutoff teacher-input metadata rows are used as a sequence /
experimental-representative index. No teacher coordinates/states/confidence input.
Reconstruct original exact-group14400/1600 train/validation assignment using its
namespace, seed101, SHA256 ranking and count1600; verify against accepted32TRAIN
and64validation. Restrict this pilot to32..256residues, record length histograms.
No near-identity deduplication or clustering change. Nested TRAIN order starts
with accepted32 and appends deterministic SHA256 rank; prefixes128,512,2048.
Fixed128validation rows come from the original1600, excluding prior64 examined
validation rows, with a separate SHA256 namespace. Check pre-cutoff TRAIN member
(sample_id/group_id) and2021-09-30 date; frozen temporal manifests/coordinates
remain unopened. This is development validation, not an untouched final test.

Audit each selected validation sequence against the maximal2048 TRAIN set using
existing high-gap-cost Biopython global identity policy. Preserve splits; report
identity/coverage strata and per-scale maxima. Near-homology remains possible;
no novel-fold generalization claim from aggregate dev scores. ESMC pretraining
sequence overlap remains unmeasured. Hash all selections before any fitting.

Prepare2176 packets in16CPU work shards. HPC3 rejected the CPU-only ACD array
and debug16CPU request; actual accepted633766 uses one debug allocation with
4CPUs/48G and4concurrent workers processing the16shards, zero GPUs. Rebuild GT from its pinned raw
mmCIF and require exact arrays; retain missing masks and canonical fixed names.
Recheck ESMC cache alignment. Derive encountered canonical/terminal chemical
inventory bond lists from the pinned20-amino-acid CCD subset; match all previously
accepted variant graphs exactly and audit any newly encountered inventory with
independent NumPy reconstruction and finite-difference adapter gradients. No
geometry or torsion target is fed to feature generation or model inputs.

## Eight independent H100 experiments

- geometry / raw at each N=128,512,2048 (6 jobs).
- geometry N=128 constantlr3e-4 (acceleration diagnostic).
- geometry N=128 cosine lr1e-4 to1e-5 across32768updates (schedule diagnostic).

Main six: fresh seed101, unchanged acceptedcore and A+.1F+R+10D, constantAdamW
lr1e-4,wd1e-4,clip10,batch1,dropout0,frozenESMC600M,BF16trunk/FP32structure,
TF32off,c1/one-structure/one-sample,confidence/distogram frozen and off. Geometry
uses accepted parameter-free articulated adapter; raw removes it only.
No warm start, no validation labels in backward. Keep optimizer studies separate
from data-scaling conclusions. N32 anchors can be assessed from acceptedC weights,
but their different stopping/selection budgets are not equal-compute baselines.

First-wave cap32768optimizerupdates or8hours optimization+scheduled-evaluation
wall time, whichever first; Slurm12hours allows final evaluation/CPUQA. Save and
report each update's samples/residues seen, train time, eval time, elapsed time,
peakGPUmemory and Slurm reservation. Evaluate atinitial/every2048updates, plus
first completed step at2h/4h/8h. Save those wall-budget and update-budget checkpoints.
Compare both common optimizer-update checkpoints and wall-budget checkpoints;
length distributions, CPU/eval/I/O overhead and H100 reservation are explicit.
No strict equal-FLOP claim. No success/futility/plateau earlystop in scaling.
No ad hoc extension. Results at capped budget are not called converged quality;
a convergence follow-up requires another predeclared budget/protocol. Noise is
training_sampler_seed(group,exposure), with deterministic per-epoch shuffle101+e.
Report exposure distribution, not just nominal epochs.

Fixed training monitor: metadata-hash-selected32 examples within each subset;
label it TRAIN probe, not full training set. Full selected-checkpoint TRAIN metrics
are computed once at finish, with final fixed128validation at seeds12345/54321.
Validation curves include macro named-heavy-atom RMSD, CA-distance RMSE, true
TM-align CA score on observed aligned-residue subset, and observed-atom lDDT
excluding same-residue pairs. TM-align optimizes its superposition with the observed sequence correspondence
fixed through its explicit alignment argument;
RMSD/lDDT also keep strict residue/name correspondence. TM normalization is by observed
CA count; report coverage. lDDT uses reference distance<15A, thresholds.5/1/2/4A,
per-atom mean over atoms with eligible inter-residue neighbors, then protein macro.
No missing-coordinate imputation or symmetry relabeling. Primary checkpoint
selection maximizes worst-noise protein-macro validation all-atom lDDT, earliest tie.
Keep fixed-budget and final checkpoints separately so validation selection cannot
replace the equal-compute comparison. Chemistry and per-protein results reported.
TM implementation tmtools0.3.0 in an isolated evaluation dependency directory,
wheel/package hashes pinned; https://github.com/jvkersch/tmtools documents the
TM-align binding. Do not mislabel old Kabsch-only TM-like proxy as TM-align.

## Acceptance and next decision

Data acceptance binds all2176prepared packets, CCD/ESMC/source hashes and mask /
GT / adapter checks before training. Separate sequence-homology audit isCPU-only.
Longest selected training/validation shape, freshinitial hash, actualcallcounts,
finitefront/decodergradients checked before optimization. Frozen temporal test
is never read. Atfinish exactselectedcheckpointGPUreplay on32trainprobe+128val,
independentCPU metrics/geometry/projection of saved predictions, checkpoint /
source/data hashes and actualtrainingmembership/schedulechecked. Preserve failures;
no silent replacement of targets and no automatictrainingresubmission.

Positive scaling evidence requires matched-budget validation improvement with
paired per-protein reporting, confidence intervals, chemistry and homology strata.
One training initialization is exploratory; two noise seeds are not replicates.
No claim that recycling/diffusionsteps are unnecessary for generalization.
Raw Capacity-C650 already passed chemistry; its final0.652A is not chemistry-failed.
Fullconfidencecalibration,longsequences,temporaltestandESMC-inclusiveinferencecost
remain future gates. No full60k training is authorized by this pilot protocol.
