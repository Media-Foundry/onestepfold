# Bounded learned pair-state emulator pilot v1

Status: completed and independently verified (HPC3 export 630528, cache QA
630549, training 630554, decoding 630570, final QA 630576). Selected epoch 20
reduces state MSE, but decoded all-atom/CA-distance ratios to c1 are
1.014031/1.022424, failing the predeclared structural criterion. Preserve the
negative result; do not extend this configuration or automatically scale up.
See `reports/stage1b_pair_state_emulator_2026-09-18.md`. The contract below was
fixed before training; its exact pre-run source is retained in the immutable
training snapshot and hashed in the training contract.

The hypothesis is that a small shared predictor can approximate c4 pair
states from one-cycle c1 information, improving frozen-decoder all-atom output
without another full Pairformer recycle. The oracle controls support testing
this hypothesis; they do not establish that it is learnable.

## Data contract

- Use a separate derived state-cache root. Select 128 train / 64 validation
  groups with the existing length-stratified selector and seeds 101/102,
  respectively, from the already accepted controlled 512/256 groups. This is
  an explicitly nested subset, not a new split or a replacement of any parent.
- Preserve original group IDs, sequence, atom identities and split assignment.
  No residual-based selection, held-out-target replacement or temporal-test use.
- Export c1/c4 `(s_inputs,s,z)` states and native c1/c2/c4 all-heavy-atom
  coordinates under the accepted deterministic protocol: feature/trunk seed
  101, sampler seed 12345, MC off, BF16, two decoder steps, one sample, same
  checkpoint and torch kernels. Verify c2/c4 prepared-feature/trunk hashes
  against their accepted parent traces.
- Preserve state dtypes and explicit source/checkpoint/protocol/artifact hashes.
  Require longest-target cached replay and exhaustive state/coordinate/atom/
  split/finite-value QA before training. Prior corpora and snapshots stay immutable.

## First model and training contract

Use a shared, position-independent residual MLP predicting only z4-z1, retaining
s1 and s_inputs for the frozen decoder. Inputs are the current pair state,
compressed endpoint c1 single states, compressed row/column means of c1 pair
states, and clipped signed sequence separation. No c2/c4 state, coordinate,
confidence, group ID or target-derived feature may be an inference input.

The first implementation uses LayerNorm on input state channels, 32-dimensional
endpoint and context projections, a 16-dimensional separation embedding with
offset clipped to [-32,32], two hidden layers of width 256 with SiLU, and a
zero-initialized 128-dimensional output projection added to z1. It has no
dropout. Preserve pair directionality; do not symmetrize z. The architecture
and implementation must be recorded before training; no architecture sweep.

Implementation details fixed before training: share one endpoint projection
between i/j and one context projection between row/column, with separate
LayerNorms for single, local pair and context channels. Take raw row/column
means in FP32 before normalization. Row i averages z[i,:,:], column j averages
z[:,j,:]; signed separation is i-j. Concatenate local pair, endpoint i/j,
row i, column j and separation in that order (272 input channels). Linear
layers include biases. Compute the output projection and residual addition
in FP32 outside autocast, then explicitly cast corrected states to BF16 for
selection and decoder use. No architectural variants are part of this pilot.

Train seed 101, AdamW learning rate 0.0003, weight decay 0.0001, gradient clipping
10, BF16 autocast, twenty epochs. Each epoch visits each training protein once
in seeded shuffled order and samples 4,096 ordered token pairs uniformly with
replacement, including diagonal pairs. Optimize unweighted raw pair-state MSE
per channel, balancing proteins rather than weighting them by L-squared.
Full row/column context is computed from c1 only. Training predicts FP32
residuals; inference states are cast to the teacher's BF16 dtype.

Validate on all ordered pairs of each held-out protein with bounded chunks.
Select by mean per-protein pair-state MSE after BF16 output conversion; report
pooled MSE and both own-c1 error ratios as well. Include epoch-zero identity
as a valid selection candidate, so a failed learner retains an explicit c1
fallback. Verify exactly zero initial correction, gradients, absence of target
leakage, chunk equivalence and checkpoint reload before actual training.

## Required decoded evaluation and interpretation

After checkpoint selection, decode all 64 validation targets with the frozen
teacher using their c1 input/single states and predicted pair states. Rebuild
all pair-dependent caches, keep original deterministic inputs/noise, and count
actual decoder calls. Independently verify identity replay against native c1
before interpreting student coordinates.

Report all-heavy-atom RMSD, CA RMSD and CA-pair distance RMSE to native c4,
relative to both native c1 and c2. Keep atom-pooled and macro statistics,
per-protein harms and length strata. State-loss improvement alone is not success.
An exploratory learning signal requires both all-atom and CA-pair pooled errors
at most 0.95 of native c1. A useful cycle-saving result additionally needs both
metrics no worse than native c2 and measured lower inference cost; cached
decoder timing alone cannot establish this. No automatic full-data training
or 1,600-group formal-gate claim follows from a 64-group pilot.

This is a teacher-side Mini-ESM compatibility experiment. Its inputs still
require the teacher's ESM2-backed c1 representation and its decoder still uses
two evaluations. The primary ESMC-600M-conditioned, eventually one-cycle and
one-structure-evaluation all-heavy-atom predictor remains the actual objective.
ESMC adaptation, direct experimental-coordinate validation and the formal
held-out gate remain separate unfinished requirements. No novelty or calibrated
physical-distribution claim is implied.
