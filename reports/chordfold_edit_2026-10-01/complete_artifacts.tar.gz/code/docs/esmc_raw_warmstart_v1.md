# Raw权重的几何适配：唯一匹配对照实验 v1

2026-09-26。HPC3扫描45份现有合同，未找到以raw2048 best.pt为父权重的训练。
历史scaling/capacity为fresh init；已有endpoint暖启动来自geometry512，不能替代本对照。

## 要回答的问题

raw表示已有较好的CA折叠能力，但直接局部投影损失侧链质量并恶化C–N。
检验从raw权重切换到当前几何输出、通过相同结构监督继续学习，能否改善这一取舍。
这不是新decoder、教师蒸馏或固定CA实验；优化过程中CA也可改变，必须实测其质量和尾部。

仅两个arm并行，所需GPU各一张，优先HPC3相同H100型号：

- raw_continue：原raw输出继续训练。
- geometry_adapt：仅将输出切到既有ArticulatedOutput，其后计算原损失。

共同父权重为esmc_scaling_raw_2048_v1_20260919/best.pt，原step22528（11轮），
SHA256 `3d650e00292f7ac33a1076defe27595f85c24f24ec4df45c2872da58b84724e9`。
父checkpoint已由旧开发集选择，后续比较仍是探索性开发研究，非独立确认。
原2048 TRAIN、128 dev、固定原子图、ESMC-600M缓存均不变；不扩大数据，不碰冻结测试。

## 相同训练条件

所有原训练参数可学习，原confidence/distogram头继续冻结。两arm均新建AdamW，
lr1e−4、wd1e−4、clip10、batch1；不加载旧optimizer。
损失仍为 A + 0.1F + R + 10D，系数和mask不变；无teacher/新几何辅助/CA锚定损失。
Sampler从旧best之后的epoch12开始，执行同一顺序与噪声。调用计数必须为
1 Pairformer cycle、1 structure evaluation、confidence0，K=1。

新增预算8192更新或4小时优化/过程评估软上限，预留7小时Slurm完成初始及最终评估。
即4轮新增曝光，只用于有限预算适配，不是收敛或最终容量证明。每2048更新评价；2/4小时
交叉点另存，初始及最终/最佳分开报告。主要终点固定新增8192，不以最佳checkpoint代替；
未达到则标记预算未完成，不能用不匹配终点比较。

每目标两个固定噪声12345/54321分别K1，按目标平均，不best-of-K。最终保留完整TRAIN2048
最佳checkpoint分数和32 TRAIN probe过程曲线。报告新增updates/samples/residues、GPU小时，
父训练成本另列，不能忽略已花的训练成本或把cached-ESMC时间当端到端速度。

## 启动、验收和解释

运行前锁定父checkpoint/report/contract/独立QA、数据acceptance/selection、当前源码。
父权重必须匹配已验收模型状态，最长序列反传、固定头和TM/lDDT identity预检通过。
任一arm在首次更新前，全部128 dev+32 TRAIN probe、两个噪声的raw输出必须逐位复现
父checkpoint保存预测（320个）。Raw arm的原分数也须完全一致。Geometry初始投影是
待比较的损失来源，不能要求其质量与raw相同或冒充“相同初始输出”。

主比较为8192时geometry减raw的mean与worst5% mean lDDT/TM，固定target-bootstrap
5000次、seed20260926；四项下界均>0才称探索性联合质量收益。质量保持的程度、P05、
下降>0.05目标数，以及相对两arm各自step0的变化另报，不能悄悄把门槛改成非劣效。
几何单列CA手性、N–CA/CA–C/C–O及C–N误差；手性正确不等于全部化学合格。
也可出现质量/化学取舍，必须如实保留，不能仅凭某一项推广默认模型。

冻结代码/合同、更新顺序、checkpoint及预测hash独立核查。Geometry采用预先确定的
precision-v2：GPU FP32逐位重放、独立Torch/NumPy FP64公式<=1e−8、原跨精度1e−4结果
单独保留并报告质量敏感性；raw应coordinate==raw_coordinate。独立CPU核查全部保存预测
的指标和四项损失。允许按group hash固定分片加速CPU验收，但必须证明完整且无重叠覆盖。
初始重放、完整TRAIN评分和QA所需时间不计入新增优化预算，必须报告实际总资源。

无新seeds/LR搜索、额外cycle、噪声选择或测试集调参。按证据完成这一对照后再决策；
无论本开发实验是否成功，整体一步质量、尾部、化学几何和独立确认目标均未自动完成。
