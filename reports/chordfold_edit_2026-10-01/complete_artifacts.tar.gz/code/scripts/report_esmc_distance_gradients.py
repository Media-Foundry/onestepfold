#!/usr/bin/env python3
"""Render the observed-distance derivative probe without quality claims."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

from fastglycan.paired_teacher_protocol import sha256


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    args = parser.parse_args()
    report = json.loads((args.root / "report.json").read_text())
    qa = json.loads((args.root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"]
    assert qa["report_sha256"] == sha256(args.root / "report.json")
    cases = report["cases"]
    groups = ["coordinates", "all_parameters", *cases[0]["parameter_summary"]["groups"]]
    ratios, cosines = [], []
    for group in groups:
        selected = [
            c["coordinate_summary"]["global"]
            if group == "coordinates"
            else c["parameter_summary"]["global"]
            if group == "all_parameters"
            else c["parameter_summary"]["groups"][group]
            for c in cases
        ]
        ratios.append([s["local_to_base_norm_ratio"] for s in selected])
        cosines.append([s["component_cosine"] for s in selected])
    ratios, cosines = np.array(ratios, dtype=float), np.array(cosines, dtype=float)
    positive = ratios[np.isfinite(ratios) & (ratios > 0)]
    norm = LogNorm(vmin=min(positive.min(), 0.1), vmax=max(positive.max(), 1.0))
    labels = [
        f"{c['checkpoint']} epoch {c['epoch']}\n{c['provenance']['length']} residues" for c in cases
    ]
    fig, axes = plt.subplots(1, 2, figsize=(12, 6), constrained_layout=True)
    left = axes[0].imshow(np.ma.masked_invalid(ratios), aspect="auto", cmap="viridis", norm=norm)
    right = axes[1].imshow(
        np.ma.masked_invalid(cosines), aspect="auto", cmap="RdBu", vmin=-1, vmax=1
    )
    for ax, values, is_ratio in ((axes[0], ratios, True), (axes[1], cosines, False)):
        ax.set_xticks(range(len(cases)), labels, fontsize=8)
        ax.set_yticks(range(len(groups)), [g.replace("_", " ") for g in groups], fontsize=8)
        for y in range(len(groups)):
            for x in range(len(cases)):
                value = values[y, x]
                if np.isnan(value):
                    label, color = "undefined", "gray"
                else:
                    label = f"{value:.3g}×" if is_ratio else f"{value:+.3f}"
                    dark = norm(value) < 0.5 if is_ratio else abs(value) > 0.6
                    color = "white" if dark else "black"
                ax.text(x, y, label, ha="center", va="center", fontsize=8, color=color)
    axes[0].set_title("Distance gradient norm / existing-loss gradient norm")
    axes[1].set_title("Component-gradient cosine")
    fig.colorbar(left, ax=axes[0], label="Norm ratio; logarithmic color scale")
    fig.colorbar(right, ax=axes[1], label="Cosine")
    fig.suptitle("Unit-coefficient derivative probe; no parameter updates")
    fig.savefig(args.prefix.with_suffix(".png"), dpi=180)
    plt.close(fig)
    lines = [
        "# Explicit observed-distance supervision: parameter gradients",
        "",
        f"HPC3 task {report['runtime']['job_id']}; all four cases and independent CPU QA complete. "
        "Observed TRAIN inputs only, initial and accepted selected checkpoint at epoch35, "
        "35/166 residues, seed12345. No optimizer or parameter updates.",
        "",
        "B = aligned atom MSE +0.1×global-frame MSE +1×same-residue frame MSE. "
        "D = equal-category mean MSE of observed N-CA, CA-C, C-O and consecutive C-N distances. "
        "P = B+D is a unit-coefficient derivative probe, not a selected training objective.",
        "",
        "| State / residues | Coordinate D/B norm | Parameter D/B norm | Parameter cosine | "
        "Probe reconstruction error | Nonzero B/D/P tensors |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    summaries = []
    for case in cases:
        p, c = case["parameter_summary"]["global"], case["coordinate_summary"]["global"]
        counts = "/".join(str(p[f"{n}_nonzero_tensors"]) for n in ("base", "local", "probe"))
        lines.append(
            f"| {case['checkpoint']} / {case['provenance']['length']} | "
            f"{c['local_to_base_norm_ratio']:.6f} | {p['local_to_base_norm_ratio']:.6f} | "
            f"{p['component_cosine']:+.6f} | {p['relative_probe_reconstruction_error']:.4%} | "
            f"{counts} |"
        )
        summaries.append(
            {
                "checkpoint": case["checkpoint"],
                "length": case["provenance"]["length"],
                "losses": case["losses"],
                "coordinate": c,
                "parameters": p,
                "groups": case["parameter_summary"]["groups"],
            }
        )
    error = max(v for r in qa["cases"] for v in r["coordinate_gradient_relative_errors"].values())
    peak = max(c["peak_gpu_allocated_bytes"] for c in cases) / 2**30
    parameter_ratios = [c["parameter_summary"]["global"]["local_to_base_norm_ratio"] for c in cases]
    decreases_both = sum(
        all(
            c["parameter_summary"]["global"][f"{n}_derivative_along_negative_probe"] < 0
            for n in ("base", "local")
        )
        for c in cases
    )
    lines += [
        "",
        f"Unit distance-term parameter-gradient ratios span {min(parameter_ratios):.3f}–"
        f"{max(parameter_ratios):.3f}. In {decreases_both}/{len(cases)} cases, the actual negative "
        "probe gradient has negative first-order directional derivatives for both B and D. "
        "These measured ratios do not select a training weight or predict finite AdamW "
        "steps or structural success. Any follow-up protocol must be declared separately.",
        "",
        f"Independent CPU coordinate-gradient relative L2 errors are at most {error:.3g}. "
        "NumPy scalars, proper-alignment coordinate metrics, source/GT/prediction hashes, "
        "moment identities and disjoint module aggregation pass. Each original prediction "
        "replays exactly; model and input hashes stay unchanged. One trunk/one structure/"
        f"zero confidence calls per forward. Peak allocation {peak:.3f} GiB applies to these "
        "short inputs only.",
        "",
        "Full parameter-gradient tensors are not archived and CPU QA does not repeat GPU "
        "parameter backward. Mixed-precision reconstruction error is measured separately. "
        "Norm ratios and local raw-gradient directional derivatives do not predict AdamW "
        "updates or trained quality. Undefined ratios denote zero denominator, not a failed "
        "replay. D does not constrain side chains, angles, handedness or all chemistry.",
        "",
        "Interpret this audit before declaring any training loss/budget. No coefficient grid "
        "or extension of failed training is implied. Confidence, formal held-out quality and "
        "ESMC-inclusive inference cost remain unfinished.",
        "",
        f"![Gradient ratios and directions]({args.prefix.name}.png)",
    ]
    args.prefix.with_suffix(".md").write_text("\n".join(lines) + "\n")
    args.prefix.with_suffix(".json").write_text(
        json.dumps(
            {
                "complete": True,
                "report_sha256": sha256(args.root / "report.json"),
                "cases": summaries,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
