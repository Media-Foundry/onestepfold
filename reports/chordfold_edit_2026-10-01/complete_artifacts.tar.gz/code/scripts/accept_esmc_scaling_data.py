#!/usr/bin/env python3
"""Bind all prepared data/worker/source hashes before any GPU training."""

import argparse
import json
from pathlib import Path

from fastglycan.paired_teacher_protocol import sha256, write_json

p = argparse.ArgumentParser()
p.add_argument("--root", type=Path, required=True)
a = p.parse_args()
root = a.root
records = json.loads((root / "selection.json").read_text())
selected = json.loads((root / "selection_report.json").read_text())
assert selected["complete"] and sha256(root / "selection.json") == selected["selection_sha256"]
assert not (root / "acceptance.json").exists()
expected = {r["group_id"]: r for r in records}
prepared, workers, variants = {}, {}, set()
for worker in range(16):
    path = root / f"worker_{worker}.json"
    report = json.loads(path.read_text())
    assert report["complete"] and report["selection_sha256"] == selected["selection_sha256"]
    workers[str(worker)] = sha256(path)
    for item in report["examples"]:
        g = item["group_id"]
        assert g in expected and g not in prepared
        folder = root / "examples" / g
        info = json.loads((folder / "prepared.json").read_text())
        assert sha256(folder / "prepared.json") == item["prepared_sha256"]
        assert info["complete"] and info["selection"] == expected[g]
        assert (
            info["mask_independent_exact"]
            and info["esmc_exact"]
            and info["projection_independent_exact"]
        )
        for name, digest in info["files_sha256"].items():
            assert sha256(folder / name) == digest
        variants.update(info["new_variants"])
        prepared[g] = item["prepared_sha256"]
assert set(prepared) == set(expected) and len(expected) == 2176
write_json(
    root / "acceptance.json",
    {
        "complete": True,
        "groups": 2176,
        "prepared_sha256": prepared,
        "selection_sha256": sha256(root / "selection.json"),
        "worker_sha256": workers,
        "new_canonical_terminal_variants": sorted(variants),
        "esmc_manifest_sha256": sha256(root.parents[2] / "esmc_600m_final_v1/manifest.jsonl.gz"),
        "scope": "all GT/ESMC/masks/chemical geometry and source-bound worker outputs checked",
    },
)
print("Accepted all2176 scaling data packets", flush=True)
