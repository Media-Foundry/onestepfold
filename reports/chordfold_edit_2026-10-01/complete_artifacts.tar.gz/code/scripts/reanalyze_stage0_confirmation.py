#!/usr/bin/env python3
"""Read existing scores only; no model execution or frozen-test access."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path

from fastglycan.stage0_confirmation import METRICS, SETTINGS, analyze


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    source = args.archive / "source"
    payloads = {s: json.loads((source / f"{s}.json").read_text()) for s in SETTINGS}
    with gzip.open(source / "temporal_variance_v1.jsonl.gz", "rt") as handle:
        subset = [json.loads(line) for line in handle]
    ids = [row["group_id"] for row in subset]
    result = analyze(payloads, ids)
    result["source_sha256"] = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(source.iterdir())
        if p.is_file()
    }
    per_target = result.pop("per_target_compensation")
    with (args.archive / "per_target_compensation.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(per_target[0]))
        writer.writeheader()
        writer.writerows(per_target)
    (args.archive / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    lock = {
        "status": "targets_seeds_and_analysis_locked_runtime_capture_pending",
        "settings": ["c4_s5", "c4_s2", "c2_s2"],
        "samples_per_run": 1,
        "discovery_seed": 101,
        "new_seeds": [103, 107, 109, 113],
        "target_manifest": "source/temporal_variance_v1.jsonl.gz",
        "target_manifest_sha256": result["source_sha256"]["temporal_variance_v1.jsonl.gz"],
        "target_ids": ids,
        "inference_count": len(ids) * 3 * 4,
        "selection": "Original pre-score metadata-stratified subset; no score-based replacement",
        "source_scores_sha256": {s: result["source_sha256"][s + ".json"] for s in SETTINGS},
    }
    (args.archive / "repeat_lock.json").write_text(json.dumps(lock, indent=2) + "\n")
    lines = [
        "# Stage 0 最小确认实验：已有结果重分析",
        "",
        "仅重用 seed 101 的九格逐目标分数，未新增推理。"
        "所有九格目标及观测原子数量一致；不重算或替换指标。",
        "TM 指固定对应的 Kabsch TM-style 分数；"
        "all-atom lDDT 沿用旧版配对平均定义（含同残基原子对），不同于 scratch scaling 的指标。",
        "",
        "## 同指标绝对质量",
        "",
        "| 配置 | TM 均值 | TM P05 | lDDT 均值 | lDDT P05 |",
        "|---|---:|---:|---:|---:|",
    ]
    for s in SETTINGS:
        a, b = [result["absolute"][s][m] for m in METRICS]
        lines.append(
            f"| {s} | {a['mean']:.4f} | {a['p05']:.4f} | {b['mean']:.4f} | {b['p05']:.4f} |"
        )
    lines += [
        "",
        "## 双参照：同一指标同时看均值与尾部",
        "",
        "配对 bootstrap 以目标为单位、5000 次；区间为描述性 95% 区间，未经多重比较校正。"
        "JSON 包含九格完整双参照、分位数及最差 5% 均值。",
        "",
        "| 比较 | 指标 | 均值差 [95% CI] | 差值 P05 | P(差值 < −0.05) |",
        "|---|---|---:|---:|---:|",
    ]
    for s, ref in (("c4_s2", "c4_s5"), ("c2_s2", "c4_s5"), ("c2_s2", "c4_s2")):
        for m in METRICS:
            item = result["paired"][ref][s][m]
            lo, hi = item["mean_ci95"]
            risk = item["degradation_rates"]["0.05"]
            lines.append(
                f"| {s} − {ref} | {m} | {item['mean']:+.4f} [{lo:+.4f}, {hi:+.4f}] | "
                f"{item['p05']:+.4f} | {risk:.2%} |"
            )
    lines += [
        "",
        "## 每目标补偿关系",
        "",
        "定义 a = Q(c4_s2) − Q(c4_s5)，b = Q(c2_s2) − Q(c4_s2)，则总差 = a+b。",
        "这里仅描述同指标差值的代数分解；共同中间项会引入统计依赖，不能当作因果补偿证据。",
        "",
    ]
    for m in METRICS:
        c = result["compensation"][m]
        lines.append(
            f"- {m}：{c['step_gain_cycle_loss_count']}/{result['n']} 个目标满足 a>0、b<0；"
            f"其中 {c['fully_offset_count']} 个完全抵消，"
            f"{c['partially_offset_count']} 个仅部分抵消。"
        )
    lines += [
        "",
        "## 固定重复子集",
        "",
        "复用原先按长度、分辨率、apo-like、实验方法分层冻结的 128 目标；不依据本轮分数增删。",
        "",
    ]
    for key in ("c4_s2_vs_c4_s5", "c2_s2_vs_c4_s5", "c2_s2_vs_c4_s2"):
        item = result["subset_tail"][key]
        lines.append(
            f"- {key}：旧任一指标退化 >0.05 的目标 {item['joint_tail_count']} 个，"
            f"普通对照 {item['non_tail_count']} 个。"
        )
    lines += [
        "",
        "新 seeds 固定为 103/107/109/113，三配置 ×128 目标 ×4 seeds =1536 次 K=1 推理；"
        "不做 best-of-seed。",
        "目标、原尾部成员及 seeds 已写入 analysis.json / repeat_lock.json；"
        "运行时采样参数、匹配计时及冻结测试执行锁尚未完成。",
        "独立重复尚未执行，本文不声称排序或尾部已复现。现有均值与尾部均属开发集发现性证据。",
        "",
    ]
    (args.archive / "reanalysis.md").write_text("\n".join(lines))
    print(
        json.dumps(
            {
                "targets": result["n"],
                "repeat_targets": len(ids),
                "new_inferences": lock["inference_count"],
            }
        )
    )


if __name__ == "__main__":
    main()
