#!/usr/bin/env python3
"""HPC3-only completion of the already declared scaling budget/homology report."""
import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.scaling_analysis import (
    METRICS, budget_entry, distribution, homology_bin, paired_quality, target_values,
)
from fastglycan.scaling_precision_repair import verify_repair

LABELS = ("control_128", "control_512", "control_2048", "control_128_lr3",
          "control_128_cosine", "raw_128", "raw_512", "raw_2048")
BUDGETS = [("updates", n) for n in (8192, 16384, 24576, 32768)] + [
    ("wall", n) for n in (7200, 14400, 28800)]
BIN_NAMES = ("lt_030", "030_050", "050_080", "ge_080", "no_eligible_match")


def describe(values, groups):
    result = {"targets": len(groups)}
    for metric in METRICS:
        result[metric] = {k: float(v) for k, v in distribution(
            [values[g][metric] for g in groups]).items()}
    for metric in ("rmsd", "ca_coverage", "ca_chirality_agreement", "consecutive_cn_mae"):
        x = [values[g][metric] for g in groups if values[g][metric] is not None]
        result[metric] = {"evaluable_targets": len(x), "mean": float(np.mean(x)) if x else None}
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--base", type=Path, required=True)
    p.add_argument("--repair-root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    assert not a.output.exists(), "Never overwrite a completed analysis"
    source = Path(__file__).resolve().parents[1]
    manifest = json.loads((source / "analysis_manifest.json").read_text())
    for name, digest in manifest["files"].items():
        assert sha256(source / name) == digest, name
    repair_lock = verify_repair(a.repair_root, a.repair_root / "code_v1")
    repair_report = json.loads((a.repair_root / "comparison.json").read_text())
    assert repair_report["complete"]
    assert repair_report["lock_sha256"] == sha256(a.repair_root / "lock.json")
    data = a.base / "esmc_scaling_data_v1_20260919"
    homology = json.loads((data / "homology_audit.json").read_text())
    assert homology["complete"] and not homology["temporal_test_read"]
    assert not homology["changes_to_splits"]
    hashes = {str(data / "homology_audit.json"): sha256(data / "homology_audit.json"),
              str(source / "analysis_manifest.json"): sha256(source / "analysis_manifest.json"),
              str(a.repair_root / "comparison.json"): sha256(a.repair_root / "comparison.json")}
    reports, histories, contracts, qa_modes = {}, {}, {}, {}
    for label in LABELS:
        root = a.base / f"esmc_scaling_{label}_v1_20260919"
        r = json.loads((root / "report.json").read_text())
        assert r["complete"] and r["best_replay_exact"] and r["frozen_weights_unchanged"]
        for name, key in (("history.json", "history_sha256"), ("contract.json", "contract_sha256"),
                          ("training.jsonl", "training_sha256")):
            assert sha256(root / name) == r[key], (label, name)
            hashes[str(root / name)] = r[key]
        if label in repair_lock["runs"]:
            qa_path = a.repair_root / label / "independent_validation_precision_v2.json"
            qa_modes[label] = "precision-v2 accepted; original cross-precision gate failed"
            assert repair_report["runs"][label]["qa_sha256"] == sha256(qa_path)
        else:
            qa_path = root / "independent_validation.json"
            qa_modes[label] = "original QA accepted"
        qa = json.loads(qa_path.read_text())
        assert qa["complete"] and qa["checkpoint_hashes_checked"]
        assert qa["report_sha256"] == sha256(root / "report.json")
        hashes[str(qa_path)] = sha256(qa_path)
        hashes[str(root / "report.json")] = sha256(root / "report.json")
        reports[label] = r
        histories[label] = json.loads((root / "history.json").read_text())
        contracts[label] = json.loads((root / "contract.json").read_text())
    groups = sorted(r["group_id"] for r in contracts["control_128"]["validation"])
    assert len(groups) == len(set(groups)) == 128
    for c in contracts.values():
        assert sorted(r["group_id"] for r in c["validation"]) == groups
        assert c["selection_sha256"] == homology["selection_sha256"] == sha256(data / "selection.json")
        assert c["data_acceptance_sha256"] == sha256(data / "acceptance.json")
    hashes[str(data / "selection.json")] = homology["selection_sha256"]
    hashes[str(data / "acceptance.json")] = sha256(data / "acceptance.json")
    hmap = {r["group_id"]: r for r in homology["examples"]}
    assert set(hmap) == set(groups)
    bins = {g: homology_bin(hmap[g]["max_identity_coverage_ge_08"]["2048"]) for g in groups}
    strata = {name: [g for g in groups if bins[g] == name] for name in BIN_NAMES}
    result = {"complete": True, "inputs_sha256": hashes, "targets": groups,
              "scope": "Existing development results only; no training or frozen-test reads. One training seed; no multiplicity correction.",
              "budget_score_provenance": "Worker history bound by final QA hashes, not independent replay of every intermediate checkpoint",
              "bootstrap": {"count": 10000, "seed": 101, "unit": "target after mean of two fixed noises"},
              "homology_policy": homology["policy"], "fixed_2048_strata": strata,
              "per_scale_homology_counts": {str(n): dict(Counter(homology_bin(
                  hmap[g]["max_identity_coverage_ge_08"][str(n)]) for g in groups)) for n in (128, 512, 2048)},
              "runs": {}, "budget_comparisons": {}}
    for label in LABELS:
        report, history = reports[label], histories[label]
        values = {}
        budgets = {}
        for kind, amount in BUDGETS:
            key = f"{kind}_{amount}"
            entry = budget_entry(history, kind, amount)
            if entry is None:
                budgets[key] = None
                continue
            target = target_values(entry["validation"]["rows"], groups)
            values[key] = target
            budgets[key] = {"step": entry["step"], "summary": describe(target, groups),
                "per_target": target,
                "strata": {name: describe(target, gs) for name, gs in strata.items() if gs},
                "compute": {k: entry[k] for k in ("samples_seen", "residues_seen", "training_seconds",
                    "evaluation_seconds", "optimization_wall_seconds", "elapsed_seconds")}}
        views = {}
        for view in ("last_validation", "best_validation", "best_full_train"):
            gs = sorted({r["group_id"] for r in report[view]["rows"]})
            views[view] = describe(target_values(report[view]["rows"], gs), gs)
        result["runs"][label] = {"qa": qa_modes[label], "steps": report["steps"],
            "best_step": report["best_step"], "stop_reason": report["stop_reason"],
            "budgets": budgets, "selected_and_last": views,
            "final_compute": {k: report[k] for k in ("samples_seen", "residues_seen", "training_seconds",
                "evaluation_seconds_during_training", "elapsed_seconds", "peak_gpu_allocated_bytes")},
            "exposure_range": [min(report["exposures"].values()), max(report["exposures"].values())]}
    comparisons = [(f"{arm}_{big}", f"{arm}_{small}") for arm in ("control", "raw")
                   for big, small in ((512, 128), (2048, 512), (2048, 128))]
    comparisons += [(f"raw_{n}", f"control_{n}") for n in (128, 512, 2048)]
    comparisons += [("control_128_lr3", "control_128"), ("control_128_cosine", "control_128")]
    for candidate, reference in comparisons:
        key = f"{candidate}_minus_{reference}"
        result["budget_comparisons"][key] = {}
        for kind, amount in BUDGETS:
            budget = f"{kind}_{amount}"
            x, y = (result["runs"][label]["budgets"][budget] for label in (candidate, reference))
            if x is None or y is None:
                result["budget_comparisons"][key][budget] = None
                continue
            result["budget_comparisons"][key][budget] = {
                "all": paired_quality(x["per_target"], y["per_target"], groups),
                "strata": {name: paired_quality(x["per_target"], y["per_target"], gs)
                           for name, gs in strata.items()},
            }
    lines = ["# Scaling-v1：匹配预算与同源性分层补充报告", "",
        "八组训练均已完成并拥有对应QA。两项原跨精度失败经事后precision-v2补验接受，原失败保留。",
        "固定128开发目标；两noise先按目标平均，不是best-of-K或训练seed重复。冻结测试未访问。",
        "中间预算分数来自已绑定hash的worker历史；不声称全部中间checkpoint经过独立坐标重算。",
        "配对target bootstrap 10000次，seed101，未做多重比较校正；不作收敛、新fold或端到端速度声明。", "",
        "## 同源性", "", "身份按aligned residues计算，coverage>=0.8仅针对较短序列。下表相对最大2048 TRAIN固定分层。", "",
        "|分层|目标数|", "|---|---:|"]
    lines += [f"|{name}|{len(gs)}|" for name, gs in strata.items()]
    for kind, amount in BUDGETS:
        budget = f"{kind}_{amount}"
        lines += ["", f"## {budget}", "", "缺失表示未达到该预算，不使用最佳或最近checkpoint替代。", "",
            "|配置|更新数|lDDT|TM|worst5 lDDT|worst5 TM|CA手性|C–N MAE Å|训练h|优化墙钟h|",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for label in LABELS:
            r = result["runs"][label]["budgets"][budget]
            if r is None:
                lines.append(f"|{label}|缺失|—|—|—|—|—|—|—|—|")
                continue
            s, c = r["summary"], r["compute"]
            lines.append(f"|{label}|{r['step']}|{s[METRICS[0]]['mean']:.4f}|{s[METRICS[1]]['mean']:.4f}|"
                f"{s[METRICS[0]]['worst5_mean']:.4f}|{s[METRICS[1]]['worst5_mean']:.4f}|"
                f"{s['ca_chirality_agreement']['mean']:.4f}|{s['consecutive_cn_mae']['mean']:.4f}|"
                f"{c['training_seconds']/3600:.3f}|{c['optimization_wall_seconds']/3600:.3f}|")
        lines += ["", "|比较|lDDT均值差 [95% CI]|TM均值差 [95% CI]|任一指标下降>0.05|", "|---|---|---|---:|"]
        for key, entries in result["budget_comparisons"].items():
            r = entries[budget]
            if r is None:
                continue
            cells = []
            for m in METRICS:
                x = r["all"]["metrics"][m]["statistics"]["mean"]
                cells.append(f"{x['delta']:+.4f} [{x['ci95'][0]:+.4f}, {x['ci95'][1]:+.4f}]")
            lines.append(f"|{key}|" + "|".join(cells) + f"|{r['all']['joint_loss_gt_005_count']}/128|")
    lines += ["", "逐目标值、尾部区间、各同源性分层配对结果、各规模同源性计数、最佳/最后checkpoint及完整TRAIN摘要见 analysis.json。",
        "wall crossing包含训练期间评估开销，实际超限量见JSON，不等于严格等FLOPs；最佳开发分数不能替代匹配预算结论。",
        "只报告CA手性和C–N摘要不代表完整化学几何门槛通过。该报告不改变权重1.0实验或一步折叠目标。"]
    a.output.mkdir(parents=True)
    write_json(a.output / "analysis.json", result)
    (a.output / "report.md").write_text("\n".join(lines) + "\n")
    print("Scaling budget/homology report complete", flush=True)


if __name__ == "__main__":
    main()
