#!/usr/bin/env python3
"""Independent checkpoint, full-pair and every-atom validation of the learned pilot."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch

from fastglycan.all_atom_metrics import compare_coordinates, summarize_coordinates
from fastglycan.models.pair_state_factory import build_pair_state_model
from fastglycan.pair_state_cache import read_cache
from fastglycan.pair_state_training import load_training_states, validate_states
from fastglycan.paired_teacher_protocol import balanced_partitions, sha256, write_json
from fastglycan.response_cache import read_response_cache
from fastglycan.response_training import ResponseDataset, response_loss, validate_responses
from fastglycan.teacher_pairing import feature_digest, tensor_digest
from fastglycan.teacher_runtime import setup_teacher


def verify_sources(report, code_root):
    for name, digest in report["source_sha256"].items():
        assert sha256(code_root / name) == digest, name
    for name, digest in report.get("runtime_source_sha256", {}).items():
        assert sha256(Path(name)) == digest, name


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--decoded-root", type=Path, required=True)
    parser.add_argument("--decode-code", type=Path, required=True)
    parser.add_argument("--training-code", type=Path, required=True)
    parser.add_argument("--qa-root", type=Path,
                        help="new directory for QA outputs/work; decoded artifacts stay immutable")
    parser.add_argument("--prior-response-diagnostic", type=Path,
                        help="failed strict replay for a same-process cuDNN policy check")
    args = parser.parse_args()
    output = args.decoded_root.resolve()
    qa_output = args.qa_root.resolve() if args.qa_root else output
    if args.qa_root:
        qa_output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    first = json.loads((output / "worker_0.json").read_text())
    cache, training = Path(first["cache_root"]), Path(first["training_root"])
    _, records = read_cache(cache, accepted=True)
    records = [r for r in records if r.split == "validation"]
    acceptance = json.loads((cache / "control/acceptance.json").read_text())
    trained = json.loads((training / "report.json").read_text())
    assert trained["complete"] and trained["checkpoint_revalidation_exact"]
    verify_sources(trained["contract"], args.training_code)
    for label in ("best", "last"):
        assert sha256(training / f"{label}.pt") == trained[f"{label}_sha256"]
    assert sha256(training / "history.json") == trained["history_sha256"]
    history = json.loads((training / "history.json").read_text())
    assert [r["epoch"] for r in history] == list(range(21))
    selected_epoch = min(history, key=lambda r: r["validation"]["macro_mse"])["epoch"]
    assert selected_epoch == trained["best_epoch"]
    checkpoint = torch.load(training / "best.pt", map_location="cpu", weights_only=False)
    assert checkpoint["epoch"] == selected_epoch and checkpoint["contract"] == trained["contract"]
    torch.manual_seed(101)
    learner = build_pair_state_model(checkpoint["config"])
    assert feature_digest(learner.state_dict()) == trained["contract"]["initial_weights_sha256"]
    if "matched_baseline" in trained["contract"]:
        lineage = trained["contract"]["matched_baseline"]
        parent_path = Path(lineage["root"]) / "report.json"
        audit_path = Path(lineage["component_audit_root"]) / "independent_validation.json"
        assert sha256(parent_path) == lineage["report_sha256"]
        assert sha256(audit_path) == lineage["component_audit_sha256"]
        parent = json.loads(parent_path.read_text())
        shared = {k: v for k, v in learner.state_dict().items() if not k.startswith("triangle_")}
        assert feature_digest(shared) == lineage["shared_initial_weights_sha256"]
        assert lineage["shared_initial_weights_sha256"] == parent["contract"][
            "initial_weights_sha256"]
        assert all(trained["contract"][key] == parent["contract"][key]
                   for key in lineage["matched_fields"])
    learner.load_state_dict(checkpoint["model"])
    device = torch.device("cuda")
    learner.to(device).eval()
    if trained["contract"]["schema_version"] == "decoder-response-pilot-v1":
        contract = trained["contract"]
        response_root = Path(contract["response_root"])
        response_protocol, _ = read_response_cache(response_root, accepted=True)
        assert Path(response_protocol["state_root"]) == cache
        assert sha256(response_root / "control/acceptance.json") == contract[
            "response_acceptance_sha256"]
        assert sha256(response_root / "control/protocol.json") == contract[
            "response_protocol_sha256"]
        lineage = contract["matched_pointwise_baseline"]
        parent_root = Path(lineage["root"])
        assert sha256(parent_root / "report.json") == lineage["report_sha256"]
        assert sha256(parent_root / "best.pt") == lineage["best_sha256"]
        parent = json.loads((parent_root / "report.json").read_text())
        assert all(contract[k] == parent["contract"][k] for k in lineage["matching_fields"])
        assert trained["teacher_final_weights_sha256"] == contract["teacher_initial_weights_sha256"]
        longest = max(records, key=lambda r: r.sequence_length)
        runner, _, _, provenance = setup_teacher([longest], qa_output / "response_qa_work")
        assert provenance["checkpoint_sha256"] == contract["checkpoint_sha256"]
        runner.model.eval().requires_grad_(False)
        assert feature_digest(runner.model.state_dict()) == contract[
            "teacher_initial_weights_sha256"]
        inputs = ResponseDataset(response_root, records)
        # Historical response training/export/decode disabled matmul TF32 via
        # Protenix, but retained PyTorch's default cuDNN TF32. The generic state
        # validator disabled both; its extra override changes fused conv2d in
        # the FP32 decoder. Reproduce the actual training policy, not a new one.
        response_cudnn_tf32 = contract["runtime"].get("cudnn_allow_tf32", True)
        torch.backends.cudnn.allow_tf32 = response_cudnn_tf32
        if args.prior_response_diagnostic:
            prior = json.loads(args.prior_response_diagnostic.read_text())
            assert not prior["exact"]
            assert prior["training_report_sha256"] == sha256(training / "report.json")
            assert prior["expected"] == trained["selected_validation"]
            assert prior["runtime"]["cudnn_allow_tf32"] is False
            example = inputs[0]
            probes = {}
            with torch.no_grad():
                for label, flag in (("disabled", False), ("training", response_cudnn_tf32)):
                    torch.backends.cudnn.allow_tf32 = flag
                    loss, response, pair, _ = response_loss(
                        learner, runner.model.diffusion_module, example, device, grad=False)
                    probes[label] = {"mse": float(loss), "pair_sha256": tensor_digest(pair),
                                     "response_sha256": tensor_digest(response),
                                     "cudnn_allow_tf32": flag}
                    del loss, response, pair
            assert probes["disabled"]["mse"] == prior["actual"]["examples"][0]["mse"]
            assert probes["training"]["mse"] == prior["expected"]["examples"][0]["mse"]
            assert probes["disabled"]["pair_sha256"] == probes["training"]["pair_sha256"]
            write_json(qa_output / "response_precision_audit.json", {
                "complete": True, "group_id": example["group_id"], "probes": probes,
                "prior_diagnostic_sha256": sha256(args.prior_response_diagnostic),
                "same_pair_different_decoder_policy": True,
                "training_policy_reproduces_saved_response_loss_exactly": True,
            })
            del example
        repeated = validate_responses(learner, runner.model.diffusion_module, inputs, device)
        write_json(qa_output / "checkpoint_response_revalidation.json", {
            "exact": repeated == trained["selected_validation"],
            "expected": trained["selected_validation"], "actual": repeated,
            "training_report_sha256": sha256(training / "report.json"),
            "best_sha256": trained["best_sha256"],
            "runtime": {
                "torch": torch.__version__, "device": torch.cuda.get_device_name(),
                "deterministic": torch.are_deterministic_algorithms_enabled(),
                "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
                "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
                "float32_matmul_precision": torch.get_float32_matmul_precision(),
            },
        })
    else:
        inputs = load_training_states(cache, records)
        repeated = validate_states(learner, inputs, device)
    assert repeated == trained["selected_validation"]
    del inputs
    partitions = balanced_partitions(records, 4)
    all_rows, worker_hashes = [], {}
    for index in range(4):
        path = output / f"worker_{index}.json"
        report = json.loads(path.read_text())
        assert report["complete"] and report["worker"] == index
        assert [r["group_id"] for r in report["examples"]] == [
            r.group_id for r in partitions[index]]
        assert report["training_report_sha256"] == sha256(training / "report.json")
        assert report["best_sha256"] == trained["best_sha256"]
        assert report["cache_acceptance_sha256"] == sha256(cache / "control/acceptance.json")
        assert report["checkpoint_sha256"] == acceptance["checkpoint_sha256"]
        assert sha256(Path(report["checkpoint_path"])) == report["checkpoint_sha256"]
        assert sha256(output / "work" / f"worker_{index}/input.json") == report["input_sha256"]
        verify_sources(report, args.decode_code)
        for row in report["examples"]:
            group = row["group_id"]
            directory, native_dir = output / "examples" / group, cache / "examples" / group
            native_path = native_dir / "trace.json"
            assert sha256(native_path) == row["cache_trace_sha256"]
            assert row["cache_trace_sha256"] == acceptance["trace_sha256"][group]
            native = json.loads(native_path.read_text())
            assert row == json.loads((directory / "trace.json").read_text())
            predicted = directory / "predicted_pair.pt"
            assert sha256(predicted) == row["predicted_pair_sha256"]
            predicted = torch.load(predicted, map_location="cpu", weights_only=True)
            assert tensor_digest(predicted) == row["predicted_pair_tensor_sha256"]
            assert predicted.dtype == torch.bfloat16 and torch.isfinite(predicted).all()
            state = torch.load(native_dir / "c1.pt", map_location="cpu", weights_only=True)
            with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
                recomputed = learner.predict_full(state[1].to(device), state[2].to(device)).cpu()
            assert torch.equal(recomputed, predicted)
            assert list(predicted.shape) == [row["length"], row["length"], 128]
            coordinates, inventory = {}, None
            for label in ("c1", "c2", "c4", "identity", "student"):
                cached = label.startswith("c")
                spec = native["conditions"][label] if cached else row["conditions"][label]
                path = (native_dir if cached else directory) / f"{label}.npz"
                assert sha256(path) == spec["coordinates_sha256"]
                with np.load(path, allow_pickle=False) as saved:
                    coordinates[label] = saved["coordinate"]
                    assert coordinates[label].shape == (row["atom_count"], 3)
                    assert np.isfinite(coordinates[label]).all()
                    current = [saved[key] for key in ("atom_name", "residue_id", "element")]
                    if inventory is None:
                        inventory = current
                    else:
                        assert all(np.array_equal(a, b) for a, b in zip(
                            inventory, current, strict=True))
                if not cached:
                    assert spec["decoder_nfe"] == 2 and spec["trunk_calls"] == 0
                    trunk, diffusion = spec["trace"]
                    expected = native["conditions"]["c1"]["trace"]
                    assert trunk["cycles"] == 1 and not trunk["mc_dropout"]
                    assert trunk["input_feature_sha256"] == expected[0]["input_feature_sha256"]
                    assert trunk["single_sha256"] == expected[0]["single_sha256"]
                    assert trunk["pair_sha256"] == (
                        expected[0]["pair_sha256"] if label == "identity"
                        else row["predicted_pair_tensor_sha256"])
                    assert diffusion["explicit_seed"] == 12345
                    assert diffusion["rng_at_sampler_entry"] == expected[1]["rng_at_sampler_entry"]
            assert row["identity_all_atoms_exact"]
            assert np.array_equal(coordinates["identity"], coordinates["c1"])
            assert row["conditions"]["identity"]["decoder_cache_sha256"] == native["conditions"][
                "c1"]["decoder_cache_sha256"]
            assert (inventory[0] == "CA").sum() == row["length"]
            assert not np.any(inventory[2] == "H")
            comparisons = {label: compare_coordinates(coordinates[label], coordinates["c4"],
                                                       inventory[0] == "CA")
                           for label in ("c1", "c2", "student")}
            for label, metrics in comparisons.items():
                for metric, value in metrics.items():
                    assert math.isclose(value, row["comparisons_to_c4"][label][metric],
                                        abs_tol=2e-5, rel_tol=2e-5)
            all_rows.append({"group_id": group, "length": row["length"],
                             "atom_count": row["atom_count"], "comparisons_to_c4": comparisons})
            print(json.dumps({"validated": len(all_rows), "group_id": group}), flush=True)
        worker_hashes[str(index)] = sha256(output / f"worker_{index}.json")
    assert len(all_rows) == len({r["group_id"] for r in all_rows}) == 64
    summary = summarize_coordinates(all_rows)
    strata = {}
    for name, lower, upper in (("20-128", 20, 128), ("129-256", 129, 256),
                               ("257-512", 257, 512), ("513-1024", 513, 1024)):
        subset = [r for r in all_rows if lower <= r["length"] <= upper]
        if subset:
            strata[name] = {"count": len(subset), **summarize_coordinates(subset)}
    result = {"complete": True, "best_epoch": selected_epoch,
              "training_report_sha256": sha256(training / "report.json"),
              "worker_report_sha256": worker_hashes, "selected_validation": repeated,
              "summary": summary, "length_strata": strata, "examples": all_rows,
              "all_64_identity_replays_exact": True, "all_64_pair_predictions_recomputed": True,
              "checkpoint_validation_repeated_exact": True,
              "checkpoint_validation_kind": (
                  "response" if trained["contract"]["schema_version"] == "decoder-response-pilot-v1"
                  else "state"),
              "decoder_nfe_per_condition": 2, "source_and_artifact_hashes_verified": True,
              "end_to_end_latency_measured": False, "formal_1600_gate_passed": False,
              "scope": "64 held-out teacher-side examples; teacher-relative, not experimental GT",
              "validator_source_sha256": sha256(Path(__file__))}
    if trained["contract"]["schema_version"] == "decoder-response-pilot-v1":
        result["response_numeric_policy"] = {
            "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
            "origin": ("training contract" if "cudnn_allow_tf32" in trained["contract"]["runtime"]
                       else "historical response-v1 source and PyTorch runtime default"),
        }
        result["checkpoint_response_revalidation_sha256"] = sha256(
            qa_output / "checkpoint_response_revalidation.json")
        if args.prior_response_diagnostic:
            result["response_precision_audit_sha256"] = sha256(
                qa_output / "response_precision_audit.json")
    write_json(qa_output / "independent_validation.json", result)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
