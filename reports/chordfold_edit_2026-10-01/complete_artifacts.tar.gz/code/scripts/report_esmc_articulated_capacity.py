#!/usr/bin/env python3
"""Plot observed-GT geometry capacity curves with explicit provisional status."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--comparison-root", type=Path)
    args = parser.parse_args()
    root = args.root
    contract = json.loads((root / "contract.json").read_text())
    frame_weight = contract["frame_weight"]
    assert (
        frame_weight == 0.1
        and contract["same_residue_weight"] == 1
        and contract["distance_weight"] == 10
    )
    history = json.loads((root / "history.json").read_text())
    training = [json.loads(line) for line in (root / "training.jsonl").read_text().splitlines()]
    report = (
        json.loads((root / "report.json").read_text()) if (root / "report.json").exists() else None
    )
    qa = (
        json.loads((root / "independent_validation.json").read_text())
        if (root / "independent_validation.json").exists()
        else None
    )
    best = min(history, key=lambda row: row["summary"]["selection_score"])
    status = (
        "running; provisional"
        if report is None
        else (
            "complete, independently verified"
            if qa and qa["complete"]
            else "training finished; QA pending"
        )
    )
    seeds = ("12345", "54321")
    epochs = [r["epoch"] for r in history]
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    for seed, style in zip(seeds, ("-", "--"), strict=True):
        for metric, color, label in (
            ("pooled_all_heavy_atom_rmsd", "#2268a5", "Atom RMSD"),
            ("pooled_ca_pair_distance_rmse", "#be7025", "CA distance"),
        ):
            axes[0, 0].plot(
                epochs,
                [r["conditions"][seed]["summary"][metric] for r in history],
                style,
                color=color,
                label=f"{label}, seed {seed}",
                marker="o" if len(epochs) == 1 else None,
            )
        axes[1, 1].plot(
            epochs,
            [1 - r["conditions"][seed]["summary"]["handedness_failure_fraction"] for r in history],
            style,
            label=f"Seed {seed}",
            marker="o" if len(epochs) == 1 else None,
        )
    axes[0, 0].axhline(1, color="gray", linestyle=":")
    axes[0, 0].set(
        title="Fixed evaluation seeds, same 32 training proteins", ylabel="Pooled error (Å)"
    )
    axes[0, 1].plot(
        [r["epoch"] for r in training],
        [r["mean_aligned_atom_mse"] for r in training],
        label="Aligned atom MSE",
    )
    axes[0, 1].plot(
        [r["epoch"] for r in training],
        [frame_weight * r["mean_local_frame_mse"] for r in training],
        label=f"{frame_weight:g} × local-frame MSE",
    )
    axes[0, 1].plot(
        [r["epoch"] for r in training],
        [r["mean_same_residue_frame_mse"] for r in training],
        label="Same-residue frame MSE (weight1)",
    )
    axes[0, 1].plot(
        [r["epoch"] for r in training],
        [10 * r["mean_observed_distance_mse"] for r in training],
        label="10 × observed distance MSE",
    )
    axes[0, 1].set(
        yscale="log",
        title="Training components; fixed loss and varied noise",
        ylabel="Mean loss contribution (Å²)",
    )
    for name in ("N_CA", "CA_C", "C_O", "consecutive_C_N"):
        axes[1, 0].plot(
            epochs,
            [
                max(
                    r["conditions"][seed]["summary"]["local_distances"][name]["rmse"]
                    for seed in seeds
                )
                for r in history
            ],
            label=name,
            marker="o" if len(epochs) == 1 else None,
        )
    axes[1, 0].axhline(0.15, color="gray", linestyle=":", label="Intra-residue threshold")
    axes[1, 0].axhline(0.30, color="gray", linestyle="--", label="Consecutive C-N threshold")
    axes[1, 0].set(
        title="Worst evaluation seed: local distances",
        ylabel="Pooled distance RMSE (Å)",
        yscale="log",
    )
    axes[1, 1].axhline(0.95, color="gray", linestyle=":", label="Gate 95%")
    axes[1, 1].set(
        title="Observed-GT CA handedness agreement", ylabel="Agreement fraction", ylim=(0, 1.02)
    )
    for ax in axes.flat:
        ax.set_xlabel("Epoch")
        ax.set_xlim(0, max(1, training[-1]["epoch"]))
        ax.axvline(best["epoch"], color="gray", linestyle=":", alpha=0.5)
        ax.grid(alpha=0.2)
        ax.legend(frameon=False, fontsize=8)
    fig.suptitle(f"Articulated output interface — {status}")
    fig.savefig(args.prefix.with_suffix(".png"), dpi=170)
    plt.close(fig)
    summary = {
        "status": status,
        "frame_weight": frame_weight,
        "same_residue_weight": 1.0,
        "distance_weight": 10.0,
        "job_id": contract["runtime"]["job_id"],
        "last_training_epoch": training[-1]["epoch"],
        "last_evaluated_epoch": epochs[-1],
        "best_epoch": best["epoch"],
        "best_joint_summary": best["summary"],
        "best_conditions": {k: v["summary"] for k, v in best["conditions"].items()},
    }
    if report:
        summary.update(
            {
                k: report[k]
                for k in (
                    "joint_capacity_pass",
                    "stop_reason",
                    "steps",
                    "last_epoch",
                    "peak_gpu_allocated_bytes",
                    "elapsed_seconds",
                )
            }
        )
    if qa:
        summary["independent_validation_complete"] = qa["complete"]
    diagnostic_path = root / "coordinate_diagnostics.json"
    diagnostic = json.loads(diagnostic_path.read_text()) if diagnostic_path.exists() else None
    if diagnostic:
        assert report is not None and diagnostic["complete"] and not diagnostic["baseline_only"]
        assert (
            diagnostic["current_report_sha256"]
            == hashlib.sha256((root / "report.json").read_bytes()).hexdigest()
        )
        summary["coordinate_diagnostics"] = {
            key: {
                "shape": {n: v["summary"] for n, v in value["shape"].items()},
                "sampler_agreement": value["sampler_agreement"]["summary"],
            }
            for key, value in diagnostic["conditions"].items()
        }
    args.prefix.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    lines = [
        "# Controlled articulated-output capacity experiment",
        "",
        f"Status: {status}. HPC3 task {summary['job_id']}; "
        f"latest training epoch {summary['last_training_epoch']}, "
        f"latest evaluation epoch {epochs[-1]}, selected epoch {best['epoch']}.",
        "",
        "Same 32 TRAIN proteins (35–166 residues), accepted observed experimental labels, "
        "frozen ESMC-600M. Fresh random initialization, one trunk/one structure call/one sample, "
        f"frozen confidence heads. Loss is aligned atom MSE +{frame_weight:g}×global-frame MSE "
        "+1×separately normalized same-residue frame MSE +10×observed-distance MSE; "
        "training sampler seeds vary by group and epoch. Both fixed evaluation seeds "
        "participate in checkpoint selection. This is not a held-out protein evaluation.",
        "",
        "| Metric at selected checkpoint | Seed12345 | Seed54321 |",
        "| --- | ---: | ---: |",
    ]
    for key in (
        "pooled_all_heavy_atom_rmsd",
        "pooled_ca_rmsd",
        "pooled_ca_pair_distance_rmse",
        "atom_rmsd_le_2_count",
    ):
        values = [best["conditions"][seed]["summary"][key] for seed in seeds]
        lines.append(f"| {key} | {values[0]:.6f} | {values[1]:.6f} |")
    for name in ("N_CA", "CA_C", "C_O", "consecutive_C_N"):
        values = [
            best["conditions"][seed]["summary"]["local_distances"][name]["rmse"] for seed in seeds
        ]
        lines.append(f"| {name} distance RMSE (Å) | {values[0]:.6f} | {values[1]:.6f} |")
    values = [
        1 - best["conditions"][seed]["summary"]["handedness_failure_fraction"] for seed in seeds
    ]
    lines += [
        f"| GT-relative handedness agreement | {values[0]:.2%} | {values[1]:.2%} |",
        "| Observed-distance MSE (Å²), before weight10 | "
        f"{best['conditions']['12345']['mean_observed_distance_mse']:.6f} | "
        f"{best['conditions']['54321']['mean_observed_distance_mse']:.6f} |",
        "| Same-residue frame MSE (Å²) | "
        f"{best['conditions']['12345']['mean_same_residue_frame_mse']:.6f} | "
        f"{best['conditions']['54321']['mean_same_residue_frame_mse']:.6f} |",
        "",
        f"Joint normalized score{best['summary']['selection_score']:.6f}; limiting criterion "
        f"`{best['summary']['limiting_criterion']}`. Passing requires score<=1 across both seeds. "
        "The gate covers coordinate accuracy, local distances, handedness and 29-of-32 protein "
        "accuracy; it is not complete stereochemical validation. Consecutive C–N observations "
        "do not certify bonds.",
        "",
        "Loss curves average updates while model parameters and noise change. Evaluation uses "
        "one fixed checkpoint per epoch. All loss coefficients remain identical to the control. "
        + "Only the parameter-free output adapter changes against accepted631937; all other "
        "training settings remain identical.",
        "",
    ]
    if report:
        lines += [
            f"Stop: `{report['stop_reason']}` after{report['steps']} updates. Joint capacity gate: "
            f"`{report['joint_capacity_pass']}`. All 64 best predictions replay exactly after "
            "checkpoint reload; inputs/frozen heads unchanged. Peak training allocation "
            f"{report['peak_gpu_allocated_bytes'] / 2**30:.3f} GiB applies to this short subset, "
            "not full-length inference.",
            "",
        ]
        if qa:
            lines += [
                f"Independent CPU QA passes; maximum coordinate-metric discrepancy "
                f"{qa['max_metric_error_angstrom']:.3g} Å; frame scalar discrepancy "
                f"{qa['max_frame_scalar_error']:.3g} Å². "
                f"Same-residue scalar discrepancy {qa['max_same_residue_scalar_error']:.3g} Å². "
                f"Distance scalar discrepancy {qa['max_distance_scalar_error']:.3g} Å². "
                f"Heavy-artifact checks: `{qa['heavy_artifacts_checked']}`.",
                "",
            ]
        if not report["joint_capacity_pass"]:
            lines += [
                "Do not extend this configuration or promote it to larger-data training. "
                "Interpret the failed "
                "criteria and accepted curves before declaring another experiment.",
                "",
            ]
    if diagnostic:
        lines += [
            "| CPU coordinate diagnosis | Fixed-RNG baseline selected | "
            "Varied-RNG initial | Varied-RNG selected |",
            "| --- | ---: | ---: | ---: |",
        ]
        columns = [
            diagnostic["conditions"][name]
            for name in ("fixed_rng_baseline_best", "varied_rng_initial", "varied_rng_best")
        ]
        for metric, label in (
            ("pooled_atom_rmsd", "Two-seed aligned atom disagreement (Å)"),
            ("pooled_ca_distance_rmse", "Two-seed CA-distance disagreement (Å)"),
        ):
            lines.append(
                f"| {label} | "
                + " | ".join(f"{v['sampler_agreement']['summary'][metric]:.6f}" for v in columns)
                + " |"
            )
        for seed in seeds:
            lines.append(
                f"| Within-residue RMS radius, seed {seed} (Å) | "
                + " | ".join(
                    f"{v['shape'][seed]['summary']['predicted_within_residue_radius']:.6f}"
                    for v in columns
                )
                + " |"
            )
        selected_shape = diagnostic["conditions"]["varied_rng_best"]["shape"]
        lines += [
            "",
            "Experimental within-residue RMS radius is 2.196170 Å. Two-seed agreement "
            "alone does not establish correctness. Selected seed12345 residue-centroid error is "
            f"{selected_shape['12345']['summary']['centroid_error_rmse']:.6f} Å and centered "
            "coordinate error is "
            f"{selected_shape['12345']['summary']['internal_shape_error_rmse']:.6f} "
            "Å, including local orientation. Radius alone does not certify local bond geometry "
            "or handedness. Comparisons with the fixed-RNG baseline use different training and "
            "selection protocols; they do not isolate a causal effect of noise variation.",
            "",
            "Interpret the accepted parameter-gradient audit together with the final joint "
            "geometry criteria before any further experiment. Do not start a coefficient grid "
            "or extend training on the basis of falling global RMSD alone.",
            "",
        ]
    if frame_weight == 0.1:
        comparison_root = args.comparison_root or root.parent / "esmc_distance_capacity_2026-09-18"
        baseline_report = json.loads((comparison_root / "report.json").read_text())
        baseline_qa = json.loads((comparison_root / "independent_validation.json").read_text())
        digest = hashlib.sha256((comparison_root / "report.json").read_bytes()).hexdigest()
        assert baseline_qa["complete"] and baseline_qa["report_sha256"] == digest
        assert digest == contract["matched_report_sha256"]
        baseline_history = json.loads((comparison_root / "history.json").read_text())
        fig, axes = plt.subplots(2, 2, figsize=(11, 7), constrained_layout=True)
        for curve, condition_label, selected_epoch in (
            (baseline_history, "Cartesian output", baseline_report["best_epoch"]),
            (history, "Articulated output", best["epoch"]),
        ):
            epoch_values = [r["epoch"] for r in curve]
            values = [
                [r["summary"]["selection_score"] for r in curve],
                [r["summary"]["worst_seed_pooled_atom_rmsd"] for r in curve],
                [
                    max(
                        c["summary"]["local_distances"]["consecutive_C_N"]["rmse"]
                        for c in r["conditions"].values()
                    )
                    for r in curve
                ],
                [
                    min(
                        1 - c["summary"]["handedness_failure_fraction"]
                        for c in r["conditions"].values()
                    )
                    for r in curve
                ],
            ]
            for ax, metric in zip(axes.flat, values, strict=True):
                (line,) = ax.plot(
                    epoch_values,
                    metric,
                    label=condition_label,
                    marker="o" if len(curve) == 1 else None,
                )
                ax.axvline(selected_epoch, color=line.get_color(), linestyle=":", alpha=0.5)
        for ax, title, threshold, scale in zip(
            axes.flat,
            (
                "Joint normalized score",
                "Worst-seed atom RMSD (Å)",
                "Worst-seed consecutive C-N RMSE (Å)",
                "Worst-seed handedness agreement",
            ),
            (1, 1, 0.30, 0.95),
            ("log", "linear", "log", "linear"),
            strict=True,
        ):
            ax.axhline(threshold, color="gray", linestyle="--")
            ax.set(title=title, xlabel="Epoch", yscale=scale)
            ax.grid(alpha=0.2)
            ax.legend(frameon=False)
        fig.suptitle(f"Controlled articulated-output comparison — {status}")
        comparison_path = args.prefix.with_name(args.prefix.name + "_comparison.png")
        fig.savefig(comparison_path, dpi=170)
        plt.close(fig)
        lines += [
            "",
            "Controlled comparison with accepted Cartesian-output run631937: "
            "same32 inputs, initialization, noise/shuffle schedule, precision, optimizer, "
            "budget and joint stopping/selection rules. All64 raw initial predictions match "
            "before optimization. Actual stopping epochs can differ under the same rule. "
            + (
                "Both runs are complete and independently verified."
                if report and qa and qa["complete"]
                else "Current-run curves remain provisional until completion and independent QA."
            ),
            "",
            "| Selected checkpoint metric | Cartesian output | Articulated output |",
            "| --- | ---: | ---: |",
        ]
        old_best = baseline_report["best"]
        for label, old_value, new_value in (
            ("Selected epoch", baseline_report["best_epoch"], best["epoch"]),
            (
                "Joint score",
                old_best["summary"]["selection_score"],
                best["summary"]["selection_score"],
            ),
            (
                "Worst-seed atom RMSD (Å)",
                old_best["summary"]["worst_seed_pooled_atom_rmsd"],
                best["summary"]["worst_seed_pooled_atom_rmsd"],
            ),
        ):
            lines.append(f"| {label} | {old_value:.6f} | {new_value:.6f} |")
        old_by_epoch = {row["epoch"]: row for row in baseline_history}
        new_by_epoch = {row["epoch"]: row for row in history}
        shared_epoch = max(old_by_epoch.keys() & new_by_epoch.keys())
        matched_old, matched_new = old_by_epoch[shared_epoch], new_by_epoch[shared_epoch]
        if shared_epoch > 0:
            lines += [
                "",
                f"At the latest shared evaluation epoch {shared_epoch}, worst-seed atom RMSD is "
                f"{matched_old['summary']['worst_seed_pooled_atom_rmsd']:.6f} Å "
                "for Cartesian output and "
                f"{matched_new['summary']['worst_seed_pooled_atom_rmsd']:.6f} Å "
                "with the articulated output interface. "
                f"Selected epochs are {baseline_report['best_epoch']} and {best['epoch']} "
                "under the same selection rules. Different training durations can contribute "
                "to selected-checkpoint differences; they do not by themselves establish "
                "faster coordinate fitting.",
                "",
                f"| Same epoch {shared_epoch} metric | Cartesian output | Articulated output |",
                "| --- | ---: | ---: |",
            ]
            for label, values in (
                (
                    "Joint score",
                    [r["summary"]["selection_score"] for r in (matched_old, matched_new)],
                ),
                (
                    "Worst-seed C–N RMSE (Å)",
                    [
                        max(
                            c["summary"]["local_distances"]["consecutive_C_N"]["rmse"]
                            for c in r["conditions"].values()
                        )
                        for r in (matched_old, matched_new)
                    ],
                ),
                (
                    "Worst-seed handedness agreement",
                    [
                        min(
                            1 - c["summary"]["handedness_failure_fraction"]
                            for c in r["conditions"].values()
                        )
                        for r in (matched_old, matched_new)
                    ],
                ),
            ):
                lines.append(f"| {label} | {values[0]:.6f} | {values[1]:.6f} |")
        lines += ["", f"![Controlled comparison]({comparison_path.name})", ""]
    lines += [
        "Formal held-out quality, confidence training/calibration and full ESMC-inclusive "
        "inference cost remain unfinished. Source snapshots, hashes, GT/inventory/coordinate "
        "artifacts and histories accompany this report.",
        "",
        f"![Training and evaluation curves]({args.prefix.name}.png)",
    ]
    args.prefix.with_suffix(".md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
