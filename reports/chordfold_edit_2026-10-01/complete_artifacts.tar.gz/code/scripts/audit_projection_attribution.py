#!/usr/bin/env python3
"""Localize existing projection changes without running a folding model."""

import argparse
import json
import statistics
from pathlib import Path

import numpy as np

from fastglycan.experimental_metrics import prediction_atom37
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.projection_attribution import cn_attribution, quality_attribution
from onestepfold.data.gt_materializer import ATOM37_INDEX, ATOM37_NAMES


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args().root
    lock = json.loads((root / "lock.json").read_text())
    for name, digest in lock["inputs_sha256"].items():
        assert sha256(Path(name)) == digest, name
    manifest = root / "code_v1/attribution_manifest.json"
    assert sha256(manifest) == lock["source_manifest_sha256"]
    for name, digest in json.loads(manifest.read_text()).items():
        assert sha256(root / "code_v1" / name) == digest
    output = root / "result_v1"
    assert not output.exists(), "Preserve partial work; inspect failure before retry"
    output.mkdir()
    parent = Path(lock["parent_root"])
    oldrows = [json.loads(line) for line in (parent / "result_v1/rows.jsonl").read_text().splitlines()]
    parent_lock = json.loads((parent / "lock.json").read_text())
    contract = json.loads((Path(parent_lock["raw_root"]) / "contract.json").read_text())
    records = {r["group_id"]: r for r in contract["train_probe"]}
    assert len(records) == 32 and len(oldrows) == 64
    assert set(records) <= {r["group_id"] for r in contract["train"]}
    assert not set(records).intersection(r["group_id"] for r in contract["validation"])
    data = Path(contract["data_root"])
    rows = []
    for old in oldrows:
        group = old["group_id"]
        record = records[group]
        pred_path = parent / "result_v1" / old["prediction_path"]
        assert sha256(pred_path) == old["prediction_sha256"]
        with np.load(pred_path) as handle:
            inventory = {k: handle[k] for k in ("atom_name", "residue_id", "element")}
            raw, available = prediction_atom37(inventory | {"coordinate": handle["raw_coordinate"]}, record["sequence"])
            projected, pavailable = prediction_atom37(inventory | {"coordinate": handle["coordinate"]}, record["sequence"])
        assert np.array_equal(available, pavailable)
        with np.load(data / "examples" / group / "gt.npz") as handle:
            gt = handle["atom37_positions"].astype(np.float64)
            mask = available & handle["atom37_mask"] & handle["residue_mask"][:, None]
        raw, projected = raw.astype(np.float64), projected.astype(np.float64)
        ri, ai = np.nonzero(mask)
        names = np.asarray(ATOM37_NAMES)[ai]
        quality = quality_attribution(raw[mask], projected[mask], gt[mask], ri, names)
        for arm, index in (("raw", 0), ("projected", 3)):
            assert abs(quality["state_mean_lddt"][index] - old[arm]["quality"]["all_atom_lddt"]) < 1e-12
        c, n = ATOM37_INDEX["C"], ATOM37_INDEX["N"]
        valid = mask[:-1, c] & mask[1:, n]
        left = np.flatnonzero(valid)
        right = left + 1
        assert len(left)
        cn = cn_attribution(raw[left, c], raw[right, n], projected[left, c], projected[right, n], gt[left, c], gt[right, n])
        for arm, index in (("raw", 0), ("projected", 3)):
            assert abs(cn["state_mae"][index] - old[arm]["geometry"]["local_distances"]["consecutive_C_N"]["mae"]) < 1e-12
        row = {"group_id": group, "noise": old["noise"], "input_sha256": old["prediction_sha256"], "quality": quality, "cn": cn}
        rows.append(row)
        with (output / "rows.jsonl").open("a") as handle:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
        print(json.dumps({"completed": len(rows), "total": 64}), flush=True)
    assert {(r["group_id"], r["noise"]) for r in rows} == {(g, s) for g in records for s in (12345, 54321)}
    per_target = []
    for group in sorted(records):
        part = [r for r in rows if r["group_id"] == group]
        per_target.append({
            "group_id": group,
            "quality": {key: statistics.fmean(r["quality"]["moving_group"][key] for r in part) for key in ("a", "b", "interaction", "total")},
            "cn": {key: statistics.fmean(r["cn"]["moving_endpoint"][key] for r in part) for key in ("a", "b", "interaction", "total")},
        })
    summary = {domain: {key: statistics.fmean(t[domain][key] for t in per_target) for key in ("a", "b", "interaction", "total")} for domain in ("quality", "cn")}
    summary["center_atom"] = {}
    for name in ("CA", "N", "C", "O", "sidechain"):
        centers = [r["quality"]["center_atom"][name] for r in rows]
        summary["center_atom"][name] = {
            "contribution_to_total": statistics.fmean(c["contribution_to_total"] for c in centers),
            "evaluable_rows": sum(c["atoms"] > 0 for c in centers),
            **{key: statistics.fmean(c[key] for c in centers if c[key] is not None) for key in ("raw", "projected", "mean_displacement")},
        }
    for domain in ("quality", "cn"):
        assert abs(summary[domain]["a"] + summary[domain]["b"] - summary[domain]["total"]) < 1e-12
    assert abs(sum(c["contribution_to_total"] for c in summary["center_atom"].values()) - summary["quality"]["total"]) < 1e-12
    report = {"complete": True, "summary": summary, "per_target": per_target, "targets": 32, "rows": 64,
              "lock_sha256": sha256(root / "lock.json"), "rows_sha256": sha256(output / "rows.jsonl"),
              "scope": "Descriptive TRAIN attribution; hybrid coordinates are not deployable candidates. No network calls, updates, dev/test coordinate access or significance tests.",
              "factor_meaning": {"quality": {"a": "backbone move", "b": "sidechain move"}, "cn": {"a": "C endpoint move", "b": "next N endpoint move"}}}
    write_json(output / "report.json", report)
    lines = ["# Projection change attribution", "", report["scope"], "", "|Change|A attribution|B attribution|Interaction|Total|", "|---|---:|---:|---:|---:|"]
    for domain in ("quality", "cn"):
        x = summary[domain]
        label = "lDDT (A backbone, B sidechain)" if domain == "quality" else "C-N MAE (A C, B next N)"
        lines.append(f"|{label}|{x['a']:+.8f}|{x['b']:+.8f}|{x['interaction']:+.8f}|{x['total']:+.8f}|")
    lines += ["", "A/B each include half the interaction; do NOT add the interaction again. Attribution depends on the predefined two factors and observed score, not unique physical causality.", "", "|Center atom|Raw lDDT|Projected lDDT|Contribution to whole-protein lDDT change|Mean displacement A|", "|---|---:|---:|---:|---:|"]
    for name, values in summary["center_atom"].items():
        lines.append(f"|{name}|{values['raw']:.6f}|{values['projected']:.6f}|{values['contribution_to_total']:+.8f}|{values['mean_displacement']:.6f}|")
    lines += ["", "Center atom scores include all inter-residue atom neighbors: a fixed CA can change score when its neighbors move. Contributions sum to the full score change; category means must not be summed. Historical development-selected checkpoint, only 32 TRAIN probes, two fixed noises averaged, no independent-training or generalization claim."]
    (output / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"complete": True, "summary": summary}), flush=True)


if __name__ == "__main__":
    main()
