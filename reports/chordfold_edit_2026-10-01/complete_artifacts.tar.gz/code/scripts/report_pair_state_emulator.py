#!/usr/bin/env python3
"""Make standalone training/structure plots and a concise verified pilot report."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--report-base", type=Path, required=True)
    args = parser.parse_args()
    training = json.loads((args.archive / "training/report.json").read_text())
    history = json.loads((args.archive / "training/history.json").read_text())
    result = json.loads((args.archive / "decoded/independent_validation.json").read_text())
    assert result["complete"] and training["complete"]
    summary = result["summary"]
    figure, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    epochs = [row["epoch"] for row in history]
    axes[0, 0].plot(epochs[1:], [r["train_sampled_online_mse"] for r in history[1:]],
                    label="Train: sampled online loss")
    axes[0, 0].plot(epochs, [r["validation"]["macro_mse"] for r in history],
                    label="Validation: all pairs, macro")
    axes[0, 0].set(xlabel="Epoch", ylabel="Raw pair-state MSE", title="Loss curves")
    axes[0, 0].legend(fontsize=8)
    for key, label in (("macro_ratio", "Per-protein mean"), ("pooled_ratio", "Pair-pooled")):
        axes[0, 1].plot(epochs, [r["validation"][key] for r in history], label=label)
    axes[0, 1].axhline(1, color="gray", linestyle="--", linewidth=1)
    axes[0, 1].axvline(result["best_epoch"], color="gray", linestyle=":", linewidth=1)
    axes[0, 1].set(xlabel="Epoch", ylabel="Validation MSE / native c1 MSE",
                    title="State improvement after BF16 conversion")
    axes[0, 1].legend(fontsize=8)
    metrics = ("all_heavy_atom_rmsd", "ca_rmsd", "ca_pair_distance_rmse")
    locations = np.arange(3)
    for index, label in enumerate(("c1", "c2", "student")):
        axes[1, 0].bar(locations + (index - 1) * 0.25,
                       [summary[label]["pooled_" + key] for key in metrics],
                       width=0.25, label=label)
    axes[1, 0].set(xticks=locations, xticklabels=["All atoms", "CA", "CA distances"],
                    ylabel="Pooled error to c4 (angstrom)", title="Frozen-decoder structure errors")
    axes[1, 0].legend(fontsize=8)
    rows = result["examples"]
    x = [r["comparisons_to_c4"]["c1"]["all_heavy_atom_rmsd"] for r in rows]
    y = [r["comparisons_to_c4"]["student"]["all_heavy_atom_rmsd"] for r in rows]
    points = axes[1, 1].scatter(x, y, c=[r["length"] for r in rows], s=22, cmap="viridis")
    top = max(x + y) * 1.05
    axes[1, 1].plot([0, top], [0, top], color="gray", linestyle="--", linewidth=1)
    axes[1, 1].set(xlabel="Native c1 all-atom RMSD (angstrom)",
                    ylabel="Student all-atom RMSD (angstrom)", title="64 held-out proteins")
    figure.colorbar(points, ax=axes[1, 1], label="Residues")
    figure.suptitle("C1 pair-state emulator: 128 train / 64 validation; teacher-relative only")
    figure.savefig(args.report_base.with_suffix(".png"), dpi=180)
    plt.close(figure)
    lines = ["# Learned c1 pair-state pilot — 2026-09-18", "",
             "The predeclared 128/64 teacher-side pilot is complete and independently verified.",
             f"Selected epoch: **{result['best_epoch']}** of 20; model: "
             f"**{training['contract']['parameter_count']:,} parameters**.", "",
             "| Metric | Native c1 | Native c2 | Learned state | Learned/c1 | Learned/c2 |",
             "|---|---:|---:|---:|---:|---:|"]
    for key in metrics:
        values = [summary[label]["pooled_" + key] for label in ("c1", "c2", "student")]
        ratios = [summary[f"student_to_{base}_pooled_ratios"][key] for base in ("c1", "c2")]
        numbers = " | ".join(f"{v:.6f}" for v in values + ratios)
        lines.append(f"| Pooled {key} (A) | {numbers} |")
    state = result["selected_validation"]
    lines += ["", f"Validation state-MSE ratios: macro **{state['macro_ratio']:.6f}**, "
              f"pair-pooled **{state['pooled_ratio']:.6f}** after BF16 conversion.",
              "Identity epoch 0 was eligible for checkpoint selection.", "",
              "Exploratory joint <=0.95-of-c1 criterion: "
              f"**{summary['exploratory_learning_signal']}**. "
              f"Joint parity with c2: **{summary['parity_with_c2']}**.",
              "Cached decoding does not measure end-to-end latency. This result does not pass the "
              "formal 1,600-group gate or establish accuracy against experimental structures.", "",
              "| Harm count (out of 64) | Versus c1 | Versus c2 |",
              "|---|---:|---:|"]
    for key in metrics:
        counts = [summary["student"][f"{key}_worse_than_{base}_count"] for base in ("c1", "c2")]
        lines.append(f"| {key} | {counts[0]} | {counts[1]} |")
    state_rows = {r["group_id"]: r for r in state["examples"]}
    state_gains = np.array([1 - state_rows[r["group_id"]]["mse"] /
                           state_rows[r["group_id"]]["c1_mse"] for r in rows])
    diagnostics = {"state_mse_improved_count": int((state_gains > 0).sum()),
                   "median_state_mse_relative_gain": float(np.median(state_gains))}
    for metric in ("all_heavy_atom_rmsd", "ca_pair_distance_rmse"):
        gains = np.array([1 - r["comparisons_to_c4"]["student"][metric] /
                          r["comparisons_to_c4"]["c1"][metric] for r in rows])
        diagnostics[metric + "_gain_pearson_with_state_gain"] = float(
            np.corrcoef(state_gains, gains)[0, 1])
    diagnostics["both_structure_metrics_improved_count"] = sum(all(
        r["comparisons_to_c4"]["student"][metric] < r["comparisons_to_c4"]["c1"][metric]
        for metric in ("all_heavy_atom_rmsd", "ca_pair_distance_rmse")) for r in rows)
    args.report_base.with_suffix(".json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    lines += ["", f"State MSE improves for {diagnostics['state_mse_improved_count']}/64 proteins; "
              "both structure metrics improve for "
              f"{diagnostics['both_structure_metrics_improved_count']}/64. "
              "This pilot shows that reducing raw state MSE is insufficient as a "
              "structure-quality selection proxy for this model.", "",
              "Decision: preserve this as a negative structural result; do not extend epochs "
              "or scale up this raw-MSE configuration. Before another training run, diagnose "
              "which predicted state components affect the frozen decoder using training-only "
              "controls. Decoder sensitivity or a decoder-related loss is a hypothesis to test, "
              "not an established remedy."]
    lines += ["", "Validation is exhaustive: source/checkpoint/history/state/coordinate hashes, "
              "all 64 recomputed learned pair tensors, exact selected-checkpoint state-MSE replay, "
              "all 64 atom-exact c1 decoder replays, fixed c1 singles, fixed sampler noise, "
              "and all recomputed structure metrics. Every cached condition uses two decoder NFE "
              "and zero trunk-stack calls.", "",
              "The model takes c1 pair/single states, c1 row/column context and signed sequence "
              "separation only. It predicts z4-z1 with a shared residual MLP; c4 labels are never "
              "inference inputs. Loss is raw state MSE, with 4,096 ordered pairs sampled per "
              "protein visit, AdamW 0.0003/0.0001, clipping 10, BF16 and twenty epochs.", "",
              "HPC3 jobs: export 630528_[0-3], cache QA 630549, training 630554, "
              "decoding 630570_[0-3], independent final QA 630576. Immutable snapshots and "
              "artifacts are under `/data/user/shuang886/Folding/stage1b/coordinate_refiner/`.", "",
              "The original objective remains an ESMC-600M-conditioned, MSA-free all-heavy-atom "
              "predictor with one cycle and eventually one structure evaluation. "
              "This Mini-ESM/ESM2 "
              "compatibility experiment still needs two decoder evaluations. No full-data training "
              "or automatic extension follows from this pilot.", "",
              f"![Training and structure validation]({args.report_base.name}.png)", ""]
    args.report_base.with_suffix(".md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
