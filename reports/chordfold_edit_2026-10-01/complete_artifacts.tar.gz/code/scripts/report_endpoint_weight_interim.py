#!/usr/bin/env python3
"""Snapshot a scheduled development checkpoint without accepting a final result."""
import argparse
import hashlib
import json
from pathlib import Path

from fastglycan.endpoint_weight_followup import verify_followup
from fastglycan.paired_teacher_protocol import sha256, write_json
from report_endpoint_objective import METRICS, comparison, summaries, vectors


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--step',type=int,required=True)
    a=p.parse_args()
    root=a.root.resolve()
    assert a.step in range(1024,8192,1024)
    lock=verify_followup(root/'lock.json',root/'code_v1')
    paths={'gt_only':Path(lock['baseline_root'])/'gt_only',
           'endpoint_01':Path(lock['baseline_root'])/'endpoint','endpoint_10':root/'endpoint_w1'}
    entries, hashes={}, {}
    for label,path in paths.items():
        raw=(path/'history.json').read_bytes()
        hashes[label]=hashlib.sha256(raw).hexdigest()
        if label!='endpoint_10':
            assert hashes[label]==lock['inputs_sha256'][str(path/'history.json')]
        history=json.loads(raw)
        matches=[h for h in history if h['step']==a.step]
        assert len(matches)==1, (label,a.step,'scheduled evaluation not complete')
        entries[label]=matches[0]
    contract=json.loads((paths['gt_only']/'contract.json').read_text())
    groups=sorted(r['group_id'] for r in contract['validation'])
    assert len(groups)==128
    values={label:{m:vectors(h['validation']['rows'],m,groups) for m in METRICS}
            for label,h in entries.items()}
    result={'complete':True,'provisional':True,'final_acceptance':False,'step':a.step,
            'lock_sha256':sha256(root/'lock.json'),'source_sha256':sha256(Path(__file__)),
            'source_history_sha256_at_read':hashes,'targets':groups,
            'summary':{label:{m:{k:float(v) for k,v in summaries(x).items()} for m,x in metrics.items()}
                       for label,metrics in values.items()},
            'paired':{label:{m:comparison(values['endpoint_10'][m],values[label][m]) for m in METRICS}
                      for label in ('gt_only','endpoint_01')},
            'scope':'Scheduled development monitoring only. Worker-reported scores; no independent QA of this intermediate checkpoint. No stop/config/seed selection or change to the 8192-update primary endpoint.'}
    output=root/f'interim_{a.step}_v1'
    output.mkdir(exist_ok=False)
    write_json(output/'evaluation_snapshot.json',entries)
    result['evaluation_snapshot_sha256']=sha256(output/'evaluation_snapshot.json')
    write_json(output/'comparison.json',result)
    lines=[f'# 权重1.0中间观察：{a.step}更新（非最终验收）','',
           '固定128开发目标、两个预定噪声按目标平均。以下为worker报告指标；尚未完成本checkpoint独立重算，不是最终质量结论。','','|方法|mean lDDT|worst5% lDDT|mean TM|worst5% TM|','|---|---:|---:|---:|---:|']
    for label,r in result['summary'].items():
        lines.append(f"|{label}|{r[METRICS[0]]['mean']:.4f}|{r[METRICS[0]]['worst5_mean']:.4f}|{r[METRICS[1]]['mean']:.4f}|{r[METRICS[1]]['worst5_mean']:.4f}|")
    lines+=['','|权重1.0相对对照|指标|mean Δ [95% CI]|worst5% Δ [95% CI]|','|---|---|---|---|']
    for label,metrics in result['paired'].items():
        for m,r in metrics.items():
            cols=[]
            for stat in ('mean','worst5_mean'):
                v=r[stat];cols.append(f"{v['delta']:+.4f} [{v['ci95'][0]:+.4f}, {v['ci95'][1]:+.4f}]")
            lines.append(f'|{label}|{m}|'+ '|'.join(cols)+'|')
    lines+=['','配对bootstrap5000次，seed20260926；探索性target区间，不是独立训练重复，也未对多次中间查看做多重检验校正。训练继续原8192更新/4小时上限，不据此挑配置或提前宣布成功。']
    (output/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'complete':True,'provisional':True,'step':a.step}),flush=True)


if __name__=='__main__':main()
