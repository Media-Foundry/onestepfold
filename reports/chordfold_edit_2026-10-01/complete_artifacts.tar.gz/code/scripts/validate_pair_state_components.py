#!/usr/bin/env python3
"""Independently reconstruct pair components, conditioning and structure metrics."""
from __future__ import annotations

import argparse
import json
import math
import statistics
from pathlib import Path

import numpy as np
import torch

from fastglycan.all_atom_metrics import compare_coordinates
from fastglycan.models.pair_state_emulator import PairStateEmulator
from fastglycan.pair_state_cache import read_cache
from fastglycan.pair_state_components import (
    LABELS,
    component_statistics,
    condition_pair,
    select_audit_records,
)
from fastglycan.paired_teacher_protocol import balanced_partitions, sha256, write_json
from fastglycan.teacher_pairing import feature_digest, tensor_digest
from fastglycan.teacher_runtime import setup_teacher
from onestepfold.training.coordinate_refiner import group_id_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    args = parser.parse_args()
    output = args.audit_root.resolve()
    reports = [json.loads((output / f"worker_{i}.json").read_text()) for i in range(4)]
    cache, training = Path(reports[0]["cache_root"]), Path(reports[0]["training_root"])
    _, records = read_cache(cache, accepted=True)
    selected = select_audit_records(records)
    acceptance = json.loads((cache / "control/acceptance.json").read_text())
    trained = json.loads((training / "report.json").read_text())
    partitions = balanced_partitions(selected, 4)
    for index, report in enumerate(reports):
        assert report["complete"] and report["worker"] == index
        assert report["selection"] == [r.group_id for r in selected]
        assert report["selection_sha256"] == group_id_digest(selected)
        assert report["training_report_sha256"] == sha256(training / "report.json")
        assert report["best_sha256"] == trained["best_sha256"] == sha256(training / "best.pt")
        assert report["cache_acceptance_sha256"] == sha256(cache / "control/acceptance.json")
        assert report["checkpoint_sha256"] == acceptance["checkpoint_sha256"]
        assert sha256(Path(report["checkpoint_path"])) == report["checkpoint_sha256"]
        assert sha256(output / "work" / f"worker_{index}/input.json") == report["input_sha256"]
        assert [r["group_id"] for r in report["examples"]] == [
            r.group_id for r in partitions[index]]
        for name, digest in report["source_sha256"].items():
            assert sha256(args.code_root / name) == digest, name
        for name, digest in report["runtime_source_sha256"].items():
            assert sha256(Path(name)) == digest, name
    runner, dataset, seed_everything, provenance = setup_teacher(selected, output / "qa_work_v2")
    assert provenance["checkpoint_sha256"] == acceptance["checkpoint_sha256"]
    checkpoint = torch.load(training / "best.pt", map_location="cpu", weights_only=False)
    learner = PairStateEmulator(**checkpoint["config"]).to(runner.device).eval()
    learner.load_state_dict(checkpoint["model"])
    rows = {r["group_id"]: r for report in reports for r in report["examples"]}
    assert len(rows) == 8
    examples = []
    for index, record in enumerate(selected):
        group = record.group_id
        row = rows[group]
        directory, native_dir = output / "examples" / group, cache / "examples" / group
        assert json.loads((directory / "trace.json").read_text()) == row
        native_path = native_dir / "trace.json"
        assert sha256(native_path) == row["cache_trace_sha256"] == acceptance["trace_sha256"][group]
        native = json.loads(native_path.read_text())
        states = {}
        for label in ("c1", "c4"):
            path = native_dir / f"{label}.pt"
            assert sha256(path) == native["states"][label]["sha256"]
            states[label] = torch.load(path, map_location="cpu", weights_only=True)
        c1, c4 = states["c1"], states["c4"]
        path = directory / "predicted_pair.pt"
        assert sha256(path) == row["predicted_pair_sha256"]
        predicted = torch.load(path, weights_only=True, map_location="cpu")
        assert tensor_digest(predicted) == row["predicted_pair_tensor_sha256"]
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            recomputed = learner.predict_full(
                c1[1].to(runner.device), c1[2].to(runner.device)).cpu()
        assert torch.equal(recomputed, predicted)
        components = component_statistics(c1[2], predicted, c4[2])
        assert components == row["components"]
        assert math.isclose(sum(p["target_fraction"] for p in components.values()), 1, rel_tol=1e-5)
        seed_everything(101, deterministic=True)
        data, atoms, error = dataset[index]
        assert not error and data["sample_name"] == group
        assert feature_digest(data["input_feature_dict"]) == native["prepared_features_sha256"]
        # Protenix.forward generates relp before entering the state boundary.
        feature_keys = ("asym_id", "residue_index", "entity_id", "token_index", "sym_id")
        relp_inputs = {key: data["input_feature_dict"][key].to(runner.device)
                       for key in feature_keys}
        relp = runner.model.relative_position_encoding.generate_relp(relp_inputs)["relp"]
        coordinates, inventory = {}, None
        for label in ("c1", "c2", "c4"):
            path = native_dir / f"{label}.npz"
            assert sha256(path) == native["conditions"][label]["coordinates_sha256"]
            with np.load(path) as saved:
                coordinates[label] = saved["coordinate"]
                inventory = [saved[k] for k in ("atom_name", "residue_id", "element")]
        assert all(np.array_equal(a, b) for a, b in zip(
            inventory, (atoms.atom_name, atoms.res_id, atoms.element), strict=True))
        target_cache = None
        assert set(row["conditions"]) == set(LABELS)
        for label in LABELS:
            spec = row["conditions"][label]
            pair = condition_pair(c1[2], predicted, c4[2], label)
            assert tensor_digest(pair) == spec["pair_tensor_sha256"]
            assert spec["decoder_nfe"] == 2 and spec["trunk_calls"] == 0
            trunk, diffusion = spec["trace"]
            reference = "c4" if label == "replay_c4" else "c1"
            assert not trunk["mc_dropout"] and trunk["cycles"] == (4 if reference == "c4" else 1)
            assert trunk["single_sha256"] == native["conditions"][reference]["trace"][0][
                "single_sha256"]
            assert trunk["pair_sha256"] == spec["pair_tensor_sha256"]
            assert trunk["input_feature_sha256"] == native["conditions"]["c1"]["trace"][0][
                "input_feature_sha256"]
            assert diffusion["explicit_seed"] == 12345
            assert diffusion["rng_at_sampler_entry"] == native["conditions"]["c1"]["trace"][1][
                "rng_at_sampler_entry"]
            enabled = not runner.configs.skip_amp.sample_diffusion
            assert all(r["cache_autocast_enabled"] == enabled for r in reports)
            with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16, enabled=enabled):
                pair_cache = runner.model.diffusion_module.diffusion_conditioning.prepare_cache(
                    relp, pair.to(runner.device), False).cpu()
            assert tensor_digest(pair_cache) == spec["decoder_cache_sha256"]["pair_z"]
            assert list(pair_cache.shape) == spec["conditioned_pair_shape"]
            assert str(pair_cache.dtype) == spec["conditioned_pair_dtype"]
            if target_cache is None:
                target_cache = pair_cache
            for key, value in (
                ("raw_pair_mse", float((pair.float() - c4[2].float()).square().mean())),
                ("conditioned_pair_mse", float((pair_cache.float() - target_cache.float())
                                               .square().mean())),
            ):
                assert value == spec[key]
            path = directory / f"{label}.npz"
            assert sha256(path) == spec["coordinates_sha256"]
            with np.load(path) as saved:
                coordinate = saved["coordinate"]
                assert coordinate.shape == (row["atom_count"], 3)
                assert np.isfinite(coordinate).all()
                for expected, key in zip(inventory, ("atom_name", "residue_id", "element"),
                                         strict=True):
                    assert np.array_equal(expected, saved[key])
            if label in ("identity", "replay_c4"):
                assert np.array_equal(coordinate, coordinates[reference])
                assert spec["decoder_cache_sha256"] == native["conditions"][reference][
                    "decoder_cache_sha256"]
            calculated = compare_coordinates(coordinate, coordinates["c4"], inventory[0] == "CA")
            for key, value in calculated.items():
                assert math.isclose(value, row["comparisons_to_c4"][label][key],
                                    rel_tol=2e-5, abs_tol=2e-5)
        assert compare_coordinates(coordinates["c2"], coordinates["c4"], inventory[0] == "CA") == (
            row["comparisons_to_c4"]["c2"])
        examples.append(row)
        print(json.dumps({"validated": len(examples), "group_id": group}), flush=True)
    summary = {}
    for label in (*LABELS, "c2"):
        summary[label] = {}
        for metric in ("all_heavy_atom_rmsd", "ca_rmsd", "ca_pair_distance_rmse"):
            values = [r["comparisons_to_c4"][label][metric] for r in examples]
            weights = [r["atom_count"] if metric == "all_heavy_atom_rmsd" else (
                r["length"] if metric == "ca_rmsd" else r["length"] * (r["length"] - 1) // 2)
                for r in examples]
            summary[label]["pooled_" + metric] = math.sqrt(sum(
                v**2 * w for v, w in zip(values, weights, strict=True)) / sum(weights))
            summary[label]["median_" + metric] = statistics.median(values)
            summary[label]["better_than_c1_" + metric + "_count"] = sum(
                value < r["comparisons_to_c4"]["identity"][metric]
                for value, r in zip(values, examples, strict=True))
        if label != "c2":
            for metric in ("raw_pair_mse", "conditioned_pair_mse"):
                summary[label]["macro_" + metric] = statistics.mean(
                    r["conditions"][label][metric] for r in examples)
                summary[label]["macro_ratio_" + metric] = statistics.mean(
                    r["conditions"][label][metric] / r["conditions"]["identity"][metric]
                    for r in examples)
    result = {"complete": True, "scope": "8 training-only target-aware controls; no new training",
              "worker_report_sha256": {
                  str(i): sha256(output / f"worker_{i}.json") for i in range(4)},
              "all_conditioned_pair_caches_recomputed_exactly": True,
              "all_c1_c4_atom_replays_exact": True, "all_pair_components_recomputed": True,
              "all_learned_pair_predictions_recomputed_exactly": True,
              "decoder_nfe": 2, "trunk_stack_calls": 0,
              "validator_source_sha256": sha256(Path(__file__)),
              "qa_runtime": provenance, "summary": summary, "examples": examples}
    write_json(output / "independent_validation.json", result)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
