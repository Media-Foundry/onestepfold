#!/usr/bin/env python3
"""Fixed-step monitoring of the warm-start pair; never substitute for final acceptance."""

import argparse
import hashlib
import json
from pathlib import Path

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.raw_warmstart import verify_lock
from report_endpoint_objective import METRICS, comparison, summaries, vectors
from report_raw_warmstart import geometry


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--step", type=int, choices=(2048, 4096, 6144))
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    source = Path(__file__).resolve().parent
    manifest = json.loads((source / "manifest.json").read_text())
    assert manifest["source_sha256"] == sha256(Path(__file__))
    verify_lock(root, root / "code_v1")
    paths = {label: root / label for label in ("raw_continue", "geometry_adapt")}
    contracts = {label: json.loads((path / "contract.json").read_text()) for label, path in paths.items()}
    for key in ("parent_checkpoint_sha256", "initial_weights_sha256", "train", "validation", "train_probe", "optimizer", "evaluation_seeds", "max_steps", "soft_seconds"):
        assert contracts["raw_continue"][key] == contracts["geometry_adapt"][key], key
    assert contracts["raw_continue"]["arm"] == "raw" and contracts["geometry_adapt"]["arm"] == "control"
    groups = sorted(r["group_id"] for r in contracts["raw_continue"]["validation"])
    probes = sorted(r["group_id"] for r in contracts["raw_continue"]["train_probe"])
    assert len(groups) == len(set(groups)) == 128 and len(probes) == 32
    if args.preflight_only:
        print(json.dumps({"complete": True, "scope": "imports, source lock and paired contracts only; no interim quality analysis", "source_sha256": sha256(Path(__file__))}), flush=True)
        return
    assert args.step is not None
    output = root / f"interim_{args.step}_v1"
    assert not output.exists(), "Preserve completed/partial snapshots; no blind rerun"
    entries, inputs = {}, {}
    for label, folder in paths.items():
        raw = (folder / "history.json").read_bytes()
        history = json.loads(raw)
        current = [h for h in history if h["step"] == args.step]
        initial = [h for h in history if h["step"] == 0]
        assert len(current) == len(initial) == 1, (label, args.step, "both scheduled evaluations must be complete")
        entries[label] = {"initial": initial[0], "current": current[0]}
        inputs[label] = {"history_sha256_at_read": hashlib.sha256(raw).hexdigest(), "contract_sha256": sha256(folder / "contract.json")}
    result = {"complete": True, "provisional": True, "final_acceptance": False, "step": args.step,
              "source_sha256": sha256(Path(__file__)), "manifest_sha256": sha256(source / "manifest.json"),
              "lock_sha256": sha256(root / "lock.json"), "source_inputs": inputs, "targets": groups, "arms": {},
              "scope": "Scheduled worker-score monitoring, not independent coordinate QA. No configuration, stopping, seed or best-checkpoint selection."}
    values = {}
    for label, entry in entries.items():
        arm = {}
        values[label] = {}
        for stage, view in entry.items():
            vectors_here = {metric: vectors(view["validation"]["rows"], metric, groups) for metric in METRICS}
            values[label][stage] = vectors_here
            arm[stage] = {metric: {key: float(value) for key, value in summaries(vector).items()} for metric, vector in vectors_here.items()}
            arm[stage]["geometry"] = geometry(view["validation"]["rows"])
        arm["current_train_probe"] = {metric: {key: float(value) for key, value in summaries(vectors(entry["current"]["train_probe"]["rows"], metric, probes)).items()} for metric in METRICS}
        arm["within_arm_current_minus_initial"] = {metric: comparison(values[label]["current"][metric], values[label]["initial"][metric]) for metric in METRICS}
        result["arms"][label] = arm
    result["paired_geometry_minus_raw"] = {metric: comparison(values["geometry_adapt"]["current"][metric], values["raw_continue"]["current"][metric]) for metric in METRICS}
    output.mkdir()
    write_json(output / "evaluation_snapshot.json", entries)
    result["snapshot_sha256"] = sha256(output / "evaluation_snapshot.json")
    write_json(output / "comparison.json", result)
    lines = [f"# Warm-start中间观察：{args.step}次新增更新", "", "固定128开发目标、两个预定K1噪声按目标平均。以下是worker分数，尚未经过本checkpoint独立坐标验收。", "", "|方法|阶段|mean lDDT|worst5% lDDT|mean TM|worst5% TM|C–N MAE Å|chirality|", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for label, arm in result["arms"].items():
        for stage in ("initial", "current"):
            s = arm[stage]
            lines.append(f"|{label}|{stage}|{s[METRICS[0]]['mean']:.5f}|{s[METRICS[0]]['worst5_mean']:.5f}|{s[METRICS[1]]['mean']:.5f}|{s[METRICS[1]]['worst5_mean']:.5f}|{s['geometry']['distance_mae']['consecutive_C_N']:.5f}|{s['geometry']['chirality_macro']:.5f}|")
    lines += ["", "|Geometry − raw|mean Δ [95% CI]|worst5% Δ [95% CI]|下降>0.05目标数|", "|---|---|---|---:|"]
    for metric, values in result["paired_geometry_minus_raw"].items():
        fields = []
        for stat in ("mean", "worst5_mean"):
            v = values[stat]; fields.append(f"{v['delta']:+.5f} [{v['ci95'][0]:+.5f}, {v['ci95'][1]:+.5f}]")
        lines.append(f"|{metric}|" + "|".join(fields) + f"|{values['loss_gt_005_count']}/128|")
    lines += ["", "相同raw权重的初始几何输出已不同，因此同时保留各arm初始与当前结果；原始逐目标差值、P05、TRAIN probe和各arm相对初始变化均在JSON。",
              "bootstrap5000次seed20260926，探索性目标区间，不是独立训练seed重复，未对多次查看作校正。仅观察预定2048/4096/6144点，禁止替代8192主终点或根据好坏改变训练。",
              "若4小时软上限阻止到达8192，正式结果须报告预算未完成；质量、尾部、化学几何与独立确认仍分开判断。"]
    (output / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"complete": True, "provisional": True, "step": args.step}), flush=True)


if __name__ == "__main__":
    main()
