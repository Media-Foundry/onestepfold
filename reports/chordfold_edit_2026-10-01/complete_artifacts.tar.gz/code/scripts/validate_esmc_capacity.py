#!/usr/bin/env python3
"""Independent CPU audit of fixed-set capacity predictions and experimental metrics."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import numpy as np
from scipy.spatial.distance import pdist

from fastglycan.experimental_metrics import prediction_atom37, validate_experimental_record
from fastglycan.paired_teacher_protocol import sha256, write_json
from onestepfold.data.gt_materializer import ATOM37_INDEX


def rmsd(x, y):
    x, y = np.asarray(x, np.float64), np.asarray(y, np.float64)
    x, y = x - x.mean(0), y - y.mean(0)
    u, _, vh = np.linalg.svd(x.T @ y)
    d = np.diag([1.0, 1.0, -1.0 if np.linalg.det(u @ vh) < 0 else 1.0])
    return float(np.sqrt(np.mean(np.sum((x @ u @ d @ vh - y) ** 2, axis=1))))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--selection-manifest", type=Path, required=True)
    parser.add_argument("--check-heavy-artifacts", action="store_true")
    args = parser.parse_args()
    root = args.root
    assert not (root / "independent_validation.json").exists()
    report = json.loads((root / "report.json").read_text())
    contract = json.loads((root / "contract.json").read_text())
    assert report["complete"] and report["contract_sha256"] == sha256(root / "contract.json")
    for name, digest in contract["source_sha256"].items():
        assert sha256(args.code_root / name) == digest, name
    assert sha256(args.selection_manifest) == (
        "1a959fdac83f8688ec9cb1a7deb95e4cf4e06670e9ca4450fcbfc8468d43d33f"
    )
    with gzip.open(args.selection_manifest, "rt") as handle:
        records = [json.loads(line) for line in handle]
    selected = sorted(
        (r for r in records if r["split"] == "train"),
        key=lambda r: (r["sequence_length"], r["group_id"]),
    )[:32]
    assert selected == contract["selection"]
    assert len(selected) == len(contract["input_provenance"]) == 32
    history = json.loads((root / "history.json").read_text())
    assert report["history_sha256"] == sha256(root / "history.json")
    assert report["training_curve_sha256"] == sha256(root / "training.jsonl")
    training = [json.loads(line) for line in (root / "training.jsonl").read_text().splitlines()]
    assert [r["epoch"] for r in training] == list(range(1, report["last_epoch"] + 1))
    assert report["steps"] == 32 * report["last_epoch"] <= 3200
    assert all(r["step"] == 32 * r["epoch"] for r in training)
    best = min(history, key=lambda r: r["summary"]["pooled_all_heavy_atom_rmsd"])
    assert best["epoch"] == report["best_epoch"]
    assert best["summary"] == report["best"]["summary"]
    assert report["forward_counts"] == {"trunk": 1, "structure": 1, "confidence": 0}
    assert all(
        report[k]
        for k in (
            "initial_train_eval_exact",
            "all32_best_replays_exact",
            "all_inputs_unchanged",
            "frozen_heads_unchanged",
        )
    )
    results = {}
    max_error = 0.0
    for condition, filename in (
        ("initial", "initial_prediction"),
        ("best", "best_prediction"),
        ("second_seed", "second_seed_prediction"),
    ):
        rows = []
        originals = report[condition]["examples"]
        assert len(originals) == 32
        for record, provenance, original in zip(
            selected, contract["input_provenance"], originals, strict=True
        ):
            group = record["group_id"]
            folder = root / group
            assert provenance["group_id"] == original["group_id"] == group
            assert json.loads((folder / "input_provenance.json").read_text()) == provenance
            assert provenance["raw_gt_rebuild_exact"]
            assert sha256(folder / "gt.npz") == provenance["gt_npz_sha256"]
            assert sha256(folder / "gt.json") == provenance["gt_metadata_sha256"]
            assert sha256(folder / f"{filename}.npz") == original["prediction_sha256"]
            with np.load(folder / "gt.npz", allow_pickle=False) as saved:
                arrays = dict(saved)
            metadata = json.loads((folder / "gt.json").read_text())
            validate_experimental_record(arrays, metadata, record["sequence"], record["sample_id"])
            with np.load(folder / f"{filename}.npz", allow_pickle=False) as saved:
                prediction = dict(saved)
            with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
                assert all(np.array_equal(prediction[k], saved[k]) for k in saved.files)
            positions, available = prediction_atom37(prediction, record["sequence"])
            observed = arrays["atom37_mask"] & arrays["residue_mask"][:, None]
            assert not np.any(observed & ~available)
            ca = observed[:, ATOM37_INDEX["CA"]]
            x, y = (
                positions[ca, ATOM37_INDEX["CA"]],
                arrays["atom37_positions"][ca, ATOM37_INDEX["CA"]],
            )
            measured = {
                "all_heavy_atom_rmsd": rmsd(
                    positions[observed], arrays["atom37_positions"][observed]
                ),
                "ca_rmsd": rmsd(x, y),
                "ca_pair_distance_rmse": float(np.sqrt(np.mean((pdist(x) - pdist(y)) ** 2))),
                "common_atom_count": int(observed.sum()),
                "common_ca_count": int(ca.sum()),
                "common_ca_pair_count": len(x) * (len(x) - 1) // 2,
            }
            assert measured["common_atom_count"] == provenance["observed_atom_count"]
            for key, value in measured.items():
                error = abs(value - original["metrics"][key])
                max_error = max(error, max_error)
                assert error <= (0 if key.endswith("count") else 2e-5), (group, key, error)
            rows.append(measured)
        summary = {}
        for metric, weight in (
            ("all_heavy_atom_rmsd", "common_atom_count"),
            ("ca_rmsd", "common_ca_count"),
            ("ca_pair_distance_rmse", "common_ca_pair_count"),
        ):
            summary["pooled_" + metric] = math.sqrt(
                sum(r[metric] ** 2 * r[weight] for r in rows) / sum(r[weight] for r in rows)
            )
            summary["macro_" + metric] = float(np.mean([r[metric] for r in rows]))
        assert all(abs(v - report[condition]["summary"][k]) <= 2e-5 for k, v in summary.items())
        passed = (
            summary["pooled_all_heavy_atom_rmsd"] <= 1
            and summary["pooled_ca_pair_distance_rmse"] <= 1
            and sum(r["all_heavy_atom_rmsd"] <= 2 for r in rows) >= 29
        )
        assert passed == report[condition]["summary"]["capacity_pass"]
        results[condition] = summary | {"capacity_pass": passed}
    if args.check_heavy_artifacts:
        import torch

        from fastglycan.experimental_training import map_experimental_atoms
        from fastglycan.teacher_pairing import feature_digest

        torch.set_num_threads(1)
        assert sha256(root / "initial.pt") == contract["initial_checkpoint_sha256"]
        assert sha256(root / "best.pt") == report["best_checkpoint_sha256"]
        assert sha256(root / "last.pt") == report["last_checkpoint_sha256"]
        initial = torch.load(root / "initial.pt", map_location="cpu", weights_only=True)
        assert feature_digest(initial) == contract["initial_weights_sha256"]
        best_state = torch.load(root / "best.pt", map_location="cpu", weights_only=True)
        assert best_state["epoch"] == report["best_epoch"]
        for key, tensor in initial.items():
            if key.startswith(("core.confidence_head.", "core.distogram_head.")):
                assert torch.equal(tensor, best_state["model"][key])
        del initial, best_state
        for record, provenance in zip(selected, contract["input_provenance"], strict=True):
            folder = root / record["group_id"]
            assert sha256(folder / "inputs.pt") == provenance["inputs_sha256"]
            packet = torch.load(folder / "inputs.pt", map_location="cpu", weights_only=True)
            assert feature_digest(packet["features"]) == provenance["feature_sha256"]
            with np.load(folder / "gt.npz", allow_pickle=False) as saved:
                arrays = dict(saved)
            with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
                inventory = dict(saved)
            labels = map_experimental_atoms(
                arrays,
                json.loads((folder / "gt.json").read_text()),
                record["sequence"],
                record["sample_id"],
                inventory,
            )
            assert all(torch.equal(v, packet["labels"][k]) for k, v in labels.items())
    audit = {
        "complete": True,
        "report_sha256": sha256(root / "report.json"),
        "contract_sha256": sha256(root / "contract.json"),
        "groups": 32,
        "conditions": results,
        "max_metric_error_angstrom": max_error,
        "heavy_artifacts_checked": args.check_heavy_artifacts,
        "validator_sha256": sha256(Path(__file__)),
        "scope": "CPU artifact/FP64 metric audit; no repeated GPU training or derivative check",
    }
    write_json(root / "independent_validation.json", audit)
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
