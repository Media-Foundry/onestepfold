#!/usr/bin/env python3
"""Read-only scaling job observer with verified archives and matched-budget plots."""

import argparse
import hashlib
import json
import shlex
import subprocess
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = "/data/user/shuang886/Folding/stage1b/coordinate_refiner"
DATA = BASE + "/esmc_scaling_data_v1_20260919"
TERMINAL = {
    "COMPLETED",
    "FAILED",
    "CANCELLED",
    "TIMEOUT",
    "OUT_OF_MEMORY",
    "NODE_FAIL",
    "PREEMPTED",
    "BOOT_FAIL",
    "DEADLINE",
    "REVOKED",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(args):
    return subprocess.check_output(["ssh", "hpc3", shlex.join(args)], text=True, timeout=30)


def write(path, value):
    temp = path.with_suffix(".part")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.replace(path)


def copy_output(remote_path, folder, live=False):
    folder.mkdir(parents=True, exist_ok=True)
    options = (
        ["--include=history.json", "--include=progress.json", "--exclude=*"]
        if live
        else ["--exclude=*.pt"]
    )
    subprocess.run(
        ["rsync", "-a", *options, f"hpc3:{remote_path}/", str(folder) + "/"],
        check=True,
        timeout=240,
    )


def terminal(archive, key, run, status):
    if run["kind"].startswith("cpu"):
        folder = archive / "data"
        folder.mkdir(exist_ok=True)
        subprocess.run(
            [
                "rsync",
                "-a",
                "--include=/*.json",
                "--include=/*.log",
                "--exclude=*",
                f"hpc3:{DATA}/",
                str(folder) + "/",
            ],
            check=True,
            timeout=120,
        )
        if status["state"] == "COMPLETED" and status["exit_code"] == "0:0":
            if run["kind"] == "cpu_acceptance":
                acceptance = json.loads((folder / "acceptance.json").read_text())
                homology = json.loads((folder / "homology_audit.json").read_text())
                assert (
                    acceptance["complete"] and homology["complete"] and acceptance["groups"] == 2176
                )
                assert (
                    digest(folder / "selection.json")
                    == acceptance["selection_sha256"]
                    == homology["selection_sha256"]
                )
            status["accepted"] = True
        else:
            status["accepted"] = False
        status["archived"] = True
        return
    folder = archive / key
    copy_output(run["output"], folder)
    subprocess.run(
        ["rsync", "-a", f"hpc3:{run['output']}-{run['job']}.log", str(folder / "worker.log")],
        check=True,
        timeout=60,
    )
    if status["state"] != "COMPLETED" or status["exit_code"] != "0:0":
        status.update(archived=True, accepted=False)
        return
    if run["kind"] == "preflight":
        r = json.loads((folder / "preflight.json").read_text())
        assert (
            r["complete"]
            and r["optimizer_updates"] == 0
            and digest(folder / "contract.json") == r["contract_sha256"]
        )
    else:
        r = json.loads((folder / "report.json").read_text())
        qa = json.loads((folder / "independent_validation.json").read_text())
        assert (
            r["complete"]
            and qa["complete"]
            and qa["report_sha256"] == digest(folder / "report.json")
        )
        for name, keyhash in [
            ("contract.json", "contract_sha256"),
            ("history.json", "history_sha256"),
            ("training.jsonl", "training_sha256"),
        ]:
            assert digest(folder / name) == r[keyhash]
        for condition in (
            "initial_validation",
            "last_validation",
            "best_validation",
            "best_train_probe",
            "best_full_train",
        ):
            for row in r[condition]["rows"]:
                assert digest(folder / row["prediction_path"]) == row["prediction_sha256"]
        status["report_sha256"] = qa["report_sha256"]
    status.update(archived=True, accepted=True)


def render(archive, runs, statuses):
    lines = [
        "# Scaling-v1：固定预算泛化实验",
        "",
        "32–256残基；嵌套128/512/2048训练集，固定128验证集。一个训练初始化，两个评估噪声。",
        "每组上限32768更新或8小时训练与过程评估；未证明收敛，frozen temporal test未使用。",
        "",
        "| 任务 | Job | 状态 | 更新数 | 最佳验证 lDDT（较差噪声） |",
        "|---|---|---|---:|---:|",
    ]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), layout="constrained")
    histories = {}
    for key, run in runs.items():
        if run["kind"] != "train":
            continue
        folder = archive / key
        state = statuses[key]
        step = 0
        score = "—"
        if (folder / "progress.json").exists():
            step = json.loads((folder / "progress.json").read_text())["step"]
        if (folder / "history.json").exists():
            h = json.loads((folder / "history.json").read_text())
            histories[key] = h
            score = f"{max(r['validation']['summary']['selection_score'] for r in h):.4f}"
            for ax, x in zip(axes, ("step", "elapsed_seconds"), strict=True):
                ax.plot(
                    [r[x] / (3600 if x == "elapsed_seconds" else 1) for r in h],
                    [r["validation"]["summary"]["selection_score"] for r in h],
                    label=key,
                )
        label = "QA passed" if state.get("accepted") else state.get("state", "submitted")
        lines.append(f"| {key} | {run['job']} | {label} | {step} | {score} |")
    for ax, label in zip(axes, ("Optimizer updates", "Worker wall hours"), strict=True):
        ax.set(xlabel=label, ylabel="Worst-noise macro validation lDDT")
        ax.grid(alpha=0.2)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=6)
    fig.savefig(archive.with_suffix(".png"), dpi=170)
    plt.close(fig)
    lines += [
        "",
        "lDDT排除同残基原子对；验证结果用于开发选择，不是最终测试。运行中数值待最终验收。",
        "训练探针与完整训练集区分；所有模型保持c1/一次结构计算，ESMC特征冻结。",
        "同源性审计见 data/homology_audit.json；近同源泄漏风险须按相似度分层解释。",
        "",
        f"![曲线]({archive.with_suffix('.png').name})",
        "",
    ]
    comparisons = {}
    # Fixed-update comparisons use the exact scheduled checkpoint, never selected-best substitutes.
    for budget in (8192, 16384, 24576, 32768):
        comparisons[str(budget)] = {
            key: next((r["validation"]["summary"] for r in h if r["step"] == budget), None)
            for key, h in histories.items()
        }
    write(archive / "matched_update_summaries.json", comparisons)
    if all(s.get("archived") for s in statuses.values()):
        paired = {}
        rng = np.random.default_rng(101)
        for arm in ("control", "raw"):
            for budget in (8192, 16384, 24576, 32768):
                rows = []
                for size in (128, 2048):
                    key = f"{arm}_{size}"
                    h = next((r for r in histories.get(key, []) if r["step"] == budget), None)
                    if h is None:
                        break
                    by = {}
                    for r in h["validation"]["rows"]:
                        by.setdefault(r["group_id"], []).append(r["quality"]["all_atom_lddt"])
                    rows.append({g: float(np.mean(v)) for g, v in by.items()})
                if len(rows) != 2:
                    continue
                groups = sorted(rows[0])
                assert set(groups) == set(rows[1])
                delta = np.array([rows[1][g] - rows[0][g] for g in groups])
                boots = np.mean(rng.choice(delta, size=(10000, len(delta)), replace=True), axis=1)
                paired[f"{arm}_{budget}"] = {
                    "mean_delta_2048_minus128": float(delta.mean()),
                    "protein_bootstrap_95ci": np.quantile(boots, [0.025, 0.975]).tolist(),
                    "scope": "paired proteins and noise mean; excludes training-seed uncertainty",
                }
        write(archive / "paired_budget_analysis.json", paired)
        lines += ["全部任务已终止，最终是否验收通过见completion_workflow.json。", ""]
    archive.with_suffix(".md").write_text("\n".join(lines))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--archive", type=Path, required=True)
    a = p.parse_args()
    archive = a.archive.resolve()
    statefile = archive / "completion_workflow.json"
    assert not statefile.exists(), "observer already has state; inspect rather than duplicate"
    runs = json.loads((archive / "jobs.json").read_text())
    statuses = {k: {"job": r["job"], "state": "submitted"} for k, r in runs.items()}
    for version in ("data_v1", "training_v1"):
        source = archive / "source" / version
        for name, expected in json.loads((source / "source_manifest.json").read_text())[
            "files"
        ].items():
            assert digest(source / name) == expected
    started = time.monotonic()
    last_live = -1e9
    while time.monotonic() - started < 24 * 3600:
        try:
            output = remote(
                [
                    "sacct",
                    "-j",
                    ",".join(r["job"] for r in runs.values()),
                    "--noheader",
                    "--parsable2",
                    "--format=JobIDRaw,State,ExitCode,Elapsed",
                ]
            )
            mapping = {
                line.split("|")[0]: line.split("|")[1:4]
                for line in output.splitlines()
                if "|" in line
            }
            refresh = time.monotonic() - last_live >= 180
            for key, run in runs.items():
                state = statuses[key]
                if run["job"] in mapping:
                    status, code, elapsed = mapping[run["job"]]
                    state.update(
                        state=status.split()[0].rstrip("+"), exit_code=code, elapsed=elapsed
                    )
                if state.get("archived"):
                    continue
                if state["state"] in TERMINAL:
                    terminal(archive, key, run, state)
                    print(json.dumps({key: state}), flush=True)
                elif refresh and state["state"] == "RUNNING" and run["kind"] == "train":
                    try:
                        copy_output(run["output"], archive / key, live=True)
                    except subprocess.CalledProcessError:
                        pass  # Slurm may start before Python creates output.
            if refresh:
                last_live = time.monotonic()
            done = all(s.get("archived") for s in statuses.values())
            write(
                statefile,
                {
                    "complete": done,
                    "all_accepted": done and all(s.get("accepted") for s in statuses.values()),
                    "jobs": statuses,
                    "scope": "observation/archive only; no submit/restart/cancel",
                },
            )
            render(archive, runs, statuses)
            if done:
                return
        except (subprocess.SubprocessError, OSError, ValueError, AssertionError) as exc:
            write(archive / "observer_error.json", {"error": repr(exc), "jobs": statuses})
            print(json.dumps({"observation_error": repr(exc)}), flush=True)
        time.sleep(30)
    write(archive / "observer_timeout.json", {"jobs": statuses})


if __name__ == "__main__":
    main()
