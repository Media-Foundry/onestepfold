#!/usr/bin/env python3
"""Read-only acceptance of actual matched execution, using the first 64 updates."""

import argparse
import json
from pathlib import Path

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.raw_warmstart import continuation_schedule, verify_lock


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args().root.resolve()
    source = Path(__file__).resolve().parent
    manifest = json.loads((source / "manifest.json").read_text())
    assert manifest["source_sha256"] == sha256(Path(__file__))
    verify_lock(root, root / "code_v1")
    output = root / "dispatch_audit_v1"
    assert not output.exists()
    contracts, prefixes, checks = {}, {}, {}
    for label in ("raw_continue", "geometry_adapt"):
        folder = root / label
        contract = json.loads((folder / "contract.json").read_text())
        initial = json.loads((folder / "initial_replay_acceptance.json").read_text())
        assert initial["complete"] and initial["optimizer_updates"] == 0 and initial["rows_checked"] == 320
        assert initial["contract_sha256"] == sha256(folder / "contract.json")
        with (folder / "training.jsonl").open() as handle:
            lines = [next(handle) for _ in range(64)]
        rows = [json.loads(line) for line in lines]
        expected = list(continuation_schedule(contract["train"], 64))
        assert len(rows) == len(expected) == 64
        for row, (step, epoch, record, noise) in zip(rows, expected, strict=True):
            assert (row["step"], row["epoch"], row["group_id"], row["noise"]) == (step, epoch, record["group_id"], noise)
            assert row["lr"] == 1e-4 and row["samples_seen"] == step
            assert len(row["weighted_losses"]) == 4
        contracts[label], prefixes[label] = contract, lines
        checks[label] = {"contract_sha256": sha256(folder / "contract.json"), "initial_replay_sha256": sha256(folder / "initial_replay_acceptance.json")}
    common = ("parent_checkpoint_sha256", "parent_step", "initial_weights_sha256", "config", "optimizer", "optimizer_reset", "max_steps", "soft_seconds", "train", "validation", "train_probe", "evaluation_seeds", "gpu_model", "matmul_tf32", "cudnn_tf32", "runtime_source_sha256")
    for key in common:
        assert contracts["raw_continue"][key] == contracts["geometry_adapt"][key], key
    assert contracts["raw_continue"]["arm"] == "raw" and contracts["geometry_adapt"]["arm"] == "control"
    for raw, geom in zip(prefixes["raw_continue"], prefixes["geometry_adapt"], strict=True):
        r, g = json.loads(raw), json.loads(geom)
        for key in ("step", "epoch", "group_id", "noise", "lr", "samples_seen", "residues_seen"):
            assert r[key] == g[key], key
    output.mkdir()
    for label, lines in prefixes.items():
        path = output / (label + "_first64.jsonl")
        path.write_text("".join(lines))
        checks[label]["prefix_sha256"] = sha256(path)
    result = {"complete": True, "rows_per_arm": 64, "epoch": 12, "checks": checks,
              "equal_contract_fields": list(common), "lock_sha256": sha256(root / "lock.json"),
              "source_sha256": sha256(Path(__file__)), "manifest_sha256": sha256(source / "manifest.json"),
              "scope": "Initial raw replay and matched actual sampler/optimizer/precision metadata only. Losses differ by design; no quality or final acceptance claim."}
    write_json(output / "acceptance.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
