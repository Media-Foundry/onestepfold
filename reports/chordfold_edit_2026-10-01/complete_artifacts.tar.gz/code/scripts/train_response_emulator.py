#!/usr/bin/env python3
"""One fixed response-supervised pilot with frozen decoder and c1-only learner."""

from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import torch

from fastglycan.models.pair_state_factory import build_pair_state_model, model_source_names
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.response_cache import read_response_cache
from fastglycan.response_training import ResponseDataset, response_loss, validate_responses
from fastglycan.teacher_pairing import feature_digest
from fastglycan.teacher_runtime import setup_teacher
from onestepfold.training.coordinate_refiner import group_id_digest


def save_checkpoint(path, model, epoch, validation, contract, optimizer=None):
    temporary = path.with_suffix(".part")
    torch.save(
        {
            "epoch": epoch,
            "model": model.state_dict(),
            "config": model.config,
            "validation": validation,
            "contract": contract,
            "optimizer": optimizer.state_dict() if optimizer else None,
        },
        temporary,
    )
    temporary.replace(path)


def gpu_checks(dataset, teacher, device):
    longest = max(range(len(dataset)), key=lambda i: dataset.records[i].sequence_length)
    example = dataset[longest]
    torch.manual_seed(101)
    disposable = build_pair_state_model({}).to(device)
    optimizer = torch.optim.AdamW(disposable.parameters(), lr=0.0003, weight_decay=0.0001)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    steps = []
    for step in range(2):
        optimizer.zero_grad(set_to_none=True)
        loss, response, predicted, correction = response_loss(
            disposable, teacher.diffusion_module, example, device
        )
        if step == 0:
            assert torch.equal(predicted.detach().cpu(), example["pair"])
            assert torch.equal(response.detach().cpu(), example["baseline"])
        assert torch.isfinite(loss)
        loss.backward()
        assert all(
            p.grad is not None and torch.isfinite(p.grad).all() for p in disposable.parameters()
        )
        assert disposable.output.weight.grad.norm() > 0
        if step == 1:
            assert disposable.endpoint.weight.grad.norm() > 0
            assert disposable.context_projection.weight.grad.norm() > 0
        assert all(p.grad is None for p in teacher.parameters())
        norm = torch.nn.utils.clip_grad_norm_(disposable.parameters(), 10, error_if_nonfinite=True)
        optimizer.step()
        steps.append(
            {"step": step, "loss": float(loss.detach()), "gradient_norm": float(norm), **correction}
        )
        del loss, response, predicted
    saved = {key: value.detach().cpu().clone() for key, value in disposable.state_dict().items()}
    other = build_pair_state_model({}).to(device)
    other.load_state_dict(saved)
    with torch.no_grad():
        a, response_a, pair_a, _ = response_loss(
            disposable, teacher.diffusion_module, example, device, grad=False
        )
        b, response_b, pair_b, _ = response_loss(
            other, teacher.diffusion_module, example, device, grad=False
        )
    assert torch.equal(pair_a, pair_b) and torch.equal(response_a, response_b) and torch.equal(a, b)
    return {
        "passed": True,
        "longest_group_id": example["group_id"],
        "longest_length": example["length"],
        "steps": steps,
        "zero_identity_exact": True,
        "checkpoint_reload_exact": True,
        "teacher_gradients_none": True,
        "second_step_context_gradients_nonzero": True,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--response-root", type=Path, required=True)
    parser.add_argument("--baseline-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    root, output, baseline_root = map(
        Path.resolve, (args.response_root, args.output_root, args.baseline_root)
    )
    protocol, records = read_response_cache(root, accepted=True)
    state_root = Path(protocol["state_root"])
    prior = json.loads((baseline_root / "report.json").read_text())
    assert prior["complete"] and sha256(baseline_root / "best.pt") == prior["best_sha256"]
    splits = {s: [r for r in records if r.split == s] for s in ("train", "validation")}
    output.mkdir(parents=True, exist_ok=False)
    longest = max(splits["train"], key=lambda r: r.sequence_length)
    runner, _, _, provenance = setup_teacher([longest], output / "work")
    teacher, device = runner.model.eval().requires_grad_(False), runner.device
    module = teacher.diffusion_module
    assert runner.configs.skip_amp.sample_diffusion
    assert module.blocks_per_ckpt == 1 and module.use_fine_grained_checkpoint
    accepted = json.loads((root / "control/acceptance.json").read_text())
    assert provenance["checkpoint_sha256"] == accepted["checkpoint_sha256"]
    teacher_hash = feature_digest(teacher.state_dict())
    train, validation = (ResponseDataset(root, splits[s]) for s in ("train", "validation"))
    checks = gpu_checks(train, teacher, device)
    assert feature_digest(teacher.state_dict()) == teacher_hash
    write_json(output / "gpu_checks.json", checks)
    torch.cuda.empty_cache()
    torch.manual_seed(101)
    model = build_pair_state_model({}).to(device)
    assert feature_digest(model.state_dict()) == prior["contract"]["initial_weights_sha256"]
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0003, weight_decay=0.0001)
    order_rng = random.Random(101)
    source = Path(__file__).resolve().parents[1]
    names = (
        "scripts/train_response_emulator.py",
        "src/fastglycan/response_training.py",
        "src/fastglycan/response_cache.py",
        "src/fastglycan/decoder_gradients.py",
        "src/fastglycan/teacher_runtime.py",
        "src/fastglycan/teacher_pairing.py",
        "docs/stage1b_decoder_supervision_pilot_v1.md",
        "tests/test_response_training.py",
        "scripts/slurm_response_training.sh",
        *model_source_names({}),
    )
    contract = {
        "schema_version": "decoder-response-pilot-v1",
        **provenance,
        "cache_root": str(state_root),
        "response_root": str(root),
        "cache_acceptance_sha256": sha256(state_root / "control/acceptance.json"),
        "cache_protocol_sha256": sha256(state_root / "control/protocol.json"),
        "response_acceptance_sha256": sha256(root / "control/acceptance.json"),
        "response_protocol_sha256": sha256(root / "control/protocol.json"),
        "source_sha256": {name: sha256(source / name) for name in names},
        "initial_weights_sha256": feature_digest(model.state_dict()),
        "teacher_initial_weights_sha256": teacher_hash,
        "architecture": "pointwise",
        "model_config": model.config,
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "epochs": 20,
        "seed": 101,
        "learning_rate": 0.0003,
        "weight_decay": 0.0001,
        "gradient_clip": 10,
        "autocast": "bf16",
        "decoder_autocast": False,
        "ordered_pairs_per_visit": "all",
        "chunk_size": 16384,
        "checkpoint_learner_chunks": True,
        "loss": "mean FP64-reduced denoised coordinate squared error",
        "selection": "mean per-protein first-response MSE; epoch 0 eligible",
        "inference_inputs": prior["contract"]["inference_inputs"],
        "target": "first c1-single/c4-pair denoised response at fixed c1 noise",
        "split_group_sha256": {s: group_id_digest(rs) for s, rs in splits.items()},
        "split_counts": {s: len(rs) for s, rs in splits.items()},
        "temporal_test_read": False,
        "matched_pointwise_baseline": {
            "root": str(baseline_root),
            "report_sha256": sha256(baseline_root / "report.json"),
            "best_sha256": prior["best_sha256"],
        },
    }
    matching = (
        "initial_weights_sha256",
        "cache_acceptance_sha256",
        "cache_protocol_sha256",
        "model_config",
        "parameter_count",
        "epochs",
        "seed",
        "learning_rate",
        "weight_decay",
        "gradient_clip",
        "autocast",
        "inference_inputs",
        "split_group_sha256",
        "split_counts",
    )
    assert all(contract[k] == prior["contract"][k] for k in matching)
    assert (
        contract["source_sha256"]["src/fastglycan/models/pair_state_emulator.py"]
        == prior["contract"]["source_sha256"]["src/fastglycan/models/pair_state_emulator.py"]
    )
    contract["matched_pointwise_baseline"]["matching_fields"] = list(matching)
    write_json(output / "contract.json", contract)
    metrics = validate_responses(model, module, validation, device, verify_identity=True)
    assert metrics["macro_ratio"] == metrics["pooled_ratio"] == 1.0
    best, best_epoch = metrics["macro_mse"], 0
    save_checkpoint(output / "best.pt", model, 0, metrics, contract)
    history = [{"epoch": 0, "validation": metrics}]
    write_json(output / "history.json", history)
    started = time.monotonic()
    for epoch in range(1, 21):
        model.train()
        order = list(range(len(train)))
        order_rng.shuffle(order)
        losses, gradients, corrections = [], [], []
        torch.cuda.reset_peak_memory_stats()
        for index in order:
            example = train[index]
            optimizer.zero_grad(set_to_none=True)
            loss, response, predicted, correction = response_loss(model, module, example, device)
            assert torch.isfinite(loss)
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
            assert all(p.grad is None for p in teacher.parameters())
            optimizer.step()
            losses.append(float(loss.detach()))
            gradients.append(float(norm))
            corrections.append(correction)
            del loss, response, predicted, example
        metrics = validate_responses(model, module, validation, device)
        if metrics["macro_mse"] < best:
            best, best_epoch = metrics["macro_mse"], epoch
            save_checkpoint(output / "best.pt", model, epoch, metrics, contract, optimizer)
        row = {
            "epoch": epoch,
            "train_online_response_mse": sum(losses) / len(losses),
            "mean_gradient_norm": sum(gradients) / len(gradients),
            "max_gradient_norm": max(gradients),
            "clipped_fraction": sum(g > 10 for g in gradients) / len(gradients),
            "mean_rounded_changed_fraction": sum(c["rounded_changed_fraction"] for c in corrections)
            / len(corrections),
            "mean_rounded_correction_rms": sum(c["rounded_correction_rms"] for c in corrections)
            / len(corrections),
            "validation": metrics,
            "best_epoch": best_epoch,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "elapsed_seconds": time.monotonic() - started,
        }
        history.append(row)
        write_json(output / "history.json", history)
        print(
            json.dumps(
                {k: v for k, v in row.items() if k != "validation"}
                | {
                    "validation_macro_ratio": metrics["macro_ratio"],
                    "validation_pooled_ratio": metrics["pooled_ratio"],
                }
            ),
            flush=True,
        )
    save_checkpoint(output / "last.pt", model, 20, metrics, contract, optimizer)
    checkpoint = torch.load(output / "best.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    repeated = validate_responses(model, module, validation, device)
    assert repeated == checkpoint["validation"]
    final_hash = feature_digest(teacher.state_dict())
    assert final_hash == teacher_hash
    read_response_cache(root, accepted=True)
    write_json(
        output / "report.json",
        {
            "complete": True,
            "contract": contract,
            "best_epoch": best_epoch,
            "selected_validation": repeated,
            "gpu_checks": checks,
            "checkpoint_revalidation_exact": True,
            "teacher_final_weights_sha256": final_hash,
            "best_sha256": sha256(output / "best.pt"),
            "last_sha256": sha256(output / "last.pt"),
            "history_sha256": sha256(output / "history.json"),
            "elapsed_seconds": time.monotonic() - started,
            "decoded_evaluation_complete": False,
        },
    )


if __name__ == "__main__":
    main()
