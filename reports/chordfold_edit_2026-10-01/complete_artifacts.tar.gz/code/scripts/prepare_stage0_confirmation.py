#!/usr/bin/env python3
"""Prepare fixed sequence-only packets and verify the exact inference contract."""

from __future__ import annotations

import argparse
import gzip
import time
from pathlib import Path

import numpy as np
import torch

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.stage0_confirm_runtime import (
    SETTINGS,
    Trace,
    environment,
    load_json,
    predict,
    runner_setup,
    seed_prediction,
    write_progress,
)
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--phase", choices=("repeat", "confirm"), default="repeat")
    args = parser.parse_args()
    root = args.root.resolve()
    phase = root / args.phase
    phase.mkdir(exist_ok=False)
    if args.phase == "confirm":
        assert load_json(root / "control/final_execution_lock.json")["locked"]
    manifest = root / "control" / f"{args.phase}_manifest.jsonl.gz"
    import json

    with gzip.open(manifest, "rt") as handle:
        rows = [json.loads(line) for line in handle]
    ids = [row["group_id"] for row in rows]
    if args.phase == "repeat":
        lock = load_json(root / "control/repeat_lock.json")
        assert ids == lock["target_ids"]
        assert sha256(manifest) == lock["target_manifest_sha256"]
    else:
        selection = load_json(root / "control/confirm_selection.json")
        assert sha256(manifest) == selection["manifest_sha256"]
        assert len(ids) == 256
    start = time.perf_counter()
    runner = runner_setup(phase / "preparation_work")
    report = {
        "complete": False,
        "phase": args.phase,
        "manifest_sha256": sha256(manifest),
        "packets": {},
        "smoke": [],
        "environment": environment(runner),
    }
    assert report["environment"]["checkpoint_sha256"] == (
        "1301bba9ad322518eace60fd244ded7904439f55317e90d402cc7a0c06026664"
    )
    assert report["environment"]["esm_checkpoint_sha256"] == (
        "7de8b4082ba15891959ab368b77ce3886697af1efb16d3c9e9e7b0c5d3f07500"
    )
    write_progress(phase / "preparation.json", report, start)
    input_path = phase / "input.json"
    write_json(
        input_path,
        [
            {
                "name": row["group_id"],
                "sequences": [{"proteinChain": {"sequence": row["sequence"], "count": 1}}],
            }
            for row in rows
        ],
    )
    config = runner.configs
    config.input_json_path = str(input_path)
    config.num_workers = 0
    seed_prediction(101)
    from protenix.data.inference.infer_dataloader import get_inference_dataloader

    feature_start = time.perf_counter()
    dataset = get_inference_dataloader(configs=config).dataset
    report["esm_preparation_seconds"] = time.perf_counter() - feature_start
    packets = phase / "packets"
    packets.mkdir()
    for index, row in enumerate(rows):
        seed_prediction(101)
        data, atoms, error = dataset[index]
        if error or data["sample_name"] != row["group_id"]:
            raise ValueError(f"Featurization failed: {error}")
        path = packets / (row["group_id"] + ".pt")
        # Only sequence-derived data and atom inventory. No GT in packets.
        torch.save({"data": data, "atoms": atoms}, path)
        report["packets"][row["group_id"]] = {
            "packet_sha256": sha256(path),
            "feature_sha256": feature_digest(data["input_feature_dict"]),
            "length": row["sequence_length"],
            "atom_count": len(atoms),
        }
        write_progress(phase / "preparation.json", report, start)
        print(f"prepared {index + 1}/{len(rows)}", flush=True)
    # Use only development targets for hook validation, even in confirmation phase.
    smoke_phase = root / "repeat"
    smoke_report = report if args.phase == "repeat" else load_json(smoke_phase / "preparation.json")
    smoke_ids = sorted(smoke_report["packets"], key=lambda g: smoke_report["packets"][g]["length"])
    for group in (smoke_ids[0], smoke_ids[-1]):
        packet = torch.load(smoke_phase / "packets" / (group + ".pt"), weights_only=False)
        for setting in SETTINGS:
            # An untimed warmup prevents initialization asymmetry in this check.
            warmup, _, _ = predict(runner, packet["data"], setting, 103, None)
            del warmup
            plain, plain_coords, _ = predict(runner, packet["data"], setting, 103, None)
            del plain
            with Trace(runner.model) as trace:
                hooked, hooked_coords, record = predict(runner, packet["data"], setting, 103, trace)
            del hooked
            exact = np.array_equal(plain_coords, hooked_coords)
            close = np.allclose(plain_coords, hooked_coords, atol=1e-5, rtol=1e-6)
            if not close:
                raise ValueError("Timing hook changed coordinates beyond predeclared tolerance")
            record.update(
                {
                    "group_id": group,
                    "hook_exact": exact,
                    "hook_max_abs_difference": float(np.abs(plain_coords - hooked_coords).max()),
                }
            )
            report["smoke"].append(record)
            write_progress(phase / "preparation.json", report, start)
    report["complete"] = True
    write_progress(phase / "preparation.json", report, start)
    write_json(
        phase / "runtime_lock.json",
        {
            "locked": True,
            "preparation_sha256": sha256(phase / "preparation.json"),
            "manifest_sha256": sha256(manifest),
            "input_sha256": sha256(input_path),
            "source_manifest_sha256": sha256(root / "control/source_manifest.json"),
            "sampler": {
                row["setting"]: {
                    key: row[key]
                    for key in (
                        "noise_schedule",
                        "schedule_dtype",
                        "sampler_parameters",
                        "trunk_calls",
                        "denoiser_calls",
                        "sample_count",
                    )
                }
                for row in report["smoke"]
            },
            "rng_policy": "seed reset per target/config; fixed sequence-only features at seed101",
            "mc_dropout_apply_rate": config.mc_dropout_apply_rate,
            "mc_dropout_rate": config.mc_dropout_rate,
            "deterministic": config.deterministic,
            "solver": "Euler; pinned protenix.model.generator.sample_diffusion",
        },
    )
    print("preparation and runtime lock complete", flush=True)


if __name__ == "__main__":
    main()
