#!/usr/bin/env python3
"""CPU-only shape and seed agreement diagnosis after final artifact acceptance."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from fastglycan.coordinate_diagnostics import residue_error_decomposition, sampler_agreement
from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.paired_teacher_protocol import sha256, write_json


def accepted(root):
    report = json.loads((root / "report.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    contract = json.loads((root / "contract.json").read_text())
    assert report["complete"] and qa["complete"]
    assert qa["report_sha256"] == sha256(root / "report.json")
    assert report["contract_sha256"] == sha256(root / "contract.json")
    return contract, report


def shape_summary(rows):
    count = sum(r["atoms"] for r in rows)
    total = {
        key: sum(r[key] for r in rows)
        for key in (
            "total_sse",
            "centroid_error_sse",
            "internal_shape_error_sse",
            "predicted_within_residue_sse",
            "gt_within_residue_sse",
        )
    }
    return {
        "atoms": count,
        "atom_rmsd": np.sqrt(total["total_sse"] / count),
        "centroid_error_rmse": np.sqrt(total["centroid_error_sse"] / count),
        "internal_shape_error_rmse": np.sqrt(total["internal_shape_error_sse"] / count),
        "predicted_within_residue_radius": np.sqrt(total["predicted_within_residue_sse"] / count),
        "gt_within_residue_radius": np.sqrt(total["gt_within_residue_sse"] / count),
        "internal_shape_fraction_of_total_sse": (
            total["internal_shape_error_sse"] / total["total_sse"] if total["total_sse"] else 0.0
        ),
    }


def diagnose(root, contract, conditions):
    rows = {name: [] for name in conditions}
    paired = []
    for i, (record, provenance) in enumerate(
        zip(contract["selection"], contract["input_provenance"], strict=True)
    ):
        group = record["group_id"]
        folder = root / group
        assert sha256(folder / "gt.npz") == provenance["gt_npz_sha256"]
        assert sha256(folder / "gt.json") == provenance["gt_metadata_sha256"]
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
            inventory = dict(saved)
        labels = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            record["sequence"],
            record["sample_id"],
            inventory,
        )
        target, mask = labels["coordinate"].numpy(), labels["coordinate_mask"].numpy()
        predictions = []
        for name, (filename, originals) in conditions.items():
            path = folder / filename
            assert originals[i]["group_id"] == group
            assert sha256(path) == originals[i]["prediction_sha256"]
            with np.load(path, allow_pickle=False) as saved:
                assert all(np.array_equal(saved[k], v) for k, v in inventory.items())
                prediction = saved["coordinate"]
            measured = residue_error_decomposition(
                prediction, target, mask, inventory["residue_id"]
            )
            assert (
                abs(
                    np.sqrt(measured["total_sse"] / measured["atoms"])
                    - originals[i]["metrics"]["all_heavy_atom_rmsd"]
                )
                <= 2e-5
            )
            rows[name].append({"group_id": group, **measured, "prediction_sha256": sha256(path)})
            predictions.append(prediction)
        assert len(predictions) == 2
        agreement = sampler_agreement(*predictions, mask, inventory["atom_name"])
        paired.append({"group_id": group, **agreement})
    pooled = {}
    for name, key, count in (
        ("atom_rmsd", "atom_sse", "atom_count"),
        ("ca_rmsd", "ca_sse", "ca_count"),
        ("ca_distance_rmse", "ca_distance_sse", "ca_pair_count"),
    ):
        pooled["pooled_" + name] = np.sqrt(
            sum(r[key] for r in paired) / sum(r[count] for r in paired)
        )
        pooled["macro_" + name] = float(np.mean([np.sqrt(r[key] / r[count]) for r in paired]))
    return {
        "shape": {
            name: {"examples": values, "summary": shape_summary(values)}
            for name, values in rows.items()
        },
        "sampler_agreement": {"examples": paired, "summary": pooled},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-root", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--baseline-only", action="store_true")
    args = parser.parse_args()
    contract, report = accepted(args.baseline_root)
    output = {
        "fixed_rng_baseline_best": diagnose(
            args.baseline_root,
            contract,
            {
                "12345": ("best_prediction.npz", report["best"]["examples"]),
                "54321": ("second_seed_prediction.npz", report["second_seed"]["examples"]),
            },
        )
    }
    # Compare the new reusable decomposition with the previously accepted CPU diagnosis.
    old_shape = json.loads((args.baseline_root / "residue_shape_diagnosis.json").read_text())
    assert old_shape["report_sha256"] == sha256(args.baseline_root / "report.json")
    for noise, old_name in (("12345", "best"), ("54321", "second_seed")):
        measured = output["fixed_rng_baseline_best"]["shape"][noise]["summary"]
        old = old_shape["conditions"][old_name]["summary"]
        for name in measured.keys() & old.keys():
            assert np.isclose(measured[name], old[name], atol=1e-8, rtol=1e-10), name
    if not args.baseline_only:
        current_contract, current_report = accepted(args.root)
        assert current_contract["selection"] == contract["selection"]
        assert current_contract["input_provenance"] == contract["input_provenance"]
        for phase in ("initial", "best"):
            output["varied_rng_" + phase] = diagnose(
                args.root,
                current_contract,
                {
                    noise: (
                        f"{phase}_{noise}.npz",
                        current_report[phase]["conditions"][noise]["examples"],
                    )
                    for noise in ("12345", "54321")
                },
            )
    source = Path(__file__).resolve().parents[1]
    destination = args.root / (
        "baseline_coordinate_diagnostics.json"
        if args.baseline_only
        else "coordinate_diagnostics.json"
    )
    assert not destination.exists()
    names = (
        "scripts/diagnose_esmc_geometry_coordinates.py",
        "src/fastglycan/coordinate_diagnostics.py",
        "docs/esmc_geometry_diagnostics_v1.md",
    )
    result = {
        "complete": True,
        "baseline_only": args.baseline_only,
        "baseline_report_sha256": sha256(args.baseline_root / "report.json"),
        "current_report_sha256": None if args.baseline_only else sha256(args.root / "report.json"),
        "source_sha256": {name: sha256(source / name) for name in names},
        "conditions": output,
        "scope": "CPU observed shape/two-seed disagreement; no model forwards or selection",
    }
    write_json(destination, result)
    print(
        json.dumps(
            {
                k: {
                    "shape": {n: s["summary"] for n, s in v["shape"].items()},
                    "agreement": v["sampler_agreement"]["summary"],
                }
                for k, v in output.items()
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
