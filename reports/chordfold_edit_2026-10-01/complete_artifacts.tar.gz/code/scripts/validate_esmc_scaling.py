#!/usr/bin/env python3
"""CPU acceptance of scaling membership, checkpoints and saved structural outputs."""

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from fastglycan.articulated_gradient_diagnostics import independent_losses
from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.articulated_validation import numpy_project
from fastglycan.experimental_geometry import compare_local_geometry
from fastglycan.experimental_metrics import compare_experimental, prediction_atom37
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.scaling_metrics import quality_metrics, summarize_quality
from fastglycan.scaling_runtime import learning_rate, update_schedule
from fastglycan.teacher_pairing import feature_digest


def dense_lddt(x, y, residues):
    # Independent chunked distance implementation; no KD-tree/pair accumulation.
    scores = []
    for start in range(0, len(y), 128):
        d = np.linalg.norm(y[start : start + 128, None, :] - y[None, :, :], axis=-1)
        pd = np.linalg.norm(x[start : start + 128, None, :] - x[None, :, :], axis=-1)
        mask = (d < 15) & (residues[start : start + 128, None] != residues[None, :])
        error = np.abs(d - pd)
        value = sum((error < t).astype(float) for t in (0.5, 1.0, 2.0, 4.0)) / 4
        count = mask.sum(axis=-1)
        valid = count > 0
        scores.extend(((value * mask).sum(axis=-1)[valid] / count[valid]).tolist())
    assert scores
    return float(np.mean(scores))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    a = p.parse_args()
    root = a.root
    torch.set_num_threads(1)
    assert not torch.cuda.is_available()
    report = json.loads((root / "report.json").read_text())
    c = json.loads((root / "contract.json").read_text())
    assert report["complete"] and report["best_replay_exact"] and report["frozen_weights_unchanged"]
    for name, key in [
        ("contract.json", "contract_sha256"),
        ("history.json", "history_sha256"),
        ("training.jsonl", "training_sha256"),
        ("best.pt", "best_checkpoint_sha256"),
        ("last.pt", "last_checkpoint_sha256"),
    ]:
        assert sha256(root / name) == report[key]
    source = Path(c["source_root"])
    assert sha256(source / "source_manifest.json") == c["source_manifest_sha256"]
    manifest = json.loads((source / "source_manifest.json").read_text())
    for name, digest in manifest["files"].items():
        assert sha256(source / name) == digest
    for name, digest in c["runtime_source_sha256"].items():
        assert sha256(Path(name)) == digest
    assert sha256(Path(c["tmtools_binary"])) == c["tmtools_binary_sha256"]
    data = Path(c["data_root"])
    assert sha256(data / "acceptance.json") == c["data_acceptance_sha256"]
    acceptance = json.loads((data / "acceptance.json").read_text())
    assert (
        sha256(data / "selection.json") == c["selection_sha256"] == acceptance["selection_sha256"]
    )
    records = json.loads((data / "selection.json").read_text())
    assert c["train"] == [r for r in records if r["split"] == "train"][: c["size"]]
    assert c["validation"] == [r for r in records if r["split"] == "validation"]
    trainset = {r["group_id"] for r in c["train"]}
    valset = {r["group_id"] for r in c["validation"]}
    assert not trainset.intersection(valset)
    seen = Counter()
    total_residues = 0
    with (root / "training.jsonl").open() as handle:
        for expected, line in zip(
            update_schedule(c["train"], report["steps"]), handle, strict=True
        ):
            step, epoch, record, noise = expected
            row = json.loads(line)
            assert (row["step"], row["epoch"], row["group_id"], row["noise"]) == (
                step,
                epoch,
                record["group_id"],
                noise,
            )
            assert row["lr"] == learning_rate(c["schedule"], step)
            assert np.isfinite(row["weighted_losses"]).all() and np.isfinite(row["preclip_norm"])
            seen[record["group_id"]] += 1
            total_residues += len(record["sequence"])
    assert dict(seen) == report["exposures"] and total_residues == report["residues_seen"]
    assert sum(seen.values()) == report["steps"] == report["samples_seen"]
    history = json.loads((root / "history.json").read_text())
    for h in history:
        for key in ("validation", "train_probe"):
            assert summarize_quality(h[key]["rows"]) == h[key]["summary"]
    chosen = max(history, key=lambda h: h["validation"]["summary"]["selection_score"])
    assert chosen["step"] == report["best_step"]
    assert chosen["validation"]["summary"] == report["best_validation"]["summary"]
    loaded = {}
    checked = set()
    max_proj = max_lddt = max_rmsd = 0.0
    max_loss = np.zeros(4)
    for key in (
        "initial_validation",
        "last_validation",
        "best_validation",
        "best_train_probe",
        "best_full_train",
    ):
        evaluation = report[key]
        assert summarize_quality(evaluation["rows"]) == evaluation["summary"]
        expected_groups = (
            trainset
            if key == "best_full_train"
            else {r["group_id"] for r in c["train_probe"]}
            if key == "best_train_probe"
            else valset
        )
        assert {(r["group_id"], r["noise"]) for r in evaluation["rows"]} == {
            (g, s) for g in expected_groups for s in (12345, 54321)
        }
        assert len(evaluation["rows"]) == 2 * len(expected_groups)
        for row in evaluation["rows"]:
            group = row["group_id"]
            folder = data / "examples" / group
            if group not in loaded:
                info = json.loads((folder / "prepared.json").read_text())
                assert sha256(folder / "prepared.json") == acceptance["prepared_sha256"][group]
                for name, digest in info["files_sha256"].items():
                    assert sha256(folder / name) == digest
                with np.load(folder / "inventory.npz") as d:
                    inventory = dict(d)
                with np.load(folder / "gt.npz") as d:
                    arrays = dict(d)
                with np.load(folder / "labels.npz") as d:
                    labels = dict(d)
                with np.load(folder / "reference.npz") as d:
                    ref = d["reference"]
                variants = json.loads((folder / "articulation_report.json").read_text())["variants"]
                adapter = ArticulatedOutput(
                    ref,
                    inventory["atom_name"],
                    inventory["residue_id"],
                    info["selection"]["sequence"],
                    variants,
                ).float()
                assert feature_digest(adapter.state_dict()) == info["adapter_sha256"]
                sup = torch.load(folder / "supervision.pt", map_location="cpu", weights_only=True)
                loaded[group] = (info, inventory, arrays, labels, adapter.double(), sup)
            info, inventory, arrays, labels, adapter, sup = loaded[group]
            path = root / row["prediction_path"]
            assert sha256(path) == row["prediction_sha256"]
            with np.load(path) as d:
                for name, value in inventory.items():
                    assert np.array_equal(d[name], value)
                prediction = inventory | {"coordinate": d["coordinate"]}
                x = d["coordinate"].astype(np.float64)
                raw = d["raw_coordinate"].astype(np.float64)
            sequence = info["selection"]["sequence"]
            assert compare_experimental(prediction, arrays, sequence) == row["metrics"]
            assert compare_local_geometry(prediction, arrays, sequence) == row["geometry"]
            assert quality_metrics(prediction, arrays, sequence) == row["quality"]
            # Reuse exact duplicate selected probe/full-train coordinates after binding each row.
            cachekey = (group, row["prediction_sha256"])
            if cachekey in checked:
                continue
            checked.add(cachekey)
            projected, counts = (
                (raw, np.zeros(3, dtype=int)) if c["arm"] == "raw" else numpy_project(raw, adapter)
            )
            error = float(np.max(np.abs(x - projected)))
            assert error <= 1e-4
            max_proj = max(max_proj, error)
            assert counts.tolist() == row["fallback_counts"]
            independent = independent_losses(
                torch.tensor(x),
                labels["coordinate"],
                labels["coordinate_mask"],
                sup["frame"],
                sup["same"],
                sup["distance"],
            ).numpy()
            delta = np.abs(independent - row["weighted_losses"])
            max_loss = np.maximum(max_loss, delta)
            assert np.allclose(independent, row["weighted_losses"], atol=1e-3, rtol=2e-5), delta
            error = abs(float(np.sqrt(independent[0])) - row["metrics"]["all_heavy_atom_rmsd"])
            assert error < 1e-5
            max_rmsd = max(max_rmsd, error)
            positions, pmask = prediction_atom37(prediction, sequence)
            observed = pmask & arrays["atom37_mask"] & arrays["residue_mask"][:, None]
            ri, _ = np.nonzero(observed)
            value = dense_lddt(
                positions[observed].astype(np.float64),
                arrays["atom37_positions"][observed].astype(np.float64),
                ri,
            )
            error = abs(value - row["quality"]["all_atom_lddt"])
            assert error < 1e-12
            max_lddt = max(max_lddt, error)
    write_json(
        root / "independent_validation.json",
        {
            "complete": True,
            "report_sha256": sha256(root / "report.json"),
            "training_updates_checked": report["steps"],
            "unique_saved_predictions_checked": len(checked),
            "max_projection_error": max_proj,
            "max_loss_errors": max_loss.tolist(),
            "max_independent_rmsd_error": max_rmsd,
            "max_independent_lddt_error": max_lddt,
            "checkpoint_hashes_checked": True,
            "scope": (
                "saved outputs, independent projection/scalar losses/RMSD/lDDT; "
                "TM-align pinned and replayed; GPU reload checked by worker"
            ),
        },
    )
    print("Scaling CPU acceptance passed", flush=True)


if __name__ == "__main__":
    main()
