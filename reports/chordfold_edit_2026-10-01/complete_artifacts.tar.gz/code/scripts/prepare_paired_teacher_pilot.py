#!/usr/bin/env python3
"""Freeze selections and protocol in a new derived root; never alter the parent."""

from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path

from fastglycan.paired_teacher_protocol import (
    PARENT_MANIFEST_SHA256,
    PROTOCOL_VERSION,
    balanced_partitions,
    sha256,
    write_json,
)
from onestepfold.data.teacher_pairs import load_teacher_pair_manifest, write_teacher_pair_manifest
from onestepfold.training.coordinate_refiner import group_id_digest, select_length_stratified


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    parent = args.parent_root.resolve()
    output = args.output_root.resolve()
    manifest = parent / "control/teacher_pair_manifest_v1.jsonl.gz"
    if sha256(manifest) != PARENT_MANIFEST_SHA256:
        raise ValueError("parent manifest differs from the frozen corpus")
    if output.exists():
        raise FileExistsError("derived root already exists; inspect before rerunning")
    selected = []
    selections = {}
    for split, count, seed, expected in (
        ("train", 512, 101, 14400),
        ("validation", 256, 102, 1600),
    ):
        records = load_teacher_pair_manifest(manifest, split=split)
        if len(records) != expected:
            raise ValueError("parent split changed")
        subset = select_length_stratified(records, count, seed=seed)
        selected.extend(subset)
        selections[split] = {
            "count": len(subset),
            "seed": seed,
            "group_id_sha256": group_id_digest(subset),
            "min_length": min(r.sequence_length for r in subset),
            "max_length": max(r.sequence_length for r in subset),
        }
    derived = [replace(r, c2_source=PROTOCOL_VERSION, c4_source=PROTOCOL_VERSION) for r in selected]
    control = output / "control"
    control.mkdir(parents=True)
    manifest_hash = write_teacher_pair_manifest(
        control / "teacher_pair_manifest_v1.jsonl.gz", derived
    )
    partitions = balanced_partitions(derived, 4)
    workers = []
    for index, records in enumerate(partitions):
        path = control / f"worker_{index}.json"
        write_json(path, [r.group_id for r in records])
        workers.append(
            {
                "index": index,
                "count": len(records),
                "sha256": sha256(path),
                "longest_group_id": records[0].group_id,
                "longest_length": records[0].sequence_length,
            }
        )
    protocol = {
        "schema_version": PROTOCOL_VERSION,
        "scope": "exploratory paired-protocol intervention; changes c2 inputs and c4 labels",
        "parent_root": str(parent),
        "parent_manifest_sha256": PARENT_MANIFEST_SHA256,
        "manifest_sha256": manifest_hash,
        "selections": selections,
        "workers": workers,
        "feature_seed": 101,
        "trunk_seed": 101,
        "diffusion_seed": 12345,
        "mc_dropout_apply_rate": 0.0,
        "mc_dropout_rate": 0.4,
        "deterministic_algorithms": True,
        "cublas_workspace_config": ":4096:8",
        "cycles": [2, 4],
        "diffusion_steps": 2,
        "samples": 1,
        "model_name": "protenix_mini_esm_v0.5.0",
        "dtype": "bf16",
        "use_msa": False,
        "use_template": False,
        "host": "hpc3",
        "frozen_temporal_test_read": False,
        "parent_corpus_modified": False,
        "formal_gate_validation_count": 1600,
    }
    write_json(control / "paired_teacher_protocol.json", protocol)
    print(protocol, flush=True)


if __name__ == "__main__":
    main()
