#!/usr/bin/env python3
"""Lock the execution contract BEFORE reading frozen-test metadata."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from fastglycan.paired_teacher_protocol import sha256, write_json
from onestepfold.data.temporal_dev import _proportional_allocation, _stratify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--frozen-manifest", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    control = root / "control"
    phase = root / "repeat"
    scored = json.loads((phase / "scoring_complete.json").read_text())
    assert scored["complete"] and scored["count"] == 1536
    for worker in scored["workers"]:
        path = phase / f"worker_{worker['worker']}" / "scores.json"
        assert sha256(path) == worker["scores_sha256"]
    analysis = json.loads((phase / "analysis.json").read_text())
    assert analysis["targets"] == 128 and analysis["seeds"] == [103, 107, 109, 113]
    qa_path = control / "scoring_replay_qa.json"
    assert json.loads(qa_path.read_text())["passed"]
    runtime = json.loads((phase / "runtime_lock.json").read_text())
    assert runtime["locked"] and runtime["deterministic"]
    lock_path = control / "final_execution_lock.json"
    assert not lock_path.exists(), "Final execution lock must not be overwritten"
    # Deliberately no frozen-manifest read before this write.
    write_json(
        lock_path,
        {
            "locked": True,
            "settings": ["c4_s5", "c4_s2", "c2_s2"],
            "K": 1,
            "seed": 127,
            "target_count": 256,
            "selection_seed": 211,
            "selection": "metadata proportional strata, sha256(211:group_id) within strata",
            "repeat_runtime_lock_sha256": sha256(phase / "runtime_lock.json"),
            "repeat_scoring_sha256": sha256(phase / "scoring_complete.json"),
            "repeat_analysis_sha256": sha256(phase / "analysis.json"),
            "protocol_sha256": sha256(root / "code_v1/docs/stage0_minimal_confirmation_v1.md"),
            "execution_addendum_sha256": sha256(control / "execution_addendum.md"),
            "numerical_policy": runtime["numerical_policy_change"],
            "scoring_replay_qa_sha256": sha256(qa_path),
            "selection_code_sha256": sha256(Path(__file__)),
            "inference_v2_source_manifest_sha256": sha256(
                control / "inference_source_manifest_v2.json"
            ),
            "inference_source_manifest_sha256": sha256(control / "source_manifest.json"),
            "evaluation_source_manifest_sha256": sha256(
                control / "evaluation_source_manifest.json"
            ),
            "metrics": ["tm_score_ca", "all_atom_lddt"],
            "tail_thresholds": [0.01, 0.02, 0.05, 0.10],
            "primary_claims": [
                "s2_improves_lddt_at_c4",
                "c2_reduces_lddt_at_s2",
                "c2_reduces_warm_time_at_s2",
            ],
            "bootstrap": {
                "unit": "target",
                "resamples": 10000,
                "seed": 211,
                "per_claim_alpha": 0.05 / 3,
            },
            "selection_after_test": "forbidden",
            "target_partition": "16 GPU workers; 4 seeds x 4 target shards for repeats; "
            "16 target shards for seed127 confirmation; all settings paired on each GPU",
            "failure_policy": "do not drop; stop acceptance and account for all locked predictions",
            "timing": "paired runner.predict including transfers; synchronized stage hooks; "
            "cached sequence features",
        },
    )
    with gzip.open(args.frozen_manifest, "rt") as handle:
        rows = [json.loads(line) for line in handle]
    buckets = defaultdict(list)
    for row in rows:
        buckets[_stratify(row)].append(row)
    for bucket in buckets.values():
        bucket.sort(key=lambda r: hashlib.sha256(f"211:{r['group_id']}".encode()).hexdigest())
    allocation = _proportional_allocation(buckets, 256)
    selected = [row for key in sorted(buckets) for row in buckets[key][: allocation[key]]]
    selected.sort(key=lambda r: r["group_id"])
    with gzip.open(control / "repeat_manifest.jsonl.gz", "rt") as handle:
        repeats = {json.loads(line)["group_id"] for line in handle}
    assert len(selected) == 256 and not repeats & {r["group_id"] for r in selected}
    output = control / "confirm_manifest.jsonl.gz"
    with output.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
            for row in selected:
                zipped.write((json.dumps(row, sort_keys=True) + "\n").encode())
    write_json(
        control / "confirm_selection.json",
        {
            "manifest_sha256": sha256(output),
            "execution_lock_sha256": sha256(lock_path),
            "frozen_source_sha256": sha256(args.frozen_manifest),
            "count": len(selected),
            "target_ids": [r["group_id"] for r in selected],
            "stratum_counts": {str(k): v for k, v in allocation.items()},
        },
    )
    print("Protocol locked; 256 new targets selected without reading coordinates or scores.")


if __name__ == "__main__":
    main()
