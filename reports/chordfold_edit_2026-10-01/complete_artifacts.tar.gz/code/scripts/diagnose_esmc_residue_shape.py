#!/usr/bin/env python3
"""Post-hoc CPU residue-centroid/within-residue coordinate error decomposition."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from fastglycan.experimental_metrics import prediction_atom37
from fastglycan.paired_teacher_protocol import sha256, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    contract = json.loads((root / "contract.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert qa["complete"] and qa["report_sha256"] == sha256(root / "report.json")
    output = {}
    for condition in ("initial", "best", "second_seed"):
        rows = []
        for record in contract["selection"]:
            folder = root / record["group_id"]
            prediction_path = folder / f"{condition}_prediction.npz"
            with np.load(prediction_path, allow_pickle=False) as saved:
                prediction = dict(saved)
            with np.load(folder / "gt.npz", allow_pickle=False) as saved:
                gt = dict(saved)
            positions, available = prediction_atom37(prediction, record["sequence"])
            mask = gt["atom37_mask"] & gt["residue_mask"][:, None]
            assert np.all(available[mask])
            x, y = positions[mask].astype(float), gt["atom37_positions"][mask].astype(float)
            residue = np.where(mask)[0]
            xc, yc = x.mean(0), y.mean(0)
            u, _, vh = np.linalg.svd((y - yc).T @ (x - xc))
            correction = np.diag([1, 1, -1 if np.linalg.det(u @ vh) < 0 else 1])
            y = (y - yc) @ u @ correction @ vh + xc
            centroid_sse = internal_sse = pred_spread = gt_spread = 0.0
            for i in np.unique(residue):
                a, b = x[residue == i], y[residue == i]
                ac, bc = a.mean(0), b.mean(0)
                centroid_sse += len(a) * np.sum((ac - bc) ** 2)
                internal_sse += np.sum(((a - ac) - (b - bc)) ** 2)
                pred_spread += np.sum((a - ac) ** 2)
                gt_spread += np.sum((b - bc) ** 2)
            total = float(np.sum((x - y) ** 2))
            assert np.isclose(total, centroid_sse + internal_sse, atol=1e-8)
            rows.append(
                {
                    "group_id": record["group_id"],
                    "atoms": len(x),
                    "total_sse": total,
                    "centroid_error_sse": float(centroid_sse),
                    "internal_shape_error_sse": float(internal_sse),
                    "predicted_within_residue_sse": float(pred_spread),
                    "gt_within_residue_sse": float(gt_spread),
                    "prediction_sha256": sha256(prediction_path),
                }
            )
        count = sum(r["atoms"] for r in rows)
        summary = {
            key: sum(r[key] for r in rows)
            for key in rows[0]
            if key not in ("atoms", "group_id", "prediction_sha256")
        }
        summary.update(
            {
                "observed_atoms": count,
                "centroid_error_rmse": (summary["centroid_error_sse"] / count) ** 0.5,
                "internal_shape_error_rmse": (summary["internal_shape_error_sse"] / count) ** 0.5,
                "predicted_within_residue_radius": (summary["predicted_within_residue_sse"] / count)
                ** 0.5,
                "gt_within_residue_radius": (summary["gt_within_residue_sse"] / count) ** 0.5,
                "internal_shape_fraction_of_total_sse": summary["internal_shape_error_sse"]
                / summary["total_sse"],
            }
        )
        output[condition] = {"examples": rows, "summary": summary}
    result = {
        "complete": True,
        "scope": "post-hoc CPU analysis; no selection or new GPU forwards",
        "alignment": (
            "one proper all-observed-atom GT-to-prediction alignment per protein; "
            "residue-centroid ANOVA decomposition"
        ),
        "report_sha256": sha256(root / "report.json"),
        "conditions": output,
    }
    destination = root / "residue_shape_diagnosis.json"
    if destination.exists():
        assert json.loads(destination.read_text()) == result
    else:
        write_json(destination, result)
    validation = root / "residue_shape_validation.json"
    assert not validation.exists()
    write_json(
        validation,
        {
            "complete": True,
            "all32_three_conditions_recomputed": True,
            "result_sha256": sha256(destination),
            "source_sha256": sha256(Path(__file__)),
            "scope": "reproducibility and exact SSE decomposition; no new model run",
        },
    )
    print(json.dumps({k: v["summary"] for k, v in output.items()}, indent=2))


if __name__ == "__main__":
    main()
