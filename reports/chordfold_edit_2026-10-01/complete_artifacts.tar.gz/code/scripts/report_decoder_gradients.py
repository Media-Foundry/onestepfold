#!/usr/bin/env python3
"""Render the accepted four-target decoder-gradient feasibility audit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    args = parser.parse_args()
    report = json.loads((args.archive / "audit.json").read_text())
    qa = json.loads((args.archive / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"]
    rows = report["examples"]
    lengths = [str(row["length"]) for row in rows]
    x = np.arange(len(rows))
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), layout="constrained")
    labels = ("raw_state_target", "pointwise", "triangle")
    for index, label in enumerate(labels):
        axes[0].bar(
            x + (index - 1) * 0.24,
            [row["directions"][label]["cosine_with_negative_gradient"] for row in rows],
            width=0.24,
            label=label,
        )
    axes[0].axhline(0, color="black", linewidth=0.7)
    axes[0].set_ylabel("Cosine with negative coordinate-loss gradient")
    axes[0].legend(fontsize=8)
    axes[1].bar(x, [r["gradient"]["peak_allocated_bytes"] / 2**30 for r in rows])
    axes[1].set_ylabel("Peak allocated GPU memory (GiB)")
    forward = [r["gradient"]["forward_seconds"] for r in rows]
    backward = [r["gradient"]["backward_seconds"] for r in rows]
    axes[2].bar(x, forward, label="Forward")
    axes[2].bar(x, backward, bottom=forward, label="Backward incl. path audit")
    axes[2].set_ylabel("Synchronized time (seconds)")
    axes[2].set_title("No warmup; includes first-use overhead", fontsize=10)
    axes[2].legend(fontsize=8)
    for ax in axes:
        ax.set_xticks(x, lengths)
        ax.set_xlabel("Training protein length")
    fig.suptitle("Frozen-decoder gradient feasibility — four training-only targets")
    fig.savefig(args.prefix.with_suffix(".png"), dpi=180)
    plt.close(fig)
    lines = [
        "# Frozen-decoder gradient feasibility audit",
        "",
        "Four fixed training-only targets; no parameter optimization or held-out quality result.",
        "All teacher weights remain unchanged. Both pair_z and atom-pair p_lm carry gradients;",
        "reference-only c_l does not depend on pair state. Independent artifact/scalar and",
        "learner-prediction checks pass; QA does not repeat decoder backward.",
        "",
        "| Residues | Coordinate MSE | Gradient norm | Peak GiB | Forward s | Backward s |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        g = row["gradient"]
        lines.append(
            f"| {row['length']} | {g['loss']:.6g} | {g['norm']:.6g} | "
            f"{g['peak_allocated_bytes'] / 2**30:.3f} | {g['forward_seconds']:.3f} | "
            f"{g['backward_seconds']:.3f} |"
        )
    lines += [
        "",
        "Positive cosine below means a locally descending update in continuous FP32 state.",
        "It does not establish a finite-step or BF16-rounded structural improvement.",
        "",
        "| Residues | Oracle state delta | Pointwise delta | Triangle delta |",
        "|---:|---:|---:|---:|",
    ]
    for row in rows:
        values = [row["directions"][label]["cosine_with_negative_gradient"] for label in labels]
        lines.append(f"| {row['length']} | " + " | ".join(f"{v:.6f}" for v in values) + " |")
    lines += [
        "",
        "Shortest-target central finite differences:",
        "",
        "| Total L2 step | Analytic derivative | Numerical derivative | Relative error | "
        "BF16 changed fraction |",
        "|---:|---:|---:|---:|---:|",
    ]
    for probe in rows[0]["finite_differences"]:
        lines.append(
            f"| {probe['step']} | {probe['analytic']:.8g} | {probe['numerical']:.8g} | "
            f"{probe['relative_error']:.6g} | {probe['rounded_changed_fraction']:.6g} |"
        )
    lines += [
        "",
        f"Runtime sampler configuration: `{json.dumps(report['sampler_config'])}`.",
        f"First noise levels: `{[r['noise_level'] for r in rows]}`.",
        f"Checkpoint settings: `{json.dumps(report['decoder_checkpointing'])}`.",
        "",
        "The audited target uses c1 singles with the c4 pair at the same first noisy input.",
        "It is target-aware teacher supervision. Native sampler replays still use two NFE;",
        "the denoiser response precedes the Euler update and is not a one-evaluation model.",
        "Timings have no warmup and include first-use overhead plus the gradient-path audit;",
        "they are not steady-state training or end-to-end folding latency benchmarks.",
        "ESMC-600M adaptation, experimental-GT accuracy, the full 1,600 validation gate and",
        "one-cycle/one-structure-evaluation remain unfinished.",
        "",
        "Execution v1 failed on an unimported torch.utils.checkpoint module; v2 explicitly",
        "imports it while preserving all numerical and selection contracts.",
    ]
    args.prefix.with_suffix(".md").write_text("\n".join(lines) + "\n")
    args.prefix.with_suffix(".json").write_text(
        json.dumps({"audit": report, "qa": qa}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
