#!/usr/bin/env python3
"""Independent CPU artifact/NumPy scalar validation; no GPU derivative rerun."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def numpy_axes(x, anchors, epsilon):
    n, ca, c = (x[anchors[:, k]] for k in range(3))
    first = c - ca
    first /= np.maximum(np.linalg.norm(first, axis=1, keepdims=True), epsilon)
    second = n - ca
    second -= np.sum(second * first, axis=1, keepdims=True) * first
    second /= np.maximum(np.linalg.norm(second, axis=1, keepdims=True), epsilon)
    return ca, np.stack((first, second, np.cross(first, second)), axis=1)


def numpy_losses(x, target, mask, supervision):
    a, b = x[mask], target[mask]
    a, b = a - a.mean(0), b - b.mean(0)
    u, _, vh = np.linalg.svd(b.T @ a)
    correction = np.eye(3)
    correction[2, 2] = np.linalg.det(u @ vh)
    atom = np.mean(np.sum((a - b @ u @ correction @ vh) ** 2, axis=1))
    origins, axes = numpy_axes(x, supervision["frame_atoms"], supervision["epsilon"])
    rows, points = supervision["frame_rows"], supervision["point_indices"]
    local = np.einsum("pij,pj->pi", axes[rows], x[points] - origins[rows])
    frame = np.mean(np.sum((local - supervision["target_local"]) ** 2, axis=1))
    return {"aligned_atom_mse": float(atom), "local_frame_mse": float(frame)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    assert not (root / "independent_validation.json").exists()
    torch.set_num_threads(1)
    report = json.loads((root / "report.json").read_text())
    cpu = json.loads((root / "cpu_audit.json").read_text())
    assert report["complete"] and report["weights_unchanged"] and cpu["complete"]
    assert report["cpu_audit_sha256"] == sha256(root / "cpu_audit.json")
    assert report["capacity_report_sha256"] == cpu["capacity_report_sha256"]
    assert not report["runtime"]["matmul_allow_tf32"]
    assert not report["runtime"]["cudnn_allow_tf32"]
    for name, digest in report["source_sha256"].items():
        assert sha256(root / "source/execution" / name) == digest
    assert [r["provenance"]["length"] for r in report["examples"]] == [35, 166, 951]
    results = []
    for row in report["examples"]:
        provenance = row["provenance"]
        assert provenance["split"] == "train"
        folder = root / provenance["group_id"]
        for name, digest in row["artifact_sha256"].items():
            assert sha256(folder / name) == digest
        for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
            assert sha256(folder / name) == provenance[key]
        with np.load(folder / "inventory.npz", allow_pickle=False) as data:
            inventory = dict(data)
        with np.load(folder / "gt.npz", allow_pickle=False) as data:
            arrays = dict(data)
        metadata = json.loads((folder / "gt.json").read_text())
        mapped = map_experimental_atoms(
            arrays, metadata, provenance["sequence"], provenance["sample_id"], inventory
        )
        packet = torch.load(folder / "labels.pt", map_location="cpu", weights_only=True)
        assert feature_digest(mapped) == feature_digest(packet["labels"])
        assert feature_digest(packet["supervision"]) == row["supervision_sha256"]
        supervision = {
            k: v.numpy() if isinstance(v, torch.Tensor) else v
            for k, v in packet["supervision"].items()
        }
        target = mapped["coordinate"].numpy().astype(np.float64)
        mask = mapped["coordinate_mask"].numpy()
        # Reconstruct eligible anchor triples and neighbor membership directly from GT.
        anchors = []
        names, residues = inventory["atom_name"], inventory["residue_id"]
        for residue in np.unique(residues):
            indices = [
                np.flatnonzero((residues == residue) & (names == n)) for n in ("N", "CA", "C")
            ]
            if not all(len(i) == 1 and mask[i[0]] for i in indices):
                continue
            triplet = np.array([i[0] for i in indices])
            n, ca, c = target[triplet]
            a = c - ca
            norm = np.linalg.norm(a)
            if norm <= supervision["epsilon"]:
                continue
            a /= norm
            b = n - ca - np.dot(n - ca, a) * a
            if np.linalg.norm(b) > supervision["epsilon"]:
                anchors.append(triplet)
        assert np.array_equal(np.array(anchors), supervision["frame_atoms"])
        expected_rows, expected_points = [], []
        for i, triplet in enumerate(anchors):
            inside = mask & (
                np.linalg.norm(target - target[triplet[1]], axis=1) <= supervision["radius"]
            )
            inside[triplet[1]] = False
            points = np.flatnonzero(inside)
            expected_rows.extend([i] * len(points))
            expected_points.extend(points.tolist())
        assert np.array_equal(expected_rows, supervision["frame_rows"])
        assert np.array_equal(expected_points, supervision["point_indices"])
        origins, axes = numpy_axes(target, supervision["frame_atoms"], supervision["epsilon"])
        gt_local = np.einsum(
            "pij,pj->pi", axes[expected_rows], target[expected_points] - origins[expected_rows]
        )
        assert np.allclose(gt_local, supervision["target_local"], atol=1e-10, rtol=0)
        with np.load(folder / "prediction.npz", allow_pickle=False) as data:
            x = data["coordinate"].astype(np.float64)
        assert np.isfinite(x).all()
        values = numpy_losses(x, target, mask, supervision)
        differences = {}
        for name, value in values.items():
            actual = row["components"][name]["value"]
            # FP32 CUDA local-frame normalization versus independent FP64 arithmetic.
            assert np.isclose(value, actual, rtol=1e-4, atol=1e-3), (name, value, actual)
            differences[name] = abs(value - actual)
        assert row["train_eval_replay_exact"]
        assert row["forward_counts"] == {"trunk": 1, "structure": 1, "confidence": 0}
        assert row["nonzero_gradient_tensors"] > 0
        for key in ("esmc_projection_gradient_norm", "output_projection_gradient_norm"):
            assert np.isfinite(row[key]) and row[key] > 0
        if provenance["length"] != 951:
            assert row["accepted_best_replay_exact"]
        if "disposable_probe" in row:
            with np.load(folder / "perturbed_prediction.npz", allow_pickle=False) as data:
                perturbed = data["coordinate"].astype(np.float64)
            after = numpy_losses(perturbed, target, mask, supervision)
            assert sum(after.values()) < sum(values.values())
            assert row["disposable_probe"]["scalar_decreased"]
            assert np.isclose(row["disposable_probe"]["weight_l2_displacement"], 1e-5, rtol=0.02)
        results.append(
            {
                "group_id": provenance["group_id"],
                "numpy_fp64": values,
                "absolute_scalar_discrepancy": differences,
            }
        )
    write_json(
        root / "independent_validation.json",
        {
            "complete": True,
            "report_sha256": sha256(root / "report.json"),
            "examples": results,
            "validator_sha256": sha256(Path(__file__)),
            "scope": "CPU source/artifact/GT/independent FP64 scalar checks; no GPU replay",
        },
    )
    print(json.dumps({"complete": True, "examples": results}, indent=2))


if __name__ == "__main__":
    main()
