#!/usr/bin/env python3
"""Observe one existing Slurm job, then audit/archive its final artifacts once.

This never submits, cancels, resumes or changes a training job. SSH observation
failures are retried against the same job ID; only sacct terminal status permits
postprocessing. CPU QA reads completed artifacts without reserving another GPU.
"""

from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    parser.add_argument("--host", default="hpc3")
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-code", required=True)
    parser.add_argument("--validation-code", required=True)
    parser.add_argument("--remote-selection", required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    args = parser.parse_args()
    args.archive.mkdir(parents=True, exist_ok=True)
    status_path = args.archive / "completion_workflow.json"
    if status_path.exists() and json.loads(status_path.read_text()).get("complete"):
        raise RuntimeError("completion workflow already accepted; inspect existing artifacts")
    repository = Path(__file__).resolve().parents[1]

    def status(**values):
        result = {"job": args.job, "host": args.host, "complete": False, **values}
        temporary = status_path.with_suffix(".part")
        temporary.write_text(json.dumps(result, indent=2) + "\n")
        temporary.replace(status_path)
        print(json.dumps(result), flush=True)

    def remote(arguments, timeout=300):
        return subprocess.run(
            ["ssh", args.host, shlex.join(arguments)],
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    started = time.monotonic()
    while time.monotonic() - started < 90 * 60:
        try:
            result = remote(
                [
                    "sacct",
                    "-j",
                    args.job,
                    "--noheader",
                    "--parsable2",
                    "--format=JobIDRaw,State,ExitCode,Elapsed",
                ],
                timeout=30,
            )
            lines = [line.split("|") for line in result.stdout.splitlines()]
            row = next((r for r in lines if r[0] == args.job), None)
        except (subprocess.SubprocessError, OSError) as exc:
            status(phase="observation_retry", error=str(exc))
            time.sleep(30)
            continue
        if row is None:
            status(phase="accounting_not_visible", action="retry same job; no submission")
        elif row[1] == "COMPLETED":
            if row[2] != "0:0":
                status(phase="terminal_error", accounting=row)
                return 1
            status(phase="cpu_final_audit", accounting=row)
            break
        elif row[1].split()[0].rstrip("+") in {
            "FAILED",
            "CANCELLED",
            "TIMEOUT",
            "OUT_OF_MEMORY",
            "NODE_FAIL",
            "PREEMPTED",
            "BOOT_FAIL",
            "DEADLINE",
            "REVOKED",
        }:
            status(phase="terminal_error", accounting=row, action="inspect; no restart")
            return 1
        else:
            status(phase="waiting_for_existing_job", accounting=row)
        time.sleep(30)
    else:
        status(phase="observation_time_budget", action="leave job untouched; recheck same handle")
        return 2

    cpu_python = "/data/user/shuang886/.conda/envs/fold/bin/python"
    # The audit rejects an existing result, preventing duplicate overwrites.
    audit = remote(
        [
            "env",
            "CUDA_VISIBLE_DEVICES=",
            "OMP_NUM_THREADS=1",
            "MKL_NUM_THREADS=1",
            f"PYTHONPATH={args.validation_code}/src",
            cpu_python,
            f"{args.validation_code}/scripts/validate_esmc_distance_capacity.py",
            "--root",
            args.remote_root,
            "--code-root",
            args.remote_code,
            "--selection-manifest",
            args.remote_selection,
            "--check-heavy-artifacts",
        ]
    )
    (args.archive / "final_audit_stdout.json").write_text(audit.stdout)
    subprocess.run(
        [
            "rsync",
            "-a",
            "--include=*/",
            "--include=*.json",
            "--include=*.jsonl",
            "--include=*.npz",
            "--include=supervision.pt",
            "--include=distance_supervision.pt",
            "--exclude=*",
            f"{args.host}:{args.remote_root}/",
            str(args.archive) + "/",
        ],
        check=True,
    )
    source = args.archive / "source/final_validation"
    source.mkdir(parents=True, exist_ok=True)
    for name in (
        "validate_esmc_distance_capacity.py",
        "validate_esmc_distance_gradients.py",
        "validate_esmc_capacity.py",
        "validate_esmc_frame_supervision.py",
    ):
        subprocess.run(
            [
                "rsync",
                "-a",
                f"{args.host}:{args.validation_code}/scripts/{name}",
                str(source) + "/",
            ],
            check=True,
        )
    subprocess.run(
        [
            sys.executable,
            str(repository / "scripts/report_esmc_distance_capacity.py"),
            "--root",
            str(args.archive),
            "--prefix",
            str(args.prefix),
        ],
        cwd=repository,
        check=True,
    )
    status(
        phase="complete",
        complete=True,
        accounting=row,
        scope="final CPU QA/compact archive/geometry-capacity report; research goal remains open",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
