#!/usr/bin/env python3
"""CPU-only checkpoint compatibility audit; no training or inference."""
import argparse
import hashlib
import json
import os
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    manifest = json.loads((args.source / 'source_manifest.json').read_text())
    for name, digest in manifest['files'].items():
        assert sha(args.source / name) == digest, name
    digest = sha(args.checkpoint)
    assert digest == '1301bba9ad322518eace60fd244ded7904439f55317e90d402cc7a0c06026664'
    import torch
    from fastglycan.models.esmc_core import ESMCFoldCore
    torch.set_num_threads(1)
    saved = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    containers = [k for k in ('model', 'state_dict') if k in saved]
    assert len(containers) <= 1, containers
    state = saved[containers[0]] if containers else saved
    assert all(isinstance(v, torch.Tensor) for v in state.values())
    prefixed = all(k.startswith('module.') for k in state)
    native = {k.removeprefix('module.') if prefixed else k: v for k, v in state.items()}
    assert len(native) == len(state)
    model = ESMCFoldCore(seed=101, deterministic_capacity=True)
    target = model.core.state_dict()
    missing = sorted(set(target) - set(native))
    unexpected = sorted(set(native) - set(target))
    mismatches = {
        k: {'native': list(native[k].shape), 'esmc': list(target[k].shape)}
        for k in sorted(set(target) & set(native))
        if target[k].shape != native[k].shape
    }
    matched = {k: native[k] for k in target if k in native and k not in mismatches}
    # Exact retained-tensor replay, with the interface difference enumerated.
    result = model.core.load_state_dict(matched, strict=False)
    assert sorted(result.missing_keys) == sorted(set(missing) | set(mismatches))
    assert not result.unexpected_keys
    loaded = model.core.state_dict()
    assert all(torch.equal(loaded[k], native[k]) for k in matched)
    report = dict(
        complete=True, scope='CPU checkpoint tensor audit only; no functional compatibility or quality claim',
        job_id=os.environ.get('SLURM_JOB_ID'), checkpoint=str(args.checkpoint),
        checkpoint_sha256=digest, script_sha256=sha(Path(__file__)),
        source_manifest_sha256=sha(args.source / 'source_manifest.json'),
        checkpoint_container=containers[0] if containers else None,
        stripped_module_prefix=prefixed, native_tensors=len(native), esmc_tensors=len(target),
        missing=missing, unexpected=unexpected, shape_mismatches=mismatches,
        matched_tensors=len(matched), matched_elements=sum(v.numel() for v in matched.values()),
        esmc_elements=sum(v.numel() for v in target.values()), retained_tensors_exact=True,
        optimizer_updates=0, gpu_inference_calls=0,
    )
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
