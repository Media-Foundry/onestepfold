#!/usr/bin/env python3
"""Audit c2-only confidence against validation residuals; fit no routing policy."""

from __future__ import annotations

import argparse
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from onestepfold.data.teacher_pairs import load_confidence, load_teacher_pair_manifest


def ranks(values):
    values = np.asarray(values)
    order = np.argsort(values, kind="stable")
    _, starts, counts = np.unique(values[order], return_index=True, return_counts=True)
    result = np.empty(len(values), dtype=np.float64)
    result[order] = np.repeat(starts + (counts - 1) / 2, counts)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--teacher-root", type=Path, required=True)
    parser.add_argument("--examples-json", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    records = load_teacher_pair_manifest(
        args.teacher_root / "control/teacher_pair_manifest_v1.jsonl.gz", split="validation"
    )
    examples = json.loads(args.examples_json.read_text())["examples"]
    indexed = {row["group_id"]: row for row in examples}
    assert len(indexed) == len(records) == 1600
    assert indexed.keys() == {record.group_id for record in records}

    def load(record):
        confidence = load_confidence(args.teacher_root / record.c2_confidence)
        if confidence.get("num_recycles") != 2:
            raise ValueError("audit requires c2-only confidence")
        row = {
            key: indexed[record.group_id][key]
            for key in (
                "group_id",
                "valid_residues",
                "baseline_ca_rmsd",
                "baseline_pair_distance_rmse",
                "ca_rmsd",
                "pair_distance_rmse",
            )
        }
        row.update({key: float(confidence[key]) for key in ("plddt", "ptm", "gpde")})
        assert 0 <= row["plddt"] <= 100 and 0 <= row["ptm"] <= 1 and row["gpde"] >= 0
        return row

    with ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(load, records))
    length = ranks([r["valid_residues"] for r in rows])
    design = np.stack((np.ones(len(rows)), length), axis=1)
    correlations = {}
    for feature in ("plddt", "ptm", "gpde"):
        x = ranks([r[feature] for r in rows])
        residual_x = x - design @ np.linalg.lstsq(design, x, rcond=None)[0]
        entry = {}
        for target in ("baseline_ca_rmsd", "baseline_pair_distance_rmse"):
            y = ranks([r[target] for r in rows])
            residual_y = y - design @ np.linalg.lstsq(design, y, rcond=None)[0]
            entry[target] = {
                "spearman": float(np.corrcoef(x, y)[0, 1]),
                "length_controlled_rank_correlation": float(
                    np.corrcoef(residual_x, residual_y)[0, 1]
                ),
            }
        correlations[feature] = entry
    bins = {}
    for name, lower, upper in (
        ("plddt_under_70", 0, 70),
        ("plddt_70_to_90", 70, 90),
        ("plddt_at_least_90", 90, 101),
    ):
        subset = [r for r in rows if lower <= r["plddt"] < upper]
        bins[name] = {"examples": len(subset)}
        if subset:
            bins[name].update(
                {
                    "median_baseline_ca_rmsd": float(
                        np.median([r["baseline_ca_rmsd"] for r in subset])
                    ),
                    "baseline_ca_under_1A_fraction": sum(r["baseline_ca_rmsd"] < 1 for r in subset)
                    / len(subset),
                    "refined_pair_worse_fraction": sum(
                        r["pair_distance_rmse"] > r["baseline_pair_distance_rmse"] for r in subset
                    )
                    / len(subset),
                }
            )
    payload = {
        "examples": len(rows),
        "correlations": correlations,
        "bins": bins,
        "per_example": rows,
        "frozen_temporal_test_read": False,
        "scope": (
            "Validation diagnostic only; no policy or threshold fitted; "
            "c4 residuals are labels only."
        ),
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({k: v for k, v in payload.items() if k != "per_example"}, indent=2))


if __name__ == "__main__":
    main()
