#!/usr/bin/env python3
"""Controlled fresh-core training through the audited chemical output adapter."""

from __future__ import annotations

import argparse
import json
import os
import random
import shutil
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch
from train_esmc_capacity import INITIAL_HASH, save_checkpoint, seed, summarize

from fastglycan.articulated_capacity_control import verify_articulated_control
from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.distance_supervision import build_distance_labels, observed_distance_mse
from fastglycan.experimental_geometry import compare_local_geometry
from fastglycan.experimental_metrics import compare_experimental
from fastglycan.experimental_training import map_experimental_atoms, observed_aligned_mse
from fastglycan.frame_attribution import frame_partitions
from fastglycan.frame_supervision import build_frame_labels, local_frame_mse, training_sampler_seed
from fastglycan.geometry_capacity import (
    EVALUATION_SEEDS,
    geometry_summary,
    joint_summary,
    stop_reason,
)
from fastglycan.models.esmc_core import ESMCFoldCore
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser()
    for name in ("baseline-root", "audit-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--frame-weight", type=float, choices=(0.1,), default=0.1)
    parser.add_argument("--matched-root", type=Path, required=True)
    parser.add_argument("--gradient-audit-root", type=Path, required=True)
    parser.add_argument("--cpu-interface-root", type=Path, required=True)
    parser.add_argument("--articulation-root", type=Path, required=True)
    args = parser.parse_args()
    frame_weight = args.frame_weight
    matched = None
    if frame_weight == 0.1:
        assert args.matched_root is not None and args.gradient_audit_root is not None
        matched = json.loads((args.matched_root / "contract.json").read_text())
        matched_report = json.loads((args.matched_root / "report.json").read_text())
        matched_qa = json.loads((args.matched_root / "independent_validation.json").read_text())
        assert matched_qa["complete"] and matched_qa["heavy_artifacts_checked"]
        assert (
            sha256(args.matched_root / "report.json")
            == matched_qa["report_sha256"]
            == ("8ff68aef2e56d801ce64b1736ab50c4525ff03451090bcd179de1ab5bfe500ab")
        )
        assert sha256(args.matched_root / "contract.json") == matched_report["contract_sha256"]
        gradient_qa = json.loads(
            (args.gradient_audit_root / "independent_validation.json").read_text()
        )
        assert gradient_qa["complete"]
        assert (
            sha256(args.gradient_audit_root / "report.json")
            == gradient_qa["report_sha256"]
            == ("a91dea42d8b96a606cfcf6fa0a30a8f97c83e8f3006e64daa42f3c836f482995")
        )
    cpu_report = json.loads((args.cpu_interface_root / "report.json").read_text())
    assert cpu_report["complete"]
    assert (
        sha256(args.cpu_interface_root / "report.json")
        == "07d2b5f5ebdca0c2d4b9193ca989adc49cc16ff6a6fa557d8accbf271a85e8e2"
    )
    articulation = json.loads((args.articulation_root / "report.json").read_text())
    assert (
        articulation["complete"]
        and sha256(args.articulation_root / "report.json")
        == cpu_report["articulation_report_sha256"]
    )
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    os.chdir(root)
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    base = json.loads((args.baseline_root / "contract.json").read_text())
    baseline = json.loads((args.baseline_root / "report.json").read_text())
    qa = json.loads((args.baseline_root / "independent_validation.json").read_text())
    assert qa["complete"] and qa["report_sha256"] == sha256(args.baseline_root / "report.json")
    assert qa["report_sha256"] == "ea15ac86b031d87b5cd0641baa99909b63eb07b769fd1ae0168c91cc8f3120ac"
    assert baseline["contract_sha256"] == sha256(args.baseline_root / "contract.json")
    audit = json.loads((args.audit_root / "independent_validation.json").read_text())
    assert audit["complete"] and audit["report_sha256"] == sha256(args.audit_root / "report.json")
    assert (
        audit["report_sha256"] == "4ab48258e4f9b14646e6331268bbf05450cc0a336bd22f0cfceb293b4b78b1eb"
    )
    source = Path(__file__).resolve().parents[1]
    for name in ("src/fastglycan/models/esmc_core.py", "src/fastglycan/experimental_training.py"):
        assert sha256(source / name) == base["source_sha256"][name]
    with patch("torch.load", side_effect=AssertionError("folding checkpoint load forbidden")):
        model = ESMCFoldCore(seed=101, deterministic_capacity=True)
    assert feature_digest(model.state_dict()) == INITIAL_HASH
    assert model.config.to_dict() == base["config"]
    save_checkpoint(root / "initial.pt", model.state_dict())
    frozen = (model.core.confidence_head, model.core.distogram_head)
    for module in frozen:
        module.requires_grad_(False)
    frozen_hashes = [feature_digest(m.state_dict()) for m in frozen]
    shutil.copy2(args.articulation_root / "report.json", root / "articulation_report.json")
    prepared, frame_provenance, same_residue_provenance, distance_provenance = [], [], [], []
    adapters, adapter_provenance = {}, []
    selected = base["selection"]
    assert len(selected) == 32
    seeds = [training_sampler_seed(r["group_id"], e) for r in selected for e in range(1, 101)]
    assert len(seeds) == len(set(seeds)) == 3200
    assert not set(seeds).intersection(EVALUATION_SEEDS)
    for record, provenance in zip(selected, base["input_provenance"], strict=True):
        group = record["group_id"]
        assert record["split"] == provenance["split"] == "train"
        assert provenance["group_id"] == group
        old, folder = args.baseline_root / group, root / group
        folder.mkdir()
        for name, key in (
            ("inputs.pt", "inputs_sha256"),
            ("gt.npz", "gt_npz_sha256"),
            ("gt.json", "gt_metadata_sha256"),
        ):
            assert sha256(old / name) == provenance[key]
        packet = torch.load(old / "inputs.pt", map_location="cpu", weights_only=True)
        features, labels = packet["features"], packet["labels"]
        assert feature_digest(features) == provenance["feature_sha256"]
        with np.load(old / "inventory.npz", allow_pickle=False) as data:
            inventory = dict(data)
        with np.load(old / "gt.npz", allow_pickle=False) as data:
            arrays = dict(data)
        metadata = json.loads((old / "gt.json").read_text())
        mapped = map_experimental_atoms(
            arrays, metadata, record["sequence"], record["sample_id"], inventory
        )
        assert feature_digest(mapped) == feature_digest(labels)
        supervision = build_frame_labels(labels, inventory)
        for name in ("gt.npz", "gt.json", "inventory.npz", "input_provenance.json"):
            shutil.copy2(old / name, folder / name)
        save_checkpoint(folder / "supervision.pt", supervision)
        frame_provenance.append(
            {
                "group_id": group,
                "sha256": feature_digest(supervision),
                "file_sha256": sha256(folder / "supervision.pt"),
            }
        )
        local_supervision = frame_partitions(supervision, inventory["residue_id"])["same_residue"]
        assert len(local_supervision["frame_rows"]) > 0
        same_residue_provenance.append(
            {
                "group_id": group,
                "sha256": feature_digest(local_supervision),
                "pair_count": len(local_supervision["frame_rows"]),
            }
        )
        distance_supervision = build_distance_labels(labels, inventory)
        assert distance_supervision["category"].bincount(minlength=4).min() > 0
        save_checkpoint(folder / "distance_supervision.pt", distance_supervision)
        distance_provenance.append(
            {
                "group_id": group,
                "sha256": feature_digest(distance_supervision),
                "file_sha256": sha256(folder / "distance_supervision.pt"),
                "category_counts": distance_supervision["category"].bincount(minlength=4).tolist(),
            }
        )
        assert features["ref_mask"].bool().all()
        adapter = ArticulatedOutput(
            features["ref_pos"].numpy(),
            inventory["atom_name"],
            inventory["residue_id"],
            record["sequence"],
            articulation["variants"],
        ).float()
        assert not list(adapter.parameters())
        adapters[id(features)] = adapter
        np.savez_compressed(
            folder / "reference.npz",
            reference=features["ref_pos"].numpy(),
            reference_mask=features["ref_mask"].numpy(),
        )
        adapter_provenance.append(
            {
                "group_id": group,
                "state_sha256": feature_digest(adapter.state_dict()),
                "reference_sha256": sha256(folder / "reference.npz"),
            }
        )
        prepared.append(
            (
                features,
                labels,
                inventory,
                arrays,
                supervision,
                local_supervision,
                distance_supervision,
            )
        )
    names = (
        "scripts/train_esmc_articulated_capacity.py",
        "scripts/slurm_esmc_articulated_capacity.sh",
        "scripts/train_esmc_capacity.py",
        "docs/esmc_geometry_capacity_v1.md",
        "src/fastglycan/geometry_capacity.py",
        "src/fastglycan/frame_supervision.py",
        "src/fastglycan/experimental_training.py",
        "src/fastglycan/experimental_metrics.py",
        "src/fastglycan/experimental_geometry.py",
        "src/fastglycan/all_atom_metrics.py",
        "src/fastglycan/models/esmc_core.py",
        "src/fastglycan/decoder_gradients.py",
        "src/fastglycan/capacity_weight_control.py",
        "src/fastglycan/local_capacity_control.py",
        "src/fastglycan/distance_capacity_control.py",
        "src/fastglycan/distance_supervision.py",
        "docs/esmc_distance_capacity_v1.md",
        "docs/esmc_articulated_capacity_v1.md",
        "src/fastglycan/articulated_output.py",
        "src/fastglycan/articulated_reference.py",
        "src/fastglycan/articulated_capacity_control.py",
        "src/fastglycan/articulated_validation.py",
        "src/fastglycan/frame_attribution.py",
        "docs/esmc_local_capacity_v1.md",
    )
    if matched is not None:
        names += (
            "docs/esmc_geometry_capacity_weight01_v1.md",
            "scripts/slurm_esmc_geometry_capacity_weight01.sh",
        )
    gradient_report = json.loads((args.gradient_audit_root / "report.json").read_text())
    assert (
        sha256(source / "src/fastglycan/distance_supervision.py")
        == gradient_report["source_sha256"]["src/fastglycan/distance_supervision.py"]
    )
    for name in (
        "src/fastglycan/frame_attribution.py",
        "src/fastglycan/frame_supervision.py",
        "src/fastglycan/experimental_training.py",
        "src/fastglycan/models/esmc_core.py",
    ):
        assert sha256(source / name) == gradient_report["source_sha256"][name]
    contract = {
        "schema_version": "esmc-articulated-capacity-v1",
        "output_adapter": "articulated_output_v1",
        "adapter_parameters": 0,
        "adapter_provenance": adapter_provenance,
        "articulation_report_sha256": sha256(root / "articulation_report.json"),
        "cpu_interface_root": str(args.cpu_interface_root),
        "cpu_interface_report_sha256": sha256(args.cpu_interface_root / "report.json"),
        "config": model.config.to_dict(),
        "selection": selected,
        "selection_sha256": base["selection_sha256"],
        "input_provenance": base["input_provenance"],
        "frame_provenance": frame_provenance,
        "baseline_root": str(args.baseline_root),
        "audit_root": str(args.audit_root),
        "baseline_report_sha256": qa["report_sha256"],
        "audit_report_sha256": audit["report_sha256"],
        "baseline_contract_sha256": sha256(args.baseline_root / "contract.json"),
        "initial_weights_sha256": INITIAL_HASH,
        "initial_checkpoint_sha256": sha256(root / "initial.pt"),
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "trainable_parameter_count": sum(p.numel() for p in model.parameters() if p.requires_grad),
        "frame_weight": frame_weight,
        "same_residue_weight": 1.0,
        "distance_weight": 10.0,
        "distance_provenance": distance_provenance,
        "same_residue_provenance": same_residue_provenance,
        "evaluation_seeds": list(EVALUATION_SEEDS),
        "training_seed_sha256": feature_digest(seeds),
        "optimizer": base["optimizer"],
        "source_sha256": {n: sha256(source / n) for n in names},
        "runtime": {
            "torch": torch.__version__,
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
        },
        "scope": "TRAIN32 controlled articulated output; no held-out/confidence claim",
    }
    for name, digest in base["runtime_source_sha256"].items():
        assert sha256(Path(name)) == digest
    contract["runtime_source_sha256"] = base["runtime_source_sha256"]
    if matched is not None:
        contract["articulated_control"] = verify_articulated_control(contract, matched)
        contract["matched_root"] = str(args.matched_root)
        contract["matched_report_sha256"] = sha256(args.matched_root / "report.json")
        contract["gradient_audit_root"] = str(args.gradient_audit_root)
        contract["gradient_audit_report_sha256"] = sha256(args.gradient_audit_root / "report.json")
    write_json(root / "contract.json", contract)
    for name in ("src/fastglycan/articulated_output.py", "src/fastglycan/articulated_reference.py"):
        assert (
            sha256(source / name)
            == gradient_report["source_sha256"][name]
            == cpu_report["source_sha256"][name]
        )
    model.cuda()
    for adapter in adapters.values():
        adapter.cuda()
    parameters = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    counts = {"trunk": 0, "structure": 0, "confidence": 0}

    def counter(name):
        def hook(*_):
            counts[name] += 1

        return hook

    handles = [
        m.register_forward_pre_hook(counter(n))
        for n, m in (
            ("trunk", model.core.pairformer_stack),
            ("structure", model.core.diffusion_module),
            ("confidence", model.core.confidence_head),
        )
    ]

    last_execution = {}
    initial_adapter_errors = []

    def execute(features, noise, train=False):
        last_execution.clear()
        model.train(train)
        seed(noise)
        counts.update(dict.fromkeys(counts, 0))
        with torch.set_grad_enabled(train):
            core_result = model(features, confidence=False)
            raw = core_result["coordinate"][0]
            before = time.perf_counter()
            adapted = adapters[id(features)](raw)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - before
            result = adapted["coordinate"]
            last_execution.update(
                raw=raw,
                fallbacks=adapted["fallback_counts"].tolist(),
                adapter_seconds=elapsed,
                core_plus_adapter_seconds=core_result["timing"]["total_core_seconds"] + elapsed,
            )
        assert counts == {"trunk": 1, "structure": 1, "confidence": 0}
        assert torch.isfinite(result).all()
        return result

    def evaluate(save=None):
        conditions = {}
        for noise in EVALUATION_SEEDS:
            rows = []
            for record_index, (record, packet) in enumerate(zip(selected, prepared, strict=True)):
                (
                    features,
                    _,
                    inventory,
                    arrays,
                    supervision,
                    local_supervision,
                    distance_supervision,
                ) = packet
                xyz = execute(features, noise)
                frame = float(local_frame_mse(xyz, supervision))
                prediction = dict(inventory) | {"coordinate": xyz.cpu().numpy()}
                row = {
                    "group_id": record["group_id"],
                    "metrics": compare_experimental(prediction, arrays, record["sequence"]),
                    "geometry": compare_local_geometry(prediction, arrays, record["sequence"]),
                    "local_frame_mse": frame,
                    "same_residue_frame_mse": float(local_frame_mse(xyz, local_supervision)),
                    "fallback_counts": last_execution["fallbacks"],
                    "adapter_seconds": last_execution["adapter_seconds"],
                    "core_plus_adapter_seconds": last_execution["core_plus_adapter_seconds"],
                    "observed_distance_mse": float(
                        observed_distance_mse(xyz, distance_supervision)
                    ),
                }
                assert row["metrics"]["predicted_gt_coverage"] == 1
                if save:
                    path = root / record["group_id"] / f"{save}_{noise}.npz"
                    np.savez_compressed(
                        path,
                        **prediction,
                        raw_coordinate=last_execution["raw"].detach().cpu().numpy(),
                    )
                    row["prediction_sha256"] = sha256(path)
                if save == "initial" and noise == 12345:
                    with np.load(
                        args.baseline_root / record["group_id"] / "initial_prediction.npz",
                        allow_pickle=False,
                    ) as old:
                        assert np.array_equal(
                            last_execution["raw"].detach().cpu().numpy(), old["coordinate"]
                        )
                if save == "initial" and matched is not None:
                    path = args.matched_root / record["group_id"] / f"initial_{noise}.npz"
                    expected = matched_report["initial"]["conditions"][str(noise)]["examples"][
                        record_index
                    ]
                    assert sha256(path) == expected["prediction_sha256"]
                    with np.load(path, allow_pickle=False) as old:
                        assert np.array_equal(
                            last_execution["raw"].detach().cpu().numpy(), old["coordinate"]
                        )
                if save == "initial":
                    path = args.cpu_interface_root / record["group_id"] / f"initial_{noise}.npz"
                    expected = cpu_report["conditions"][f"initial_{noise}"][record_index]
                    assert (
                        expected["group_id"] == record["group_id"]
                        and sha256(path) == expected["prediction_sha256"]
                    )
                    with np.load(path, allow_pickle=False) as cpu_prediction:
                        error = float(
                            np.max(np.abs(prediction["coordinate"] - cpu_prediction["coordinate"]))
                        )
                    assert error <= 5e-5, error
                    initial_adapter_errors.append(error)
                rows.append(row)
            conditions[str(noise)] = {
                "examples": rows,
                "summary": summarize(rows) | geometry_summary(rows),
                "mean_same_residue_frame_mse": float(
                    np.mean([r["same_residue_frame_mse"] for r in rows])
                ),
                "mean_observed_distance_mse": float(
                    np.mean([r["observed_distance_mse"] for r in rows])
                ),
            }
        return {"conditions": conditions, "summary": joint_summary(conditions)}

    a = execute(prepared[0][0], 12345).cpu()
    b = execute(prepared[0][0], 12345, True).detach().cpu()
    assert torch.equal(a, b)
    del a, b
    model.zero_grad(set_to_none=True)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    initial = evaluate(save="initial")
    if matched is not None:
        write_json(
            root / "matched_initial_validation.json",
            {
                "complete": True,
                "predictions": 64,
                "all_raw_initial_predictions_exact": True,
                "adapted_initial_max_abs_error": max(initial_adapter_errors),
                "matched_report_sha256": contract["matched_report_sha256"],
                "contract_sha256": sha256(root / "contract.json"),
            },
        )
    history = [{"epoch": 0, "step": 0, **initial, "elapsed_seconds": time.monotonic() - started}]
    write_json(root / "history.json", history)
    best_epoch, best_value = 0, initial["summary"]["selection_score"]

    def save_best(epoch):
        save_checkpoint(
            root / "best.pt",
            {
                "model": model.state_dict(),
                "epoch": epoch,
                "contract_sha256": sha256(root / "contract.json"),
            },
        )

    save_best(0)
    step, stop, gradient_probe = 0, "epoch_budget", None
    optimization_started = time.monotonic()
    for epoch in range(1, 101):
        losses, atoms, frames, locals_, distances_, norms, epoch_seeds = [], [], [], [], [], [], []
        epoch_fallbacks = np.zeros(3, dtype=np.int64)
        order = list(range(32))
        random.Random(101 + epoch).shuffle(order)
        for index in order:
            features, labels, _, _, supervision, local_supervision, distance_supervision = prepared[
                index
            ]
            noise = training_sampler_seed(selected[index]["group_id"], epoch)
            epoch_seeds.append(noise)
            optimizer.zero_grad(set_to_none=True)
            prediction = execute(features, noise, True)
            epoch_fallbacks += np.array(last_execution["fallbacks"])
            atom = observed_aligned_mse(
                prediction, labels["coordinate"].cuda(), labels["coordinate_mask"].cuda()
            )
            frame = local_frame_mse(prediction, supervision)
            local = local_frame_mse(prediction, local_supervision)
            distance = observed_distance_mse(prediction, distance_supervision)
            loss = atom + frame_weight * frame + local + 10.0 * distance
            assert torch.isfinite(loss)
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(parameters, 10, error_if_nonfinite=True)
            if gradient_probe is None:
                projection = model.core.input_embedder.linear_esm.weight
                assert projection.grad is not None and projection.grad.norm() > 0
                gradient_probe = {
                    "projection_gradient_norm_after_clip": float(projection.grad.norm()),
                    "nonzero_gradient_tensors": sum(
                        p.grad is not None and bool(p.grad.count_nonzero()) for p in parameters
                    ),
                }
            optimizer.step()
            losses.append(float(loss.detach()))
            atoms.append(float(atom.detach()))
            frames.append(float(frame.detach()))
            locals_.append(float(local.detach()))
            distances_.append(float(distance.detach()))
            norms.append(float(norm))
            del prediction, atom, frame, local, distance, loss
            step += 1
        optimizer.zero_grad(set_to_none=True)
        train_row = {
            "epoch": epoch,
            "step": step,
            "mean_loss": float(np.mean(losses)),
            "fallback_counts": epoch_fallbacks.tolist(),
            "mean_aligned_atom_mse": float(np.mean(atoms)),
            "mean_local_frame_mse": float(np.mean(frames)),
            "mean_same_residue_frame_mse": float(np.mean(locals_)),
            "mean_observed_distance_mse": float(np.mean(distances_)),
            "max_gradient_norm_before_clip": max(norms),
            "training_seed_sha256": feature_digest(epoch_seeds),
            "elapsed_seconds": time.monotonic() - started,
        }
        with (root / "training.jsonl").open("a") as handle:
            handle.write(json.dumps(train_row) + "\n")
        write_json(root / "progress.json", train_row)
        exceeded = time.monotonic() - optimization_started >= 75 * 60
        if epoch % 5 and not exceeded:
            continue
        row = train_row | evaluate()
        history.append(row)
        if row["summary"]["selection_score"] < best_value:
            best_value, best_epoch = row["summary"]["selection_score"], epoch
            save_best(epoch)
        save_checkpoint(
            root / "last.pt",
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "epoch": epoch,
                "step": step,
                "best_epoch": best_epoch,
                "contract_sha256": sha256(root / "contract.json"),
            },
        )
        write_json(root / "history.json", history)
        print(
            json.dumps({k: row[k] for k in ("epoch", "step", "summary", "elapsed_seconds")}),
            flush=True,
        )
        reason = stop_reason(history, exceeded)
        if reason:
            stop = reason
            break
    saved = torch.load(root / "best.pt", map_location="cpu", weights_only=True)
    model.load_state_dict(saved["model"], strict=True)
    assert saved["epoch"] == best_epoch
    del saved
    best = evaluate(save="best")
    expected = next(r for r in history if r["epoch"] == best_epoch)
    assert best["summary"] == expected["summary"]
    for noise in EVALUATION_SEEDS:
        actual, original = best["conditions"][str(noise)], expected["conditions"][str(noise)]
        assert actual["summary"] == original["summary"]
        for x, y in zip(actual["examples"], original["examples"], strict=True):
            for key in (
                "metrics",
                "geometry",
                "local_frame_mse",
                "same_residue_frame_mse",
                "observed_distance_mse",
                "fallback_counts",
            ):
                assert x[key] == y[key]
        for record, packet in zip(selected, prepared, strict=True):
            xyz = execute(packet[0], noise).cpu().numpy()
            with np.load(
                root / record["group_id"] / f"best_{noise}.npz", allow_pickle=False
            ) as data:
                assert np.array_equal(xyz, data["coordinate"])
                assert np.array_equal(
                    last_execution["raw"].detach().cpu().numpy(), data["raw_coordinate"]
                )
    for packet, provenance in zip(prepared, base["input_provenance"], strict=True):
        assert feature_digest(packet[0]) == provenance["feature_sha256"]
    for packet, info in zip(prepared, adapter_provenance, strict=True):
        assert feature_digest(adapters[id(packet[0])].state_dict()) == info["state_sha256"]
    assert [feature_digest(m.state_dict()) for m in frozen] == frozen_hashes
    assert all(torch.isfinite(p).all() for p in model.parameters())
    report = {
        "complete": True,
        "stop_reason": stop,
        "last_epoch": epoch,
        "steps": step,
        "best_epoch": best_epoch,
        "initial": initial,
        "best": best,
        "joint_capacity_pass": best["summary"]["joint_capacity_pass"],
        "gradient_probe": gradient_probe,
        "all64_best_replays_exact": True,
        "initial_train_eval_exact": True,
        "baseline_raw_initial32_exact": True,
        "matched_raw_initial64_exact": matched is not None,
        "all_inputs_unchanged": True,
        "all_adapters_unchanged": True,
        "adapted_initial_max_abs_error": max(initial_adapter_errors),
        "frozen_heads_unchanged": True,
        "forward_counts": {"trunk": 1, "structure": 1, "confidence": 0},
        "peak_gpu_allocated_bytes": torch.cuda.max_memory_allocated(),
        "elapsed_seconds": time.monotonic() - started,
        "contract_sha256": sha256(root / "contract.json"),
        "best_checkpoint_sha256": sha256(root / "best.pt"),
        "last_checkpoint_sha256": sha256(root / "last.pt"),
        "history_sha256": sha256(root / "history.json"),
        "training_curve_sha256": sha256(root / "training.jsonl"),
    }
    write_json(root / "report.json", report)
    for handle in handles:
        handle.remove()
    print(
        json.dumps({"complete": True, "summary": best["summary"], "best_epoch": best_epoch}),
        flush=True,
    )


if __name__ == "__main__":
    main()
