#!/usr/bin/env python3
"""Bind accepted raw parent, preserved scientific source and zero-update model state."""

import argparse
import json
import py_compile
from pathlib import Path

import torch

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.raw_warmstart import verify_lock
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args().root.resolve()
    source = root / "code_v1"
    lock = verify_lock(root, source)
    parent = Path(lock["parent_root"])
    contract = json.loads((parent / "contract.json").read_text())
    assert contract["arm"] == "raw" and contract["size"] == 2048 and contract["schedule"] == "constant"
    assert lock["data_root"] == contract["data_root"]
    original = json.loads((Path(contract["source_root"]) / "source_manifest.json").read_text())
    for name, digest in original["files"].items():
        assert sha256(source / name) == digest, name
    for name, digest in contract["runtime_source_sha256"].items():
        assert sha256(Path(name)) == digest
    for file in source.glob("scripts/*warmstart*.py"):
        py_compile.compile(str(file), doraise=True)
    saved = torch.load(parent / "best.pt", map_location="cpu", weights_only=True)
    assert saved["step"] == lock["parent_step"] == 22528
    assert saved["contract_sha256"] == sha256(parent / "contract.json")
    assert lock["runs"] == {label: {"root": str(root / label), "arm": arm} for label, arm in (("raw_continue", "raw"), ("geometry_adapt", "control"))}
    write_json(root / "lock_acceptance.json", {
        "complete": True, "lock_sha256": sha256(root / "lock.json"),
        "initial_weights_sha256": feature_digest(saved["model"]),
        "checkpoint_sha256": lock["checkpoint_sha256"],
        "original_source_files_preserved": len(original["files"]),
        "optimizer_reset_both_arms": True, "optimizer_updates": 0,
    })
    print("Accepted raw parent and preserved source; no optimizer updates", flush=True)


if __name__ == "__main__":
    main()
