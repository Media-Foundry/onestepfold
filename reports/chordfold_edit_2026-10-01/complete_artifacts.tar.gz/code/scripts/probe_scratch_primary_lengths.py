#!/usr/bin/env python3
"""Bounded full-length scratch+smooth memory probe; never saves trained weights."""
import argparse,json,time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from fastglycan.models.esmc_core import ESMCFoldCore
from fastglycan.pretrained_gt import gt_loss_parts
from fastglycan.smooth_lddt_supervision import build_smooth_lddt_labels,smooth_lddt_loss
from fastglycan.paired_teacher_protocol import sha256,write_json
from fastglycan.teacher_pairing import feature_digest

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--group',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 a.output.mkdir(parents=True,exist_ok=False);torch.set_num_threads(1);torch.set_num_interop_threads(1)
 torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False
 f=a.data/'examples'/a.group;meta=json.loads((f/'prepared.json').read_text());assert meta['complete'] and meta['input_provenance']['raw_gt_rebuild_exact']
 for n,h in meta['files_sha256'].items():assert sha256(f/n)==h,n
 d=torch.load(f/'inputs.pt',map_location='cpu',weights_only=True);s=torch.load(f/'supervision.pt',map_location='cpu',weights_only=True)
 if 'smooth' not in s:
  with np.load(f/'inventory.npz') as inv:s['smooth']=build_smooth_lddt_labels(d['labels'],dict(inv))
 write_json(a.output/'input.json',dict(group=a.group,length=len(meta['selection']['sequence']),atoms=len(d['labels']['coordinate']),pairs=len(s['smooth']['pairs']),prepared_sha256=sha256(f/'prepared.json')))
 with patch('torch.load',side_effect=AssertionError('no folding checkpoint')):m=ESMCFoldCore(seed=101,deterministic_capacity=True)
 initial=feature_digest(m.state_dict());m.cuda().train()
 for head in (m.core.confidence_head,m.core.distogram_head):head.requires_grad_(False)
 pars=[x for x in m.parameters() if x.requires_grad];opt=torch.optim.AdamW(pars,lr=1e-4,weight_decay=1e-4)
 counts={}
 for name,module in [('trunk',m.core.pairformer_stack),('structure',m.core.diffusion_module),('confidence',m.core.confidence_head)]:
  def hook(*_,name=name):counts[name]+=1
  module.register_forward_pre_hook(hook)
 rows=[]
 for step in range(2):
  opt.zero_grad(set_to_none=True);torch.manual_seed(101+step);torch.cuda.reset_peak_memory_stats();counts.update(trunk=0,structure=0,confidence=0);start=time.monotonic()
  x=m(d['features'],confidence=False)['coordinate'][0];parts=gt_loss_parts(x,d['labels'],s)+[10*smooth_lddt_loss(x,s['smooth'])];loss=sum(parts)
  assert torch.isfinite(loss);loss.backward();norm=torch.nn.utils.clip_grad_norm_(pars,10,error_if_nonfinite=True);opt.step();torch.cuda.synchronize()
  assert counts==dict(trunk=1,structure=1,confidence=0)
  rows.append(dict(step=step+1,seconds=time.monotonic()-start,losses=[float(v.detach()) for v in parts],preclip_norm=float(norm),peak_allocated=torch.cuda.max_memory_allocated(),peak_reserved=torch.cuda.max_memory_reserved()))
  write_json(a.output/'progress.json',rows);del x,parts,loss
 write_json(a.output/'report.json',dict(complete=True,initial_weights_sha256=initial,folding_checkpoint_load_calls=0,diagnostic_updates=2,weights_discarded=True,gpu=torch.cuda.get_device_name(),torch=torch.__version__,hip=torch.version.hip,rows=rows))
if __name__=='__main__':main()
