#!/usr/bin/env python3
"""Read-only CPU B-versus-weighted-D coordinate diagnosis after final heavy QA."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import torch
from validate_esmc_distance_gradients import cpu_coordinate_gradients, independent_distance_labels
from validate_esmc_frame_supervision import numpy_losses

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.frame_attribution import frame_partitions
from fastglycan.frame_supervision import build_frame_labels
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    torch.set_num_threads(1)
    root = args.root
    report = json.loads((root / "report.json").read_text())
    contract = json.loads((root / "contract.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"] and qa["heavy_artifacts_checked"]
    assert sha256(root / "report.json") == qa["report_sha256"]
    assert sha256(root / "contract.json") == report["contract_sha256"]
    assert (
        contract["frame_weight"],
        contract["same_residue_weight"],
        contract["distance_weight"],
    ) == (0.1, 1, 10)
    weight = contract["distance_weight"]
    source = Path(__file__).resolve().parents[1]
    for name in ("experimental_training.py", "frame_attribution.py", "frame_supervision.py"):
        relative = "src/fastglycan/" + name
        assert sha256(source / relative) == contract["source_sha256"][relative]
    rows = []
    for index, provenance in enumerate(contract["input_provenance"]):
        group = provenance["group_id"]
        folder = root / group
        for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
            assert sha256(folder / name) == provenance[key]
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
            inventory = dict(saved)
        labels = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            provenance["sequence"],
            provenance["sample_id"],
            inventory,
        )
        supervision = build_frame_labels(labels, inventory)
        assert feature_digest(supervision) == contract["frame_provenance"][index]["sha256"]
        local = frame_partitions(supervision, inventory["residue_id"])["same_residue"]
        assert feature_digest(local) == contract["same_residue_provenance"][index]["sha256"]
        global_np, local_np = [
            {k: v.numpy() if isinstance(v, torch.Tensor) else v for k, v in s.items()}
            for s in (supervision, local)
        ]
        ds = independent_distance_labels(arrays, inventory)
        saved_ds = torch.load(
            folder / "distance_supervision.pt", map_location="cpu", weights_only=True
        )
        dp = contract["distance_provenance"][index]
        assert (
            dp["group_id"] == group
            and sha256(folder / "distance_supervision.pt") == dp["file_sha256"]
        )
        assert feature_digest(saved_ds) == dp["sha256"]
        for key in ("pairs", "category"):
            assert torch.equal(ds[key], saved_ds[key])
        assert torch.allclose(
            ds["target_distance"], saved_ds["target_distance"], atol=1e-12, rtol=1e-12
        )
        pairs, category = ds["pairs"].numpy(), ds["category"].numpy()
        assert (
            np.bincount(category).tolist() == dp["category_counts"]
            and np.bincount(category).min() > 0
        )
        target = labels["coordinate"].numpy().astype(np.float64)
        mask = labels["coordinate_mask"].numpy()
        for seed in ("12345", "54321"):
            original = report["best"]["conditions"][seed]["examples"][index]
            path = folder / f"best_{seed}.npz"
            assert original["group_id"] == group and sha256(path) == original["prediction_sha256"]
            with np.load(path, allow_pickle=False) as saved:
                assert all(np.array_equal(saved[k], v) for k, v in inventory.items())
                x = saved["coordinate"].astype(np.float64)
            scalars = numpy_losses(x, target, mask, global_np)
            same = numpy_losses(x, target, mask, local_np)["local_frame_mse"]
            delta = x[pairs[:, 0]] - x[pairs[:, 1]]
            distance = np.linalg.norm(delta, axis=1)
            error = distance - ds["target_distance"].numpy()
            d = float(np.mean([np.mean(error[category == c] ** 2) for c in range(4)]))
            assert np.isclose(
                scalars["local_frame_mse"], original["local_frame_mse"], rtol=1e-4, atol=1e-3
            )
            assert np.isclose(same, original["same_residue_frame_mse"], rtol=1e-4, atol=1e-3)
            assert np.isclose(d, original["observed_distance_mse"], rtol=1e-4, atol=1e-3)
            assert np.isclose(
                scalars["aligned_atom_mse"],
                original["metrics"]["all_heavy_atom_rmsd"] ** 2,
                rtol=1e-5,
                atol=1e-4,
            )
            gradients = cpu_coordinate_gradients(x, target, mask, global_np, local_np, ds)
            assert all(np.isfinite(g).all() and np.all(g[~mask] == 0) for g in gradients.values())
            analytic = np.zeros_like(x)
            direction = np.divide(
                delta, distance[:, None], out=np.zeros_like(delta), where=distance[:, None] != 0
            )
            derivative = (
                2 * error[:, None] * direction / (4 * np.bincount(category)[category])[:, None]
            )
            np.add.at(analytic, pairs[:, 0], derivative)
            np.add.at(analytic, pairs[:, 1], -derivative)
            analytic_error = np.linalg.norm(analytic - gradients["local"]) / max(
                np.linalg.norm(analytic), 1e-12
            )
            additivity_error = np.linalg.norm(
                gradients["probe"] - gradients["base"] - gradients["local"]
            ) / max(np.linalg.norm(gradients["probe"]), 1e-12)
            assert analytic_error <= 1e-10 and additivity_error <= 1e-10
            b_grad, d_grad = gradients["base"], weight * gradients["local"]
            total_grad = b_grad + d_grad
            bn, dn = np.linalg.norm(b_grad), np.linalg.norm(d_grad)
            assert bn > 0 and dn > 0
            b = scalars["aligned_atom_mse"] + 0.1 * scalars["local_frame_mse"] + same
            rows.append(
                {
                    "group_id": group,
                    "seed": seed,
                    "prediction_sha256": sha256(path),
                    "base_loss": float(b),
                    "distance_loss": d,
                    "weighted_distance_loss": weight * d,
                    "total_loss": float(b + weight * d),
                    "base_gradient_norm": float(bn),
                    "weighted_distance_gradient_norm": float(dn),
                    "distance_to_base_gradient_ratio": float(dn / bn),
                    "component_cosine": float(np.sum(b_grad * d_grad) / (bn * dn)),
                    "base_derivative_along_negative_total": float(-np.sum(b_grad * total_grad)),
                    "weighted_distance_derivative_along_negative_total": float(
                        -np.sum(d_grad * total_grad)
                    ),
                    "coincident_pairs": int(np.sum(distance == 0)),
                    "analytic_distance_gradient_relative_error": float(analytic_error),
                    "gradient_additivity_relative_error": float(additivity_error),
                }
            )
    summaries = {}
    for seed in ("12345", "54321"):
        selected = [r for r in rows if r["seed"] == seed]
        summaries[seed] = {
            "macro_base_loss": float(np.mean([r["base_loss"] for r in selected])),
            "macro_weighted_distance_loss": float(
                np.mean([r["weighted_distance_loss"] for r in selected])
            ),
            "median_distance_to_base_gradient_ratio": float(
                np.median([r["distance_to_base_gradient_ratio"] for r in selected])
            ),
            "median_component_cosine": float(np.median([r["component_cosine"] for r in selected])),
            "negative_total_lowers_both_count": sum(
                r["base_derivative_along_negative_total"] < 0
                and r["weighted_distance_derivative_along_negative_total"] < 0
                for r in selected
            ),
            "coincident_pairs": sum(r["coincident_pairs"] for r in selected),
        }
    names = (
        "scripts/diagnose_esmc_distance_balance.py",
        "scripts/validate_esmc_distance_gradients.py",
        "scripts/validate_esmc_frame_supervision.py",
        "docs/esmc_distance_balance_diagnostic_v1.md",
        "src/fastglycan/frame_attribution.py",
        "src/fastglycan/frame_supervision.py",
        "src/fastglycan/experimental_training.py",
    )
    result = {
        "complete": True,
        "report_sha256": sha256(root / "report.json"),
        "contract_sha256": sha256(root / "contract.json"),
        "best_epoch": report["best_epoch"],
        "distance_weight": weight,
        "examples": rows,
        "summaries": summaries,
        "source_sha256": {name: sha256(source / name) for name in names},
        "scope": "CPU coordinate B-versus10D; no parameter gradients, optimizer or forwards",
    }
    write_json(args.output, result)
    for name in names:
        destination = args.output.with_suffix("") / "source" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, destination)
    lines = [
        "# Recorded distance-objective coordinate balance",
        "",
        f"Accepted selected epoch{report['best_epoch']}, 32 TRAIN proteins and both seeds. "
        "B=atom+0.1globalframe+same-residue frame; weighted distance term=10D. "
        "CPU FP64, saved predictions only.",
        "",
        "| Metric | Seed12345 | Seed54321 |",
        "| --- | ---: | ---: |",
    ]
    for key in summaries["12345"]:
        lines.append(f"| {key} | {summaries['12345'][key]:.8g} | {summaries['54321'][key]:.8g} |")
    lines += [
        "",
        "Independent atom37 distance-label reconstruction, observed masks, scalar/source/artifact "
        "checks, analytic distance derivatives and gradient additivity pass. These are "
        "coordinate-space directions, not parameter-gradient or AdamW updates. No coefficient, "
        "checkpoint or trained-quality conclusion is selected by this diagnostic.",
    ]
    args.output.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
