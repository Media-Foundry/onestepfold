#!/usr/bin/env python3
"""First Capacity-B wave: one TRAIN protein, isolated independent interventions."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch
from train_esmc_capacity import INITIAL_HASH, save_checkpoint, seed

from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.capacity_b import (
    NativeConditionOracle,
    all_frame_labels,
    atom_score,
    run_core,
    strict_single_pass,
)
from fastglycan.distance_supervision import build_distance_labels, observed_distance_mse
from fastglycan.experimental_geometry import compare_local_geometry
from fastglycan.experimental_metrics import compare_experimental
from fastglycan.experimental_training import map_experimental_atoms, observed_aligned_mse
from fastglycan.frame_attribution import frame_partitions
from fastglycan.frame_supervision import build_frame_labels, local_frame_mse, training_sampler_seed
from fastglycan.models.esmc_core import ESMCFoldCore
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--arm", choices=("control", "raw", "allframe", "oracle", "c4"), required=True
    )
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    os.chdir(root)
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    parent = json.loads((args.parent / "contract.json").read_text())
    report = json.loads((args.parent / "report.json").read_text())
    qa = json.loads((args.parent / "independent_validation.json").read_text())
    assert qa["complete"] and qa["heavy_artifacts_checked"]
    assert (
        sha256(args.parent / "report.json")
        == qa["report_sha256"]
        == ("57c9863836acf674202d7e4100299a1c11c5cca07fb83964d0ebf797c3b86379")
    )
    assert sha256(args.parent / "contract.json") == report["contract_sha256"]
    source = Path(__file__).resolve().parents[1]
    for name in (
        "models/esmc_core.py",
        "articulated_output.py",
        "articulated_reference.py",
        "frame_supervision.py",
        "frame_attribution.py",
        "distance_supervision.py",
        "experimental_training.py",
    ):
        key = "src/fastglycan/" + name
        assert sha256(source / key) == parent["source_sha256"][key]
    for name, digest in parent["runtime_source_sha256"].items():
        assert sha256(Path(name)) == digest
    selection = parent["selection"][15]
    provenance = parent["input_provenance"][15]
    group = selection["group_id"]
    assert len(selection["sequence"]) == 128 and selection["split"] == "train"
    assert group == "36e538543c24414069b77ac1a24e0597ea526b6c77eb19f02ef2c671db700f37"
    old = Path(parent["baseline_root"]) / group
    assert sha256(old / "inputs.pt") == provenance["inputs_sha256"]
    packet = torch.load(old / "inputs.pt", map_location="cpu", weights_only=True)
    features, labels = packet["features"], packet["labels"]
    assert feature_digest(features) == provenance["feature_sha256"]
    for name in ("inventory.npz", "gt.npz", "gt.json"):
        shutil.copy2(old / name, root / name)
    assert sha256(root / "gt.npz") == provenance["gt_npz_sha256"]
    assert sha256(root / "gt.json") == provenance["gt_metadata_sha256"]
    with np.load(root / "inventory.npz") as data:
        inventory = dict(data)
    with np.load(root / "gt.npz") as data:
        arrays = dict(data)
    mapped = map_experimental_atoms(
        arrays,
        json.loads((root / "gt.json").read_text()),
        selection["sequence"],
        selection["sample_id"],
        inventory,
    )
    assert feature_digest(mapped) == feature_digest(labels)
    np.savez_compressed(root / "labels.npz", **{k: v.numpy() for k, v in labels.items()})
    local15 = build_frame_labels(labels, inventory)
    same = frame_partitions(local15, inventory["residue_id"])["same_residue"]
    frame = all_frame_labels(labels, inventory) if args.arm == "allframe" else local15
    distances = build_distance_labels(labels, inventory)
    assert distances["category"].bincount(minlength=4).min() > 0
    save_checkpoint(root / "supervision.pt", {"frame": frame, "same": same, "distance": distances})
    shutil.copy2(args.parent / "articulation_report.json", root / "articulation_report.json")
    variants = json.loads((root / "articulation_report.json").read_text())["variants"]
    assert features["ref_mask"].bool().all()
    adapter = (
        ArticulatedOutput(
            features["ref_pos"].numpy(),
            inventory["atom_name"],
            inventory["residue_id"],
            selection["sequence"],
            variants,
        )
        .float()
        .cuda()
    )
    adapter_hash = feature_digest(adapter.state_dict())
    assert adapter_hash == parent["adapter_provenance"][15]["state_sha256"]
    np.savez_compressed(root / "reference.npz", reference=features["ref_pos"].numpy())
    with patch("torch.load", side_effect=AssertionError("no folding checkpoint input")):
        model = ESMCFoldCore(seed=101, deterministic_capacity=True)
    assert feature_digest(model.state_dict()) == INITIAL_HASH
    assert model.config.to_dict() == parent["config"]
    model.cuda().eval()
    for module in (model.core.confidence_head, model.core.distogram_head):
        module.requires_grad_(False)
    oracle = None
    oracle_initial = None
    if args.arm == "oracle":
        captured = []
        seed(12345)
        with torch.no_grad():
            oracle_initial = run_core(model, features, capture=captured)["coordinate"].detach()
        assert len(captured) == 3
        oracle = NativeConditionOracle(captured).cuda()
        decoder_trainable = {
            n for n, p in model.core.diffusion_module.named_parameters() if p.requires_grad
        }
        model.requires_grad_(False)
        for name, parameter in model.core.diffusion_module.named_parameters():
            parameter.requires_grad_(name in decoder_trainable)
        del captured
    frozen_before = feature_digest(
        {n: p for n, p in model.named_parameters() if not p.requires_grad}
    )
    parameters = [p for p in model.parameters() if p.requires_grad]
    if oracle is not None:
        parameters += list(oracle.parameters())
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    cycles = 4 if args.arm == "c4" else 1
    expected_counts = {
        "trunk": 0 if oracle is not None else cycles,
        "structure": 1,
        "confidence": 0,
    }
    counts, cycle_grad_flags = {}, []

    def hook(name):
        def count(*_):
            counts[name] += 1
            if name == "trunk":
                cycle_grad_flags.append(torch.is_grad_enabled())

        return count

    handles = [
        m.register_forward_pre_hook(hook(n))
        for n, m in (
            ("trunk", model.core.pairformer_stack),
            ("structure", model.core.diffusion_module),
            ("confidence", model.core.confidence_head),
        )
    ]
    last = {}

    def execute(noise, train=False):
        model.train(train)
        seed(noise)
        counts.update(dict.fromkeys(expected_counts, 0))
        cycle_grad_flags.clear()
        with torch.set_grad_enabled(train):
            result = run_core(model, features, cycles=cycles, oracle=oracle)
            raw = result["coordinate"][0]
            adapted = (
                adapter(raw)
                if args.arm != "raw"
                else {"coordinate": raw, "fallback_counts": torch.zeros(3, dtype=torch.long)}
            )
        assert counts == expected_counts, counts
        expected_flags = [] if oracle is not None else [False] * (cycles - 1) + [train]
        assert cycle_grad_flags == expected_flags, cycle_grad_flags
        assert torch.isfinite(raw).all() and torch.isfinite(adapted["coordinate"]).all()
        last.update(
            raw=raw,
            fallbacks=adapted["fallback_counts"].tolist(),
            cycle_grad_flags=list(cycle_grad_flags),
        )
        return adapted["coordinate"]

    target, mask = labels["coordinate"].cuda(), labels["coordinate_mask"].cuda()

    def losses(x):
        return [
            observed_aligned_mse(x, target, mask),
            0.1 * local_frame_mse(x, frame),
            local_frame_mse(x, same),
            10 * observed_distance_mse(x, distances),
        ]

    def evaluate(step, save=None):
        rows = []
        for noise in (12345, 54321):
            x = execute(noise)
            predicted = dict(inventory) | {"coordinate": x.cpu().numpy()}
            row = {
                "noise": noise,
                "metrics": compare_experimental(predicted, arrays, selection["sequence"]),
                "geometry": compare_local_geometry(predicted, arrays, selection["sequence"]),
                "weighted_losses": [float(v) for v in losses(x)],
                "fallback_counts": last["fallbacks"],
            }
            assert row["metrics"]["predicted_gt_coverage"] == 1
            if save:
                path = root / f"{save}_{noise}.npz"
                np.savez_compressed(path, **predicted, raw_coordinate=last["raw"].cpu().numpy())
                row["prediction_sha256"] = sha256(path)
            rows.append(row)
        return {
            "step": step,
            "rows": rows,
            "atom_score": atom_score(rows),
            "strict_single_pass": strict_single_pass(rows),
            "elapsed_seconds": time.monotonic() - started,
        }

    a = execute(12345).detach().clone()
    raw_initial = last["raw"].detach().clone()
    b = execute(12345, True)
    assert torch.equal(a, b.detach())
    if oracle is not None:
        assert torch.equal(raw_initial, oracle_initial[0])
        del oracle_initial
    del a, b, raw_initial
    model.zero_grad(set_to_none=True)
    initial = evaluate(0, "initial")
    initial_errors = []
    if args.arm != "c4":
        for noise in (12345, 54321):
            old_prediction = args.parent / group / f"initial_{noise}.npz"
            expected = report["initial"]["conditions"][str(noise)]["examples"][15]
            assert sha256(old_prediction) == expected["prediction_sha256"]
            with (
                np.load(old_prediction) as old_data,
                np.load(root / f"initial_{noise}.npz") as data,
            ):
                assert np.array_equal(data["raw_coordinate"], old_data["raw_coordinate"])
                if args.arm != "raw":
                    error = float(np.max(np.abs(data["coordinate"] - old_data["coordinate"])))
                    assert error <= 5e-5
                    initial_errors.append(error)
    seeds = [training_sampler_seed(group, step) for step in range(1, 1601)]
    assert len(set(seeds)) == 1600 and not set(seeds).intersection((12345, 54321))
    contract = {
        "schema": "capacity-b-v1",
        "arm": args.arm,
        "selection": selection,
        "parent_root": str(args.parent),
        "parent_report_sha256": sha256(args.parent / "report.json"),
        "parent_contract_sha256": sha256(args.parent / "contract.json"),
        "input_path": str(old / "inputs.pt"),
        "input_provenance": provenance,
        "initial_weights_sha256": INITIAL_HASH,
        "adapter_sha256": adapter_hash,
        "config": model.config.to_dict(),
        "cycles_override": cycles,
        "expected_forward_counts": expected_counts,
        "recycle_gradient_policy": "native_final_cycle_only",
        "dispatch_revision": 3,
        "oracle_trainability": "preserve_original_decoder_flags_including_frozen_Fourier",
        "decoder_noise_policy": "preserve_c1_dummy_msa_rng_consumption",
        "c4_autocast_cache_enabled": False if cycles > 1 else None,
        "source_manifest_sha256": sha256(source / "source_manifest.json"),
        "source_root": str(source),
        "runtime_source_sha256": parent["runtime_source_sha256"],
        "optimizer": {"name": "AdamW", "lr": 1e-4, "weight_decay": 1e-4, "clip": 10},
        "training_seed_sha256": feature_digest(seeds),
        "evaluation_seeds": [12345, 54321],
        "max_steps": 1600,
        "soft_seconds": 2700,
        "trainable_parameters": sum(p.numel() for p in parameters),
        "oracle_shapes": None if oracle is None else [list(p.shape) for p in oracle.values],
        "oracle_dtypes": None if oracle is None else [str(d) for d in oracle.dtypes],
        "oracle_parameters": 0 if oracle is None else sum(p.numel() for p in oracle.parameters()),
        "labels_sha256": sha256(root / "labels.npz"),
        "supervision_sha256": sha256(root / "supervision.pt"),
        "inventory_sha256": sha256(root / "inventory.npz"),
        "reference_sha256": sha256(root / "reference.npz"),
        "initial_train_eval_exact": True,
        "initial_raw_exact_parent": args.arm != "c4",
        "initial_adapter_max_error": max(initial_errors, default=0),
        "job_id": os.environ.get("SLURM_JOB_ID"),
        "torch": torch.__version__,
        "matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cudnn_tf32": torch.backends.cudnn.allow_tf32,
    }
    write_json(root / "contract.json", contract)
    history = [initial]
    best_step, best_score = 0, initial["atom_score"]

    def save(path, step, include_optimizer=False):
        state = {
            "model": model.state_dict(),
            "oracle": None if oracle is None else oracle.state_dict(),
            "step": step,
            "contract_sha256": sha256(root / "contract.json"),
        }
        if include_optimizer:
            state["optimizer"] = optimizer.state_dict()
        save_checkpoint(path, state)

    save(root / "best.pt", 0)
    write_json(root / "history.json", history)
    print(json.dumps({"preflight_complete": True, "arm": args.arm, "initial": initial}), flush=True)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    optimization_start = time.monotonic()
    stop, gradient_probe = "update_budget", None
    for step, noise in enumerate(seeds, start=1):
        optimizer.zero_grad(set_to_none=True)
        x = execute(noise, True)
        flags = last["cycle_grad_flags"]
        values = losses(x)
        loss = sum(values)
        assert torch.isfinite(loss)
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(parameters, 10, error_if_nonfinite=True)
        if gradient_probe is None:
            head = model.core.diffusion_module.atom_attention_decoder.linear_no_bias_out.weight
            assert head.grad is not None and head.grad.norm() > 0
            if oracle is None:
                front = model.core.input_embedder.linear_esm.weight
                assert front.grad is not None and front.grad.norm() > 0
                upstream_norms = [float(front.grad.norm())]
            else:
                upstream_norms = [
                    0.0 if p.grad is None else float(p.grad.norm()) for p in oracle.parameters()
                ]
                assert max(upstream_norms) > 0
            gradient_probe = {
                "head_norm_after_clip": float(head.grad.norm()),
                "upstream_norms_after_clip": upstream_norms,
                "cycle_grad_flags": flags,
                "preclip_norm": float(norm),
            }
            write_json(root / "gradient_probe.json", gradient_probe)
        optimizer.step()
        row = {
            "step": step,
            "noise": noise,
            "weighted_losses": [float(v.detach()) for v in values],
            "preclip_norm": float(norm),
            "fallback_counts": last["fallbacks"],
            "elapsed_seconds": time.monotonic() - started,
            "oracle_gradient_norms_after_clip": None
            if oracle is None
            else [0.0 if p.grad is None else float(p.grad.norm()) for p in oracle.parameters()],
        }
        with (root / "training.jsonl").open("a") as handle:
            handle.write(json.dumps(row) + "\n")
        write_json(root / "progress.json", row)
        del x, loss, values
        exceeded = time.monotonic() - optimization_start >= 2700
        if step % 50 and not exceeded:
            continue
        optimizer.zero_grad(set_to_none=True)
        evaluation = evaluate(step)
        history.append(evaluation)
        if evaluation["atom_score"] < best_score:
            best_step, best_score = step, evaluation["atom_score"]
            save(root / "best.pt", step)
        write_json(root / "history.json", history)
        print(json.dumps(evaluation), flush=True)
        if evaluation["strict_single_pass"] or exceeded:
            stop = "strict_single_pass" if evaluation["strict_single_pass"] else "soft_time_budget"
            break
    save(root / "last.pt", step, True)
    final_last = evaluate(step, "last")
    saved = torch.load(root / "best.pt", map_location="cpu", weights_only=True)
    assert saved["step"] == best_step and saved["contract_sha256"] == sha256(root / "contract.json")
    model.load_state_dict(saved["model"], strict=True)
    if oracle is not None:
        oracle.load_state_dict(saved["oracle"], strict=True)
    del saved
    best = evaluate(best_step, "best")
    expected = next(row for row in history if row["step"] == best_step)
    assert best["atom_score"] == expected["atom_score"]
    for current, prior in zip(best["rows"], expected["rows"], strict=True):
        for key in ("metrics", "geometry", "weighted_losses", "fallback_counts"):
            assert current[key] == prior[key]
        x = execute(current["noise"])
        with np.load(root / f"best_{current['noise']}.npz") as data:
            assert np.array_equal(data["coordinate"], x.cpu().numpy())
            assert np.array_equal(data["raw_coordinate"], last["raw"].cpu().numpy())
    assert feature_digest(features) == provenance["feature_sha256"]
    assert feature_digest(adapter.state_dict()) == adapter_hash
    assert (
        feature_digest({n: p for n, p in model.named_parameters() if not p.requires_grad})
        == frozen_before
    )
    assert all(torch.isfinite(p).all() for p in parameters)
    final = {
        "complete": True,
        "arm": args.arm,
        "steps": step,
        "best_step": best_step,
        "stop_reason": stop,
        "initial": initial,
        "best": best,
        "last": final_last,
        "minimum_atom_pass": best["atom_score"] < 1,
        "desired_atom_pass": best["atom_score"] < 0.5,
        "strict_single_pass": best["strict_single_pass"],
        "gradient_probe": gradient_probe,
        "best_replay_exact": True,
        "inputs_adapters_frozen_weights_unchanged": True,
        "contract_sha256": sha256(root / "contract.json"),
        "best_checkpoint_sha256": sha256(root / "best.pt"),
        "last_checkpoint_sha256": sha256(root / "last.pt"),
        "history_sha256": sha256(root / "history.json"),
        "training_sha256": sha256(root / "training.jsonl"),
        "peak_gpu_allocated_bytes": torch.cuda.max_memory_allocated(),
        "elapsed_seconds": time.monotonic() - started,
    }
    write_json(root / "report.json", final)
    for handle in handles:
        handle.remove()
    print(
        json.dumps(
            {
                "complete": True,
                "arm": args.arm,
                "best_step": best_step,
                "best_atom": best_score,
                "strict_single_pass": final["strict_single_pass"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
