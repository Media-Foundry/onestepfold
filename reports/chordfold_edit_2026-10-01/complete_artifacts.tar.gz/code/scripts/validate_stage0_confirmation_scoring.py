#!/usr/bin/env python3
"""Replay old GT scores to verify the relocated confirmation evaluator."""

import argparse
import gzip
import json
from pathlib import Path

from evaluate_stage0 import evaluate_row

from fastglycan.paired_teacher_protocol import write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    args = p.parse_args()
    with gzip.open(args.root / "control/repeat_manifest.jsonl.gz", "rt") as handle:
        rows = sorted([json.loads(line) for line in handle], key=lambda r: r["sequence_length"])
    selected = [rows[0], rows[len(rows) // 2], rows[-1]]
    old_root = Path("/data/user/shuang886/Folding/stage0_v1")
    archives = {}
    checks = []
    try:
        for setting in ("c4_s5", "c4_s2", "c2_s2"):
            old = json.loads((old_root / "eval_v1" / (setting + ".json")).read_text())
            table = {r["group_id"]: r for r in old["records"]}
            for row in selected:
                row = dict(row)
                row["shard"] = row["shard"].replace(
                    "/hpc2hdd/home/shuang886/Folding/", "/data/user/shuang886/Folding/", 1
                )
                score = evaluate_row(row, old_root / "protenix_runs", setting, archives, seed=101)
                assert score["status"] == "ok", score
                expected = table[row["group_id"]]
                errors = {
                    key: abs(score[key] - expected[key])
                    for key in ("tm_score_ca", "all_atom_lddt", "ca_lddt", "backbone_rmsd_angstrom")
                }
                assert max(errors.values()) < 1e-7, errors
                for key in ("common_ca_count", "common_atom_count", "gt_atom_count"):
                    assert score[key] == expected[key]
                checks.append({"group_id": row["group_id"], "setting": setting, "errors": errors})
    finally:
        for archive in archives.values():
            archive.close()
    write_json(args.root / "control/scoring_replay_qa.json", {"passed": True, "checks": checks})
    print("All nine old per-target scores reproduced at unchanged definitions", flush=True)


if __name__ == "__main__":
    main()
