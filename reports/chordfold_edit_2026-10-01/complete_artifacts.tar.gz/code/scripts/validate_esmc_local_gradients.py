#!/usr/bin/env python3
"""CPU scalar, coordinate and gradient-moment QA; does not repeat GPU backprop."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch
from scipy.spatial.distance import pdist
from validate_esmc_capacity import rmsd
from validate_esmc_frame_supervision import numpy_losses

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.frame_supervision import build_frame_labels
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest

MOMENT_KEYS = (
    "base_sq",
    "local_sq",
    "probe_sq",
    "base_local_dot",
    "base_probe_dot",
    "local_probe_dot",
    "reconstructed_sq",
    "difference_sq",
)


def expected_group(name):
    parts = name.split(".")
    if parts[:3] == ["core", "input_embedder", "linear_esm"]:
        return "esmc_projection"
    if parts[:2] == ["core", "pairformer_stack"]:
        return "pairformer"
    if parts[:2] == ["core", "diffusion_module"]:
        return {
            "diffusion_conditioning": "diffusion_conditioning",
            "atom_attention_encoder": "atom_encoder",
            "diffusion_transformer": "diffusion_transformer",
            "atom_attention_decoder": "atom_decoder",
        }.get(parts[2], "diffusion_other")
    return "remaining_input_trunk"


def check_moment(row):
    assert all(np.isfinite(row[k]) for k in MOMENT_KEYS)
    for name in ("base", "local", "probe"):
        assert row[name + "_sq"] >= 0
        assert row[name + "_nonzero"] == (row[name + "_sq"] > 0)
        assert row[name + "_present"] or row[name + "_sq"] == 0
    assert row["reconstructed_sq"] >= 0 and row["difference_sq"] >= 0
    for x, y, dot in (
        ("base_sq", "local_sq", "base_local_dot"),
        ("base_sq", "probe_sq", "base_probe_dot"),
        ("local_sq", "probe_sq", "local_probe_dot"),
    ):
        assert row[dot] ** 2 <= row[x] * row[y] * (1 + 1e-10) + 1e-20
    reconstructed = row["base_sq"] + 2 * row["base_local_dot"] + 1 * row["local_sq"]
    assert np.isclose(reconstructed, row["reconstructed_sq"], rtol=1e-9, atol=1e-10)
    difference = (
        row["probe_sq"] + reconstructed - 2 * (row["base_probe_dot"] + 1.0 * row["local_probe_dot"])
    )
    assert abs(difference - row["difference_sq"]) <= 1e-9 * max(1, reconstructed + row["probe_sq"])


def independent_summary(rows):
    totals = {key: float(np.sum([r[key] for r in rows], dtype=np.float64)) for key in MOMENT_KEYS}
    a, f, c = [math.sqrt(totals[key]) for key in ("base_sq", "local_sq", "probe_sq")]
    return {
        "tensor_count": len(rows),
        "parameter_count": sum(r["numel"] for r in rows),
        "moments": totals,
        **{
            f"{name}_{kind}_tensors": sum(r[f"{name}_{kind}"] for r in rows)
            for name in ("base", "local", "probe")
            for kind in ("present", "nonzero")
        },
        "base_norm": a,
        "local_norm": f,
        "probe_norm": c,
        "local_to_base_norm_ratio": 1.0 * f / a if a else None,
        "component_cosine": totals["base_local_dot"] / (a * f) if a * f else None,
        "reconstructed_norm": math.sqrt(totals["reconstructed_sq"]),
        "relative_probe_reconstruction_error": math.sqrt(totals["difference_sq"]) / c
        if c
        else None,
        "base_derivative_along_negative_probe": -totals["base_probe_dot"],
        "local_derivative_along_negative_probe": -totals["local_probe_dot"],
    }


def close_tree(actual, expected):
    assert actual.keys() == expected.keys()
    for key, value in actual.items():
        if isinstance(value, dict):
            close_tree(value, expected[key])
        elif value is None:
            assert expected[key] is None
        else:
            assert np.isclose(value, expected[key], rtol=1e-10, atol=1e-10), key


def coordinate_moments(gradients):
    a, f, c = (gradients[k].astype(np.float64) for k in ("base", "local", "probe"))
    r = a + 1.0 * f
    return {
        "numel": a.size,
        **{f"{n}_present": True for n in ("base", "local", "probe")},
        **{f"{n}_nonzero": bool(np.any(gradients[n])) for n in ("base", "local", "probe")},
        "base_sq": float(np.sum(a * a)),
        "local_sq": float(np.sum(f * f)),
        "probe_sq": float(np.sum(c * c)),
        "base_local_dot": float(np.sum(a * f)),
        "base_probe_dot": float(np.sum(a * c)),
        "local_probe_dot": float(np.sum(f * c)),
        "reconstructed_sq": float(np.sum(r * r)),
        "difference_sq": float(np.sum((r - c) ** 2)),
    }


def cpu_coordinate_gradients(prediction, target, mask, global_sup, local_sup):
    """Independent FP64 coordinate graph: NumPy proper fit and explicit local axes."""
    x = torch.tensor(prediction, dtype=torch.float64, requires_grad=True)
    p, t = prediction[mask], target[mask]
    pc, tc = p.mean(0), t.mean(0)
    u, _, vh = np.linalg.svd((t - tc).T @ (p - pc))
    rotation = u @ np.diag([1.0, 1.0, np.linalg.det(u @ vh)]) @ vh
    fitted = torch.from_numpy((t - tc) @ rotation + pc)
    atom = (x[mask] - fitted).square().sum(1).mean()

    def frame(sup):
        anchors = x[torch.from_numpy(sup["frame_atoms"])]
        n, origin, c = anchors[:, 0], anchors[:, 1], anchors[:, 2]
        first = c - origin
        first = first / first.norm(dim=1).clamp_min(sup["epsilon"])[:, None]
        second = n - origin
        second = second - torch.sum(second * first, dim=1)[:, None] * first
        second = second / second.norm(dim=1).clamp_min(sup["epsilon"])[:, None]
        third = torch.cross(first, second, dim=1)
        axes = torch.stack((first, second, third), dim=1)
        rows, points = torch.from_numpy(sup["frame_rows"]), torch.from_numpy(sup["point_indices"])
        local = torch.einsum("pij,pj->pi", axes[rows], x[points] - origin[rows])
        return (local - torch.from_numpy(sup["target_local"])).square().sum(1).mean()

    base, local = atom + 0.1 * frame(global_sup), frame(local_sup)
    results = {}
    for name, scalar in (("base", base), ("local", local), ("probe", base + local)):
        (gradient,) = torch.autograd.grad(scalar, x, retain_graph=True)
        results[name] = gradient.numpy()
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--training-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    assert not (root / "independent_validation.json").exists()
    torch.set_num_threads(1)
    report = json.loads((root / "report.json").read_text())
    train_report = json.loads((args.training_root / "report.json").read_text())
    contract = json.loads((args.training_root / "contract.json").read_text())
    train_qa = json.loads((args.training_root / "independent_validation.json").read_text())
    history = json.loads((args.training_root / "history.json").read_text())
    assert train_qa["complete"] and train_qa["heavy_artifacts_checked"]
    assert (
        sha256(args.training_root / "report.json")
        == report["training_report_sha256"]
        == train_qa["report_sha256"]
    )
    assert (
        report["training_report_sha256"]
        == "ff534b92b7f3275aac03bd4ccd02a574f0eee3c02edaf67d036a9edcfccfd8d9"
    )
    assert sha256(args.training_root / "contract.json") == train_report["contract_sha256"]
    assert (
        report["complete"]
        and report["global_frame_weight"] == 0.1
        and report["local_probe_weight"] == 1
        and report["seed"] == 12345
    )
    assert not report["runtime"]["matmul_allow_tf32"] and not report["runtime"]["cudnn_allow_tf32"]
    for name, digest in report["source_sha256"].items():
        assert sha256(root / "source/execution" / name) == digest
    assert [(r["checkpoint"], r["epoch"], r["provenance"]["length"]) for r in report["cases"]] == [
        ("initial", 0, 35),
        ("initial", 0, 166),
        ("best", 35, 35),
        ("best", 35, 166),
    ]
    expected_names = None
    results = []
    for row in report["cases"]:
        folder = root / row["folder"]
        provenance = row["provenance"]
        assert provenance["split"] == "train"
        index = 0 if provenance["length"] == 35 else 31
        assert provenance == contract["input_provenance"][index]
        expected_checkpoint = (
            contract["initial_checkpoint_sha256"]
            if row["checkpoint"] == "initial"
            else train_report["best_checkpoint_sha256"]
        )
        assert row["checkpoint_sha256"] == expected_checkpoint
        for name, digest in row["artifact_sha256"].items():
            assert sha256(folder / name) == digest
        for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
            assert sha256(folder / name) == provenance[key]
        moments = json.loads((folder / "parameter_moments.json").read_text())
        names = [r["name"] for r in moments]
        assert len(names) == len(set(names))
        if expected_names is None:
            expected_names = names
        assert names == expected_names
        assert sum(r["numel"] for r in moments) == contract["trainable_parameter_count"]
        for tensor in moments:
            assert math.prod(tensor["shape"]) == tensor["numel"]
            assert tensor["group"] == expected_group(tensor["name"])
            check_moment(tensor)
        measured = {
            "global": independent_summary(moments),
            "groups": {
                name: independent_summary([r for r in moments if r["group"] == name])
                for name in sorted({r["group"] for r in moments})
            },
        }
        close_tree(measured, row["parameter_summary"])
        assert all(measured["global"][k + "_norm"] > 0 for k in ("base", "local", "probe"))
        with np.load(folder / "gt.npz", allow_pickle=False) as data:
            arrays = dict(data)
        with np.load(folder / "inventory.npz", allow_pickle=False) as data:
            inventory = dict(data)
        labels = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            provenance["sequence"],
            provenance["sample_id"],
            inventory,
        )
        saved = torch.load(folder / "labels.pt", map_location="cpu", weights_only=True)
        assert feature_digest(labels) == feature_digest(saved["labels"])
        assert (
            feature_digest(saved["supervision"])
            == row["supervision_sha256"]
            == contract["frame_provenance"][index]["sha256"]
        )
        assert feature_digest(build_frame_labels(labels, inventory)) == row["supervision_sha256"]
        sup = {
            k: v.numpy() if isinstance(v, torch.Tensor) else v
            for k, v in saved["supervision"].items()
        }
        with np.load(folder / "prediction.npz", allow_pickle=False) as data:
            prediction = data["coordinate"].astype(np.float64)
        target, mask = (
            labels["coordinate"].numpy().astype(np.float64),
            labels["coordinate_mask"].numpy(),
        )
        loss = numpy_losses(prediction, target, mask, sup)
        centers = sup["frame_atoms"][:, 1]
        own = (
            inventory["residue_id"][sup["point_indices"]]
            == inventory["residue_id"][centers[sup["frame_rows"]]]
        )
        local_sup = dict(saved["supervision"])
        for key in ("frame_rows", "point_indices", "target_local"):
            local_sup[key] = local_sup[key][own]
        assert len(local_sup["frame_rows"]) == row["same_residue_pair_count"]
        assert feature_digest(local_sup) == row["same_residue_supervision_sha256"]
        local_numpy = {
            k: v.numpy() if isinstance(v, torch.Tensor) else v for k, v in local_sup.items()
        }
        local_loss = numpy_losses(prediction, target, mask, local_numpy)["local_frame_mse"]
        expected_losses = {
            "aligned_atom_mse": loss["aligned_atom_mse"],
            "global_frame_mse": loss["local_frame_mse"],
            "base": loss["aligned_atom_mse"] + 0.1 * loss["local_frame_mse"],
            "local": local_loss,
            "probe": loss["aligned_atom_mse"] + 0.1 * loss["local_frame_mse"] + local_loss,
        }
        for name, value in expected_losses.items():
            assert np.isclose(value, row["losses"][name], rtol=1e-4, atol=1e-3), name
        assert np.isclose(
            loss["aligned_atom_mse"], row["losses"]["aligned_atom_mse"], rtol=1e-10, atol=1e-8
        )
        ca = mask & (inventory["atom_name"] == "CA")
        metrics = {
            "all_heavy_atom_rmsd": math.sqrt(loss["aligned_atom_mse"]),
            "ca_rmsd": rmsd(prediction[ca], target[ca]),
            "ca_pair_distance_rmse": float(
                np.sqrt(np.mean((pdist(prediction[ca]) - pdist(target[ca])) ** 2))
            ),
        }
        reference = next(r for r in history if r["epoch"] == row["epoch"])["conditions"]["12345"][
            "examples"
        ][index]
        for key, value in metrics.items():
            assert abs(value - row["metrics"][key]) <= 2e-5
            assert abs(value - reference["metrics"][key]) <= 2e-5
        if row["checkpoint"] in ("initial", "best"):
            with np.load(
                args.training_root / row["group_id"] / f"{row['checkpoint']}_12345.npz",
                allow_pickle=False,
            ) as data:
                assert np.array_equal(prediction, data["coordinate"])
        with np.load(folder / "coordinate_gradients.npz", allow_pickle=False) as data:
            gradients = dict(data)
        assert all(np.isfinite(g).all() and np.all(g[~mask] == 0) for g in gradients.values())
        reference_gradients = cpu_coordinate_gradients(prediction, target, mask, sup, local_numpy)
        gradient_errors = {}
        for name, expected in reference_gradients.items():
            relative = float(
                np.linalg.norm(gradients[name].astype(np.float64) - expected)
                / np.linalg.norm(expected)
            )
            assert relative <= 1e-3, (name, relative)
            gradient_errors[name] = relative
        coord = coordinate_moments(gradients)
        check_moment(coord)
        independent = independent_summary([coord])
        close_tree(independent, row["coordinate_summary"]["global"])
        close_tree(independent, row["coordinate_summary"]["groups"]["coordinates"])
        assert row["forward_counts"] == {"trunk": 1, "structure": 1, "confidence": 0}
        assert row["train_eval_replay_exact"] and row["saved_evaluation_replay_exact"]
        assert row["weights_and_inputs_unchanged"]
        results.append(
            {
                "folder": row["folder"],
                "metrics": metrics,
                "losses": expected_losses,
                "coordinate_gradient_relative_errors": gradient_errors,
                "global_gradients": measured["global"],
            }
        )
    source = Path(__file__).resolve().parent
    names = (
        "validate_esmc_local_gradients.py",
        "validate_esmc_capacity.py",
        "validate_esmc_frame_supervision.py",
    )
    write_json(
        root / "independent_validation.json",
        {
            "complete": True,
            "report_sha256": sha256(root / "report.json"),
            "cases": results,
            "source_sha256": {name: sha256(source / name) for name in names},
            "scope": "CPU artifact/scalar/coordinate/moment QA; no repeated GPU derivatives",
        },
    )
    print(json.dumps({"complete": True, "cases": len(results)}))


if __name__ == "__main__":
    main()
