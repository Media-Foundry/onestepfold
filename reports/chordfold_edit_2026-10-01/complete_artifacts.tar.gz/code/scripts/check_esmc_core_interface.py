#!/usr/bin/env python3
"""Disposable scratch-core gate on the fixed shortest/longest training inputs."""

from __future__ import annotations

import argparse
import gzip
import inspect
import io
import json
import os
import random
import tarfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from fastglycan.esmc_features import attach_esmc_monomer_features
from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.models.esmc_core import ESMCFoldCore
from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest, tensor_digest
from onestepfold.data.gt_materializer import materialize_entry
from onestepfold.data.teacher_pair_training import ESMCShardStore


def seed(value=12345):
    random.seed(value)
    np.random.seed(value)
    torch.manual_seed(value)


def prepare(record, args, folder, store):
    from protenix.data.inference.json_to_feature import SampleDictToFeatures
    from protenix.data.utils import data_type_transform, make_dummy_feature

    folder.mkdir()
    path = args.input_root / record.shard / "metadata.jsonl.gz"
    with gzip.open(path, "rt") as handle:
        rows = [json.loads(line) for line in handle if record.group_id in line]
    assert len(rows) == 1
    row = rows[0]
    assert row["group_id"] == record.group_id and row["sequence"] == record.sequence
    assert row["sample_id"] == record.sample_id
    old = Path(row["shard"])
    assert old.parent.name == "shards" and old.parent.parent.name == "processed_stageb_v1"
    source = args.stageb_root / "shards" / old.name
    with tarfile.open(source, "r") as archive:
        for key, name in (("npz", "gt.npz"), ("metadata", "gt.json")):
            assert Path(row[key]).name == row[key]
            member = archive.extractfile(row[key])
            assert member is not None
            (folder / name).write_bytes(member.read())
    metadata = json.loads((folder / "gt.json").read_text())
    with np.load(io.BytesIO((folder / "gt.npz").read_bytes()), allow_pickle=False) as saved:
        arrays = {k: saved[k] for k in saved.files}
    pdb = row["pdb_id"]
    raw = args.raw_root / pdb[1:3] / f"{pdb}.cif.gz"
    assert sha256(raw) == metadata["provenance"]["source_mmcif_sha256"]
    rebuilt, _ = materialize_entry({
        "pdb_id": pdb, "sequence": record.sequence,
        "source_label_asym_id": metadata["chains"][0]["source_label_asym_id"],
        "assembly_id": metadata["assembly_id"],
    }, raw)
    assert all(np.array_equal(value, rebuilt[k]) for k, value in arrays.items())
    seed(101)
    sample = {"name": record.group_id, "sequences": [
        {"proteinChain": {"sequence": record.sequence, "count": 1}}]}
    features, atoms, tokens = SampleDictToFeatures(sample).get_feature_dict()
    features["distogram_rep_atom_mask"] = torch.from_numpy(
        atoms.distogram_rep_atom_mask.astype(np.int64))
    features = data_type_transform(make_dummy_feature(features, dummy_feats=["msa", "template"]))
    centres = atoms[tokens.get_annotation("centre_atom_index")]
    features = attach_esmc_monomer_features(
        features, store=store, group_id=record.group_id, sequence=record.sequence,
        token_residue_names=centres.cano_seq_resname.tolist())
    inventory = {"atom_name": atoms.atom_name, "residue_id": atoms.res_id,
                 "element": atoms.element}
    labels = map_experimental_atoms(arrays, metadata, record.sequence, record.sample_id, inventory)
    torch.save({"features": features, "labels": labels}, folder / "inputs.pt")
    provenance = {
        "group_id": record.group_id, "sample_id": record.sample_id,
        "sequence": record.sequence, "length": record.sequence_length,
        "split": record.split, "atom_count": len(atoms),
        "observed_atom_count": int(labels["coordinate_mask"].sum()),
        "missing_residue_count": int((~arrays["residue_mask"]).sum()),
        "raw_gt_rebuild_exact": True, "source_shard": str(source),
        "source_metadata_sha256": sha256(path), "source_mmcif_sha256": sha256(raw),
        "gt_npz_sha256": sha256(folder / "gt.npz"),
        "gt_metadata_sha256": sha256(folder / "gt.json"),
        "inputs_sha256": sha256(folder / "inputs.pt"),
        "feature_sha256": feature_digest(features),
    }
    write_json(folder / "input_provenance.json", provenance)
    return features, labels, inventory, provenance


def main():
    parser = argparse.ArgumentParser()
    for name in ("state-root", "esmc-root", "input-root", "stageb-root", "raw-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    os.chdir(output)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    with patch("torch.load", side_effect=AssertionError("no folding checkpoint loading")) as loader:
        model = ESMCFoldCore(seed=101)
    assert loader.call_count == 0
    assert model.config.model.pairformer.n_blocks == 16
    assert model.config.model.diffusion_module.transformer.n_blocks == 8
    initial_hash = feature_digest(model.state_dict())
    torch.save(model.state_dict(), output / "initial.pt")
    _, records = read_cache(args.state_root, accepted=True)
    train = [r for r in records if r.split == "train"]
    selected = [min(train, key=lambda r: r.sequence_length),
                max(train, key=lambda r: r.sequence_length)]
    assert [r.sequence_length for r in selected] == [35, 951]
    store = ESMCShardStore(args.esmc_root)
    prepared = [prepare(r, args, output / r.group_id, store) for r in selected]
    assert not (output / "esm_embeddings").exists()
    source = Path(__file__).resolve().parents[1]
    names = ("src/fastglycan/models/esmc_core.py", "src/fastglycan/esmc_features.py",
             "src/fastglycan/experimental_training.py", "scripts/check_esmc_core_interface.py",
             "docs/esmc_core_interface_v1.md", "scripts/slurm_esmc_core_interface.sh")
    import protenix.model.generator
    import protenix.model.modules.transformer
    import protenix.model.protenix

    runtime = (protenix.model.generator, protenix.model.modules.transformer,
               protenix.model.protenix)
    contract = {
        "schema_version": "esmc-core-interface-v1", "config": model.config.to_dict(),
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "initial_weights_sha256": initial_hash, "folding_checkpoint_load_calls": loader.call_count,
        "initial_checkpoint_sha256": sha256(output / "initial.pt"),
        "source_sha256": {name: sha256(source / name) for name in names},
        "runtime_source_sha256": {inspect.getfile(m): sha256(Path(inspect.getfile(m)))
                                  for m in runtime},
        "esmc_manifest_sha256": sha256(args.esmc_root / "manifest.jsonl.gz"),
        "esmc_spec_sha256": sha256(args.esmc_root / "feature_spec.json"),
        "input_provenance": [x[3] for x in prepared], "cpu_preparation_passed": True,
        "runtime": {"torch": torch.__version__, "job_id": os.environ.get("SLURM_JOB_ID"),
                    "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
                    "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32},
        "scope": "disposable scratch core interface and derivative probes, no quality training",
    }
    write_json(output / "contract.json", contract)
    print(json.dumps({"cpu_preparation_passed": True,
                      "parameter_count": contract["parameter_count"]}), flush=True)
    model.cuda()
    counts = {"trunk": 0, "structure": 0, "confidence": 0}

    def counter(name):
        def hook(*_):
            counts[name] += 1
        return hook

    handles = [module.register_forward_pre_hook(counter(name)) for name, module in (
        ("trunk", model.core.pairformer_stack), ("structure", model.core.diffusion_module),
        ("confidence", model.core.confidence_head))]

    def execute(features, *, grad=False, confidence=True):
        seed()
        counts.update(dict.fromkeys(counts, 0))
        model.train(grad)
        with torch.set_grad_enabled(grad):
            result = model(features, confidence=confidence)
        observed_counts = dict(counts)
        assert observed_counts == {"trunk": 1, "structure": 1, "confidence": int(confidence)}
        for value in result.values():
            if isinstance(value, torch.Tensor):
                assert torch.isfinite(value).all()
        return result, observed_counts

    results = []
    for index, (features, labels, inventory, provenance) in enumerate(prepared):
        model.load_state_dict(torch.load(
            output / "initial.pt", map_location="cpu", weights_only=True))
        assert feature_digest(model.state_dict()) == initial_hash
        model.zero_grad(set_to_none=True)
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        before = feature_digest(features)
        first, observed_counts = execute(features)
        saved = {k: value.detach().cpu() for k, value in first.items()
                 if isinstance(value, torch.Tensor)}
        assert saved["coordinate"].shape == (1, provenance["atom_count"], 3)
        timings = first["timing"]
        del first
        again, _ = execute(features)
        assert all(torch.equal(value, again[k].cpu()) for k, value in saved.items())
        del again
        zero_input = dict(features) | {"esm_token_embedding": torch.zeros_like(
            features["esm_token_embedding"])}
        if index == 0:
            zero, _ = execute(zero_input, confidence=False)
            assert torch.equal(saved["coordinate"], zero["coordinate"].cpu())
            del zero
        inference_peak = torch.cuda.max_memory_allocated()
        torch.cuda.reset_peak_memory_stats()
        prediction, gradient_forward_counts = execute(features, grad=True, confidence=False)
        mask = labels["coordinate_mask"].cuda()
        target = labels["coordinate"].cuda()
        # Unaligned experimental-coordinate MSE is only a derivative probe;
        # no model quality or training-objective claim follows from its value.
        loss = (prediction["coordinate"][0, mask].double() - target[mask].double()).square().mean()
        loss.backward()
        grads = {name: float(p.grad.norm()) for name, p in model.named_parameters()
                 if p.grad is not None}
        assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        projection = model.core.input_embedder.linear_esm.weight
        assert projection.grad is not None and projection.grad.norm() > 0
        backward_peak = torch.cuda.max_memory_allocated()
        probe_loss = float(loss.detach())
        del prediction, loss, target, mask
        sensitivity = None
        if index == 0:
            with torch.no_grad():
                projection.add_(projection.grad, alpha=-0.1 / float(projection.grad.norm()))
            model.zero_grad(set_to_none=True)
            perturbed, _ = execute(features, confidence=False)
            perturbed_coordinate = perturbed["coordinate"].detach().cpu()
            del perturbed
            zero, _ = execute(zero_input, confidence=False)
            sensitivity = float((perturbed_coordinate - zero["coordinate"].cpu()).abs().max())
            assert sensitivity > 0
            del zero
        assert feature_digest(features) == before
        folder = output / provenance["group_id"]
        np.savez_compressed(folder / "initial_prediction.npz",
                            coordinate=saved["coordinate"][0].numpy(), **inventory)
        row = {
            "group_id": provenance["group_id"], "length": provenance["length"],
            "forward_counts": observed_counts, "gradient_forward_counts": gradient_forward_counts,
            "deterministic_replay_exact": True, "initial_checkpoint_reload_exact": True,
            "initial_output_sha256": {k: tensor_digest(v) for k, v in saved.items()},
            "confidence_shapes": {k: list(v.shape) for k, v in saved.items() if k != "coordinate"},
            "inference_peak_bytes": inference_peak, "backward_peak_bytes": backward_peak,
            "timing": timings, "unaligned_derivative_probe_loss": probe_loss,
            "gradient_norms": grads,
            "nonzero_gradient_parameters": sum(v > 0 for v in grads.values()),
            "projection_probe_update_l2": 0.1 if index == 0 else None,
            "updated_projection_input_sensitivity_max_abs": sensitivity,
            "prediction_sha256": sha256(folder / "initial_prediction.npz"),
        }
        write_json(folder / "result.json", row)
        results.append(row)
        write_json(output / "progress.json", {"complete": False, "examples": results})
        print(json.dumps({"checked_length": row["length"], "backward_peak_bytes": backward_peak,
                          "esmc_projection_gradient_norm": grads[
                              "core.input_embedder.linear_esm.weight"]}), flush=True)
        del saved
    for handle in handles:
        handle.remove()
    write_json(output / "report.json", {
        "complete": True, "contract_sha256": sha256(output / "contract.json"),
        "examples": results, "scope": contract["scope"],
        "trained_model": False, "quality_gate_passed": False,
        "esmc_extraction_in_timing": False, "temporal_test_read": False,
    })


if __name__ == "__main__":
    main()
