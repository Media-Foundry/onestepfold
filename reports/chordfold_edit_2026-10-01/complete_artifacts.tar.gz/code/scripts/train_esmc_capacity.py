#!/usr/bin/env python3
"""Bounded fresh-core observed-GT training; protocol docs/esmc_capacity_v1.md."""

from __future__ import annotations

import argparse
import inspect
import json
import math
import os
import random
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from fastglycan.experimental_inputs import prepare_experimental_input
from fastglycan.experimental_metrics import compare_experimental
from fastglycan.experimental_training import observed_aligned_mse
from fastglycan.models.esmc_core import ESMCFoldCore
from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest
from onestepfold.data.teacher_pair_training import ESMCShardStore
from onestepfold.training.coordinate_refiner import group_id_digest

INITIAL_HASH = "baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea"
METRICS = (
    ("all_heavy_atom_rmsd", "common_atom_count"),
    ("ca_rmsd", "common_ca_count"),
    ("ca_pair_distance_rmse", "common_ca_pair_count"),
)


def seed(value):
    random.seed(value)
    np.random.seed(value)
    torch.manual_seed(value)


def save_checkpoint(path, contents):
    temp = path.with_suffix(".part")
    torch.save(contents, temp)
    temp.replace(path)


def summarize(rows):
    result = {}
    for metric, count in METRICS:
        result["macro_" + metric] = float(np.mean([r["metrics"][metric] for r in rows]))
        result["pooled_" + metric] = math.sqrt(
            sum(r["metrics"][metric] ** 2 * r["metrics"][count] for r in rows)
            / sum(r["metrics"][count] for r in rows)
        )
    result["atom_rmsd_le_2_count"] = sum(r["metrics"]["all_heavy_atom_rmsd"] <= 2 for r in rows)
    result["capacity_pass"] = (
        result["pooled_all_heavy_atom_rmsd"] <= 1
        and result["pooled_ca_pair_distance_rmse"] <= 1
        and result["atom_rmsd_le_2_count"] >= 29
    )
    return result


def main():
    parser = argparse.ArgumentParser()
    for name in ("state-root", "esmc-root", "input-root", "stageb-root", "raw-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    os.chdir(root)
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    with patch(
        "torch.load", side_effect=AssertionError("folding checkpoint load forbidden")
    ) as load:
        model = ESMCFoldCore(seed=101, deterministic_capacity=True)
    assert load.call_count == 0
    assert feature_digest(model.state_dict()) == INITIAL_HASH
    save_checkpoint(root / "initial.pt", model.state_dict())
    frozen = (model.core.confidence_head, model.core.distogram_head)
    for module in frozen:
        module.requires_grad_(False)
    frozen_hashes = [feature_digest(m.state_dict()) for m in frozen]
    _, records = read_cache(args.state_root, accepted=True)
    selected = sorted(
        (r for r in records if r.split == "train"), key=lambda r: (r.sequence_length, r.group_id)
    )[:32]
    assert len(selected) == 32 and [selected[i].sequence_length for i in (0, -1)] == [35, 166]
    store = ESMCShardStore(args.esmc_root)
    prepared = []
    for record in selected:
        packet = prepare_experimental_input(
            record,
            input_root=args.input_root,
            stageb_root=args.stageb_root,
            raw_root=args.raw_root,
            folder=root / record.group_id,
            store=store,
        )
        with np.load(root / record.group_id / "gt.npz", allow_pickle=False) as data:
            arrays = {k: data[k] for k in data.files}
        prepared.append((*packet, arrays))
    assert not (root / "esm_embeddings").exists()
    source = Path(__file__).resolve().parents[1]
    source_names = (
        "scripts/train_esmc_capacity.py",
        "scripts/slurm_esmc_capacity.sh",
        "docs/esmc_capacity_v1.md",
        "src/fastglycan/experimental_inputs.py",
        "src/fastglycan/experimental_training.py",
        "src/fastglycan/experimental_metrics.py",
        "src/fastglycan/all_atom_metrics.py",
        "src/fastglycan/models/esmc_core.py",
        "src/fastglycan/esmc_features.py",
        "src/fastglycan/decoder_gradients.py",
    )
    import protenix.model.generator
    import protenix.model.modules.fused_ops
    import protenix.model.modules.pairformer
    import protenix.model.modules.transformer
    import protenix.model.protenix

    runtime = (
        protenix.model.generator,
        protenix.model.protenix,
        protenix.model.modules.fused_ops,
        protenix.model.modules.pairformer,
        protenix.model.modules.transformer,
    )
    contract = {
        "schema_version": "esmc-capacity-v1",
        "config": model.config.to_dict(),
        "initial_weights_sha256": INITIAL_HASH,
        "folding_checkpoint_load_calls": 0,
        "initial_checkpoint_sha256": sha256(root / "initial.pt"),
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "trainable_parameter_count": sum(p.numel() for p in model.parameters() if p.requires_grad),
        "selection": [r.to_dict() for r in selected],
        "selection_sha256": group_id_digest(selected),
        "state_root": str(args.state_root),
        "state_acceptance_sha256": sha256(args.state_root / "control/acceptance.json"),
        "source_sha256": {n: sha256(source / n) for n in source_names},
        "runtime_source_sha256": {
            inspect.getfile(m): sha256(Path(inspect.getfile(m))) for m in runtime
        },
        "esmc_manifest_sha256": sha256(args.esmc_root / "manifest.jsonl.gz"),
        "esmc_spec_sha256": sha256(args.esmc_root / "feature_spec.json"),
        "input_provenance": [p[3] for p in prepared],
        "runtime": {
            "torch": torch.__version__,
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
        },
        "optimizer": {
            "name": "AdamW",
            "lr": 1e-4,
            "weight_decay": 1e-4,
            "clip_norm": 10,
            "epochs": 100,
            "batch_size": 1,
        },
        "noise_seed": 12345,
        "diagnostic_noise_seed": 54321,
        "loss": "observed proper-rigid-aligned mean squared Euclidean atom error",
        "scope": "32 training groups, fixed-noise capacity only; no held-out/confidence claim",
    }
    write_json(root / "contract.json", contract)
    model.cuda()
    parameters = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    counts = {"trunk": 0, "structure": 0, "confidence": 0}

    def counter(name):
        def hook(*_):
            counts[name] += 1

        return hook

    handles = [
        m.register_forward_pre_hook(counter(n))
        for n, m in (
            ("trunk", model.core.pairformer_stack),
            ("structure", model.core.diffusion_module),
            ("confidence", model.core.confidence_head),
        )
    ]

    def execute(features, train=False, noise=12345):
        model.train(train)
        seed(noise)
        counts.update(dict.fromkeys(counts, 0))
        with torch.set_grad_enabled(train):
            result = model(features, confidence=False)["coordinate"][0]
        assert counts == {"trunk": 1, "structure": 1, "confidence": 0}
        assert torch.isfinite(result).all()
        return result

    def evaluate(noise=12345, save=None):
        rows = []
        for record, (features, _, inventory, _, arrays) in zip(selected, prepared, strict=True):
            xyz = execute(features, noise=noise).detach().cpu().numpy()
            prediction = dict(inventory) | {"coordinate": xyz}
            metrics = compare_experimental(prediction, arrays, record.sequence)
            assert metrics["predicted_gt_coverage"] == 1
            row = {"group_id": record.group_id, "metrics": metrics}
            if save:
                destination = root / record.group_id / f"{save}.npz"
                np.savez_compressed(destination, **prediction)
                row["prediction_sha256"] = sha256(destination)
            rows.append(row)
        return {"examples": rows, "summary": summarize(rows)}

    a = execute(prepared[0][0]).detach().cpu()
    b = execute(prepared[0][0], train=True).detach().cpu()
    assert torch.equal(a, b), "initial training and inference must agree with dropout disabled"
    del a, b
    model.zero_grad(set_to_none=True)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    initial = evaluate(save="initial_prediction")
    write_json(root / "initial_evaluation.json", initial)
    history = [{"epoch": 0, "step": 0, **initial, "elapsed_seconds": time.monotonic() - started}]
    best_epoch, best_value = 0, initial["summary"]["pooled_all_heavy_atom_rmsd"]
    save_checkpoint(
        root / "best.pt",
        {
            "model": model.state_dict(),
            "epoch": 0,
            "contract_sha256": sha256(root / "contract.json"),
        },
    )
    step, stop, gradient_probe = 0, "epoch_budget", None
    optimization_started = time.monotonic()
    for epoch in range(1, 101):
        losses, grad_norms = [], []
        order = list(range(32))
        random.Random(101 + epoch).shuffle(order)
        for index in order:
            features, labels, _, _, _ = prepared[index]
            optimizer.zero_grad(set_to_none=True)
            prediction = execute(features, train=True)
            loss = observed_aligned_mse(
                prediction, labels["coordinate"].cuda(), labels["coordinate_mask"].cuda()
            )
            assert torch.isfinite(loss)
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(parameters, 10, error_if_nonfinite=True)
            if gradient_probe is None:
                projection = model.core.input_embedder.linear_esm.weight
                assert projection.grad is not None and projection.grad.norm() > 0
                gradient_probe = {
                    "projection_gradient_norm_after_clip": float(projection.grad.norm()),
                    "nonzero_gradient_tensors": sum(
                        p.grad is not None and bool(torch.count_nonzero(p.grad)) for p in parameters
                    ),
                }
            optimizer.step()
            losses.append(float(loss.detach()))
            grad_norms.append(float(norm))
            del loss, prediction
            step += 1
        optimizer.zero_grad(set_to_none=True)
        exceeded = time.monotonic() - optimization_started >= 75 * 60
        train_row = {
            "epoch": epoch,
            "step": step,
            "mean_training_mse": float(np.mean(losses)),
            "max_gradient_norm_before_clip": max(grad_norms),
            "elapsed_seconds": time.monotonic() - started,
        }
        with (root / "training.jsonl").open("a") as handle:
            handle.write(json.dumps(train_row) + "\n")
        write_json(root / "progress.json", train_row)
        if epoch % 5 != 0 and not exceeded:
            continue
        evaluated = evaluate()
        row = train_row | evaluated
        history.append(row)
        value = row["summary"]["pooled_all_heavy_atom_rmsd"]
        if value < best_value:
            best_value, best_epoch = value, epoch
            save_checkpoint(
                root / "best.pt",
                {
                    "model": model.state_dict(),
                    "epoch": epoch,
                    "contract_sha256": sha256(root / "contract.json"),
                },
            )
        save_checkpoint(
            root / "last.pt",
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "epoch": epoch,
                "step": step,
                "best_epoch": best_epoch,
                "contract_sha256": sha256(root / "contract.json"),
            },
        )
        write_json(root / "history.json", history)
        print(
            json.dumps({k: row[k] for k in ("epoch", "step", "summary", "elapsed_seconds")}),
            flush=True,
        )
        if row["summary"]["capacity_pass"]:
            stop = "capacity_pass"
        elif epoch == 20 and all(
            row["summary"]["pooled_" + m] > 0.9 * initial["summary"]["pooled_" + m]
            for m in ("all_heavy_atom_rmsd", "ca_pair_distance_rmse")
        ):
            stop = "futility_epoch20"
        elif epoch >= 30 and best_value >= 0.99 * min(
            r["summary"]["pooled_all_heavy_atom_rmsd"] for r in history if r["epoch"] <= epoch - 20
        ):
            stop = "plateau_20epochs"
        elif exceeded:
            stop = "soft_time_budget"
        else:
            continue
        break
    checkpoint = torch.load(root / "best.pt", map_location="cpu", weights_only=True)
    model.load_state_dict(checkpoint["model"])
    assert checkpoint["epoch"] == best_epoch
    del checkpoint
    best = evaluate(save="best_prediction")
    expected = next(r for r in history if r["epoch"] == best_epoch)
    assert best["summary"] == expected["summary"]
    assert all(
        x["metrics"] == y["metrics"]
        for x, y in zip(best["examples"], expected["examples"], strict=True)
    )
    for record, packet in zip(selected, prepared, strict=True):
        xyz = execute(packet[0]).detach().cpu().numpy()
        with np.load(root / record.group_id / "best_prediction.npz", allow_pickle=False) as saved:
            assert np.array_equal(xyz, saved["coordinate"])
        assert feature_digest(packet[0]) == packet[3]["feature_sha256"]
    second_seed = evaluate(noise=54321, save="second_seed_prediction")
    assert [feature_digest(m.state_dict()) for m in frozen] == frozen_hashes
    assert all(torch.isfinite(p).all() for p in model.parameters())
    report = {
        "complete": True,
        "stop_reason": stop,
        "last_epoch": epoch,
        "steps": step,
        "best_epoch": best_epoch,
        "initial": initial,
        "best": best,
        "second_seed": second_seed,
        "capacity_pass": best["summary"]["capacity_pass"],
        "gradient_probe": gradient_probe,
        "initial_train_eval_exact": True,
        "all32_best_replays_exact": True,
        "all_inputs_unchanged": True,
        "frozen_heads_unchanged": True,
        "forward_counts": {"trunk": 1, "structure": 1, "confidence": 0},
        "peak_gpu_allocated_bytes": torch.cuda.max_memory_allocated(),
        "elapsed_seconds": time.monotonic() - started,
        "contract_sha256": sha256(root / "contract.json"),
        "best_checkpoint_sha256": sha256(root / "best.pt"),
        "last_checkpoint_sha256": sha256(root / "last.pt"),
        "history_sha256": sha256(root / "history.json"),
        "training_curve_sha256": sha256(root / "training.jsonl"),
    }
    write_json(root / "report.json", report)
    for h in handles:
        h.remove()
    print(
        json.dumps(
            {
                "complete": True,
                "capacity_pass": report["capacity_pass"],
                "stop_reason": stop,
                "best_epoch": best_epoch,
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
