#!/usr/bin/env python3
"""Independent CPU checks of controlled observed-distance capacity artifacts and gates."""

from __future__ import annotations

import argparse
import gzip
import json
import math
import random
from pathlib import Path

import numpy as np
import torch
from scipy.spatial.distance import pdist
from validate_esmc_capacity import rmsd
from validate_esmc_distance_gradients import independent_distance_labels
from validate_esmc_frame_supervision import numpy_losses

from fastglycan.articulated_capacity_control import verify_articulated_control
from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.articulated_validation import numpy_project
from fastglycan.experimental_metrics import prediction_atom37
from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.frame_supervision import build_frame_labels, training_sampler_seed
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest
from onestepfold.data.gt_materializer import ATOM37_INDEX

LIMITS = {"N_CA": 0.15, "CA_C": 0.15, "C_O": 0.15, "consecutive_C_N": 0.30}
METRICS = (
    ("all_heavy_atom_rmsd", "common_atom_count"),
    ("ca_rmsd", "common_ca_count"),
    ("ca_pair_distance_rmse", "common_ca_pair_count"),
)


def independent_geometry(positions, arrays):
    x = np.asarray(positions, np.float64)
    y = arrays["atom37_positions"].astype(np.float64)
    mask = arrays["atom37_mask"] & arrays["residue_mask"][:, None]
    distances = {}
    for name, left, right, offset in (
        ("N_CA", "N", "CA", 0),
        ("CA_C", "CA", "C", 0),
        ("C_O", "C", "O", 0),
        ("consecutive_C_N", "C", "N", 1),
    ):
        a, b = ATOM37_INDEX[left], ATOM37_INDEX[right]
        pairs = [
            (i, i + offset) for i in range(len(mask) - offset) if mask[i, a] and mask[i + offset, b]
        ]
        pred = np.array([np.linalg.norm(x[i, a] - x[j, b]) for i, j in pairs])
        gt = np.array([np.linalg.norm(y[i, a] - y[j, b]) for i, j in pairs])
        delta = pred - gt
        distances[name] = {
            "count": len(pairs),
            "squared_error_sum": float(delta @ delta),
            "rmse": float(np.sqrt(np.mean(delta**2))),
        }
    centers = [ATOM37_INDEX[n] for n in ("N", "CA", "C", "CB")]
    agree = evaluable = 0
    for i in range(len(mask)):
        if not mask[i, centers].all():
            continue

        def volume(z, i=i):
            n, ca, c, cb = z[i, centers]
            return np.dot(np.cross(n - ca, c - ca), cb - ca)

        vy, vx = volume(y), volume(x)
        if abs(vy) <= 1e-6:
            continue
        evaluable += 1
        agree += int(abs(vx) > 1e-6 and np.sign(vx) == np.sign(vy))
    return {
        "local_distances": distances,
        "ca_chirality": {"evaluable_count": evaluable, "agreement_count": agree},
    }


def summarize(rows):
    result = {}
    for metric, count in METRICS:
        result["pooled_" + metric] = math.sqrt(
            sum(r["metrics"][metric] ** 2 * r["metrics"][count] for r in rows)
            / sum(r["metrics"][count] for r in rows)
        )
        result["macro_" + metric] = float(np.mean([r["metrics"][metric] for r in rows]))
    result["atom_rmsd_le_2_count"] = sum(r["metrics"]["all_heavy_atom_rmsd"] <= 2 for r in rows)
    result["atom_rmsd_29th_smallest"] = sorted(r["metrics"]["all_heavy_atom_rmsd"] for r in rows)[
        28
    ]
    result["local_distances"] = {}
    for name in LIMITS:
        parts = [r["geometry"]["local_distances"][name] for r in rows]
        n = sum(p["count"] for p in parts)
        result["local_distances"][name] = {
            "count": n,
            "rmse": math.sqrt(sum(p["squared_error_sum"] for p in parts) / n),
        }
    result["handedness_evaluable"] = sum(
        r["geometry"]["ca_chirality"]["evaluable_count"] for r in rows
    )
    result["handedness_agreement"] = sum(
        r["geometry"]["ca_chirality"]["agreement_count"] for r in rows
    )
    result["handedness_failure_fraction"] = (
        result["handedness_evaluable"] - result["handedness_agreement"]
    ) / result["handedness_evaluable"]
    result["macro_local_frame_mse"] = float(np.mean([r["local_frame_mse"] for r in rows]))
    return result


def score(conditions):
    values = []
    for condition in conditions.values():
        s = condition["summary"]
        values += [
            s["pooled_all_heavy_atom_rmsd"],
            s["pooled_ca_pair_distance_rmse"],
            s["atom_rmsd_29th_smallest"] / 2,
            s["handedness_failure_fraction"] / 0.05,
        ]
        values += [s["local_distances"][k]["rmse"] / limit for k, limit in LIMITS.items()]
    return max(values)


def check_summary(expected, actual):
    for key, value in expected.items():
        if key == "local_distances":
            for name, part in value.items():
                assert part["count"] == actual[key][name]["count"]
                assert abs(part["rmse"] - actual[key][name]["rmse"]) < 2e-5
        elif key == "macro_local_frame_mse":
            assert np.isclose(value, actual[key], rtol=1e-4, atol=1e-3)
        else:
            assert abs(value - actual[key]) <= (0 if isinstance(value, int) else 2e-5), key


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--selection-manifest", type=Path, required=True)
    parser.add_argument("--check-heavy-artifacts", action="store_true")
    parser.add_argument("--matched-root", type=Path)
    parser.add_argument("--gradient-audit-root", type=Path)
    args = parser.parse_args()
    root = args.root
    assert not (root / "independent_validation.json").exists()
    torch.set_num_threads(1)
    contract = json.loads((root / "contract.json").read_text())
    report = json.loads((root / "report.json").read_text())
    assert report["complete"] and report["contract_sha256"] == sha256(root / "contract.json")
    frame_weight = contract["frame_weight"]
    assert (
        frame_weight == 0.1
        and contract["same_residue_weight"] == 1
        and contract["distance_weight"] == 10
    )
    assert contract["evaluation_seeds"] == [12345, 54321]
    matched_root = None
    if frame_weight == 0.1:
        matched_root = args.matched_root or Path(contract["matched_root"])
        matched = json.loads((matched_root / "contract.json").read_text())
        matched_report = json.loads((matched_root / "report.json").read_text())
        matched_qa = json.loads((matched_root / "independent_validation.json").read_text())
        assert matched_qa["complete"] and matched_qa["heavy_artifacts_checked"]
        assert (
            sha256(matched_root / "contract.json")
            == matched_report["contract_sha256"]
            == matched_qa["contract_sha256"]
        )
        assert (
            sha256(matched_root / "report.json")
            == matched_qa["report_sha256"]
            == contract["matched_report_sha256"]
            == ("8ff68aef2e56d801ce64b1736ab50c4525ff03451090bcd179de1ab5bfe500ab")
        )
        assert (
            matched["frame_weight"] == 0.1
            and matched["same_residue_weight"] == 1
            and matched["distance_weight"] == 10
            and report["matched_raw_initial64_exact"]
        )
        for key in (
            "config",
            "selection",
            "selection_sha256",
            "input_provenance",
            "initial_weights_sha256",
            "parameter_count",
            "trainable_parameter_count",
            "evaluation_seeds",
            "training_seed_sha256",
            "optimizer",
            "baseline_report_sha256",
            "audit_report_sha256",
            "runtime_source_sha256",
            "same_residue_provenance",
        ):
            assert contract[key] == matched[key], key
        for key in ("torch", "matmul_allow_tf32", "cudnn_allow_tf32"):
            assert contract["runtime"][key] == matched["runtime"][key]
        for name, digest in matched["source_sha256"].items():
            if name.startswith("src/") or name == "scripts/train_esmc_capacity.py":
                assert contract["source_sha256"][name] == digest
        for actual, expected in zip(
            contract["frame_provenance"], matched["frame_provenance"], strict=True
        ):
            assert (actual["group_id"], actual["sha256"]) == (
                expected["group_id"],
                expected["sha256"],
            )
        assert contract["gradient_audit_report_sha256"] == (
            "a91dea42d8b96a606cfcf6fa0a30a8f97c83e8f3006e64daa42f3c836f482995"
        )
        gradient_root = args.gradient_audit_root or Path(contract["gradient_audit_root"])
        gradient_report = json.loads((gradient_root / "report.json").read_text())
        gradient_qa = json.loads((gradient_root / "independent_validation.json").read_text())
        assert gradient_qa["complete"] and gradient_report["complete"]
        assert (
            sha256(gradient_root / "report.json")
            == gradient_qa["report_sha256"]
            == contract["gradient_audit_report_sha256"]
        )
        for name in (
            "src/fastglycan/frame_attribution.py",
            "src/fastglycan/distance_supervision.py",
            "src/fastglycan/frame_supervision.py",
            "src/fastglycan/experimental_training.py",
            "src/fastglycan/models/esmc_core.py",
        ):
            assert contract["source_sha256"][name] == gradient_report["source_sha256"][name]
        assert contract["articulated_control"] == verify_articulated_control(contract, matched)
        for name in (
            "src/fastglycan/articulated_output.py",
            "src/fastglycan/articulated_reference.py",
        ):
            assert contract["source_sha256"][name] == gradient_report["source_sha256"][name]
        initial_qa = json.loads((root / "matched_initial_validation.json").read_text())
        assert (
            initial_qa["complete"]
            and initial_qa["all_raw_initial_predictions_exact"]
            and initial_qa["predictions"] == 64
        )
        assert initial_qa["contract_sha256"] == sha256(root / "contract.json")
    assert (
        contract["initial_weights_sha256"]
        == "baad41b475327b40f3b458d04e7ee85696639776096a12699b661b2b87b908ea"
    )
    for name, digest in contract["source_sha256"].items():
        assert sha256(args.code_root / name) == digest
    assert (
        sha256(args.selection_manifest)
        == "1a959fdac83f8688ec9cb1a7deb95e4cf4e06670e9ca4450fcbfc8468d43d33f"
    )
    with gzip.open(args.selection_manifest, "rt") as handle:
        records = [json.loads(line) for line in handle]
    selected = sorted(
        (r for r in records if r["split"] == "train"),
        key=lambda r: (r["sequence_length"], r["group_id"]),
    )[:32]
    assert selected == contract["selection"]
    seeds = [training_sampler_seed(r["group_id"], e) for r in selected for e in range(1, 101)]
    assert len(set(seeds)) == 3200 and not set(seeds).intersection([12345, 54321])
    assert feature_digest(seeds) == contract["training_seed_sha256"]
    history = json.loads((root / "history.json").read_text())
    training = [json.loads(line) for line in (root / "training.jsonl").read_text().splitlines()]
    assert sha256(root / "history.json") == report["history_sha256"]
    assert sha256(root / "training.jsonl") == report["training_curve_sha256"]
    assert [r["epoch"] for r in training] == list(range(1, report["last_epoch"] + 1))
    assert report["steps"] == 32 * report["last_epoch"] <= 3200
    for row in training:
        order = list(range(32))
        random.Random(101 + row["epoch"]).shuffle(order)
        assert row["step"] == 32 * row["epoch"]
        assert row["training_seed_sha256"] == feature_digest(
            [training_sampler_seed(selected[i]["group_id"], row["epoch"]) for i in order]
        )
        assert np.isclose(
            row["mean_loss"],
            row["mean_aligned_atom_mse"]
            + frame_weight * row["mean_local_frame_mse"]
            + row["mean_same_residue_frame_mse"]
            + 10 * row["mean_observed_distance_mse"],
            atol=1e-6,
        )
        assert np.isfinite(row["max_gradient_norm_before_clip"])
        assert len(row["fallback_counts"]) == 3 and all(
            isinstance(v, int) and v >= 0 for v in row["fallback_counts"]
        )
    for index, row in enumerate(history):
        assert set(row["conditions"]) == {"12345", "54321"}
        for condition in row["conditions"].values():
            check_summary(summarize(condition["examples"]), condition["summary"])
            local_values = [r["same_residue_frame_mse"] for r in condition["examples"]]
            assert all(np.isfinite(v) and v >= 0 for v in local_values)
            assert np.isclose(
                np.mean(local_values), condition["mean_same_residue_frame_mse"], rtol=1e-12
            )
            distance_values = [r["observed_distance_mse"] for r in condition["examples"]]
            assert all(np.isfinite(v) and v >= 0 for v in distance_values)
            assert np.isclose(
                np.mean(distance_values), condition["mean_observed_distance_mse"], rtol=1e-12
            )
        value = score(row["conditions"])
        assert abs(value - row["summary"]["selection_score"]) < 1e-10
        assert (value <= 1) == row["summary"]["joint_capacity_pass"]
        assert row["summary"]["worst_seed_pooled_atom_rmsd"] == max(
            c["summary"]["pooled_all_heavy_atom_rmsd"] for c in row["conditions"].values()
        )
        if index:
            assert row["epoch"] % 5 == 0 or index == len(history) - 1
            assert row["step"] == row["epoch"] * 32
    best = min(history, key=lambda row: score(row["conditions"]))
    assert best["epoch"] == report["best_epoch"]
    assert best["summary"] == report["best"]["summary"]
    for i, row in enumerate(history[1:], 1):
        prior = history[: i + 1]
        reason = None
        if row["summary"]["joint_capacity_pass"]:
            reason = "joint_capacity_pass"
        elif row["epoch"] == 20 and all(
            row["summary"][k] > 0.9 * history[0]["summary"][k]
            for k in ("selection_score", "worst_seed_pooled_atom_rmsd")
        ):
            reason = "futility_epoch20"
        elif row["epoch"] >= 30 and min(
            r["summary"]["selection_score"] for r in prior
        ) >= 0.99 * min(
            r["summary"]["selection_score"] for r in prior if r["epoch"] <= row["epoch"] - 20
        ):
            reason = "plateau_20epochs"
        if reason:
            assert i == len(history) - 1 and report["stop_reason"] == reason
        elif i == len(history) - 1:
            assert report["stop_reason"] in ("epoch_budget", "soft_time_budget")
            if report["stop_reason"] == "epoch_budget":
                assert row["epoch"] == 100
            else:
                assert row["elapsed_seconds"] - history[0]["elapsed_seconds"] >= 4500
    assert report["forward_counts"] == {"trunk": 1, "structure": 1, "confidence": 0}
    assert all(
        report[k]
        for k in (
            "all64_best_replays_exact",
            "initial_train_eval_exact",
            "baseline_raw_initial32_exact",
            "all_inputs_unchanged",
            "frozen_heads_unchanged",
        )
    )
    assert history[0]["summary"] == report["initial"]["summary"]
    assert history[-1]["epoch"] == report["last_epoch"]
    max_metric_error, max_frame_error, max_same_residue_error, max_distance_error = (
        0.0,
        0.0,
        0.0,
        0.0,
    )
    distance_provenance = {r["group_id"]: r for r in contract["distance_provenance"]}
    assert len(distance_provenance) == 32
    local_provenance = {r["group_id"]: r for r in contract["same_residue_provenance"]}
    assert len(local_provenance) == 32
    label_hashes = {}
    assert report["all_adapters_unchanged"] and report["adapted_initial_max_abs_error"] <= 5e-5
    assert sha256(root / "articulation_report.json") == contract["articulation_report_sha256"]
    articulation = json.loads((root / "articulation_report.json").read_text())
    cpu_root = Path(contract["cpu_interface_root"])
    cpu = json.loads((cpu_root / "report.json").read_text())
    assert (
        cpu["complete"]
        and sha256(cpu_root / "report.json") == contract["cpu_interface_report_sha256"]
    )
    adapter_info = {row["group_id"]: row for row in contract["adapter_provenance"]}
    assert len(adapter_info) == 32
    adapters, chemical_references = {}, {}
    max_adapter_error, initial_adapter_errors = 0.0, []
    results = {}
    for condition_name in ("initial", "best"):
        results[condition_name] = {}
        for noise in ("12345", "54321"):
            rows, local_scalars, distance_scalars = [], [], []
            original = report[condition_name]["conditions"][noise]
            for record, provenance, frame_info, row in zip(
                selected,
                contract["input_provenance"],
                contract["frame_provenance"],
                original["examples"],
                strict=True,
            ):
                group = record["group_id"]
                folder = root / group
                assert group == provenance["group_id"] == frame_info["group_id"] == row["group_id"]
                assert json.loads((folder / "input_provenance.json").read_text()) == provenance
                for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
                    assert sha256(folder / name) == provenance[key]
                assert sha256(folder / f"{condition_name}_{noise}.npz") == row["prediction_sha256"]
                assert sha256(folder / "supervision.pt") == frame_info["file_sha256"]
                with np.load(folder / "gt.npz", allow_pickle=False) as data:
                    arrays = dict(data)
                with np.load(folder / "inventory.npz", allow_pickle=False) as data:
                    inventory = dict(data)
                with np.load(folder / f"{condition_name}_{noise}.npz", allow_pickle=False) as data:
                    prediction = dict(data)
                if condition_name == "initial" and matched_root is not None:
                    path = matched_root / group / f"initial_{noise}.npz"
                    original_index = next(
                        i for i, r in enumerate(selected) if r["group_id"] == group
                    )
                    assert (
                        sha256(path)
                        == matched_report["initial"]["conditions"][noise]["examples"][
                            original_index
                        ]["prediction_sha256"]
                    )
                    with np.load(path, allow_pickle=False) as data:
                        assert np.array_equal(prediction["raw_coordinate"], data["coordinate"])
                assert all(np.array_equal(prediction[k], v) for k, v in inventory.items())
                assert sha256(folder / "reference.npz") == adapter_info[group]["reference_sha256"]
                if group not in adapters:
                    with np.load(folder / "reference.npz", allow_pickle=False) as reference:
                        assert reference["reference_mask"].astype(bool).all()
                        chemical_references[group] = {
                            k: reference[k].copy() for k in reference.files
                        }
                    adapter = ArticulatedOutput(
                        chemical_references[group]["reference"],
                        inventory["atom_name"],
                        inventory["residue_id"],
                        record["sequence"],
                        articulation["variants"],
                    ).float()
                    assert (
                        feature_digest(adapter.state_dict()) == adapter_info[group]["state_sha256"]
                    )
                    adapters[group] = adapter.double()
                rebuilt, fallbacks = numpy_project(
                    prediction["raw_coordinate"].astype(np.float64), adapters[group]
                )
                error = float(np.max(np.abs(rebuilt - prediction["coordinate"])))
                assert error < 1e-4, (group, condition_name, noise, error)
                max_adapter_error = max(max_adapter_error, error)
                assert fallbacks.tolist() == row["fallback_counts"]
                if condition_name == "initial":
                    original_index = next(
                        i for i, r in enumerate(selected) if r["group_id"] == group
                    )
                    expected = cpu["conditions"][f"initial_{noise}"][original_index]
                    path = cpu_root / group / f"initial_{noise}.npz"
                    assert sha256(path) == expected["prediction_sha256"]
                    with np.load(path, allow_pickle=False) as old:
                        error = float(np.max(np.abs(prediction["coordinate"] - old["coordinate"])))
                    assert error <= 5e-5
                    initial_adapter_errors.append(error)
                labels = map_experimental_atoms(
                    arrays,
                    json.loads((folder / "gt.json").read_text()),
                    record["sequence"],
                    record["sample_id"],
                    inventory,
                )
                label_hashes[group] = feature_digest(labels)
                supervision = torch.load(
                    folder / "supervision.pt", map_location="cpu", weights_only=True
                )
                assert (
                    feature_digest(supervision)
                    == frame_info["sha256"]
                    == feature_digest(build_frame_labels(labels, inventory))
                )
                sup_numpy = {
                    k: v.numpy() if isinstance(v, torch.Tensor) else v
                    for k, v in supervision.items()
                }
                scalars = numpy_losses(
                    prediction["coordinate"].astype(np.float64),
                    labels["coordinate"].numpy().astype(np.float64),
                    labels["coordinate_mask"].numpy(),
                    sup_numpy,
                )
                frame = scalars["local_frame_mse"]
                assert np.isclose(frame, row["local_frame_mse"], rtol=1e-4, atol=1e-3)
                max_frame_error = max(max_frame_error, abs(frame - row["local_frame_mse"]))
                centers = sup_numpy["frame_atoms"][:, 1]
                own = (
                    inventory["residue_id"][sup_numpy["point_indices"]]
                    == inventory["residue_id"][centers[sup_numpy["frame_rows"]]]
                )
                local_sup = dict(supervision)
                for key in ("frame_rows", "point_indices", "target_local"):
                    local_sup[key] = local_sup[key][own]
                assert feature_digest(local_sup) == local_provenance[group]["sha256"]
                assert len(local_sup["frame_rows"]) == local_provenance[group]["pair_count"]
                local_np = {
                    k: v.numpy() if isinstance(v, torch.Tensor) else v for k, v in local_sup.items()
                }
                local_scalar = numpy_losses(
                    prediction["coordinate"].astype(np.float64),
                    labels["coordinate"].numpy().astype(np.float64),
                    labels["coordinate_mask"].numpy(),
                    local_np,
                )["local_frame_mse"]
                assert np.isclose(local_scalar, row["same_residue_frame_mse"], rtol=1e-4, atol=1e-3)
                max_same_residue_error = max(
                    max_same_residue_error, abs(local_scalar - row["same_residue_frame_mse"])
                )
                local_scalars.append(local_scalar)
                distance_info = distance_provenance[group]
                path = folder / "distance_supervision.pt"
                assert sha256(path) == distance_info["file_sha256"]
                distance_saved = torch.load(path, map_location="cpu", weights_only=True)
                assert feature_digest(distance_saved) == distance_info["sha256"]
                distance_sup = independent_distance_labels(arrays, prediction)
                for key in ("pairs", "category"):
                    assert torch.equal(distance_saved[key], distance_sup[key])
                assert torch.allclose(
                    distance_saved["target_distance"],
                    distance_sup["target_distance"],
                    rtol=1e-12,
                    atol=1e-12,
                )
                assert (
                    distance_sup["category"].bincount(minlength=4).tolist()
                    == distance_info["category_counts"]
                )
                pairs, categories = distance_sup["pairs"].numpy(), distance_sup["category"].numpy()
                coords = prediction["coordinate"].astype(np.float64)
                distances = np.linalg.norm(coords[pairs[:, 0]] - coords[pairs[:, 1]], axis=1)
                errors = (distances - distance_sup["target_distance"].numpy()) ** 2
                distance_scalar = float(np.mean([errors[categories == c].mean() for c in range(4)]))
                assert np.isclose(
                    distance_scalar, row["observed_distance_mse"], rtol=1e-4, atol=1e-3
                )
                max_distance_error = max(
                    max_distance_error, abs(distance_scalar - row["observed_distance_mse"])
                )
                distance_scalars.append(distance_scalar)
                xyz, available = prediction_atom37(prediction, record["sequence"])
                observed = arrays["atom37_mask"] & arrays["residue_mask"][:, None]
                assert not np.any(observed & ~available)
                ca = observed[:, ATOM37_INDEX["CA"]]
                x, y = (
                    xyz[ca, ATOM37_INDEX["CA"]],
                    arrays["atom37_positions"][ca, ATOM37_INDEX["CA"]],
                )
                metrics = {
                    "all_heavy_atom_rmsd": rmsd(
                        xyz[observed], arrays["atom37_positions"][observed]
                    ),
                    "ca_rmsd": rmsd(x, y),
                    "ca_pair_distance_rmse": float(np.sqrt(np.mean((pdist(x) - pdist(y)) ** 2))),
                    "common_atom_count": int(observed.sum()),
                    "common_ca_count": int(ca.sum()),
                    "common_ca_pair_count": len(x) * (len(x) - 1) // 2,
                }
                for name, value in metrics.items():
                    error = abs(value - row["metrics"][name])
                    assert error <= (0 if name.endswith("count") else 2e-5)
                    max_metric_error = max(max_metric_error, error)
                geometry = independent_geometry(xyz, arrays)
                for name, part in geometry["local_distances"].items():
                    for key, value in part.items():
                        assert np.isclose(
                            value,
                            row["geometry"]["local_distances"][name][key],
                            rtol=1e-10,
                            atol=1e-8,
                        )
                for key, value in geometry["ca_chirality"].items():
                    assert value == row["geometry"]["ca_chirality"][key]
                rows.append({"metrics": metrics, "geometry": geometry, "local_frame_mse": frame})
            result = summarize(rows)
            check_summary(result, original["summary"])
            assert np.isclose(
                np.mean(local_scalars),
                original["mean_same_residue_frame_mse"],
                rtol=1e-4,
                atol=1e-3,
            )
            assert np.isclose(
                np.mean(distance_scalars),
                original["mean_observed_distance_mse"],
                rtol=1e-4,
                atol=1e-3,
            )
            results[condition_name][noise] = {
                "summary": result,
                "mean_same_residue_frame_mse": float(np.mean(local_scalars)),
                "mean_observed_distance_mse": float(np.mean(distance_scalars)),
            }
        assert np.isclose(
            score(results[condition_name]),
            report[condition_name]["summary"]["selection_score"],
            atol=2e-5,
            rtol=0,
        )
    assert (score(results["best"]) <= 1) == report["joint_capacity_pass"]
    if args.check_heavy_artifacts:
        for name, digest in (
            ("initial.pt", contract["initial_checkpoint_sha256"]),
            ("best.pt", report["best_checkpoint_sha256"]),
            ("last.pt", report["last_checkpoint_sha256"]),
        ):
            assert sha256(root / name) == digest
        initial = torch.load(root / "initial.pt", map_location="cpu", weights_only=True)
        assert feature_digest(initial) == contract["initial_weights_sha256"]
        best_state = torch.load(root / "best.pt", map_location="cpu", weights_only=True)
        assert best_state["epoch"] == report["best_epoch"]
        assert best_state["contract_sha256"] == sha256(root / "contract.json")
        for key, value in best_state["model"].items():
            assert torch.isfinite(value).all()
            if key.startswith(("core.confidence_head.", "core.distogram_head.")):
                assert torch.equal(value, initial[key])
        del initial, best_state
        for provenance in contract["input_provenance"]:
            path = Path(contract["baseline_root"]) / provenance["group_id"] / "inputs.pt"
            assert sha256(path) == provenance["inputs_sha256"]
            packet = torch.load(path, map_location="cpu", weights_only=True)
            assert feature_digest(packet["features"]) == provenance["feature_sha256"]
            reference = chemical_references[provenance["group_id"]]
            assert np.array_equal(reference["reference"], packet["features"]["ref_pos"].numpy())
            assert np.array_equal(
                reference["reference_mask"], packet["features"]["ref_mask"].numpy()
            )
            assert feature_digest(packet["labels"]) == label_hashes[provenance["group_id"]]
    assert (
        max(initial_adapter_errors)
        == report["adapted_initial_max_abs_error"]
        == initial_qa["adapted_initial_max_abs_error"]
    )
    source = Path(__file__).resolve().parent
    result = {
        "complete": True,
        "report_sha256": sha256(root / "report.json"),
        "contract_sha256": sha256(root / "contract.json"),
        "groups": 32,
        "conditions": results,
        "max_metric_error_angstrom": max_metric_error,
        "max_frame_scalar_error": max_frame_error,
        "max_same_residue_scalar_error": max_same_residue_error,
        "max_distance_scalar_error": max_distance_error,
        "heavy_artifacts_checked": args.check_heavy_artifacts,
        "max_adapter_reconstruction_error": max_adapter_error,
        "all128_raw_to_adapted_checked": True,
        "adapter_validation_source_sha256": sha256(
            source.parent / "src/fastglycan/articulated_validation.py"
        ),
        "source_sha256": {
            name: sha256(source / name)
            for name in (
                "validate_esmc_articulated_capacity.py",
                "validate_esmc_distance_gradients.py",
                "validate_esmc_capacity.py",
                "validate_esmc_frame_supervision.py",
            )
        },
        "scope": "CPU artifact/FP64 metric/local geometry/selection audit; no GPU rerun",
    }
    write_json(root / "independent_validation.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "conditions"}, indent=2))


if __name__ == "__main__":
    main()
