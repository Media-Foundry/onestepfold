#!/usr/bin/env python3
"""Exhaustive response artifact QA and direct longest-target decoder replays."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from fastglycan.decoder_gradients import decoder_response, detached_tree
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.response_cache import read_response_cache
from fastglycan.teacher_pairing import feature_digest, tensor_digest
from fastglycan.teacher_runtime import setup_teacher


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.cache_root.resolve()
    protocol, records = read_response_cache(root)
    parent = Path(protocol["state_root"])
    prior = json.loads((parent / "control/acceptance.json").read_text())
    reports = [json.loads((root / "control" / f"worker_{i}.json").read_text()) for i in range(4)]
    hashes = {}
    for index, report in enumerate(reports):
        assert report["complete"] and report["worker"] == index
        assert report["protocol_sha256"] == sha256(root / "control/protocol.json")
        assert set(report["trace_sha256"]) == set(protocol["workers"][index])
        assert report["checkpoint_sha256"] == prior["checkpoint_sha256"]
        assert sha256(Path(report["checkpoint_path"])) == report["checkpoint_sha256"]
        assert sha256(root / "work" / str(index) / "input.json") == report["input_sha256"]
        assert not report["sampling_autocast_enabled"]
        assert report["sampler_config"] == reports[0]["sampler_config"]
        for name, digest in report["source_sha256"].items():
            assert sha256(args.code_root / name) == digest, name
        for name, digest in report["runtime_source_sha256"].items():
            assert sha256(Path(name)) == digest, name
        assert not set(hashes).intersection(report["trace_sha256"])
        hashes.update(report["trace_sha256"])
    assert set(hashes) == {r.group_id for r in records}
    longest = [
        max((r for r in records if r.split == split), key=lambda r: (r.sequence_length, r.group_id))
        for split in ("train", "validation")
    ]
    runner, _, _, provenance = setup_teacher(longest, root / "qa_work")
    assert provenance["checkpoint_sha256"] == prior["checkpoint_sha256"]
    runner.model.eval().requires_grad_(False)
    replays, byte_count = {}, 0
    for index, record in enumerate(records):
        group = record.group_id
        folder, native_folder = root / "examples" / group, parent / "examples" / group
        assert sha256(folder / "trace.json") == hashes[group]
        row = json.loads((folder / "trace.json").read_text())
        assert row["group_id"] == group and row["split"] == record.split
        assert row["length"] == record.sequence_length
        assert sha256(native_folder / "trace.json") == prior["trace_sha256"][group]
        assert row["parent_trace_sha256"] == prior["trace_sha256"][group]
        native = json.loads((native_folder / "trace.json").read_text())
        assert row["prepared_features_sha256"] == native["prepared_features_sha256"]
        states = {}
        for label in ("c1", "c4"):
            path = native_folder / f"{label}.pt"
            assert sha256(path) == native["states"][label]["sha256"]
            states[label] = torch.load(path, map_location="cpu", weights_only=True)
        for name, digest in row["artifact_sha256"].items():
            path = folder / name
            assert sha256(path) == digest, (group, name)
            byte_count += path.stat().st_size
        packet = torch.load(folder / "packet.pt", map_location="cpu", weights_only=False)
        responses = torch.load(folder / "responses.pt", map_location="cpu", weights_only=True)
        assert feature_digest(packet) == row["packet_sha256"]
        assert feature_digest(packet["input_feature_dict"]) == row["feature_sha256"]
        assert torch.equal(packet["s_inputs"], states["c1"][0])
        assert torch.equal(packet["s_trunk"], states["c1"][1])
        assert packet["t_hat_noise_level"].tolist() == [protocol["noise_level"]]
        assert packet["x_noisy"].shape == (1, row["atom_count"], 3)
        for label, pair in (("c1", states["c1"][2]), ("oracle_pair", states["c4"][2])):
            capture = row["captures"][label]
            assert capture["decoder_nfe"] == 2 and capture["trunk_calls"] == 0
            trunk, diffusion = capture["trace"]
            assert trunk["pair_sha256"] == tensor_digest(pair)
            assert trunk["single_sha256"] == tensor_digest(states["c1"][1])
            assert not trunk["mc_dropout"] and trunk["cycles"] == 1
            assert (
                trunk["input_feature_sha256"]
                == native["conditions"]["c1"]["trace"][0]["input_feature_sha256"]
            )
            assert diffusion["explicit_seed"] == 12345
            assert (
                diffusion["rng_at_sampler_entry"]
                == native["conditions"]["c1"]["trace"][1]["rng_at_sampler_entry"]
            )
            assert tensor_digest(responses[label]) == capture["response_sha256"]
            assert responses[label].shape == (1, row["atom_count"], 3)
            assert torch.isfinite(responses[label]).all()
            assert (
                sha256(native_folder / "c1.npz") == native["conditions"]["c1"]["coordinates_sha256"]
            )
            with (
                np.load(folder / f"{label}.npz") as saved,
                np.load(native_folder / "c1.npz") as original,
            ):
                for key in ("atom_name", "residue_id", "element"):
                    assert np.array_equal(saved[key], original[key])
                assert saved["coordinate"].shape == (row["atom_count"], 3)
                assert np.isfinite(saved["coordinate"]).all()
                assert (saved["atom_name"] == "CA").sum() == record.sequence_length
                assert not np.any(saved["element"] == "H")
                if label == "c1":
                    assert np.array_equal(saved["coordinate"], original["coordinate"])
            if group in {r.group_id for r in longest}:
                gpu_packet = detached_tree(packet, runner.device)
                with torch.no_grad(), torch.autocast("cuda", enabled=False):
                    actual, caches = decoder_response(
                        runner.model.diffusion_module, gpu_packet, pair.to(runner.device)
                    )
                assert torch.equal(actual.cpu(), responses[label])
                assert {k: tensor_digest(v) for k, v in caches.items()} == capture["cache_sha256"]
                replays[f"{group}/{label}"] = True
                del actual, caches, gpu_packet
        delta = responses["c1"].numpy().astype(np.float64) - responses[
            "oracle_pair"
        ].numpy().astype(np.float64)
        assert math.isclose(float(np.mean(delta**2)), row["baseline_response_mse"], rel_tol=1e-12)
        print(json.dumps({"verified": index + 1, "group_id": group}), flush=True)
    assert len(replays) == 4
    accepted = {
        "complete": True,
        "protocol_sha256": sha256(root / "control/protocol.json"),
        "split_counts": dict(Counter(r.split for r in records)),
        "trace_sha256": hashes,
        "artifact_bytes": byte_count,
        "longest_response_cache_replays_exact": replays,
        "checkpoint_sha256": prior["checkpoint_sha256"],
        "worker_sha256": {str(i): sha256(root / "control" / f"worker_{i}.json") for i in range(4)},
        "validator_sha256": sha256(Path(__file__)),
    }
    write_json(root / "control/acceptance.json", accepted)
    (root / "control/PASSED").write_text(sha256(root / "control/acceptance.json") + "\n")
    read_response_cache(root, accepted=True)


if __name__ == "__main__":
    main()
