#!/usr/bin/env python3
"""Resume recorded CPU preparation batches; never retry failed or ambiguous jobs."""
import fcntl
import json
import shlex
import subprocess
import time
from pathlib import Path

ARCHIVE = Path('reports/esmc_expansion_2026-09-27')
ROOT = '/data/user/shuang886/Folding/esmc_expansion_data_v1_20260927'


def remote(args):
    return subprocess.check_output(['ssh', 'hpc3', shlex.join(args)], text=True)


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    with (ARCHIVE / '.preparation.lock').open('w') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while True:
            record = json.loads((ARCHIVE / 'jobs.json').read_text())
            assert not record.get('submission_in_flight'), 'Ambiguous prior submission; inspect scheduler before recovery'
            batches = {0: record['prepare_first_four']}
            batches.update({r['start']: r['job'] for r in record.get('additional_batches', [])})
            ids = ','.join(str(j) for j in batches.values())
            raw = remote(['sacct', '-n', '-P', '-X', '-j', ids, '--format=JobIDRaw,State,ExitCode,Elapsed'])
            states = {int(line.split('|')[0]): line.split('|')[1:]
                      for line in raw.splitlines() if line.strip()}
            if set(states) != set(batches.values()):
                # Newly submitted jobs may not yet be visible to sacct. Their
                # recorded IDs remain authoritative; wait without resubmitting.
                write(ARCHIVE / 'preparation_status.json', dict(
                    accounting_pending=sorted(set(batches.values()) - set(states)),
                    states=states, data_accepted=False))
                time.sleep(45)
                continue
            failure = {j: v for j, v in states.items() if v[0].split()[0] not in
                       ('COMPLETED', 'RUNNING', 'PENDING', 'CONFIGURING', 'COMPLETING')
                       or (v[0] == 'COMPLETED' and v[1] != '0:0')}
            status = dict(states=states, failed=failure, submitted_workers=len(batches)*4,
                          completed_workers=sum(v[0] == 'COMPLETED' for v in states.values())*4,
                          all_preparation_jobs_complete=False, data_accepted=False)
            write(ARCHIVE / 'preparation_status.json', status)
            assert not failure, failure
            if len(batches) == 16 and all(v[0] == 'COMPLETED' for v in states.values()):
                status['all_preparation_jobs_complete'] = True
                write(ARCHIVE / 'preparation_status.json', status)
                subprocess.run(['rsync', '-a', '--include=/*.json', '--exclude=*',
                                'hpc3:' + ROOT + '/new_packets_v1/', str(ARCHIVE / 'workers') + '/'], check=True)
                print('All64 worker shards completed; combined data acceptance still required', flush=True)
                return
            active = sum(v[0] != 'COMPLETED' for v in states.values())
            queued = remote(['squeue', '-h', '-u', 'shuang886', '-o', '%i']).splitlines()
            # Leave a scheduler slot for interface fitting/QA alongside preparation.
            if len(batches) < 16 and active < 3 and len(queued) < 5:
                start = next(s for s in range(0,64,4) if s not in batches)
                record['submission_in_flight'] = {'start': start, 'name': 'expand8k_%02d' % start}
                write(ARCHIVE / 'jobs.json', record)
                result = remote(['sbatch', '--parsable', '--job-name=expand8k_%02d' % start,
                                 '--export=ALL,START_WORKER=%d' % start, ROOT + '/prepare.sh']).strip()
                job = int(result.split(';')[0])
                record.setdefault('additional_batches', []).append({'start': start, 'job': job})
                record.pop('submission_in_flight')
                write(ARCHIVE / 'jobs.json', record)
                print('submitted', start, job, flush=True)
                continue
            time.sleep(45)


if __name__ == '__main__':
    main()
