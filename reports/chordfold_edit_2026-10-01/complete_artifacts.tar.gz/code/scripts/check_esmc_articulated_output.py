#!/usr/bin/env python3
"""CPU interface checks and saved-prediction diagnosis, with no network execution."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from validate_esmc_articulated_fit import check_geometry

from fastglycan.articulated_output import AA, ArticulatedOutput
from fastglycan.articulated_reference import articulate_reference, bridge_rotations
from fastglycan.experimental_geometry import compare_local_geometry
from fastglycan.experimental_metrics import compare_experimental
from fastglycan.experimental_training import map_experimental_atoms


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pool(rows):
    result = {}
    for metric, weight in (
        ("all_heavy_atom_rmsd", "common_atom_count"),
        ("ca_rmsd", "common_ca_count"),
        ("ca_pair_distance_rmse", "common_ca_pair_count"),
    ):
        result[metric] = float(
            np.sqrt(
                sum(r["metrics"][metric] ** 2 * r["metrics"][weight] for r in rows)
                / sum(r["metrics"][weight] for r in rows)
            )
        )
    result["atom_rmsd_le_2"] = sum(r["metrics"]["all_heavy_atom_rmsd"] <= 2 for r in rows)
    result["local_distances"] = {}
    for name in ("N_CA", "CA_C", "C_O", "consecutive_C_N"):
        values = [r["geometry"]["local_distances"][name] for r in rows]
        result["local_distances"][name] = float(
            np.sqrt(sum(v["squared_error_sum"] for v in values) / sum(v["count"] for v in values))
        )
    centers = [r["geometry"]["ca_chirality"] for r in rows]
    result["handedness_agreement"] = sum(c["agreement_count"] for c in centers) / sum(
        c["evaluable_count"] for c in centers
    )
    result["fallback_counts"] = np.sum([r["fallback_counts"] for r in rows], axis=0).tolist()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--references", type=Path, required=True)
    parser.add_argument("--articulation", type=Path, required=True)
    parser.add_argument("--training", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    started = time.monotonic()
    args.output.mkdir(parents=True, exist_ok=False)
    refs = json.loads((args.references / "report.json").read_text())
    art = json.loads((args.articulation / "report.json").read_text())
    train = json.loads((args.training / "report.json").read_text())
    qa = json.loads((args.training / "independent_validation.json").read_text())
    contract = json.loads((args.training / "contract.json").read_text())
    assert (
        sha(args.references / "report.json")
        == "40909d6dee6f23e5b8f2e0abb542922dafa97e3ff1068324c888e05c54f597e4"
    )
    assert (
        sha(args.articulation / "report.json")
        == "82b1a7f10bc32f46fe33e11ae0df5e2a5df18c9a2045e1d653d567e862ac960d"
    )
    assert qa["complete"] and train["complete"] and qa["heavy_artifacts_checked"]
    assert (
        sha(args.training / "report.json")
        == qa["report_sha256"]
        == "8ff68aef2e56d801ce64b1736ab50c4525ff03451090bcd179de1ab5bfe500ab"
    )
    assert sha(args.training / "contract.json") == train["contract_sha256"]
    provenance = {r["group_id"]: r for r in contract["input_provenance"]}
    maxima, conditions, derivatives = defaultdict(float), defaultdict(list), []
    rng = np.random.default_rng(913)
    reference_residues = 0
    for index, case in enumerate(refs["cases"]):
        group = case["group_id"]
        path = args.references / f"{group}.npz"
        assert sha(path) == case["artifact_sha256"]
        with np.load(path, allow_pickle=False) as saved:
            data = dict(saved)
        inventory = {k: data[k] for k in ("atom_name", "residue_id", "element")}
        p = provenance[group]
        assert p["sequence"] == case["provenance"]["sequence"] and p["split"] == "train"
        assert data["reference_mask"].all()
        adapter = ArticulatedOutput(
            data["reference"], data["atom_name"], data["residue_id"], p["sequence"], art["variants"]
        )
        assert not list(adapter.parameters())
        # Generate a fresh admissible conformation without reading target coordinates/masks.
        generated = np.empty_like(data["reference"], dtype=np.float64)
        local_specs = []
        for residue in np.unique(data["residue_id"]):
            indices = np.flatnonzero(data["residue_id"] == residue)
            names = data["atom_name"][indices].tolist()
            variant = art["variants"][AA[p["sequence"][int(residue) - 1]] + ":" + ",".join(names)]
            reference = data["reference"][indices].astype(np.float64)
            rotations = bridge_rotations(names, variant["bonds"])
            angles = torch.from_numpy(rng.uniform(-np.pi, np.pi, len(rotations)))
            x = articulate_reference(torch.from_numpy(reference), angles, rotations).numpy()
            rotation, _ = np.linalg.qr(rng.normal(size=(3, 3)))
            rotation[:, -1] *= np.linalg.det(rotation)
            generated[indices] = x @ rotation + rng.normal(size=3) * 4
            local_specs.append((indices, reference, variant))
            reference_residues += 1
        for dtype, tolerance in ((torch.float64, 1e-10), (torch.float32, 5e-5)):
            adapter = adapter.to(dtype=dtype)
            raw = torch.tensor(generated, dtype=dtype)
            checked = adapter(raw)
            assert checked["fallback_counts"].sum() == 0
            error = float((checked["coordinate"] - raw).abs().max())
            key = f"generated_reconstruction_{dtype}"
            maxima[key] = max(maxima[key], error)
            assert error < tolerance, (group, key, error)
            repeat = adapter(checked["coordinate"])["coordinate"]
            error = float((repeat - checked["coordinate"]).abs().max())
            maxima[f"generated_idempotence_{dtype}"] = max(
                maxima[f"generated_idempotence_{dtype}"], error
            )
            assert error < tolerance
            for indices, reference, variant in local_specs:
                error = check_geometry(reference, checked["coordinate"].numpy()[indices], variant)
                maxima[f"generated_geometry_{dtype}"] = max(
                    maxima[f"generated_geometry_{dtype}"], error
                )
                assert error < tolerance
        folder = args.training / group
        assert sha(folder / "gt.npz") == p["gt_npz_sha256"]
        assert sha(folder / "gt.json") == p["gt_metadata_sha256"]
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        labels = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            p["sequence"],
            p["sample_id"],
            inventory,
        )
        assert np.array_equal(labels["coordinate"].numpy(), data["target"])
        assert np.array_equal(labels["coordinate_mask"].numpy(), data["observed"])
        for stage in ("initial", "best"):
            for seed in (12345, 54321):
                original = train[stage]["conditions"][str(seed)]["examples"][index]
                assert original["group_id"] == group
                path = folder / f"{stage}_{seed}.npz"
                assert sha(path) == original["prediction_sha256"]
                with np.load(path, allow_pickle=False) as saved:
                    raw_data = dict(saved)
                assert all(np.array_equal(raw_data[k], v) for k, v in inventory.items())
                raw = torch.tensor(raw_data["coordinate"])
                projected = adapter(raw)
                assert torch.isfinite(projected["coordinate"]).all()
                geometry_error = max(
                    check_geometry(reference, projected["coordinate"].numpy()[indices], variant)
                    for indices, reference, variant in local_specs
                )
                maxima["saved_prediction_geometry_fp32"] = max(
                    maxima["saved_prediction_geometry_fp32"], geometry_error
                )
                assert geometry_error < 1e-4
                prediction = inventory | {"coordinate": projected["coordinate"].numpy()}
                original_metrics = compare_experimental(raw_data, arrays, p["sequence"])
                assert (
                    abs(
                        original_metrics["all_heavy_atom_rmsd"]
                        - original["metrics"]["all_heavy_atom_rmsd"]
                    )
                    < 2e-5
                )
                dest = args.output / group / f"{stage}_{seed}.npz"
                dest.parent.mkdir(exist_ok=True)
                np.savez_compressed(dest, **prediction)
                condition = f"{stage}_{seed}"
                conditions[condition].append(
                    {
                        "group_id": group,
                        "raw_prediction_sha256": sha(path),
                        "prediction_sha256": sha(dest),
                        "metrics": compare_experimental(prediction, arrays, p["sequence"]),
                        "geometry": compare_local_geometry(prediction, arrays, p["sequence"]),
                        "fallback_counts": projected["fallback_counts"].tolist(),
                    }
                )
                if stage == "best" and seed == 12345 and index in (0, 31):
                    adapter.double()
                    variable = raw.double().requires_grad_(True)
                    weights = torch.from_numpy(rng.normal(size=variable.shape))
                    loss = (adapter(variable)["coordinate"] * weights).sum()
                    gradient = torch.autograd.grad(loss, variable)[0]
                    direction = gradient / gradient.norm()
                    delta = 1e-6
                    plus = (
                        adapter(variable.detach() + delta * direction)["coordinate"] * weights
                    ).sum()
                    minus = (
                        adapter(variable.detach() - delta * direction)["coordinate"] * weights
                    ).sum()
                    fd = float((plus - minus) / (2 * delta))
                    analytic = float((gradient * direction).sum())
                    assert np.isfinite(analytic) and analytic > 0
                    relative = abs(fd - analytic) / analytic
                    assert relative < 1e-5
                    derivatives.append(
                        {
                            "group_id": group,
                            "gradient_norm": analytic,
                            "directional_finite_difference": fd,
                            "relative_error": relative,
                        }
                    )
                    adapter.float()
    assert reference_residues == 3979
    source = Path(__file__).resolve().parents[1]
    names = (
        "scripts/check_esmc_articulated_output.py",
        "scripts/validate_esmc_articulated_fit.py",
        "src/fastglycan/articulated_output.py",
        "src/fastglycan/articulated_reference.py",
        "src/fastglycan/experimental_geometry.py",
        "src/fastglycan/experimental_metrics.py",
        "src/fastglycan/experimental_training.py",
        "src/fastglycan/all_atom_metrics.py",
        "src/onestepfold/data/gt_materializer.py",
        "tests/test_articulated_output.py",
        "docs/esmc_articulated_output_v1.md",
    )
    hashes = {}
    for name in names:
        dest = args.output / "source" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, dest)
        hashes[name] = sha(dest)
    summaries = {name: pool(rows) for name, rows in conditions.items()}
    result = {
        "complete": True,
        "reference_report_sha256": sha(args.references / "report.json"),
        "articulation_report_sha256": sha(args.articulation / "report.json"),
        "training_report_sha256": sha(args.training / "report.json"),
        "training_qa_sha256": sha(args.training / "independent_validation.json"),
        "generated_chemical_residues": reference_residues,
        "max_errors": dict(maxima),
        "derivatives": derivatives,
        "summaries": summaries,
        "conditions": dict(conditions),
        "source_sha256": hashes,
        "elapsed_seconds": time.monotonic() - started,
        "scope": "GT-free CPU interface and saved prediction postprocessing; no trained result",
    }
    (args.output / "report.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {k: v for k, v in result.items() if k not in ("conditions", "source_sha256")}, indent=2
        )
    )


if __name__ == "__main__":
    main()
