#!/usr/bin/env python3
"""Independently reread every state/atom and accepted parent before training."""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, validate_pair_traces, write_json
from fastglycan.teacher_pairing import tensor_digest
from onestepfold.data.teacher_pairs import load_teacher_pair, load_teacher_pair_manifest
from onestepfold.training.coordinate_refiner import group_id_digest, select_length_stratified


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.cache_root.resolve()
    control = root / "control"
    if (control / "acceptance.json").exists():
        raise FileExistsError("cache already has acceptance; preserve the audit")
    protocol, records = read_cache(root)
    parent = Path(protocol["parent_root"])
    parent_manifest = parent / "control/teacher_pair_manifest_v1.jsonl.gz"
    assert len(records) == len({r.group_id for r in records}) == 192
    for split, count, seed in (("train", 128, 101), ("validation", 64, 102)):
        actual = [r for r in records if r.split == split]
        expected = select_length_stratified(
            load_teacher_pair_manifest(parent_manifest, split=split), count, seed=seed)
        assert actual == expected
        assert group_id_digest(actual) == protocol["selections"][split]["group_id_sha256"]
    worker_groups, worker_hashes, checkpoint_hashes, longest = [], {}, set(), set()
    for spec in protocol["workers"]:
        index = spec["index"]
        selection = control / f"worker_{index}.json"
        assert sha256(selection) == spec["sha256"]
        ids = json.loads(selection.read_text())
        report_path = control / f"worker_{index}_report.json"
        report = json.loads(report_path.read_text())
        assert report["complete"] and report["completed_groups"] == ids
        assert report["protocol_sha256"] == sha256(control / "protocol.json")
        assert sha256(root / "work" / f"worker_{index}/input.json") == report["input_sha256"]
        for name, digest in report["source_sha256"].items():
            assert sha256(args.code_root / name) == digest, name
        for name, digest in report["runtime_source_sha256"].items():
            assert sha256(Path(name)) == digest, name
        assert sha256(Path(report["checkpoint_path"])) == report["checkpoint_sha256"]
        checkpoint_hashes.add(report["checkpoint_sha256"])
        worker_groups.extend(ids)
        longest.add(spec["longest_group_id"])
        assert ids[0] == spec["longest_group_id"]
        worker_hashes[str(index)] = sha256(report_path)
    assert len(checkpoint_hashes) == 1
    assert Counter(worker_groups) == Counter(r.group_id for r in records)
    trace_hashes, tensor_bytes = {}, 0
    for record in records:
        directory = root / "examples" / record.group_id
        trace_path = directory / "trace.json"
        row = json.loads(trace_path.read_text())
        assert (row["group_id"], row["split"], row["sequence"], row["length"]) == (
            record.group_id, record.split, record.sequence, record.sequence_length)
        prior_path = parent / "control/traces" / f"{record.group_id}.json"
        assert sha256(prior_path) == row["parent_trace_sha256"]
        prior = json.loads(prior_path.read_text())
        assert row["prepared_features_sha256"] == prior["prepared_features_sha256"]
        length = record.sequence_length
        for label in ("c1", "c4"):
            path = directory / f"{label}.pt"
            spec = row["states"][label]
            assert sha256(path) == spec["sha256"]
            state = torch.load(path, map_location="cpu", weights_only=True)
            assert [list(t.shape) for t in state] == spec["shapes"] == [
                [length, 449], [length, 384], [length, length, 128]]
            assert [str(t.dtype) for t in state] == spec["dtypes"] == [
                "torch.float32", "torch.bfloat16", "torch.bfloat16"]
            assert all(bool(torch.isfinite(t).all()) for t in state)
            assert [tensor_digest(t) for t in state] == spec["tensor_sha256"]
            assert sum(t.numel() * t.element_size() for t in state) == spec["tensor_bytes"]
            trunk = row["conditions"][label]["trace"][0]
            assert spec["tensor_sha256"][1:] == [trunk["single_sha256"], trunk["pair_sha256"]]
            tensor_bytes += spec["tensor_bytes"]
            del state
        assert row["states"]["c1"]["tensor_sha256"][0] == row["states"]["c4"]["tensor_sha256"][0]
        arrays, inventory = {}, None
        expected_labels = {"c1", "c2", "c4"}
        if record.group_id in longest:
            expected_labels.add("replay_c4")
        assert set(row["conditions"]) == expected_labels
        for label, spec in row["conditions"].items():
            path = directory / f"{label}.npz"
            assert sha256(path) == spec["coordinates_sha256"]
            assert spec["decoder_nfe"] == 2
            assert spec["trunk_calls"] == (0 if label == "replay_c4" else int(label[1:]))
            trunk, diffusion = spec["trace"]
            assert not trunk["mc_dropout"] and diffusion["explicit_seed"] == 12345
            with np.load(path, allow_pickle=False) as saved:
                arrays[label] = saved["coordinate"]
                assert arrays[label].shape == (row["atom_count"], 3)
                assert np.isfinite(arrays[label]).all()
                current = (saved["atom_name"], saved["residue_id"], saved["element"])
                if inventory is None:
                    inventory = current
                else:
                    assert all(np.array_equal(a, b) for a, b in zip(
                        inventory, current, strict=True))
            if label in ("c2", "c4"):
                for key in ("input_feature_sha256", "single_sha256", "pair_sha256"):
                    assert trunk[key] == prior["conditions"][label][0][key]
                assert diffusion["rng_at_sampler_entry"] == prior["conditions"][label][1][
                    "rng_at_sampler_entry"]
        validate_pair_traces(row["conditions"]["c2"]["trace"], row["conditions"]["c4"]["trace"])
        assert len({s["trace"][1]["rng_at_sampler_entry"] for s in row["conditions"].values()}) == 1
        if record.group_id in longest:
            assert row["longest_replay_exact"]
            assert np.array_equal(arrays["c4"], arrays["replay_c4"])
            assert row["conditions"]["c4"]["decoder_cache_sha256"] == row["conditions"][
                "replay_c4"]["decoder_cache_sha256"]
        names, residue_ids, elements = inventory
        assert not np.any(elements == "H")
        assert np.array_equal(residue_ids[names == "CA"], np.arange(1, length + 1))
        keys = list(zip(residue_ids.tolist(), names.tolist(), strict=True))
        assert len(set(keys)) == len(keys)
        lookup = {key: i for i, key in enumerate(keys)}
        # Load both parent CIFs through the strict sequence/atom/confidence loader.
        pair = load_teacher_pair(record, parent)
        for label, structure in (("c2", pair.c2), ("c4", pair.c4)):
            expected_keys = [(residue, atom) for _, residue, atom in structure.atom_keys]
            assert set(expected_keys) == set(keys) and len(expected_keys) == len(keys)
            reordered = arrays[label][[lookup[key] for key in expected_keys]]
            assert np.max(np.abs(reordered - structure.positions)) <= 0.0006
        for name, digest in prior["artifact_sha256"].items():
            assert sha256(parent / name) == digest
        trace_hashes[record.group_id] = sha256(trace_path)
        print(json.dumps({"validated": len(trace_hashes), "group_id": record.group_id}), flush=True)
    result = {"complete": True, "schema_version": "pair-state-cache-acceptance-v1",
              "protocol_sha256": sha256(control / "protocol.json"),
              "manifest_sha256": protocol["manifest_sha256"],
              "split_counts": dict(Counter(r.split for r in records)),
              "worker_report_sha256": worker_hashes, "trace_sha256": trace_hashes,
              "checkpoint_sha256": next(iter(checkpoint_hashes)),
              "saved_tensor_bytes": tensor_bytes, "exact_longest_replays": len(longest),
              "all_parent_cif_atoms_verified": True,
              "validator_source_sha256": sha256(Path(__file__))}
    write_json(control / "acceptance.json", result)
    (control / "PASSED").write_text(sha256(control / "acceptance.json") + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "trace_sha256"}), flush=True)


if __name__ == "__main__":
    main()
