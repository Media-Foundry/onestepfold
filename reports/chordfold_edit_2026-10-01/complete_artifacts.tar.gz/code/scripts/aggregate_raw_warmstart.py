#!/usr/bin/env python3
"""Accept sharded validation only after exact disjoint prediction coverage."""
import argparse
import json
import py_compile
from pathlib import Path

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.raw_warmstart import verify_lock

VIEWS=('initial_validation','initial_train_probe','last_validation','best_validation','best_train_probe','best_full_train')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--experiment',type=Path,required=True)
    a=p.parse_args();root=a.experiment.resolve();phase=root
    base=verify_lock(root,root/'code_v1')
    plan={'parts':{'raw_continue':2,'geometry_adapt':2}}
    expected={}
    for label,item in base['runs'].items():
        r=json.loads((Path(item['root'])/'report.json').read_text())
        keys={(row['group_id'],row['prediction_sha256']) for view in VIEWS for row in r[view]['rows']}
        count=plan['parts'][label]
        split=[{key for key in keys if int(key[0],16)%count==i} for i in range(count)]
        assert all(split) and set.union(*split)==keys and sum(map(len,split))==len(keys)
        expected[label]=split
    accepted_results={}
    for label,parts_expected in expected.items():
        folder=root/label
        assert not (folder/'independent_validation_precision_v2.json').exists()
        parts=[];seen=set()
        for i,wanted in enumerate(parts_expected):
            part=json.loads((folder/'precision_parts'/f'part_{i}.json').read_text())
            assert part['shard_complete'] and not part['complete'] and part['shard']==i
            assert part['shards']==len(parts_expected)
            assert part['phase_lock_sha256']==sha256(phase/'lock.json')
            assert part['validator_source_sha256']==sha256(root/'code_v1/scripts/validate_esmc_raw_warmstart.py')
            actual={tuple(key) for key in part['checked_prediction_keys']}
            assert len(actual)==len(part['checked_prediction_keys'])==part['unique_saved_predictions_checked']
            assert actual==wanted and not seen.intersection(actual)
            seen.update(actual);parts.append(part)
        audit=json.loads((folder/'gpu_projection.json').read_text())
        assert len(seen)==audit['checked']
        result=dict(parts[0])
        for name in ('shard_complete','shard','shards','checked_prediction_keys'):
            result.pop(name)
        common=('experiment_lock_sha256','report_sha256','training_updates_checked','audit_sha256',
                'gpu32_replay_exact','fp64_formula_atol','legacy_cross_precision_atol')
        for part in parts:
            for key in common:assert part[key]==result[key],(label,key)
            assert part['gpu32_replay_exact'] and part['checkpoint_hashes_checked']
            assert part['max_fp64_formula_error']<=1e-8
        assert result['experiment_lock_sha256']==sha256(root/'lock.json')
        assert result['report_sha256']==sha256(Path(base['runs'][label]['root'])/'report.json')
        assert result['audit_sha256']==sha256(folder/'gpu_projection.json')
        result['complete']=True
        result['unique_saved_predictions_checked']=len(seen)
        result['part_sha256']={f'part_{i}.json':sha256(folder/'precision_parts'/f'part_{i}.json') for i in range(len(parts))}
        result['aggregation_source_sha256']=sha256(Path(__file__))
        result['coverage_partition']='group_id interpreted as hex modulo number of parts; exact disjoint union verified'
        result['legacy_cross_precision_failures']=[x for part in parts for x in part['legacy_cross_precision_failures']]
        result['legacy_cross_precision_gate_passed']=not result['legacy_cross_precision_failures']
        assert {x['prediction_sha256'] for x in result['legacy_cross_precision_failures']}=={x['prediction_sha256'] for x in audit['failures']}
        for key in ('max_projection_error','max_fp64_formula_error','max_independent_rmsd_error','max_independent_lddt_error'):
            result[key]=max(part[key] for part in parts)
        result['max_loss_errors']=[max(part['max_loss_errors'][i] for part in parts) for i in range(4)]
        accepted_results[label]=result
    for label,result in accepted_results.items():
        write_json(root/label/'independent_validation_precision_v2.json',result)
    print('Full disjoint coverage verified; precision-v2 reports accepted',flush=True)


if __name__=='__main__':main()
