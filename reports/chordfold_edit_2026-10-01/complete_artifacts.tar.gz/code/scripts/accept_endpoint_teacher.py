#!/usr/bin/env python3
"""CPU verification of all teacher inventories, call counts and development quality."""
import argparse
import json
from pathlib import Path
import numpy as np
from fastglycan.endpoint_distillation import map_terminal_coordinates
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.scaling_metrics import quality_metrics
from fastglycan.experimental_geometry import compare_local_geometry


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    lock = json.loads((root / 'lock.json').read_text())
    selection = json.loads((root / 'selection.json').read_text())
    assert sha256(root / 'selection.json') == lock['selection_sha256']
    rows = {r['group_id']: r for r in selection}
    acceptance = json.loads((Path(lock['data_root']) / 'acceptance.json').read_text())
    seen, targets, qualities, progress_hashes = set(), {}, [], {}
    expected_env = None
    for worker in range(8):
        folder = root / f'teacher_{worker}'
        progress = json.loads((folder / 'progress.json').read_text())
        assert json.loads((folder / 'completed.json').read_text())['progress_sha256'] == sha256(folder / 'progress.json')
        assert progress['complete'] and progress['lock_sha256'] == sha256(root / 'lock.json')
        assert {p['setting'] for p in progress['preflight'] if p['exact']} == {'c4_s2', 'c1_s1'}
        env = {k: progress['environment'][k] for k in ('checkpoint_sha256', 'esm_checkpoint_sha256', 'runtime_source_sha256')}
        if expected_env is None:
            expected_env = env
        assert env == expected_env
        progress_hashes[str(worker)] = sha256(folder / 'progress.json')
        for r in progress['records']:
            group, setting = r['group_id'], r['setting']
            assert (group, setting) not in seen
            seen.add((group, setting))
            assert group in {x['group_id'] for x in selection[worker::8]}
            assert r['split'] == rows[group]['split'] and r['seed'] == 103
            expected_calls = (4, 2) if setting == 'c4_s2' else (1, 1)
            assert (r['trunk_calls'], r['denoiser_calls']) == expected_calls
            assert r['sample_count'] == 1 and not r['mc_dropout_applied']
            assert r['sampler_parameters']['gamma0'] == 0 and r['sampler_parameters']['step_scale_eta'] == 1
            assert sha256(root / r['path']) == r['sha256']
            assert sha256(root / r['native_path']) == r['native_sha256']
            assert sha256(root / r['path'].rsplit('/', 1)[0] / 'sequence_packet.pt') == r['packet_sha256']
            datafolder = Path(lock['data_root']) / 'examples' / group
            assert sha256(datafolder / 'prepared.json') == acceptance['prepared_sha256'][group]
            info = json.loads((datafolder / 'prepared.json').read_text())
            for name in ('inventory.npz', 'gt.npz'):
                assert sha256(datafolder / name) == info['files_sha256'][name]
            with np.load(datafolder / 'inventory.npz') as d:
                inventory = dict(d)
            with np.load(root / r['native_path']) as d:
                independent = map_terminal_coordinates(d['coordinate'], d['atom_name'], d['residue_id'], inventory)
            with np.load(root / r['path']) as d:
                for key, value in inventory.items():
                    assert np.array_equal(d[key], value)
                assert np.array_equal(d['coordinate'], independent)
            with np.load(datafolder / 'gt.npz') as d:
                gt = dict(d)
            prediction = inventory | {'coordinate': independent}
            qualities.append({'group_id': group, 'split': r['split'], 'setting': setting,
                              'quality': quality_metrics(prediction, gt, rows[group]['sequence']),
                              'geometry': compare_local_geometry(prediction, gt, rows[group]['sequence']),
                              'model_forward_seconds': r['model_forward_seconds']})
            if setting == 'c4_s2':
                targets[group] = {k: r[k] for k in ('path', 'sha256', 'split', 'atom_count')}
    expected = {(r['group_id'], s) for r in selection for s in (
        ['c4_s2'] if r['split'] == 'train' else ['c4_s2', 'c1_s1'])}
    assert seen == expected and len(seen) == 768 and len(targets) == 640
    write_json(root / 'teacher_quality.json', qualities)
    write_json(root / 'teacher_acceptance.json', {
        'complete': True, 'predictions': 768, 'targets': targets,
        'lock_sha256': sha256(root / 'lock.json'), 'progress_sha256': progress_hashes,
        'quality_sha256': sha256(root / 'teacher_quality.json'), 'environment': expected_env})
    print('Teacher cache accepted: 512 training targets + 128 paired development references', flush=True)


if __name__ == '__main__':
    main()
