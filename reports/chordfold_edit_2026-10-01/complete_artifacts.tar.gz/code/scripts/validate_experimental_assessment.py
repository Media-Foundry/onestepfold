#!/usr/bin/env python3
"""Rebuild selected experimental labels from raw CIF and recompute metrics in FP64."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.spatial.distance import pdist

from fastglycan.experimental_metrics import prediction_atom37, validate_experimental_record
from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, write_json
from onestepfold.data.gt_materializer import ATOM37_INDEX, materialize_entry
from onestepfold.training.coordinate_refiner import group_id_digest


def rigid_rmsd(first, second):
    x, y = first.astype(np.float64), second.astype(np.float64)
    x, y = x - x.mean(0), y - y.mean(0)
    u, _, vt = np.linalg.svd(x.T @ y)
    correction = np.diag([1.0, 1.0, np.linalg.det(u @ vt)])
    return float(np.sqrt(np.mean(np.sum((x @ u @ correction @ vt - y) ** 2, axis=1))))


def independent_metrics(prediction, arrays, sequence, expected_inventory):
    positions, inventory = prediction_atom37(prediction, sequence)
    assert np.array_equal(inventory, expected_inventory)
    common = arrays["atom37_mask"] & inventory & arrays["residue_mask"][:, None]
    ca = common[:, ATOM37_INDEX["CA"]]
    x, y = positions[ca, ATOM37_INDEX["CA"]], arrays["atom37_positions"][ca, ATOM37_INDEX["CA"]]
    assert len(x) >= 3
    return {
        "all_heavy_atom_rmsd": rigid_rmsd(positions[common], arrays["atom37_positions"][common]),
        "ca_rmsd": rigid_rmsd(x, y),
        "ca_pair_distance_rmse": float(np.sqrt(np.mean((pdist(x) - pdist(y)) ** 2))),
        "common_atom_count": int(common.sum()),
        "common_ca_count": int(ca.sum()),
        "common_ca_pair_count": len(x) * (len(x) - 1) // 2,
        "observed_gt_atom_count": int(arrays["atom37_mask"].sum()),
        "predicted_gt_coverage": float(common.sum() / arrays["atom37_mask"].sum()),
        "missing_gt_residue_count": int((~arrays["residue_mask"]).sum()),
    }


def summarize(rows):
    result = {}
    for label in rows[0]["conditions"]:
        values = [r["conditions"][label]["metrics"] for r in rows]
        result[label] = {}
        for metric, count in (
            ("all_heavy_atom_rmsd", "common_atom_count"),
            ("ca_rmsd", "common_ca_count"),
            ("ca_pair_distance_rmse", "common_ca_pair_count"),
        ):
            result[label]["macro_" + metric] = float(np.mean([v[metric] for v in values]))
            result[label]["pooled_" + metric] = math.sqrt(
                sum(v[metric] ** 2 * v[count] for v in values) / sum(v[count] for v in values)
            )
            for reference in ("c1", "c2", "c4"):
                deltas = [
                    r["conditions"][label]["metrics"][metric]
                    - r["conditions"][reference]["metrics"][metric]
                    for r in rows
                ]
                result[label][f"{metric}_worse_than_{reference}_count"] = sum(
                    d > 1e-6 for d in deltas
                )
                result[label][f"{metric}_mean_difference_to_{reference}"] = float(np.mean(deltas))
        result[label]["min_gt_coverage"] = min(v["predicted_gt_coverage"] for v in values)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assessment-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--response-decoded-root", type=Path)
    args = parser.parse_args()
    root = args.assessment_root.resolve()
    protocol = json.loads((root / "protocol.json").read_text())
    baseline = json.loads((root / "baseline.json").read_text())
    assert baseline["complete"] and baseline["protocol_sha256"] == sha256(root / "protocol.json")
    _, records = read_cache(Path(protocol["state_root"]), accepted=True)
    selected = [r for r in records if r.split == "validation"]
    assert len(selected) == 64 and protocol["selection"] == [r.to_dict() for r in selected]
    assert protocol["selection_sha256"] == group_id_digest(selected)
    assert (
        sha256(Path(protocol["state_root"]) / "control/acceptance.json")
        == protocol["state_acceptance_sha256"]
    )
    assert (
        sha256(Path(protocol["stageb_root"]) / "stageb_v1_summary.json")
        == protocol["stageb_summary_sha256"]
    )
    for name, digest in protocol["source_sha256"].items():
        assert sha256(args.code_root / name) == digest, name
    for name, digest in protocol["input_metadata_sha256"].items():
        assert sha256(Path(name)) == digest, name
    for spec in protocol["baseline_decoders"].values():
        assert sha256(Path(spec["root"]) / "independent_validation.json") == spec["qa_sha256"]
    response_rows, response_qa_sha = {}, None
    if args.response_decoded_root:
        accepted_path = args.response_decoded_root / "independent_validation.json"
        accepted = json.loads(accepted_path.read_text())
        assert accepted["complete"] and accepted["checkpoint_validation_kind"] == "response"
        assert (
            accepted["all_64_identity_replays_exact"]
            and accepted["all_64_pair_predictions_recomputed"]
        )
        assert {r["group_id"] for r in accepted["examples"]} == {r.group_id for r in selected}
        response_qa_sha = sha256(accepted_path)
        for worker, digest in accepted["worker_report_sha256"].items():
            path = args.response_decoded_root / f"worker_{worker}.json"
            assert sha256(path) == digest
            report = json.loads(path.read_text())
            for row in report["examples"]:
                response_rows[row["group_id"]] = row
    rows = []
    for record, original in zip(selected, baseline["examples"], strict=True):
        group = record.group_id
        assert original["group_id"] == group
        folder = root / "examples" / group
        assert sha256(folder / "trace.json") == baseline["trace_sha256"][group]
        assert json.loads((folder / "trace.json").read_text()) == original
        assert sha256(folder / "gt.npz") == original["gt_npz_sha256"]
        assert sha256(folder / "gt.json") == original["gt_metadata_sha256"]
        metadata = json.loads((folder / "gt.json").read_text())
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = {key: saved[key] for key in saved.files}
        validate_experimental_record(arrays, metadata, record.sequence, record.sample_id)
        raw = Path(original["raw_mmcif_path"])
        assert (
            sha256(raw)
            == original["source_mmcif_sha256"]
            == metadata["provenance"]["source_mmcif_sha256"]
        )
        # Rebuild only this selected raw chain, including the declared assembly operation and masks.
        rebuilt, _ = materialize_entry(
            {
                "pdb_id": metadata["pdb_id"],
                "sequence": record.sequence,
                "source_label_asym_id": metadata["chains"][0]["source_label_asym_id"],
                "assembly_id": metadata["assembly_id"],
            },
            raw,
        )
        assert all(np.array_equal(value, rebuilt[key]) for key, value in arrays.items())
        row = json.loads(json.dumps(original))
        if response_rows:
            response = response_rows[group]
            path = args.response_decoded_root / "examples" / group / "student.npz"
            assert sha256(path) == response["conditions"]["student"]["coordinates_sha256"]
            row["conditions"]["response"] = {"path": str(path.resolve()), "sha256": sha256(path)}
        inventory = None
        for label in (
            "c1",
            "c2",
            "c4",
            "pointwise",
            "triangle",
            *(["response"] if response_rows else []),
        ):
            spec = row["conditions"][label]
            path = Path(spec["path"])
            assert sha256(path) == spec["sha256"]
            with np.load(path, allow_pickle=False) as saved:
                prediction = {key: saved[key] for key in saved.files}
            if inventory is None:
                _, inventory = prediction_atom37(prediction, record.sequence)
            metrics = independent_metrics(prediction, arrays, record.sequence, inventory)
            if "metrics" in spec:
                for key, value in metrics.items():
                    assert math.isclose(value, spec["metrics"][key], abs_tol=2e-5, rel_tol=2e-5), (
                        group,
                        label,
                        key,
                    )
            spec["metrics"] = metrics
        rows.append(row)
        print(json.dumps({"verified": len(rows), "group_id": group}), flush=True)
    output_name = "response_validation.json" if response_rows else "independent_validation.json"
    assert not (root / output_name).exists()
    write_json(
        root / output_name,
        {
            "complete": True,
            "baseline_sha256": sha256(root / "baseline.json"),
            "protocol_sha256": sha256(root / "protocol.json"),
            "response_qa_sha256": response_qa_sha,
            "validator_sha256": sha256(Path(__file__)),
            "summary": summarize(rows),
            "examples": rows,
            "all_64_raw_gt_rebuilds_exact": True,
            "all_scalar_metrics_independent_fp64": True,
            "scope": "exploratory fixed 64-group experimental GT; "
                     "no checkpoint selection or temporal test",
        },
    )


if __name__ == "__main__":
    main()
