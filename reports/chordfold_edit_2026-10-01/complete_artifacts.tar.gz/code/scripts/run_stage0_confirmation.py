#!/usr/bin/env python3
"""Run all three paired settings on one GPU, with immutable feature packets."""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import torch

from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.stage0_confirm_runtime import (
    ORDERS,
    SETTINGS,
    Trace,
    environment,
    load_json,
    predict,
    runner_setup,
    save_prediction,
    verify_packet,
    write_progress,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--phase", choices=("repeat", "confirm"), required=True)
    parser.add_argument("--worker", type=int, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    phase = root / args.phase
    lock_path = phase / "runtime_lock.json"
    lock = load_json(lock_path)
    prep_path = phase / "preparation.json"
    assert lock["locked"] and sha256(prep_path) == lock["preparation_sha256"]
    prep = load_json(prep_path)
    ids = load_json(phase / "input.json")
    ids = [row["name"] for row in ids]
    if args.phase == "repeat":
        seed = [103, 107, 109, 113][args.worker // 4]
        ids = ids[args.worker % 4 :: 4]
    else:
        seed = 127
        ids = ids[args.worker :: 16]
    output = phase / f"worker_{args.worker}"
    output.mkdir(exist_ok=False)
    start = time.perf_counter()
    runner = runner_setup(output / "work")
    env = environment(runner)
    for key in ("checkpoint_sha256", "esm_checkpoint_sha256", "runtime_source_sha256"):
        assert env[key] == prep["environment"][key]
    result = {
        "complete": False,
        "phase": args.phase,
        "worker": args.worker,
        "seed": seed,
        "runtime_lock_sha256": sha256(lock_path),
        "environment": env,
        "records": [],
        "warmup_seconds": 0.0,
        "seed_policy": lock["rng_policy"],
    }
    warm_start = time.perf_counter()
    # Warm only on an already scored development target, never on confirmation labels.
    repeat_prep = load_json(root / "repeat/preparation.json")
    warm_group = min(repeat_prep["packets"], key=lambda g: repeat_prep["packets"][g]["length"])
    warm_packet = verify_packet(
        root / "repeat/packets" / (warm_group + ".pt"), repeat_prep["packets"][warm_group]
    )
    for setting in SETTINGS:
        pred, _, _ = predict(runner, warm_packet["data"], setting, seed, None)
        del pred
    result["warmup_seconds"] = time.perf_counter() - warm_start
    write_progress(output / "progress.json", result, start)
    with Trace(runner.model) as trace:
        for index, group in enumerate(ids):
            packet = verify_packet(phase / "packets" / (group + ".pt"), prep["packets"][group])
            for setting in ORDERS[(index + args.worker) % len(ORDERS)]:
                prediction, _, record = predict(runner, packet["data"], setting, seed, trace)
                for key, value in lock["sampler"][setting].items():
                    assert record[key] == value, f"Sampler changed: {setting}/{key}"
                save_start = time.perf_counter()
                artifact = save_prediction(output, setting, seed, group, prediction, packet)
                record.update(
                    {
                        "group_id": group,
                        "length": prep["packets"][group]["length"],
                        "feature_sha256": prep["packets"][group]["feature_sha256"],
                        "serialization_seconds": time.perf_counter() - save_start,
                        "artifact": artifact,
                        "order_index": len(result["records"]),
                    }
                )
                result["records"].append(record)
                del prediction
            write_progress(output / "progress.json", result, start)
            print(f"{args.phase} worker{args.worker}: {index + 1}/{len(ids)} targets", flush=True)
    result["complete"] = True
    result["expected_predictions"] = len(ids) * 3
    assert len(result["records"]) == result["expected_predictions"]
    write_progress(output / "progress.json", result, start)
    write_json(
        output / "completed.json",
        {"complete": True, "progress_sha256": sha256(output / "progress.json")},
    )
    torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
