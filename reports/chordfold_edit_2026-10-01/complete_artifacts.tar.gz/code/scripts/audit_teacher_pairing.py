#!/usr/bin/env python3
"""Small same-device teacher pairing experiment on training groups only."""

from __future__ import annotations

import argparse
import copy
import hashlib
import inspect
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

from fastglycan.teacher_pairing import TeacherRNGTrace, feature_digest
from onestepfold.data.teacher_pair_training import kabsch_align
from onestepfold.data.teacher_pairs import load_teacher_pair, load_teacher_pair_manifest
from onestepfold.training.coordinate_refiner import group_id_digest, select_length_stratified


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compare_ca(first, second):
    first = torch.as_tensor(first, dtype=torch.float32)
    second = torch.as_tensor(second, dtype=torch.float32)
    aligned = kabsch_align(second, first, torch.ones(len(first), dtype=torch.bool))
    return {
        "ca_rmsd": float((aligned - first).square().sum(-1).mean().sqrt()),
        "pair_distance_rmse": float(
            (torch.pdist(first) - torch.pdist(second)).square().mean().sqrt()
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--teacher-root", type=Path, required=True)
    parser.add_argument("--reference-report", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--deterministic", action="store_true")
    args = parser.parse_args()
    args.output_dir = args.output_dir.resolve()
    args.teacher_root = args.teacher_root.resolve()
    args.reference_report = args.reference_report.resolve()
    source_root = Path(__file__).resolve().parents[1]
    if args.output_dir.exists():
        raise FileExistsError("diagnostic output exists; inspect it before rerunning")
    assert torch.cuda.is_available()
    reference = json.loads(args.reference_report.read_text())
    manifest = args.teacher_root / "control/teacher_pair_manifest_v1.jsonl.gz"
    assert sha256(manifest) == reference["data"]["teacher_manifest_sha256"]
    train = select_length_stratified(
        load_teacher_pair_manifest(manifest, split="train"), 4096, seed=101
    )
    assert group_id_digest(train) == reference["run_contract"]["train_group_id_sha256"]
    selected = select_length_stratified([r for r in train if r.sequence_length <= 256], 8, seed=104)
    assert len(selected) == 8
    args.output_dir.mkdir(parents=True)
    input_path = args.output_dir / "input.json"
    input_path.write_text(
        json.dumps(
            [
                {
                    "name": r.group_id,
                    "sequences": [{"proteinChain": {"sequence": r.sequence, "count": 1}}],
                }
                for r in selected
            ],
            indent=2,
        )
        + "\n"
    )
    work = args.output_dir / "work"
    work.mkdir()
    os.chdir(work)
    os.environ["LAYERNORM_TYPE"] = "torch"
    from protenix.data.inference.infer_dataloader import get_inference_dataloader
    from protenix.utils.seed import seed_everything
    from runner import batch_inference

    old_argv = sys.argv
    try:
        sys.argv = sys.argv[:1]
        runner = batch_inference.get_default_runner(
            seeds=[101],
            n_cycle=2,
            n_step=2,
            n_sample=1,
            dtype="bf16",
            model_name="protenix_mini_esm_v0.5.0",
            use_msa=False,
            use_template=False,
            trimul_kernel="torch",
            triatt_kernel="torch",
            enable_tf32=False,
        )
    finally:
        sys.argv = old_argv
    config = runner.configs
    original_mc = {
        "apply_rate": config.mc_dropout_apply_rate,
        "dropout_rate": config.mc_dropout_rate,
    }
    assert original_mc == {"apply_rate": 0.4, "dropout_rate": 0.4}
    config.input_json_path = str(input_path)
    config.num_workers = 0
    seed_everything(101, deterministic=args.deterministic)
    loader = get_inference_dataloader(configs=config)
    checkpoint_path = Path(config.load_checkpoint_dir) / "protenix_mini_esm_v0.5.0.pt"
    checkpoint_hash = sha256(checkpoint_path)
    conditions = [
        ("mc_on_c2", 2, 1.0, None),
        ("mc_on_c4", 4, 1.0, None),
        ("mc_off_c2", 2, 0.0, 12345),
        ("mc_off_c4", 4, 0.0, 12345),
        ("mc_off_c4_repeat", 4, 0.0, 12345),
        ("mc_off_c4_alt_noise", 4, 0.0, 12346),
    ]
    report = {
        "schema_version": "teacher-pairing-diagnostic-v1",
        "complete": False,
        "scope": (
            "8 length-stratified training groups, length <=256; not a corpus noise-floor estimate"
        ),
        "frozen_temporal_test_read": False,
        "teacher_corpus_modified": False,
        "teacher_manifest_sha256": sha256(manifest),
        "reference_report_sha256": sha256(args.reference_report),
        "selection_seed": 104,
        "group_id_sha256": group_id_digest(selected),
        "input_sha256": sha256(input_path),
        "checkpoint_sha256": checkpoint_hash,
        "original_mc_configuration": original_mc,
        "deterministic_algorithms_requested": args.deterministic,
        "conditions": conditions,
        "runtime": {
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "torch": torch.__version__,
            "device": torch.cuda.get_device_name(0),
        },
        "source_sha256": {
            name: sha256(source_root / name)
            for name in (
                "scripts/audit_teacher_pairing.py",
                "src/fastglycan/teacher_pairing.py",
                "src/onestepfold/data/teacher_pairs.py",
                "src/onestepfold/data/teacher_pair_training.py",
                "src/onestepfold/training/coordinate_refiner.py",
            )
        },
        "runtime_source_sha256": {},
        "examples": [],
    }
    for obj in (
        batch_inference.get_default_runner,
        type(runner).predict,
        type(runner.model).get_pairformer_output,
        get_inference_dataloader,
    ):
        path = Path(inspect.getfile(obj))
        report["runtime_source_sha256"][str(path)] = sha256(path)
    records = {r.group_id: r for r in selected}
    started = time.monotonic()
    with TeacherRNGTrace(runner.model, runner.device) as trace:
        for batch in loader:
            data, atoms, error = batch[0]
            if error:
                raise RuntimeError(str(error))
            group_id = data["sample_name"]
            record = records[group_id]
            ca_mask = np.asarray(atoms.atom_name) == "CA"
            assert int(ca_mask.sum()) == record.sequence_length
            features_hash = feature_digest(data["input_feature_dict"])
            row = {
                "group_id": group_id,
                "length": record.sequence_length,
                "prepared_features_sha256": features_hash,
                "conditions": {},
                "comparisons": {},
            }
            coordinates = {}
            for name, cycles, apply_rate, diffusion_seed in conditions:
                config.model.N_cycle = cycles
                runner.model.N_cycle = cycles  # Protenix caches this field at construction.
                config.mc_dropout_apply_rate = apply_rate
                trace.diffusion_seed = diffusion_seed
                trace.events = []
                seed_everything(101, deterministic=args.deterministic)
                prediction = runner.predict(copy.deepcopy(data))
                coordinate = prediction["coordinate"].detach().float().cpu().numpy()
                assert coordinate.shape == (1, len(atoms), 3) and np.isfinite(coordinate).all()
                assert len(trace.events) == 2
                assert trace.events[0]["cycles"] == cycles
                assert trace.events[0]["mc_dropout"] == bool(apply_rate)
                assert trace.events[1]["explicit_seed"] == diffusion_seed
                path = args.output_dir / f"{group_id}_{name}.npz"
                np.savez_compressed(
                    path,
                    coordinate=coordinate[0],
                    atom_name=np.asarray(atoms.atom_name),
                    residue_id=np.asarray(atoms.res_id),
                )
                coordinates[name] = coordinate[0, ca_mask]
                row["conditions"][name] = {
                    "trace": copy.deepcopy(trace.events),
                    "coordinates_sha256": sha256(path),
                }
                del prediction
                assert feature_digest(data["input_feature_dict"]) == features_hash
                print(
                    json.dumps(
                        {"group_id": group_id, "condition": name, "length": record.sequence_length}
                    ),
                    flush=True,
                )
            for label, first, second in (
                ("mc_on_c2_to_c4", "mc_on_c2", "mc_on_c4"),
                ("mc_off_paired_c2_to_c4", "mc_off_c2", "mc_off_c4"),
                ("c4_exact_repeat", "mc_off_c4", "mc_off_c4_repeat"),
                ("c4_alternate_noise", "mc_off_c4", "mc_off_c4_alt_noise"),
            ):
                row["comparisons"][label] = compare_ca(coordinates[first], coordinates[second])
            row["repeat_max_coordinate_difference"] = float(
                np.abs(coordinates["mc_off_c4"] - coordinates["mc_off_c4_repeat"]).max()
            )
            pair = load_teacher_pair(record, args.teacher_root)
            row["comparisons"]["accepted_mixed_device_c2_to_c4"] = compare_ca(
                pair.c2.backbone_positions[:, 1], pair.c4.backbone_positions[:, 1]
            )
            report["examples"].append(row)
            (args.output_dir / "audit.json").write_text(
                json.dumps(report, indent=2, allow_nan=False) + "\n"
            )
    assert len(report["examples"]) == len({r["group_id"] for r in report["examples"]}) == 8
    assert sha256(checkpoint_path) == checkpoint_hash
    assert sha256(manifest) == report["teacher_manifest_sha256"]
    report["complete"] = True
    report["elapsed_seconds"] = time.monotonic() - started
    (args.output_dir / "audit.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )
    print(
        json.dumps({"complete": True, "examples": 8, "elapsed_seconds": report["elapsed_seconds"]}),
        flush=True,
    )


if __name__ == "__main__":
    main()
