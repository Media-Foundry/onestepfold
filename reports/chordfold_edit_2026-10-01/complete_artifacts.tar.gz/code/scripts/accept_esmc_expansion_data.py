#!/usr/bin/env python3
"""Verify all reused and newly prepared packets before expanded training."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root
    assert not (root / 'acceptance.json').exists()
    selection = json.loads((root / 'selection.json').read_text())
    report = json.loads((root / 'selection_report.json').read_text())
    assert report['complete'] and sha(root / 'selection.json') == report['selection_sha256']
    assert sha(root.parent / 'esmc_600m_final_v1/manifest.jsonl.gz') == report['esmc_manifest_sha256']
    assert len(selection) == len({r['group_id'] for r in selection}) == 8320
    assert sum(r['split'] == 'train' for r in selection) == 8192
    assert sum(r['split'] == 'validation' for r in selection) == 128
    source = root / 'code_v1'
    source_manifest = json.loads((source / 'source_manifest.json').read_text())
    for name, digest in source_manifest['files'].items():
        assert sha(source / name) == digest, name
    source_hash = sha(source / 'source_manifest.json')
    old = root.parent / 'stage1b/coordinate_refiner/esmc_scaling_data_v1_20260919'
    assert sha(old / 'acceptance.json') == report['old_acceptance_sha256']
    previous = json.loads((old / 'acceptance.json').read_text())
    assert previous['complete'] and previous['groups'] == 2176
    expected = dict(previous['prepared_sha256'])
    added, workers = {}, {}
    new = root / 'new_packets_v1'
    assert sha(new / 'selection.json') == report['new_selection_sha256']
    new_rows = json.loads((new / 'selection.json').read_text())
    for i in range(64):
        path = new / ('worker_%d.json' % i)
        d = json.loads(path.read_text())
        assert d['complete'] and d['selection_sha256'] == report['new_selection_sha256']
        assert d['source_manifest_sha256'] == source_hash
        assert [r['group_id'] for r in d['examples']] == [r['group_id'] for r in new_rows[i::64]]
        for item in d['examples']:
            g = item['group_id']
            assert g not in expected and g not in added
            added[g] = item['prepared_sha256']
        workers[str(i)] = sha(path)
    assert len(added) == 6144
    expected.update(added)
    assert set(expected) == {r['group_id'] for r in selection}
    metadata_hashes = {str(p.parent.name): sha(p) for p in (root / 'input').glob('*/metadata.jsonl.gz')}
    def verify(row):
        folder = root / 'examples' / row['group_id']
        assert sha(folder / 'prepared.json') == expected[row['group_id']]
        info = json.loads((folder / 'prepared.json').read_text())
        assert info['complete'] and info['selection'] == row
        assert info['mask_independent_exact'] and info['esmc_exact'] and info['projection_independent_exact']
        assert info['input_provenance']['raw_gt_rebuild_exact']
        assert info['input_provenance']['source_metadata_sha256'] == metadata_hashes[row['input_shard']]
        for name, digest in info['files_sha256'].items():
            assert sha(folder / name) == digest, (row['group_id'], name)
        return info['new_variants']
    with ThreadPoolExecutor(max_workers=4) as pool:
        variants = sorted({v for values in pool.map(verify, selection) for v in values})
    acceptance = dict(complete=True, groups=8320, train=8192, validation=128,
                      prepared_sha256=expected, selection_sha256=report['selection_sha256'],
                      worker_sha256=workers, source_manifest_sha256=source_hash,
                      prior_acceptance_sha256=report['old_acceptance_sha256'],
                      new_canonical_terminal_variants=variants,
                      esmc_manifest_sha256=report['esmc_manifest_sha256'],
                      scope='All8320 prepared packet files, selected identities, source-bound worker assertions and reused acceptance checked',
                      acceptance_script_sha256=sha(Path(__file__)))
    (root / 'acceptance.json').write_text(json.dumps(acceptance, indent=2)+'\n')
    print('Accepted8192 TRAIN +128 fixed DEV packets', flush=True)


if __name__ == '__main__':
    main()
