#!/usr/bin/env python3
"""Conditional runtime projection from matched logged updates, not a quality analysis."""

import argparse
import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args().root.resolve()
    manifest = Path(__file__).parent / "manifest.json"
    assert json.loads(manifest.read_text())["source_sha256"] == digest(Path(__file__))
    output = root / "runtime_estimate_v1"
    assert not output.exists()
    data = {}
    prefixes = {}
    now = datetime.now(ZoneInfo("Asia/Hong_Kong"))
    for label in ("raw_continue", "geometry_adapt"):
        folder = root / label
        with (folder / "training.jsonl").open() as handle:
            lines = [next(handle) for _ in range(512)]
        rows = [json.loads(line) for line in lines]
        assert [r["step"] for r in rows] == list(range(1, 513))
        prefixes[label] = lines
        contract = json.loads((folder / "contract.json").read_text())
        initial = json.loads((folder / "history.json").read_text())[0]
        assert initial["step"] == 0 and contract["max_steps"] == 8192
        progress_text = (folder / "progress.json").read_text()
        progress = json.loads(progress_text)
        assert progress["step"] >= 512
        rates = [rows[255]["training_seconds"] / 256,
                 (rows[511]["training_seconds"] - rows[255]["training_seconds"]) / 256]
        assert min(rates) > 0
        eval_seconds = initial["validation"]["seconds"] + initial["train_probe"]["seconds"]
        eval_rows = len(initial["validation"]["rows"]) + len(initial["train_probe"]["rows"])
        assert eval_rows == 320
        remaining = contract["max_steps"] - progress["step"]
        scheduled = sum(step > progress["step"] for step in (2048, 4096, 6144, 8192))
        # Future wall-budget crossings may add evaluations. Show 0 vs 2 extra calls.
        stage_remaining = [remaining * min(rates) + scheduled * eval_seconds,
                           remaining * max(rates) + (scheduled + 2) * eval_seconds]
        stage_totals = [progress["optimization_wall_seconds"] + value for value in stage_remaining]
        final_rows = 256 + 256 + 64 + 256 + 64 + 4096
        final_eval_seconds = eval_seconds / eval_rows * final_rows
        data[label] = {
            "snapshot_step": progress["step"],
            "seconds_per_update_chunks_1_256_and_257_512": rates,
            "initial_eval_seconds_320_predictions": eval_seconds,
            "optimization_stage_total_seconds_scenarios": stage_totals,
            "soft_cap_seconds": contract["soft_seconds"],
            "soft_cap_headroom_seconds_scenarios": [contract["soft_seconds"] - value for value in stage_totals],
            "remaining_optimization_seconds_scenarios": stage_remaining,
            "final_eval_predictions": final_rows,
            "final_eval_seconds_linear_estimate": final_eval_seconds,
            "worker_completion_hkt_scenarios_if_8192_reached": [(now + timedelta(seconds=s + final_eval_seconds)).isoformat() for s in stage_remaining],
            "progress_snapshot": progress,
            "contract_sha256": digest(folder / "contract.json"),
        }
    for rline, gline in zip(prefixes["raw_continue"], prefixes["geometry_adapt"], strict=True):
        raw, geom = json.loads(rline), json.loads(gline)
        for key in ("step", "epoch", "group_id", "noise", "lr", "samples_seen", "residues_seen"):
            assert raw[key] == geom[key], key
    output.mkdir()
    for label, lines in prefixes.items():
        path = output / (label + "_first512.jsonl")
        path.write_text("".join(lines))
        data[label]["prefix_sha256"] = digest(path)
    result = {"complete": True, "observed_at_hkt": now.isoformat(), "source_sha256": digest(Path(__file__)),
              "manifest_sha256": digest(manifest), "arms": data,
              "scope": "Matched first512 timing only; no performance/quality selection or budget change",
              "limitations": ["Two 256-update chunks are scenario rates, not confidence bounds or worst-case guarantees.",
                              "Initial320 evaluation rate is extrapolated to final4992 predictions despite potential length/cache/checkpoint differences.",
                              "Snapshots can lag up to32 updates. Startup/checkpoint I/O, queue delay, post-worker GPU audit, CPU QA, report and plot are not modeled.",
                              "If a modeled optimization total exceeds4h, the existing soft cap still applies; do not extend budget from this estimate."]}
    (output / "estimate.json").write_text(json.dumps(result, indent=2) + "\n")
    brief = {label: {k: v for k, v in arm.items() if k != "progress_snapshot"} for label, arm in data.items()}
    print(json.dumps({"complete": True, "observed_at_hkt": now.isoformat(), "arms": brief}), flush=True)


if __name__ == "__main__":
    main()
