#!/usr/bin/env python3
"""Train the Stage 1B c2-to-c4 coordinate refiner with held-out selection."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import socket
import statistics
import time
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import DataLoader

from fastglycan.models.confidence_features import C2_QUALITY_FEATURE_NAMES
from fastglycan.models.geometry_losses import masked_pair_distance_loss
from fastglycan.paired_teacher_protocol import accepted_protocol_hash
from fastglycan.teacher_pairing import feature_digest
from onestepfold.data.teacher_pair_training import (
    CoordinateRefinerDataset,
    ESMCShardStore,
    LengthAwareCollator,
    LengthBucketBatchSampler,
)
from onestepfold.data.teacher_pairs import TeacherPairRecord, load_teacher_pair_manifest
from onestepfold.models import CoordinateRefinerConfig, GlobalCoordinateRefiner
from onestepfold.training.coordinate_refiner import (
    atomic_torch_save,
    contract_fingerprint,
    evaluate_coordinate_refiner,
    group_id_digest,
    masked_coordinate_loss,
    select_length_stratified,
)

CHECKPOINT_SCHEMA = "coordinate-refiner-training-checkpoint-v1"
REPORT_SCHEMA = "coordinate-refiner-training-report-v1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".part")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def _describe_records(records: list[TeacherPairRecord]) -> dict[str, Any]:
    lengths = [record.sequence_length for record in records]
    return {
        "count": len(records),
        "group_id_sha256": group_id_digest(records),
        "minimum_length": min(lengths),
        "median_length": statistics.median(lengths),
        "maximum_length": max(lengths),
        "total_residues": sum(lengths),
    }


def _make_loader(
    records: list[TeacherPairRecord],
    teacher_root: Path,
    esmc_store: ESMCShardStore,
    *,
    batch_size: int,
    workers: int,
    seed: int,
    shuffle: bool,
    bucket_size_multiplier: int,
    device: torch.device,
    confidence_features: str = "none",
) -> tuple[DataLoader, LengthBucketBatchSampler]:
    dataset = CoordinateRefinerDataset(
        records, teacher_root, esmc_store, confidence_features=confidence_features
    )
    sampler = LengthBucketBatchSampler(
        [record.sequence_length for record in records],
        batch_size,
        bucket_size_multiplier=bucket_size_multiplier,
        shuffle=shuffle,
        seed=seed,
    )
    loader_options: dict[str, Any] = {
        "dataset": dataset,
        "batch_sampler": sampler,
        "collate_fn": LengthAwareCollator(pad_to_multiple=8),
        "num_workers": workers,
        "pin_memory": device.type == "cuda",
        "persistent_workers": workers > 0,
    }
    if workers > 0:
        loader_options["prefetch_factor"] = 2
    return DataLoader(**loader_options), sampler


def _move_batch(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    moved = {
        **batch,
        "residue_features": batch["residue_features"].to(
            device=device, dtype=torch.float32, non_blocking=True
        ),
        "backbone_positions": batch["backbone_positions"].to(device, non_blocking=True),
        "target_ca": batch["target_ca"].to(device, non_blocking=True),
        "residue_mask": batch["residue_mask"].to(device, non_blocking=True),
    }
    if "confidence" in batch:
        moved["confidence"] = batch["confidence"].to(device, non_blocking=True)
    return moved


def _train_epoch(
    model: GlobalCoordinateRefiner,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    *,
    amp_dtype: torch.dtype | None,
    maximum_gradient_norm: float,
    pair_distance_loss_weight: float = 0.0,
) -> dict[str, float | int]:
    model.train()
    squared_error = 0.0
    valid_residues = 0
    maximum_preclip_gradient_norm = 0.0
    batch_count = 0
    objective_sum = 0.0
    pair_loss_sum = 0.0
    clipped_batches = 0
    started = time.monotonic()
    for cpu_batch in loader:
        batch = _move_batch(cpu_batch, device)
        optimizer.zero_grad(set_to_none=True)
        enabled = amp_dtype is not None and device.type == "cuda"
        with torch.autocast(device_type=device.type, dtype=amp_dtype, enabled=enabled):
            output = model(
                batch["residue_features"],
                batch["backbone_positions"],
                batch["residue_mask"],
                **({"confidence": batch["confidence"]} if "confidence" in batch else {}),
            )
            coordinate_loss = masked_coordinate_loss(
                output["corrected_ca"], batch["target_ca"], batch["residue_mask"]
            )
            pair_loss = (
                masked_pair_distance_loss(
                    output["corrected_ca"], batch["target_ca"], batch["residue_mask"]
                )
                if pair_distance_loss_weight > 0
                else coordinate_loss.new_zeros(())
            )
            loss = coordinate_loss + pair_distance_loss_weight * pair_loss
        if not bool(torch.isfinite(loss)):
            raise RuntimeError("training produced a non-finite loss")
        loss.backward()
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), max_norm=maximum_gradient_norm
        )
        if not bool(torch.isfinite(gradient_norm)):
            raise RuntimeError("training produced a non-finite gradient")
        optimizer.step()
        count = int(batch["residue_mask"].sum().item())
        squared_error += float(coordinate_loss.item()) * 3.0 * count
        objective_sum += float(loss.item())
        pair_loss_sum += float(pair_loss.item())
        clipped_batches += int(float(gradient_norm.item()) > maximum_gradient_norm)
        valid_residues += count
        maximum_preclip_gradient_norm = max(
            maximum_preclip_gradient_norm, float(gradient_norm.item())
        )
        batch_count += 1
    if valid_residues == 0:
        raise RuntimeError("training epoch has no valid residues")
    coordinate_mse = squared_error / (3.0 * valid_residues)
    return {
        "batches": batch_count,
        "valid_residues": valid_residues,
        "coordinate_mse": coordinate_mse,
        "ca_rmsd": math.sqrt(squared_error / valid_residues),
        "maximum_preclip_gradient_norm": maximum_preclip_gradient_norm,
        "elapsed_seconds": time.monotonic() - started,
        "mean_batch_objective": objective_sum / batch_count,
        "mean_batch_pair_mse": pair_loss_sum / batch_count
        if pair_distance_loss_weight > 0
        else None,
        "gradient_clipped_batch_fraction": clipped_batches / batch_count,
    }


def _cpu_model_state(model: torch.nn.Module) -> dict[str, torch.Tensor]:
    return {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}


def _capture_rng_state() -> dict[str, Any]:
    return {
        "python": random.getstate(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
    }


def _restore_rng_state(state: dict[str, Any]) -> None:
    random.setstate(state["python"])
    torch.set_rng_state(state["torch"].cpu())
    if torch.cuda.is_available() and state.get("cuda"):
        torch.cuda.set_rng_state_all([cuda_state.cpu() for cuda_state in state["cuda"]])


def _checkpoint_payload(
    *,
    epoch: int,
    model: GlobalCoordinateRefiner,
    optimizer: torch.optim.Optimizer,
    run_contract: dict[str, Any],
    fingerprint: str,
    best_epoch: int,
    best_validation: dict[str, Any] | None,
    history: list[dict[str, Any]],
    initialization_provenance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": CHECKPOINT_SCHEMA,
        "epoch": epoch,
        "model_config": asdict(model.config),
        "model_state_dict": _cpu_model_state(model),
        "optimizer_state_dict": optimizer.state_dict(),
        "run_contract": run_contract,
        "contract_fingerprint": fingerprint,
        "best_epoch": best_epoch,
        "best_validation": best_validation,
        "history": history,
        "rng_state": _capture_rng_state(),
        "initialization_provenance": initialization_provenance,
    }


def _resolve_resume(value: str, output_dir: Path) -> Path | None:
    if value == "none":
        return None
    if value == "auto":
        candidate = output_dir / "last.pt"
        return candidate if candidate.is_file() else None
    return Path(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--teacher-root", type=Path, required=True)
    parser.add_argument("--esmc-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--train-limit", type=int, default=0)
    parser.add_argument("--validation-limit", type=int, default=0)
    parser.add_argument("--validation-every", type=int, default=1)
    parser.add_argument("--bucket-size-multiplier", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--maximum-gradient-norm", type=float, default=10.0)
    parser.add_argument("--hidden-dim", type=int, default=128)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--max-delta-angstrom", type=float, default=8.0)
    parser.add_argument(
        "--geometry-features", choices=("none", "radial_frames_v1", "pair_bias_v1"), default="none"
    )
    parser.add_argument("--pair-distance-loss-weight", type=float, default=0.0)
    parser.add_argument("--confidence-features", choices=("none", "c2_quality_v1"), default="none")
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--amp", choices=("bf16", "none"), default="bf16")
    parser.add_argument("--resume", default="auto")
    parser.add_argument("--maximum-ca-rmsd-ratio", type=float, default=0.95)
    parser.add_argument("--maximum-pair-distance-rmse-ratio", type=float, default=0.95)
    parser.add_argument("--require-pilot-gate", action="store_true")
    args = parser.parse_args()
    positive_values = {
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "validation_every": args.validation_every,
        "bucket_size_multiplier": args.bucket_size_multiplier,
        "maximum_gradient_norm": args.maximum_gradient_norm,
    }
    if any(value <= 0 for value in positive_values.values()) or args.workers < 0:
        parser.error(
            "epochs, batch size, validation cadence, bucket size, and gradient norm "
            "must be positive; workers cannot be negative"
        )
    if args.train_limit < 0 or args.validation_limit < 0:
        parser.error("train and validation limits cannot be negative")
    if not math.isfinite(args.pair_distance_loss_weight) or args.pair_distance_loss_weight < 0:
        parser.error("pair distance loss weight must be finite and nonnegative")

    _seed_everything(args.seed)
    torch.set_float32_matmul_precision("high")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    amp_dtype = torch.bfloat16 if args.amp == "bf16" else None

    all_train = load_teacher_pair_manifest(args.manifest, split="train")
    all_validation = load_teacher_pair_manifest(args.manifest, split="validation")
    train_records = select_length_stratified(all_train, args.train_limit, seed=args.seed)
    validation_records = select_length_stratified(
        all_validation, args.validation_limit, seed=args.seed + 1
    )
    if not train_records or not validation_records:
        raise RuntimeError("both train and validation selections must be non-empty")

    esmc_store = ESMCShardStore(args.esmc_root)
    train_loader, train_sampler = _make_loader(
        train_records,
        args.teacher_root,
        esmc_store,
        batch_size=args.batch_size,
        workers=args.workers,
        seed=args.seed,
        shuffle=True,
        bucket_size_multiplier=args.bucket_size_multiplier,
        device=device,
        confidence_features=args.confidence_features,
    )
    validation_loader, validation_sampler = _make_loader(
        validation_records,
        args.teacher_root,
        esmc_store,
        batch_size=args.batch_size,
        workers=args.workers,
        seed=args.seed,
        shuffle=False,
        bucket_size_multiplier=args.bucket_size_multiplier,
        device=device,
        confidence_features=args.confidence_features,
    )
    validation_sampler.set_epoch(0)

    config = CoordinateRefinerConfig(
        input_dim=int(esmc_store.feature_spec["hidden_dim"]),
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        num_heads=args.num_heads,
        dropout=args.dropout,
        max_length=max(
            1024,
            max(record.sequence_length for record in train_records + validation_records),
        ),
        max_delta_angstrom=args.max_delta_angstrom,
        zero_initialize_output=True,
        geometry_features=args.geometry_features,
        confidence_dim=4 if args.confidence_features == "c2_quality_v1" else 0,
    )
    model = GlobalCoordinateRefiner(config).to(device)
    seeded_initial_model_sha256 = feature_digest(model.state_dict())
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    manifest_sha256 = _sha256(args.manifest)
    esmc_manifest_sha256 = _sha256(args.esmc_root / "manifest.jsonl.gz")
    model_contract = asdict(config)
    if config.geometry_features == "none":
        # Keep pre-geometry baseline checkpoint fingerprints resumable.
        model_contract.pop("geometry_features")
    run_contract = {
        "teacher_manifest_sha256": manifest_sha256,
        "esmc_manifest_sha256": esmc_manifest_sha256,
        "train_group_id_sha256": group_id_digest(train_records),
        "validation_group_id_sha256": group_id_digest(validation_records),
        "model_config": model_contract,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "weight_decay": args.weight_decay,
        "maximum_gradient_norm": args.maximum_gradient_norm,
        "seed": args.seed,
        "amp": args.amp,
    }
    if args.pair_distance_loss_weight > 0:
        run_contract["loss"] = {
            "coordinate_weight": 1.0,
            "pair_distance_weight": args.pair_distance_loss_weight,
            "pair_reduction": "pooled_unordered_per_batch_v1",
        }
    if args.confidence_features != "none":
        run_contract["confidence_features"] = {
            "version": args.confidence_features,
            "names": list(C2_QUALITY_FEATURE_NAMES),
        }
    teacher_protocol_hash = accepted_protocol_hash(args.teacher_root, args.manifest)
    if teacher_protocol_hash is not None:
        run_contract["teacher_protocol_sha256"] = teacher_protocol_hash
    fingerprint = contract_fingerprint(run_contract)
    source_root = Path(__file__).resolve().parents[1]
    source_sha256 = {
        name: _sha256(source_root / name)
        for name in (
            "scripts/train_coordinate_refiner_stage1b.py",
            "src/onestepfold/models/coordinate_refiner.py",
            "src/onestepfold/training/coordinate_refiner.py",
            "src/onestepfold/data/teacher_pair_training.py",
            "src/fastglycan/models/relative_geometry.py",
            "src/fastglycan/models/geometry_losses.py",
            "src/fastglycan/models/pair_attention.py",
            "src/fastglycan/models/confidence_features.py",
            "src/fastglycan/paired_teacher_protocol.py",
            "src/fastglycan/teacher_pairing.py",
        )
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    best_path = args.output_dir / "best.pt"
    last_path = args.output_dir / "last.pt"
    report_path = args.output_dir / "training_report.json"
    resume_path = _resolve_resume(args.resume, args.output_dir)

    start_epoch = 1
    best_epoch = 0
    best_validation: dict[str, Any] | None = None
    history: list[dict[str, Any]] = []
    initialization_provenance = None
    if resume_path is not None:
        checkpoint = torch.load(resume_path, map_location=device, weights_only=False)
        if checkpoint.get("schema_version") != CHECKPOINT_SCHEMA:
            raise RuntimeError(f"unsupported checkpoint schema in {resume_path}")
        if checkpoint.get("contract_fingerprint") != fingerprint:
            raise RuntimeError("resume checkpoint does not match the current run contract")
        model.load_state_dict(checkpoint["model_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        start_epoch = int(checkpoint["epoch"]) + 1
        best_epoch = int(checkpoint["best_epoch"])
        best_validation = checkpoint["best_validation"]
        history = list(checkpoint["history"])
        initialization_provenance = checkpoint.get("initialization_provenance")
        _restore_rng_state(checkpoint["rng_state"])
        print(f"resumed {resume_path} at epoch {start_epoch}", flush=True)
    elif any(path.exists() for path in (best_path, last_path, report_path)):
        raise RuntimeError(
            f"output directory {args.output_dir} already contains training artifacts; "
            "use --resume auto or a new directory"
        )

    process_started = time.monotonic()
    started_at = datetime.now(UTC).isoformat()
    initial_validation = evaluate_coordinate_refiner(
        model, validation_loader, device, amp_dtype=amp_dtype
    )
    print(json.dumps({"epoch": 0, "validation": initial_validation}, sort_keys=True), flush=True)

    def build_report(last_completed_epoch: int, complete: bool) -> dict[str, Any]:
        if best_validation is None:
            ca_ratio = None
            pair_ratio = None
            pilot_pass = False
        else:
            ca_ratio = best_validation["ca_rmsd"] / best_validation["baseline_ca_rmsd"]
            pair_ratio = (
                best_validation["pair_distance_rmse"]
                / best_validation["baseline_pair_distance_rmse"]
            )
            pilot_pass = (
                ca_ratio <= args.maximum_ca_rmsd_ratio
                and pair_ratio <= args.maximum_pair_distance_rmse_ratio
            )
        return {
            "schema_version": REPORT_SCHEMA,
            "complete": complete,
            "pilot_pass": pilot_pass,
            "criteria": {
                "maximum_validation_ca_rmsd_to_c2_ratio": args.maximum_ca_rmsd_ratio,
                "maximum_validation_pair_distance_rmse_to_c2_ratio": (
                    args.maximum_pair_distance_rmse_ratio
                ),
            },
            "last_completed_epoch": last_completed_epoch,
            "requested_epochs": args.epochs,
            "best_epoch": best_epoch,
            "best_validation": best_validation,
            "best_validation_ca_rmsd_to_c2_ratio": ca_ratio,
            "best_validation_pair_distance_rmse_to_c2_ratio": pair_ratio,
            "initial_validation_this_process": initial_validation,
            "seeded_initial_model_sha256": seeded_initial_model_sha256,
            "selection": {
                "policy": "deterministic_length_stratified_v1",
                "seed": args.seed,
                "train": _describe_records(train_records),
                "validation": _describe_records(validation_records),
            },
            "data": {
                "teacher_manifest": str(args.manifest),
                "teacher_manifest_sha256": manifest_sha256,
                "teacher_root": str(args.teacher_root),
                "esmc_root": str(args.esmc_root),
                "esmc_manifest_sha256": esmc_manifest_sha256,
                "target": "c4 CA rigidly Kabsch-aligned into the c2 CA frame",
                "frozen_temporal_test_read": False,
            },
            "run_contract": run_contract,
            "source_sha256": source_sha256,
            "initialization_provenance": initialization_provenance,
            "contract_fingerprint": fingerprint,
            "history": history,
            "runtime": {
                "started_at_utc": started_at,
                "elapsed_seconds_current_process": time.monotonic() - process_started,
                "hostname": socket.gethostname(),
                "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                "git_commit": os.environ.get("ONESTEPFOLD_GIT_COMMIT"),
                "python": platform.python_version(),
                "torch": torch.__version__,
                "device": str(device),
                "device_name": (
                    torch.cuda.get_device_name(device) if device.type == "cuda" else "cpu"
                ),
            },
        }

    last_completed_epoch = start_epoch - 1
    for epoch in range(start_epoch, args.epochs + 1):
        train_sampler.set_epoch(epoch)
        training_metrics = _train_epoch(
            model,
            train_loader,
            optimizer,
            device,
            amp_dtype=amp_dtype,
            maximum_gradient_norm=args.maximum_gradient_norm,
            pair_distance_loss_weight=args.pair_distance_loss_weight,
        )
        validation_metrics = None
        if epoch % args.validation_every == 0 or epoch == args.epochs:
            validation_metrics = evaluate_coordinate_refiner(
                model, validation_loader, device, amp_dtype=amp_dtype
            )
        epoch_record = {
            "epoch": epoch,
            "train": training_metrics,
            "validation": validation_metrics,
        }
        history.append(epoch_record)
        if validation_metrics is not None and (
            best_validation is None
            or validation_metrics["coordinate_mse"] < best_validation["coordinate_mse"]
        ):
            best_epoch = epoch
            best_validation = dict(validation_metrics)
            atomic_torch_save(
                _checkpoint_payload(
                    epoch=epoch,
                    model=model,
                    optimizer=optimizer,
                    run_contract=run_contract,
                    fingerprint=fingerprint,
                    best_epoch=best_epoch,
                    best_validation=best_validation,
                    history=history,
                    initialization_provenance=initialization_provenance,
                ),
                best_path,
            )
        last_completed_epoch = epoch
        atomic_torch_save(
            _checkpoint_payload(
                epoch=epoch,
                model=model,
                optimizer=optimizer,
                run_contract=run_contract,
                fingerprint=fingerprint,
                best_epoch=best_epoch,
                best_validation=best_validation,
                history=history,
                initialization_provenance=initialization_provenance,
            ),
            last_path,
        )
        _write_json_atomic(report_path, build_report(epoch, complete=epoch == args.epochs))
        print(json.dumps(epoch_record, sort_keys=True), flush=True)

    if best_validation is None or not best_path.is_file():
        raise RuntimeError("training completed without a validation-selected checkpoint")
    best_checkpoint = torch.load(best_path, map_location=device, weights_only=False)
    if best_checkpoint.get("contract_fingerprint") != fingerprint:
        raise RuntimeError("best checkpoint contract fingerprint changed unexpectedly")
    model.load_state_dict(best_checkpoint["model_state_dict"])
    per_example: list[dict[str, Any]] = []
    best_revalidation = evaluate_coordinate_refiner(
        model, validation_loader, device, amp_dtype=amp_dtype, per_example=per_example
    )
    examples_path = args.output_dir / "best_validation_examples.json"
    _write_json_atomic(examples_path, {"examples": per_example})
    report = build_report(last_completed_epoch, complete=last_completed_epoch >= args.epochs)
    report["best_checkpoint"] = str(best_path)
    report["best_checkpoint_sha256"] = _sha256(best_path)
    report["best_checkpoint_revalidation"] = best_revalidation
    report["best_validation_examples"] = str(examples_path)
    report["best_validation_examples_sha256"] = _sha256(examples_path)
    _write_json_atomic(report_path, report)
    print(json.dumps({key: value for key, value in report.items() if key != "history"}, indent=2))
    if args.require_pilot_gate and not report["pilot_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
