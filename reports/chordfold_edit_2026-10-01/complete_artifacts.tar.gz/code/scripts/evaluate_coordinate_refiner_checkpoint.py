#!/usr/bin/env python3
"""Re-evaluate a frozen validation-selected refiner and emit per-protein errors."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from train_coordinate_refiner_stage1b import _sha256

from onestepfold.data.teacher_pair_training import (
    CoordinateRefinerDataset,
    ESMCShardStore,
    LengthAwareCollator,
    LengthBucketBatchSampler,
)
from onestepfold.data.teacher_pairs import load_teacher_pair_manifest
from onestepfold.models import CoordinateRefinerConfig, GlobalCoordinateRefiner
from onestepfold.training.coordinate_refiner import (
    evaluate_coordinate_refiner,
    group_id_digest,
    select_length_stratified,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--teacher-root", type=Path, required=True)
    parser.add_argument("--esmc-root", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--validation-limit", type=int, default=0)
    args = parser.parse_args()
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    contract = checkpoint["run_contract"]
    manifest = args.teacher_root / "control/teacher_pair_manifest_v1.jsonl.gz"
    assert _sha256(manifest) == contract["teacher_manifest_sha256"]
    assert _sha256(args.esmc_root / "manifest.jsonl.gz") == contract["esmc_manifest_sha256"]
    records = select_length_stratified(
        load_teacher_pair_manifest(manifest, split="validation"),
        args.validation_limit,
        seed=contract["seed"] + 1,
    )
    assert group_id_digest(records) == contract["validation_group_id_sha256"]
    dataset = CoordinateRefinerDataset(
        records,
        args.teacher_root,
        ESMCShardStore(args.esmc_root),
        confidence_features=contract.get("confidence_features", {}).get("version", "none"),
    )
    sampler = LengthBucketBatchSampler(
        [r.sequence_length for r in records],
        contract["batch_size"],
        shuffle=False,
        seed=contract["seed"],
    )
    loader = DataLoader(
        dataset,
        batch_sampler=sampler,
        collate_fn=LengthAwareCollator(8),
        num_workers=8,
        pin_memory=True,
    )
    model = GlobalCoordinateRefiner(CoordinateRefinerConfig(**checkpoint["model_config"])).cuda()
    model.load_state_dict(checkpoint["model_state_dict"])
    torch.set_float32_matmul_precision("high")
    examples = []
    metrics = evaluate_coordinate_refiner(
        model,
        loader,
        torch.device("cuda"),
        amp_dtype=torch.bfloat16 if contract["amp"] == "bf16" else None,
        per_example=examples,
    )
    for key, value in checkpoint["best_validation"].items():
        if abs(metrics[key] - value) > 1e-4:
            raise RuntimeError(f"checkpoint revalidation differs: {key} {metrics[key]} vs {value}")
    payload = {
        "checkpoint": str(args.checkpoint),
        "checkpoint_sha256": _sha256(args.checkpoint),
        "metrics": metrics,
        "examples": examples,
        "revalidated": True,
        "frozen_temporal_test_read": False,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({k: v for k, v in payload.items() if k != "examples"}), flush=True)


if __name__ == "__main__":
    main()
