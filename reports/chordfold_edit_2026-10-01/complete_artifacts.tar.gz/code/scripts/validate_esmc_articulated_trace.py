#!/usr/bin/env python3
"""Validate archived coordinate and parameter gradient moments independently."""

import argparse
import json
from pathlib import Path

import numpy as np

from fastglycan.paired_teacher_protocol import sha256, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu", type=Path, required=True)
    parser.add_argument("--gpu", type=Path, required=True)
    args = parser.parse_args()
    assert not (args.gpu / "independent_validation.json").exists()
    cpu = json.loads((args.cpu / "report.json").read_text())
    gpu = json.loads((args.gpu / "report.json").read_text())
    assert (
        cpu["complete"] and gpu["complete"] and len(cpu["cases"]) == 128 and len(gpu["cases"]) == 2
    )
    assert (
        cpu["training_report_sha256"]
        == gpu["training_report_sha256"]
        == "57c9863836acf674202d7e4100299a1c11c5cca07fb83964d0ebf797c3b86379"
    )
    sources = {}
    for root in (args.cpu, args.gpu):
        folder = root / "source/execution"
        manifest = json.loads((folder / "source_manifest.json").read_text())
        for name, digest in manifest.items():
            assert sha256(folder / name) == digest
        sources[root.name] = sha256(folder / "source_manifest.json")

    def check_statistics(values, summary):
        flat = values.reshape(len(values), -1).astype(np.float64)
        norms = np.linalg.norm(flat, axis=1)
        expected_gram = np.array([[np.dot(a, b) for b in flat] for a in flat])
        np.testing.assert_allclose(expected_gram, summary["gram"], rtol=1e-10, atol=1e-10)
        np.testing.assert_allclose(norms, summary["norms"], rtol=1e-10, atol=1e-10)
        np.testing.assert_allclose(
            -expected_gram.sum(1),
            summary["derivative_along_negative_total"],
            rtol=1e-10,
            atol=1e-10,
        )
        assert np.isclose(np.linalg.norm(flat.sum(0)), summary["total_norm"], rtol=1e-10)

    max_addition, max_fd = 0.0, 0.0
    for row in cpu["cases"]:
        path = args.cpu / row["artifact"]
        assert sha256(path) == row["artifact_sha256"]
        with np.load(path) as data:
            assert all(np.isfinite(data[k]).all() for k in data.files)
            for space, key in (
                ("output", "output_gradient"),
                ("raw", "raw_gradient"),
                ("retracted", "retracted_gradient"),
            ):
                check_statistics(data[key], row[space])
            for i, key in enumerate(cpu["branches"]):
                check_statistics(data["branch_gradient"][i], row["branches"][key])
            error = np.linalg.norm(
                data["branch_gradient"].sum(0) - data["raw_gradient"]
            ) / np.linalg.norm(data["raw_gradient"])
            assert error <= 1e-8
            max_addition = max(max_addition, float(error))
        for fd in row["qa"]["finite_differences"]:
            error = abs(fd["numerical"] - fd["analytic"]) / max(abs(fd["analytic"]), 1e-8)
            assert error <= 1e-4 and np.isclose(error, fd["relative_error"], atol=1e-15)
            max_fd = max(max_fd, error)
    comparisons = []
    for case in gpu["cases"]:
        for name, digest in case["artifact_sha256"].items():
            assert sha256(args.gpu / name) == digest
        group = case["group_id"]
        reference = next(
            x
            for x in cpu["cases"]
            if x["state"] == "best" and x["seed"] == "12345" and x["group_id"] == group
        )
        np.testing.assert_allclose(case["losses"], reference["losses"], rtol=1e-4, atol=0.002)
        errors = {}
        with (
            np.load(args.gpu / f"gradients_{group}.npz") as data,
            np.load(args.cpu / reference["artifact"]) as independent,
        ):
            for key in ("output_gradient", "raw_gradient"):
                actual, expected = data[key][:4].astype(np.float64), independent[key]
                relative = np.linalg.norm(
                    (actual - expected).reshape(4, -1), axis=1
                ) / np.linalg.norm(expected.reshape(4, -1), axis=1)
                assert relative.max() <= 1e-3
                errors[key] = relative.tolist()
                check_statistics(
                    data[key][:4], case["output" if key == "output_gradient" else "raw"]
                )
        moments = json.loads((args.gpu / f"parameter_moments_{group}.json").read_text())
        assert sum(r["numel"] for r in moments) == 121673521
        total = np.zeros((5, 5))
        difference = 0.0
        for r in moments:
            g = np.asarray(r["gram"])
            assert np.isfinite(g).all() and np.all(np.diag(g) >= 0)
            np.testing.assert_allclose(g, g.T, atol=1e-10)
            assert np.all(g * g <= np.diag(g)[:, None] * np.diag(g)[None, :] * (1 + 1e-9) + 1e-10)
            reconstructed = g[4, 4] + g[:4, :4].sum() - 2 * g[4, :4].sum()
            assert abs(reconstructed - r["combined_difference_sq"]) <= 1e-8 * max(g[4, 4], 1)
            total += g
            difference += r["combined_difference_sq"]
        np.testing.assert_allclose(total, case["total_parameter_gram"], rtol=1e-10, atol=1e-10)
        error = float(np.sqrt(difference / total[4, 4]))
        assert error <= 0.02 and np.isclose(error, case["parameter_sum_relative_error"])
        assert (
            case["exact_saved_and_train_eval_replay"] and case["weights_inputs_adapter_unchanged"]
        )
        assert case["forward_counts"] == {"trunk": 1, "structure": 1, "confidence": 0}
        comparisons.append(
            {
                "group_id": group,
                "length": case["length"],
                "coordinate_gradient_errors": errors,
                "parameter_sum_relative_error": error,
            }
        )
    result = {
        "complete": True,
        "cpu_report_sha256": sha256(args.cpu / "report.json"),
        "gpu_report_sha256": sha256(args.gpu / "report.json"),
        "source_manifests": sources,
        "max_branch_additivity_relative_error": max_addition,
        "max_finite_difference_relative_error": max_fd,
        "gpu_cpu_comparisons": comparisons,
        "scope": "artifact/moment/independent CPU derivative QA; no rerun",
    }
    write_json(args.gpu / "independent_validation.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
