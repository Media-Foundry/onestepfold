#!/usr/bin/env python3
"""Attribute an accepted run's selected local-frame loss on CPU only."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import torch
from audit_frame_supervision_cpu import numpy_frame_loss

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.frame_attribution import frame_coordinate_attribution, frame_partitions
from fastglycan.frame_supervision import build_frame_labels, local_frame_mse
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest
from fastglycan.weighted_frame_attribution import weighted_geometry_attribution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    root = args.root
    contract = json.loads((root / "contract.json").read_text())
    report = json.loads((root / "report.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"] and qa["heavy_artifacts_checked"]
    assert qa["report_sha256"] == sha256(root / "report.json")
    assert report["contract_sha256"] == sha256(root / "contract.json")
    torch.set_num_threads(1)
    source = Path(__file__).resolve().parents[1]
    for name in ("src/fastglycan/frame_supervision.py", "src/fastglycan/experimental_training.py"):
        assert sha256(source / name) == contract["source_sha256"][name]
    rows, max_numpy_error, max_weighted_gradient_error = [], 0.0, 0.0
    global_weight = contract["frame_weight"]
    same_weight = contract.get("same_residue_weight", 0.0)
    if contract.get("distance_weight", 0.0):
        raise ValueError(
            "this attribution omits the distance term; use diagnose_esmc_distance_balance.py "
            "for the recorded distance-supervised objective"
        )
    for index, (record, provenance, frame_info) in enumerate(
        zip(
            contract["selection"],
            contract["input_provenance"],
            contract["frame_provenance"],
            strict=True,
        )
    ):
        group = record["group_id"]
        assert group == provenance["group_id"] == frame_info["group_id"]
        folder = root / group
        for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
            assert sha256(folder / name) == provenance[key]
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
            inventory = dict(saved)
        labels = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            record["sequence"],
            record["sample_id"],
            inventory,
        )
        assert sha256(folder / "supervision.pt") == frame_info["file_sha256"]
        supervision = torch.load(folder / "supervision.pt", map_location="cpu", weights_only=True)
        assert feature_digest(supervision) == frame_info["sha256"]
        assert feature_digest(build_frame_labels(labels, inventory)) == frame_info["sha256"]
        parts = frame_partitions(supervision, inventory["residue_id"])
        for seed in ("12345", "54321"):
            original = report["best"]["conditions"][seed]["examples"][index]
            assert original["group_id"] == group
            path = folder / f"best_{seed}.npz"
            assert sha256(path) == original["prediction_sha256"]
            with np.load(path, allow_pickle=False) as saved:
                assert all(np.array_equal(saved[k], v) for k, v in inventory.items())
                xyz = saved["coordinate"].astype(np.float64)
            result, gradients = frame_coordinate_attribution(
                xyz, supervision, inventory["residue_id"]
            )
            assert np.isclose(
                result["total_mse"], original["local_frame_mse"], rtol=1e-4, atol=1e-3
            )
            result.update(group_id=group, seed=seed, prediction_sha256=sha256(path))
            weighted, weighted_gradient = weighted_geometry_attribution(
                result, gradients, global_weight=global_weight, same_residue_weight=same_weight
            )
            x = torch.tensor(xyz, dtype=torch.float64, requires_grad=True)
            geometry = global_weight * local_frame_mse(
                x, supervision
            ) + same_weight * local_frame_mse(x, parts["same_residue"])
            (direct_gradient,) = torch.autograd.grad(geometry, x)
            error = float((weighted_gradient - direct_gradient).norm())
            assert error <= 1e-10 * max(1.0, float(direct_gradient.norm()))
            relative = error / max(1e-12, float(direct_gradient.norm()))
            max_weighted_gradient_error = max(max_weighted_gradient_error, relative)
            assert np.isclose(
                weighted["geometry_loss"], float(geometry.detach()), rtol=1e-12, atol=1e-9
            )
            weighted["direct_backward_relative_error"] = relative
            result["weighted_geometry"] = weighted
            if same_weight:
                assert np.isclose(
                    result["parts"]["same_residue"]["mean_mse"],
                    original["same_residue_frame_mse"],
                    rtol=1e-4,
                    atol=1e-3,
                )
            for name, subset in parts.items():
                part = result["parts"][name]
                if not part["pair_count"]:
                    continue
                independent = numpy_frame_loss(xyz, subset)
                error = abs(independent - part["mean_mse"])
                max_numpy_error = max(max_numpy_error, error)
                assert error < 1e-8
                part["numpy_mean_mse"] = independent
                assert gradients[name][~labels["coordinate_mask"]].count_nonzero() == 0
                if index == 0 and seed == "12345":
                    gradient = gradients[name]
                    direction = gradient / gradient.norm()
                    x = torch.from_numpy(xyz)
                    epsilon = 1e-6
                    numerical = float(
                        part["pair_fraction"]
                        * (
                            local_frame_mse(x + epsilon * direction, subset)
                            - local_frame_mse(x - epsilon * direction, subset)
                        )
                        / (2 * epsilon)
                    )
                    analytic = float((gradient * direction).sum())
                    relative = abs(numerical - analytic) / max(abs(analytic), 1e-12)
                    assert relative < 1e-4
                    part["finite_difference"] = {
                        "step_l2_angstrom": epsilon,
                        "numerical": numerical,
                        "analytic": analytic,
                        "relative_error": relative,
                    }
            rows.append(result)
    summaries = {}
    for seed in ("12345", "54321"):
        selected = [r for r in rows if r["seed"] == seed]
        macro_total = float(np.mean([r["total_mse"] for r in selected]))
        parts_summary = {}
        for name in ("same_residue", "cross_residue"):
            parts_summary[name] = {
                "pairs": sum(r["parts"][name]["pair_count"] for r in selected),
                "macro_pair_fraction": float(
                    np.mean([r["parts"][name]["pair_fraction"] for r in selected])
                ),
                "macro_mse_contribution": float(
                    np.mean([r["parts"][name]["contribution_mse"] for r in selected])
                ),
                "median_coordinate_gradient_norm": float(
                    np.median([r["parts"][name]["coordinate_gradient_norm"] for r in selected])
                ),
            }
        ratios = [
            r["parts"]["same_residue"]["coordinate_gradient_norm"]
            / r["parts"]["cross_residue"]["coordinate_gradient_norm"]
            for r in selected
        ]
        summaries[seed] = {
            "macro_total_mse": macro_total,
            "parts": parts_summary,
            "median_same_to_cross_coordinate_gradient_norm": float(np.median(ratios)),
            "min_same_to_cross_coordinate_gradient_norm": min(ratios),
            "max_same_to_cross_coordinate_gradient_norm": max(ratios),
            "median_partition_gradient_cosine": float(
                np.median([r["partition_gradient_cosine"] for r in selected])
            ),
            "frames_at_or_below_floor": sum(
                v["at_or_below_floor"]
                for r in selected
                for v in r["predicted_frame_lengths"].values()
            ),
            "minimum_C_CA": min(r["predicted_frame_lengths"]["C_CA"]["minimum"] for r in selected),
            "minimum_projected_N_CA": min(
                r["predicted_frame_lengths"]["projected_N_CA"]["minimum"] for r in selected
            ),
        }
        weighted = [r["weighted_geometry"] for r in selected]
        means = {
            key: float(np.mean([r[key] for r in weighted]))
            for key in ("geometry_loss", "same_residue_contribution", "cross_residue_contribution")
        }
        summaries[seed]["weighted_geometry"] = {
            **{"macro_" + key: value for key, value in means.items()},
            "same_residue_fraction_of_macro_geometry_loss": means["same_residue_contribution"]
            / means["geometry_loss"],
            "median_same_to_cross_coordinate_gradient_norm": float(
                np.median([r["same_to_cross_coordinate_gradient_norm"] for r in weighted])
            ),
        }
    names = (
        "scripts/diagnose_esmc_frame_attribution.py",
        "scripts/audit_frame_supervision_cpu.py",
        "src/fastglycan/frame_attribution.py",
        "src/fastglycan/weighted_frame_attribution.py",
        "tests/test_weighted_frame_attribution.py",
        "src/fastglycan/frame_supervision.py",
        "docs/esmc_frame_attribution_v1.md",
        "tests/test_frame_attribution.py",
    )
    output = {
        "complete": True,
        "frame_weight": global_weight,
        "same_residue_weight": same_weight,
        "max_weighted_geometry_gradient_relative_error": max_weighted_gradient_error,
        "best_epoch": report["best_epoch"],
        "report_sha256": sha256(root / "report.json"),
        "contract_sha256": sha256(root / "contract.json"),
        "max_numpy_mean_mse_error": max_numpy_error,
        "examples": rows,
        "summaries": summaries,
        "source_sha256": {n: sha256(source / n) for n in names},
        "scope": (
            "CPU saved-coordinate attribution; no model forward/update or parameter-gradient claim"
        ),
    }
    write_json(args.output, output)
    archive = args.output.with_suffix("") / "source"
    for name in names:
        destination = archive / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, destination)
    lines = [
        "# Existing frame-loss attribution",
        "",
        f"Accepted global-frame weight {global_weight:g}, same-residue weight {same_weight:g}, "
        f"selected epoch {report['best_epoch']}; "
        "32 TRAIN proteins, CPU FP64, no model forward or update.",
        "",
        "| Metric | Seed 12345 | Seed 54321 |",
        "| --- | ---: | ---: |",
    ]
    for name in (
        "macro_total_mse",
        "median_same_to_cross_coordinate_gradient_norm",
        "median_partition_gradient_cosine",
        "frames_at_or_below_floor",
        "minimum_C_CA",
        "minimum_projected_N_CA",
    ):
        lines.append(
            f"| {name} | {summaries['12345'][name]:.8g} | {summaries['54321'][name]:.8g} |"
        )
    for name in ("same_residue", "cross_residue"):
        for metric in ("macro_pair_fraction", "macro_mse_contribution"):
            lines.append(
                f"| {name}: {metric} | {summaries['12345']['parts'][name][metric]:.8g} | "
                f"{summaries['54321']['parts'][name][metric]:.8g} |"
            )
    lines += [
        "",
        "The original global-frame partition above uses its total-pair denominator. "
        "The table below attributes the recorded geometry objective (aligned atom loss excluded).",
        "",
        "| Recorded geometry objective | Seed 12345 | Seed 54321 |",
        "| --- | ---: | ---: |",
    ]
    for key in summaries["12345"]["weighted_geometry"]:
        lines.append(
            f"| {key} | {summaries['12345']['weighted_geometry'][key]:.8g} | "
            f"{summaries['54321']['weighted_geometry'][key]:.8g} |"
        )
    lines += [
        "",
        f"Weighted coordinate-gradient sum agrees with direct FP64 backward to maximum "
        f"relative L2 error {max_weighted_gradient_error:.3g}. These are recorded weights, "
        "not a coefficient sweep or a new training experiment.",
    ]
    lines += [
        "",
        f"Independent NumPy maximum scalar difference {max_numpy_error:.3g} Å²; "
        "partition scalar/gradient conservation, missing-atom exclusion and shortest-protein "
        "directional finite differences pass.",
        "",
        "The weighted table includes the extra same-residue denominator where recorded. "
        "Cross-residue terms "
        "also act on local frame anchors, so this partition does not isolate chemistry from "
        "folding causally. Coordinate-gradient ratios do not establish parameter-gradient "
        "balance or optimizer steps. This diagnostic selects no new coefficient or checkpoint.",
    ]
    args.output.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(
        json.dumps(
            {k: v for k, v in output.items() if k not in ("examples", "source_sha256")}, indent=2
        )
    )


if __name__ == "__main__":
    main()
