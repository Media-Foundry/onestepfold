#!/usr/bin/env python3
"""Independent stdlib checks of budget provenance, target pairing and report scalars."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_close(x, y):
    assert abs(x - y) < 1e-12, (x, y)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--result", type=Path, required=True)
    a = p.parse_args()
    path = a.result / "analysis.json"
    r = json.loads(path.read_text())
    assert r["complete"]
    for name, expected in r["inputs_sha256"].items():
        assert digest(Path(name)) == expected, name
    groups = r["targets"]
    assert len(groups) == len(set(groups)) == 128
    strata = r["fixed_2048_strata"]
    covered = [g for gs in strata.values() for g in gs]
    assert len(covered) == len(groups) and set(covered) == set(groups)
    histories = {}
    for name in r["inputs_sha256"]:
        p = Path(name)
        if p.name == "history.json":
            label = p.parent.name.removeprefix("esmc_scaling_").removesuffix("_v1_20260919")
            histories[label] = json.loads(p.read_text())
    checked = 0
    for label, run in r["runs"].items():
        for budget, item in run["budgets"].items():
            kind, amount = budget.split("_");amount = int(amount)
            matches = [h for h in histories[label] if
                       h["step"] == amount] if kind == "updates" else [
                           h for h in histories[label] if amount in h.get("budget_crossings", [])]
            assert len(matches) <= 1
            assert (item is None) == (not matches)
            if item is None:
                continue
            h = matches[0];assert item["step"] == h["step"]
            for key, value in item["compute"].items():
                assert value == h[key]
            values = item["per_target"]
            for metric in ("all_atom_lddt", "tm_score_ca_observed"):
                for g in groups:
                    pair = [x for x in h["validation"]["rows"] if x["group_id"] == g]
                    assert len(pair) == 2 and {x['noise'] for x in pair} == {12345, 54321}
                    check_close(values[g][metric], math.fsum(x["quality"][metric] for x in pair) / 2)
                for gs, summary in [(groups, item["summary"])] + [
                    (strata[name], s) for name, s in item["strata"].items()]:
                    x = sorted(values[g][metric] for g in gs)
                    tail = x[:math.ceil(len(x) * .05)]
                    check_close(summary[metric]["mean"], math.fsum(x) / len(x))
                    check_close(summary[metric]["worst5_mean"], math.fsum(tail) / len(tail))
                    pos = (len(x) - 1) * .05;lo = int(pos);hi = math.ceil(pos)
                    check_close(summary[metric]["p05"], x[lo] + (x[hi] - x[lo]) * (pos - lo))
            checked += 1
    paired = 0
    for name, budgets in r["budget_comparisons"].items():
        candidate, reference = name.split("_minus_")
        for budget, result in budgets.items():
            x, y = (r["runs"][label]["budgets"][budget] for label in (candidate, reference))
            assert (result is None) == (x is None or y is None)
            if result is None:
                continue
            for subset, gs in [(result["all"], groups)] + [(s, strata[name]) for name, s in result["strata"].items()]:
                assert subset["targets"] == len(gs)
                harms = set()
                for metric, m in subset["metrics"].items():
                    assert set(m["per_target_delta"]) == set(gs)
                    delta = {g: x["per_target"][g][metric] - y["per_target"][g][metric] for g in gs}
                    for g, v in delta.items():check_close(m["per_target_delta"][g], v)
                    check_close(m["statistics"]["mean"]["delta"], math.fsum(delta.values()) / len(gs))
                    bad = {g for g,v in delta.items() if v < -.05}
                    assert m["loss_gt_005_count"] == len(bad)
                    harms.update(bad)
                assert subset["joint_loss_gt_005_count"] == len(harms)
            paired += 1
    output = {"complete": True, "analysis_sha256": digest(path), "validator_sha256": digest(Path(__file__)),
              "run_budget_views_checked": checked, "paired_budget_comparisons_checked": paired,
              "scope": "Independent stdlib budget, pairing, scalar and harm checks; bootstrap routine covered by focused tests, not independently recomputed here"}
    (a.result / "validation.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
