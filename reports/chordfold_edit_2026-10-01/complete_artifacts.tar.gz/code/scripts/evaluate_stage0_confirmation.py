#!/usr/bin/env python3
"""CPU-only, label-isolated scoring of every locked K=1 prediction."""

from __future__ import annotations

import argparse
import concurrent.futures
import gzip
import json
import tarfile
import time
from pathlib import Path

import numpy as np
from evaluate_stage0 import evaluate_row

from fastglycan.paired_teacher_protocol import sha256, write_json

METRICS = ("tm_score_ca", "all_atom_lddt")


def evaluate_worker(spec):
    root, phase_name, worker, rows = spec
    root = Path(root)
    phase = root / phase_name
    output = phase / f"worker_{worker}"
    progress_path = output / "progress.json"
    completed = json.loads((output / "completed.json").read_text())
    assert completed["complete"] and completed["progress_sha256"] == sha256(progress_path)
    progress = json.loads(progress_path.read_text())
    assert progress["complete"]
    archives: dict[str, tarfile.TarFile] = {}
    records = []
    start = time.perf_counter()
    try:
        for index, trace in enumerate(progress["records"]):
            artifact = output / trace["artifact"]["cif"]
            assert sha256(artifact) == trace["artifact"]["sha256"]
            row = dict(rows[trace["group_id"]])
            # Relocation only: exact tar member and observed labels remain unchanged.
            row["shard"] = row["shard"].replace(
                "/hpc2hdd/home/shuang886/Folding/", "/data/user/shuang886/Folding/", 1
            )
            score = evaluate_row(row, output, trace["setting"], archives, seed=trace["seed"])
            # Do not silently drop prediction/scoring failures or lower the denominator.
            if score["status"] != "ok":
                raise ValueError(
                    f"Incomplete scoring; requires explicit failure accounting: {score}"
                )
            assert all(np.isfinite(score[m]) for m in METRICS)
            score.update(
                {
                    "setting": trace["setting"],
                    "seed": trace["seed"],
                    "model_forward_seconds": trace["model_forward_seconds"],
                    "stages_seconds": trace["stages_seconds"],
                    "peak_allocated_bytes": trace["peak_allocated_bytes"],
                    "feature_sha256": trace["feature_sha256"],
                    "prediction_sha256": trace["artifact"]["sha256"],
                }
            )
            records.append(score)
            if (index + 1) % 24 == 0:
                print(f"scored worker{worker} {index + 1}/{len(progress['records'])}", flush=True)
    finally:
        for archive in archives.values():
            archive.close()
    result = {
        "complete": True,
        "worker": worker,
        "seed": progress["seed"],
        "records": records,
        "elapsed_seconds": time.perf_counter() - start,
        "progress_sha256": sha256(progress_path),
    }
    write_json(output / "scores.json", result)
    return {
        "worker": worker,
        "count": len(records),
        "scores_sha256": sha256(output / "scores.json"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--phase", choices=("repeat", "confirm"), required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    with gzip.open(root / "control" / f"{args.phase}_manifest.jsonl.gz", "rt") as handle:
        rows = {r["group_id"]: r for r in map(json.loads, handle)}
    specs = [(str(root), args.phase, worker, rows) for worker in range(16)]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        workers = list(pool.map(evaluate_worker, specs))
    count = sum(w["count"] for w in workers)
    assert count == (1536 if args.phase == "repeat" else 768)
    write_json(
        root / args.phase / "scoring_complete.json",
        {"complete": True, "phase": args.phase, "count": count, "workers": workers},
    )
    print(f"All {count} predictions scored", flush=True)


if __name__ == "__main__":
    main()
