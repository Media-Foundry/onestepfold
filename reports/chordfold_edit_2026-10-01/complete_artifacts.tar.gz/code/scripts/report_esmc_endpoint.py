#!/usr/bin/env python3
"""Summarize paired continuation quality and tails only after independent QA."""
import argparse
import json
from pathlib import Path
import numpy as np
from fastglycan.paired_teacher_protocol import sha256, write_json

METRICS = ('all_atom_lddt', 'tm_score_ca_observed')


def vector(rows, metric, groups):
    values = {g: [] for g in groups}
    for r in rows:
        values[r['group_id']].append(r['quality'][metric])
    assert all(len(v) == 2 for v in values.values())
    result = np.array([np.mean(values[g]) for g in groups])
    assert np.isfinite(result).all()
    return result


def summary(x):
    return {'mean': float(x.mean()), 'p05': float(np.quantile(x, .05)),
            'worst_5pct_mean': float(np.sort(x)[:max(1, int(np.ceil(.05 * len(x))))].mean())}


def paired(x, y):
    delta = x - y
    rng = np.random.default_rng(20260922)
    means = delta[rng.integers(len(x), size=(5000, len(x)))].mean(axis=1)
    return summary(delta) | {'ci95': np.quantile(means, [.025, .975]).tolist(),
                            'degradation_gt_005': float(np.mean(delta < -.05)),
                            'per_target_delta': delta.tolist()}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root
    labels = ('gt_only', 'endpoint')
    accepted, problems = {}, {}
    for label in labels:
        folder = root / label
        if not (folder / 'independent_validation.json').exists():
            problems[label] = 'Independent QA absent; do not claim accepted final result'
            continue
        qa = json.loads((folder / 'independent_validation.json').read_text())
        assert qa['complete'] and qa['report_sha256'] == sha256(folder / 'report.json')
        accepted[label] = json.loads((folder / 'report.json').read_text())
    if problems:
        write_json(root / 'comparison.json', {'complete': False, 'problems': problems})
        (root / 'report.md').write_text('# Endpoint pilot\n\nFinal comparison unavailable: ' + str(problems) + '\n')
        return
    contracts = {k: json.loads((root / k / 'contract.json').read_text()) for k in labels}
    assert contracts['gt_only']['initial_weights_sha256'] == contracts['endpoint']['initial_weights_sha256']
    assert contracts['gt_only']['parent_checkpoint_sha256'] == contracts['endpoint']['parent_checkpoint_sha256']
    assert contracts['gt_only']['validation'] == contracts['endpoint']['validation']
    assert contracts['gt_only']['train'] == contracts['endpoint']['train']
    groups = sorted(r['group_id'] for r in contracts['gt_only']['validation'])
    assert len(groups) == 128
    history = {k: {h['step']: h for h in json.loads((root / k / 'history.json').read_text())} for k in labels}
    common = sorted(set(history['gt_only']).intersection(history['endpoint']))
    compared = {}
    for step in common:
        compared[str(step)] = {m: paired(
            vector(history['endpoint'][step]['validation']['rows'], m, groups),
            vector(history['gt_only'][step]['validation']['rows'], m, groups)) for m in METRICS}
    teacher = json.loads((root / 'teacher_quality.json').read_text())
    refs = {setting: {m: np.array([next(r['quality'][m] for r in teacher if
                 r['group_id'] == g and r['setting'] == setting) for g in groups]) for m in METRICS}
            for setting in ('c1_s1', 'c4_s2')}
    result = {'complete': True, 'targets': groups, 'common_update_comparisons': compared,
              'parent_checkpoint_sha256': contracts['endpoint']['parent_checkpoint_sha256'],
              'arms': {}, 'teacher_reference': {s: {m: summary(x) for m, x in q.items()} for s, q in refs.items()},
              'scope': 'development continuation; two noise evaluations per target, no best-of-K; cached ESMC cost excluded'}
    lines = ['# ESMC 一步终点蒸馏 pilot', '', '两个学生均通过独立产物验收。两噪声先按目标平均；不是两个训练seeds或best-of-K。', '',
             '| 相同新增更新数 | ΔlDDT endpoint−GT [95% CI] | ΔTM-align [95% CI] |', '|---:|---:|---:|']
    for step in common:
        items = []
        for m in METRICS:
            v = compared[str(step)][m]
            items.append(f"{v['mean']:+.4f} [{v['ci95'][0]:+.4f}, {v['ci95'][1]:+.4f}]")
        lines.append(f'| {step} | ' + ' | '.join(items) + ' |')
    lines += ['', '## 最后与开发集最佳checkpoint', '', '| 学生 | checkpoint | mean lDDT | worst5% lDDT | mean TM | 对c4_s2任一质量退化>0.05 |', '|---|---|---:|---:|---:|---:|']
    for label in labels:
        r = accepted[label]
        arm = {'steps': r['steps'], 'best_step': r['best_step'], 'gpu_worker_seconds': r['elapsed_seconds'], 'views': {}}
        for view in ('initial_validation', 'last_validation', 'best_validation'):
            values = {m: vector(r[view]['rows'], m, groups) for m in METRICS}
            q = {m: summary(x) for m, x in values.items()}
            q['vs_teacher'] = {s: {m: paired(values[m], refs[s][m]) for m in METRICS} for s in refs}
            q['joint_tail_vs_c4_s2'] = float(np.mean(np.logical_or.reduce([values[m] - refs['c4_s2'][m] < -.05 for m in METRICS])))
            q['geometry_per_target_noise'] = [{k: row[k] for k in ('group_id', 'noise', 'geometry')} for row in r[view]['rows']]
            q['core_seconds_mean'] = float(np.mean([row['core_seconds'] for row in r[view]['rows']]))
            arm['views'][view] = q
            lines.append(f"| {label} | {view} | {q['all_atom_lddt']['mean']:.4f} | {q['all_atom_lddt']['worst_5pct_mean']:.4f} | {q['tm_score_ca_observed']['mean']:.4f} | {q['joint_tail_vs_c4_s2']:.2%} |")
        result['arms'][label] = arm
    lines += ['', '训练/验证划分来自已有pre-cutoff开发集，近同源限制不变。当前数据不能证明新折叠泛化。',
              '完整逐目标差值、化学几何、相同预算曲线及teacher参照见comparison.json。固定预算结束不是收敛证明；验收通过不是科学收益成立。',
              'warm core不含ESMC计算，不能据此声称已完成端到端加速验收。']
    write_json(root / 'comparison.json', result)
    (root / 'report.md').write_text('\n'.join(lines) + '\n')
    print('Accepted paired report written', flush=True)


if __name__ == '__main__':
    main()
