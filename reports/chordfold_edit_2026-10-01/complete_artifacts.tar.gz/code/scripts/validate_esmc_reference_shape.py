#!/usr/bin/env python3
"""Independent saved-reference proper-fit QA and report; no heavy input reload."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import matplotlib
import numpy as np
from validate_esmc_capacity import rmsd

from fastglycan.paired_teacher_protocol import sha256, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--training-root", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    assert not (root / "independent_validation.json").exists()
    report = json.loads((root / "report.json").read_text())
    contract = json.loads((args.training_root / "contract.json").read_text())
    train_qa = json.loads((args.training_root / "independent_validation.json").read_text())
    assert report["complete"] and train_qa["complete"]
    assert (
        sha256(args.training_root / "report.json")
        == report["training_report_sha256"]
        == train_qa["report_sha256"]
    )
    assert report["runtime"]["cuda_visible_devices"] == ""
    for name, digest in report["source_sha256"].items():
        assert sha256(root / "source/execution" / name) == digest
    assert len(report["cases"]) == len(contract["input_provenance"]) == 32
    maximum_error = 0.0
    atom_total, sse_total = 0, 0.0
    for row, provenance in zip(report["cases"], contract["input_provenance"], strict=True):
        assert row["provenance"] == provenance and row["group_id"] == provenance["group_id"]
        path = root / f"{row['group_id']}.npz"
        assert sha256(path) == row["artifact_sha256"]
        with np.load(path, allow_pickle=False) as saved:
            data = dict(saved)
        mask, refmask = data["observed"], data["reference_mask"]
        assert mask.dtype == refmask.dtype == np.bool_ and np.all(refmask[mask])
        assert np.array_equal(data["fitted_observed_indices"], np.flatnonzero(mask))
        assert len(data["fitted_observed_coordinate"]) == int(mask.sum()) == row["observed_atoms"]
        residues = data["residue_id"][mask]
        a, b = data["reference"][mask], data["target"][mask]
        fitted = data["fitted_observed_coordinate"]
        with np.load(
            args.training_root / row["group_id"] / "inventory.npz", allow_pickle=False
        ) as inventory:
            assert all(np.array_equal(data[k], inventory[k]) for k in inventory.files)
        group_sse = 0.0
        for residue in row["residues"]:
            keep = residues == residue["residue_id"]
            n = int(keep.sum())
            assert n == residue["observed_atoms"]
            measured = rmsd(a[keep], b[keep])
            actual = float(np.sqrt(np.mean(np.sum((fitted[keep] - b[keep]) ** 2, axis=1))))
            error = max(abs(measured - residue["rmsd"]), abs(measured - actual))
            assert error <= 2e-6
            maximum_error = max(maximum_error, error)
            group_sse += n * measured**2
        assert np.isclose(group_sse, row["sse"], rtol=1e-5, atol=1e-5)
        atom_total += int(mask.sum())
        sse_total += group_sse
    pooled = float(np.sqrt(sse_total / atom_total))
    assert np.isclose(pooled, report["summary"]["pooled_rigid_residue_floor"], rtol=1e-6)
    assert atom_total == report["summary"]["observed_atoms"]
    source = Path(__file__).resolve().parent
    names = ("validate_esmc_reference_shape.py", "validate_esmc_capacity.py")
    qa = {
        "complete": True,
        "report_sha256": sha256(root / "report.json"),
        "groups": 32,
        "observed_atoms": atom_total,
        "independent_pooled_rmsd": pooled,
        "max_residue_rmsd_discrepancy": maximum_error,
        "source_sha256": {name: sha256(source / name) for name in names},
        "scope": "Saved-reference proper-fit/identity/mask/hash QA; no original heavy input reload",
    }
    write_json(root / "independent_validation.json", qa)
    for name in names:
        dest = root / "source/final_validation" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, dest)
    runtime_sources = {
        str(p.relative_to(root / "source/runtime")): sha256(p)
        for p in sorted((root / "source/runtime").rglob("*.py"))
    }
    write_json(root / "runtime_source_manifest.json", runtime_sources)
    values = [r["rmsd"] for r in report["cases"]]
    fig, ax = plt.subplots(figsize=(12, 4), constrained_layout=True)
    ax.bar(range(32), values, color="#557d9b")
    ax.axhline(1, color="#b64b37", linestyle="--", label="Existing pooled capacity threshold (1 Å)")
    ax.set_xticks(range(32), [str(r["provenance"]["length"]) for r in report["cases"]], rotation=90)
    ax.set(
        xlabel="TRAIN protein length (fixed selection order)",
        ylabel="Per-protein rigid-residue floor (Å)",
        title="GT-dependent reference-shape lower bound — not folding predictions",
    )
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(args.prefix.with_suffix(".png"), dpi=170)
    plt.close(fig)
    summary = report["summary"]
    lines = [
        "# Rigid cached-reference representational lower bound",
        "",
        f"HPC3 CPU step {report['runtime']['job_id']}.{report['runtime']['step_id']}; 32 "
        f"TRAIN proteins, {atom_total:,} observed atoms. No GPU/model forward. Proper "
        f"fits use target coordinates independently for every residue and do not enforce "
        f"peptide connectivity.",
        "",
        f"Pooled floor: **{pooled:.6f} Å**; macro floor "
        f"{summary['macro_rigid_residue_floor']:.6f} Å; largest per-protein floor "
        f"{summary['max_protein_floor']:.6f} Å. {summary['proteins_floor_gt_1']}/32 "
        f"protein floors exceed1 Å. Every observed atom has a valid cached reference "
        f"coordinate.",
        "",
        "Because even this target-aware lower bound exceeds the existing pooled1 Å "
        "gate, an output restricted to independent proper rigid transforms of these "
        "exact cached residue conformers cannot meet that gate. This does not rule out "
        "torsion-capable or otherwise internally flexible heads, alternative reference "
        "conformers, or the current unconstrained Cartesian decoder. A low floor would "
        "not have proved learnability or connectivity.",
        "",
        f"Independent local saved-artifact QA passes; max per-residue RMSD difference "
        f"{maximum_error:.3g} Å. Worker verified original feature/input/GT hashes and "
        f"label mapping; local QA checks saved references and fits, without reloading "
        f"heavy HPC feature packets. Missing atoms are excluded, with no fitted "
        f"coordinates written for them.",
        "",
        "Installed-source inspection: reference conformers come from CCD and receive "
        "per-residue random proper pose transforms in featurization. "
        "AtomAttentionDecoder ends in an unconstrained three-coordinate projection; "
        "diffusion preconditioning combines it with noisy coordinates. frames.py "
        "projects/gathers existing coordinates; constants.py contains chi/frame atom "
        "indices. Those inspected facilities are not a complete chemically constrained "
        "coordinate builder. Six inspected source files and hashes are archived. No "
        "live model, loss, input or training setting was changed.",
        "",
        f"![Reference floor by protein]({args.prefix.name}.png)",
    ]
    args.prefix.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps(qa, indent=2))


if __name__ == "__main__":
    main()
