#!/usr/bin/env python3
"""Read only the fixed 64 GT members and score existing predictions on CPU."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import tarfile
from contextlib import ExitStack
from pathlib import Path

import numpy as np
import torch

from fastglycan.experimental_metrics import (
    compare_experimental,
    prediction_atom37,
    validate_experimental_record,
)
from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, write_json
from onestepfold.training.coordinate_refiner import group_id_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--stageb-root", type=Path, required=True)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--pointwise-root", type=Path, required=True)
    parser.add_argument("--triangle-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    state, root = args.state_root.resolve(), args.output_root.resolve()
    _, all_records = read_cache(state, accepted=True)
    records = [r for r in all_records if r.split == "validation"]
    assert len(records) == 64
    accepted = json.loads((state / "control/acceptance.json").read_text())
    root.mkdir(parents=True, exist_ok=False)
    selected, metadata_hashes = {}, {}
    for shard in sorted({r.shard for r in records}):
        path = args.input_root / shard / "metadata.jsonl.gz"
        metadata_hashes[str(path.resolve())] = sha256(path)
        wanted = {r.group_id for r in records if r.shard == shard}
        with gzip.open(path, "rt") as handle:
            for line in handle:
                row = json.loads(line)
                if row["group_id"] in wanted:
                    assert row["group_id"] not in selected
                    selected[row["group_id"]] = row
    assert set(selected) == {r.group_id for r in records}
    decoded = {"pointwise": args.pointwise_root.resolve(), "triangle": args.triangle_root.resolve()}
    baseline_qa, baseline_rows = {}, {}
    for label, path in decoded.items():
        qa = json.loads((path / "independent_validation.json").read_text())
        assert qa["complete"] and qa["all_64_identity_replays_exact"]
        assert {r["group_id"] for r in qa["examples"]} == set(selected)
        baseline_qa[label] = {
            "root": str(path),
            "qa_sha256": sha256(path / "independent_validation.json"),
        }
        baseline_rows[label] = {}
        for worker, digest in qa["worker_report_sha256"].items():
            assert sha256(path / f"worker_{worker}.json") == digest
            report = json.loads((path / f"worker_{worker}.json").read_text())
            for row in report["examples"]:
                assert row["group_id"] not in baseline_rows[label]
                baseline_rows[label][row["group_id"]] = row
        assert set(baseline_rows[label]) == set(selected)
    source = Path(__file__).resolve().parents[1]
    names = (
        "scripts/prepare_experimental_assessment.py",
        "src/fastglycan/experimental_metrics.py",
        "src/fastglycan/all_atom_metrics.py",
        "src/onestepfold/data/gt_materializer.py",
        "src/onestepfold/data/teacher_pair_training.py",
        "docs/stage1b_experimental_validation_v1.md",
    )
    protocol = {
        "schema_version": "experimental-assessment-64-v1",
        "state_root": str(state),
        "state_acceptance_sha256": sha256(state / "control/acceptance.json"),
        "selection": [r.to_dict() for r in records],
        "selection_sha256": group_id_digest(records),
        "input_metadata_sha256": metadata_hashes,
        "stageb_root": str(args.stageb_root.resolve()),
        "stageb_summary_sha256": sha256(args.stageb_root / "stageb_v1_summary.json"),
        "baseline_decoders": baseline_qa,
        "source_sha256": {name: sha256(source / name) for name in names},
        "frozen_temporal_test_manifests_or_coordinates_read": False,
        "checkpoint_selection_uses_experimental_metrics": False,
        "scope": "fixed 64-group exploratory experimental assessment; no training change",
    }
    write_json(root / "protocol.json", protocol)
    result = {
        "complete": False,
        "protocol_sha256": sha256(root / "protocol.json"),
        "examples": [],
        "trace_sha256": {},
    }
    with ExitStack() as stack:
        archives = {}
        for record in records:
            group, row = record.group_id, selected[record.group_id]
            assert row["sample_id"] == record.sample_id and row["sequence"] == record.sequence
            assert row["sequence_length"] == record.sequence_length
            assert (
                row["sequence_sha256"]
                == hashlib.sha256(record.sequence.encode()).hexdigest()
                == group
            )
            old = Path(row["shard"])
            assert old.parent.name == "shards" and old.parent.parent.name == "processed_stageb_v1"
            shard = args.stageb_root / "shards" / old.name
            if shard not in archives:
                archives[shard] = stack.enter_context(tarfile.open(shard, "r"))
            payloads = {}
            for key in ("metadata", "npz"):
                assert Path(row[key]).name == row[key]
                member = archives[shard].extractfile(row[key])
                assert member is not None
                payloads[key] = member.read()
            metadata = json.loads(payloads["metadata"])
            with np.load(io.BytesIO(payloads["npz"]), allow_pickle=False) as arrays_file:
                arrays = {key: arrays_file[key] for key in arrays_file.files}
            validate_experimental_record(arrays, metadata, record.sequence, record.sample_id)
            pdb = row["pdb_id"]
            assert metadata["pdb_id"] == pdb and len(pdb) == 4 and pdb.isalnum()
            raw = args.raw_root / pdb[1:3] / f"{pdb}.cif.gz"
            assert sha256(raw) == metadata["provenance"]["source_mmcif_sha256"]
            folder = root / "examples" / group
            folder.mkdir(parents=True)
            (folder / "gt.npz").write_bytes(payloads["npz"])
            (folder / "gt.json").write_bytes(payloads["metadata"])
            native_dir = state / "examples" / group
            assert sha256(native_dir / "trace.json") == accepted["trace_sha256"][group]
            native = json.loads((native_dir / "trace.json").read_text())
            trace = {
                "group_id": group,
                "sample_id": record.sample_id,
                "sequence": record.sequence,
                "length": record.sequence_length,
                "gt_npz_sha256": sha256(folder / "gt.npz"),
                "gt_metadata_sha256": sha256(folder / "gt.json"),
                "source_metadata": row,
                "source_shard": str(shard.resolve()),
                "raw_mmcif_path": str(raw.resolve()),
                "source_mmcif_sha256": sha256(raw),
                "conditions": {},
            }
            inventory = None
            for label in ("c1", "c2", "c4", "pointwise", "triangle"):
                if label.startswith("c"):
                    path = native_dir / f"{label}.npz"
                    digest = native["conditions"][label]["coordinates_sha256"]
                else:
                    directory = decoded[label] / "examples" / group
                    parent_trace = json.loads((directory / "trace.json").read_text())
                    # The accepted worker embeds the full per-group trace; verify that lineage.
                    accepted_row = baseline_rows[label][group]
                    assert parent_trace == accepted_row
                    path, digest = (
                        directory / "student.npz",
                        parent_trace["conditions"]["student"]["coordinates_sha256"],
                    )
                assert sha256(path) == digest
                with np.load(path, allow_pickle=False) as saved:
                    prediction = {key: saved[key] for key in saved.files}
                _, this_inventory = prediction_atom37(prediction, record.sequence)
                if inventory is None:
                    inventory = this_inventory
                metric = compare_experimental(
                    prediction, arrays, record.sequence, expected_prediction_mask=inventory
                )
                trace["conditions"][label] = {
                    "path": str(path.resolve()),
                    "sha256": digest,
                    "metrics": metric,
                }
            write_json(folder / "trace.json", trace)
            result["trace_sha256"][group] = sha256(folder / "trace.json")
            result["examples"].append(trace)
            write_json(root / "baseline.json", result)
            print(
                json.dumps(
                    {
                        "completed": len(result["examples"]),
                        "group_id": group,
                        "common_atoms": trace["conditions"]["c1"]["metrics"]["common_atom_count"],
                    }
                ),
                flush=True,
            )
    result["complete"] = True
    write_json(root / "baseline.json", result)


if __name__ == "__main__":
    main()
