#!/usr/bin/env python3
"""Generate one immutable worker partition of the controlled teacher pilot."""

from __future__ import annotations

import argparse
import copy
import inspect
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

from fastglycan.paired_teacher_protocol import sha256, validate_pair_traces, write_json
from fastglycan.teacher_pairing import TeacherRNGTrace, feature_digest
from onestepfold.data.teacher_pairs import load_teacher_pair, load_teacher_pair_manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--worker", type=int, required=True)
    args = parser.parse_args()
    root = args.output_root.resolve()
    control = root / "control"
    protocol_path = control / "paired_teacher_protocol.json"
    protocol = json.loads(protocol_path.read_text())
    protocol_hash = sha256(protocol_path)
    manifest = control / "teacher_pair_manifest_v1.jsonl.gz"
    if sha256(manifest) != protocol["manifest_sha256"]:
        raise ValueError("manifest changed")
    worker_path = control / f"worker_{args.worker}.json"
    worker_spec = protocol["workers"][args.worker]
    if sha256(worker_path) != worker_spec["sha256"]:
        raise ValueError("worker selection changed")
    ids = json.loads(worker_path.read_text())
    records = {r.group_id: r for r in load_teacher_pair_manifest(manifest)}
    work = root / "work" / f"worker_{args.worker}"
    work.mkdir(parents=True, exist_ok=False)
    os.chdir(work)
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != protocol["cublas_workspace_config"]:
        raise RuntimeError("CUBLAS workspace must be set before starting Python")
    os.environ["LAYERNORM_TYPE"] = "torch"
    from protenix.data.inference.infer_dataloader import get_inference_dataloader
    from protenix.utils.seed import seed_everything
    from runner import batch_inference
    from runner.dumper import DataDumper

    input_path = work / "input.json"
    write_json(
        input_path,
        [
            {
                "name": group,
                "sequences": [{"proteinChain": {"sequence": records[group].sequence, "count": 1}}],
            }
            for group in ids
        ],
    )
    seed_everything(protocol["feature_seed"], deterministic=True)
    old_argv = sys.argv
    try:
        sys.argv = sys.argv[:1]
        runner = batch_inference.get_default_runner(
            seeds=[101],
            n_cycle=2,
            n_step=2,
            n_sample=1,
            dtype="bf16",
            model_name=protocol["model_name"],
            use_msa=False,
            use_template=False,
            trimul_kernel="torch",
            triatt_kernel="torch",
            enable_tf32=False,
        )
    finally:
        sys.argv = old_argv
    config = runner.configs
    config.mc_dropout_apply_rate = 0.0
    config.input_json_path = str(input_path)
    config.num_workers = 0
    seed_everything(protocol["feature_seed"], deterministic=True)
    dataset = get_inference_dataloader(configs=config).dataset
    checkpoint = Path(config.load_checkpoint_dir) / (protocol["model_name"] + ".pt")
    source_root = Path(__file__).resolve().parents[1]
    source_names = (
        "scripts/generate_paired_teacher_pilot.py",
        "scripts/prepare_paired_teacher_pilot.py",
        "src/fastglycan/teacher_pairing.py",
        "src/fastglycan/paired_teacher_protocol.py",
        "src/onestepfold/data/teacher_pairs.py",
    )
    report = {
        "complete": False,
        "worker": args.worker,
        "protocol_sha256": protocol_hash,
        "checkpoint_sha256": sha256(checkpoint),
        "input_sha256": sha256(input_path),
        "source_sha256": {name: sha256(source_root / name) for name in source_names},
        "runtime_source_sha256": {},
        "runtime": {
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "torch": torch.__version__,
            "device": torch.cuda.get_device_name(0),
            "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        },
        "completed_groups": [],
    }
    for obj in (
        batch_inference.get_default_runner,
        type(runner).predict,
        type(runner.model).get_pairformer_output,
        get_inference_dataloader,
        DataDumper,
    ):
        path = Path(inspect.getfile(obj))
        report["runtime_source_sha256"][str(path)] = sha256(path)
    started = time.monotonic()
    with TeacherRNGTrace(runner.model, runner.device) as trace:
        for index, group in enumerate(ids):
            seed_everything(protocol["feature_seed"], deterministic=True)
            data, atoms, error = dataset[index]
            if error or data["sample_name"] != group:
                raise RuntimeError(f"input mismatch for {group}: {error}")
            record = records[group]
            features_hash = feature_digest(data["input_feature_dict"])
            row = {
                "group_id": group,
                "length": record.sequence_length,
                "protocol_sha256": protocol_hash,
                "prepared_features_sha256": features_hash,
                "conditions": {},
                "artifact_sha256": {},
            }
            coordinates = {}
            conditions = [("c2", 2), ("c4", 4)]
            if index == 0:
                conditions.append(("c4_repeat", 4))
            for label, cycles in conditions:
                config.model.N_cycle = cycles
                runner.model.N_cycle = cycles
                trace.diffusion_seed = protocol["diffusion_seed"]
                trace.events = []
                seed_everything(protocol["trunk_seed"], deterministic=True)
                prediction = runner.predict(copy.deepcopy(data))
                coordinate = prediction["coordinate"].detach().float().cpu().numpy()
                if coordinate.shape != (1, len(atoms), 3) or not np.isfinite(coordinate).all():
                    raise ValueError("invalid predicted coordinates")
                row["conditions"][label] = copy.deepcopy(trace.events)
                if index == 0:
                    coordinates[label] = coordinate.copy()
                if label != "c4_repeat":
                    dumper = DataDumper(str(root / f"c{cycles}_s2" / record.shard / "seed-101"))
                    dumper.dump(
                        dataset_name="",
                        pdb_id=group,
                        seed=101,
                        pred_dict=prediction,
                        atom_array=atoms,
                        entity_poly_type={
                            k: v for k, v in data["entity_poly_type"].items() if v != "non-polymer"
                        },
                    )
                del prediction
                if feature_digest(data["input_feature_dict"]) != features_hash:
                    raise ValueError("prepared features were modified")
            validate_pair_traces(row["conditions"]["c2"], row["conditions"]["c4"])
            if index == 0:
                first, repeat = row["conditions"]["c4"], row["conditions"]["c4_repeat"]
                if first != repeat or not np.array_equal(
                    coordinates["c4"], coordinates["c4_repeat"]
                ):
                    raise ValueError("longest target is not exactly reproducible")
                repeat_path = control / f"worker_{args.worker}_longest_repeat.npz"
                np.savez_compressed(repeat_path, **coordinates)
                row["longest_repeat"] = {
                    "all_atoms_exact": True,
                    "path": str(repeat_path.relative_to(root)),
                    "sha256": sha256(repeat_path),
                }
            pair = load_teacher_pair(record, root)
            if not pair.c2.backbone_mask.all() or not pair.c4.backbone_mask.all():
                raise ValueError("predicted backbone is incomplete")
            for relative in (
                record.c2_cif,
                record.c4_cif,
                record.c2_confidence,
                record.c4_confidence,
            ):
                row["artifact_sha256"][relative] = sha256(root / relative)
            write_json(control / "traces" / f"{group}.json", row)
            report["completed_groups"].append(group)
            report["elapsed_seconds"] = time.monotonic() - started
            write_json(control / f"worker_{args.worker}_report.json", report)
            print(
                json.dumps(
                    {
                        "worker": args.worker,
                        "completed": index + 1,
                        "total": len(ids),
                        "group": group,
                        "length": record.sequence_length,
                        "elapsed_seconds": report["elapsed_seconds"],
                    }
                ),
                flush=True,
            )
    if sha256(checkpoint) != report["checkpoint_sha256"] or sha256(protocol_path) != protocol_hash:
        raise ValueError("checkpoint or protocol changed during inference")
    report["complete"] = True
    write_json(control / f"worker_{args.worker}_report.json", report)


if __name__ == "__main__":
    main()
