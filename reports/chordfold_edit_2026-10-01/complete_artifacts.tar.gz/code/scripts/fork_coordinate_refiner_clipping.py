#!/usr/bin/env python3
"""Create a new, explicitly fingerprinted continuation from an immutable run."""

import argparse
import json
from pathlib import Path

import torch
from train_coordinate_refiner_stage1b import _sha256

from fastglycan.checkpoint_forks import fork_gradient_clip_checkpoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent-run", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--maximum-gradient-norm", type=float, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise FileExistsError("fork output exists; inspect before resubmitting")
    report_path = args.parent_run / "training_report.json"
    report = json.loads(report_path.read_text())
    assert report["complete"] and report["last_completed_epoch"] == 10
    inputs = {name: args.parent_run / (name + ".pt") for name in ("best", "last")}
    hashes = {name: _sha256(path) for name, path in inputs.items()}
    assert hashes["best"] == report["best_checkpoint_sha256"]
    checkpoints = {
        name: torch.load(path, map_location="cpu", weights_only=False)
        for name, path in inputs.items()
    }
    for checkpoint in checkpoints.values():
        assert checkpoint["run_contract"] == report["run_contract"]
        assert checkpoint["best_epoch"] == report["best_epoch"]
        assert checkpoint["best_validation"] == report["best_validation"]
    assert checkpoints["last"]["epoch"] == 10
    assert checkpoints["best"]["epoch"] == report["best_epoch"]
    assert checkpoints["last"]["history"] == report["history"]
    provenance = {
        "run": str(args.parent_run),
        "checkpoints_sha256": hashes,
        "report_sha256": _sha256(report_path),
        "inherited_through_epoch": 10,
        "inherited_source_sha256": report["source_sha256"],
    }
    args.output_dir.mkdir(parents=True)
    for name, checkpoint in checkpoints.items():
        child = fork_gradient_clip_checkpoint(checkpoint, args.maximum_gradient_norm, provenance)
        torch.save(child, args.output_dir / (name + ".pt"))
    assert all(_sha256(path) == hashes[name] for name, path in inputs.items())
    (args.output_dir / "fork.json").write_text(
        json.dumps(
            {
                "parent": provenance,
                "maximum_gradient_norm": args.maximum_gradient_norm,
                "derived_checkpoints_sha256": {
                    name: _sha256(args.output_dir / (name + ".pt")) for name in inputs
                },
                "fork_source_sha256": {
                    name: _sha256(Path(name))
                    for name in (
                        "scripts/fork_coordinate_refiner_clipping.py",
                        "src/fastglycan/checkpoint_forks.py",
                    )
                },
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "output": str(args.output_dir),
                "parent": provenance["run"],
                "clip": args.maximum_gradient_norm,
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
