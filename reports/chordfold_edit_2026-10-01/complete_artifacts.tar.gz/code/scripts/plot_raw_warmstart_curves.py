#!/usr/bin/env python3
"""Render accepted endpoint histories; never change endpoint selection or training."""
import argparse
import json
import math
import statistics
from pathlib import Path

PARENT_STEPS = 22528
MAX_STEPS = 8192

def verify_lock(root, source):
    root, source = Path(root), Path(source)
    lock = json.loads((root / "lock.json").read_text())
    assert lock["schema"] == "esmc-raw-warmstart-v1"
    assert lock["max_steps"] == MAX_STEPS and lock["parent_step"] == PARENT_STEPS
    assert lock["student"] == {"cycles": 1, "structure_evaluations": 1, "K": 1}
    assert str(source) == lock["source_root"]
    assert sha256(source / "source_manifest.json") == lock["source_manifest_sha256"]
    for name, digest in json.loads((source / "source_manifest.json").read_text())["files"].items():
        assert sha256(source / name) == digest, name
    for name, digest in lock["inputs_sha256"].items():
        assert sha256(Path(name)) == digest, name
    parent = Path(lock["parent_root"])
    report = json.loads((parent / "report.json").read_text())
    qa = json.loads((parent / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"]
    assert qa["report_sha256"] == sha256(parent / "report.json")
    assert report["best_step"] == PARENT_STEPS
    assert sha256(parent / "best.pt") == report["best_checkpoint_sha256"] == lock["checkpoint_sha256"]
    return lock
from fastglycan.paired_teacher_protocol import sha256, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    source = Path(__file__).resolve().parent
    manifest = json.loads((source / 'manifest.json').read_text())
    assert sha256(Path(__file__)) == manifest['source_sha256']
    lock = verify_lock(root, root / 'code_v1')
    final = json.loads((root / 'comparison.json').read_text())
    assert final['complete'] and final['lock_sha256'] == sha256(root / 'lock.json')
    for name, digest in final['inputs_sha256'].items():
        assert sha256(Path(name)) == digest, name
    paths = {label: root / label for label in ('raw_continue', 'geometry_adapt')}
    groups = final['groups']
    assert len(groups) == len(set(groups)) == 128
    curves = {}
    histories = {}
    for label, folder in paths.items():
        history = json.loads((folder / 'history.json').read_text())
        histories[label] = sha256(folder / 'history.json')
        curve = []
        for entry in history:
            rows = entry['validation']['rows']
            by = {(r['group_id'], r['noise']): r for r in rows}
            assert len(by) == len(rows) == len(groups) * 2
            assert set(by) == {(g, n) for g in groups for n in (12345, 54321)}
            point = {'step': entry['step']}
            for metric in ('all_atom_lddt', 'tm_score_ca_observed'):
                values = [statistics.fmean(by[g, n]['quality'][metric] for n in (12345, 54321))
                          for g in groups]
                point[metric + '_mean'] = statistics.fmean(values)
                point[metric + '_worst5'] = statistics.fmean(sorted(values)[:math.ceil(.05 * len(values))])
            cn = [r['geometry']['local_distances']['consecutive_C_N'] for r in rows]
            assert all(r['count'] > 0 for r in cn), 'Missing C-N observations need an explicit plotting policy'
            point['cn_mae'] = statistics.fmean(r['mae'] for r in cn)
            ch = [r['geometry']['ca_chirality'] for r in rows]
            eligible = [r['agreement_count'] / r['evaluable_count'] for r in ch if r['evaluable_count']]
            point['chirality'] = statistics.fmean(eligible)
            point['chirality_evaluable_rows'] = len(eligible)
            assert all(math.isfinite(v) for v in point.values())
            curve.append(point)
        assert [p['step'] for p in curve] == sorted({p['step'] for p in curve})
        last = curve[-1]
        accepted = final['arms'][label]['views']['last_validation']
        assert last['step'] == accepted['step'] == final['arms'][label]['steps']
        for metric in ('all_atom_lddt', 'tm_score_ca_observed'):
            assert abs(last[metric + '_mean'] - accepted[metric]['mean']) < 1e-12
            assert abs(last[metric + '_worst5'] - accepted[metric]['worst5_mean']) < 1e-12
        assert abs(last['cn_mae'] - accepted['geometry']['distance_mae']['consecutive_C_N']) < 1e-12
        assert abs(last['chirality'] - accepted['geometry']['chirality_macro']) < 1e-12
        curves[label] = curve
    # Independently match plotted mean/tail differences to the accepted comparisons.
    for step, comparisons in final['common_update_comparisons'].items():
        at = {label: next(p for p in curve if p['step'] == int(step)) for label, curve in curves.items()}
        for metric, values in comparisons.items():
            for plotted, stat in (('mean', 'mean'), ('worst5', 'worst5_mean')):
                key = metric + '_' + plotted
                assert abs(at['geometry_adapt'][key] - at['raw_continue'][key] - values[stat]['delta']) < 1e-12
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy
    assert matplotlib.__version__ == manifest['matplotlib_version']
    assert numpy.__version__ == manifest['numpy_version']
    output = root / 'curves_v1'
    assert not output.exists(), 'Never overwrite a completed plot artifact'
    output.mkdir()
    names = {'raw_continue': 'Raw continuation', 'geometry_adapt': 'Geometry adaptation'}
    colors = {'raw_continue': '#1976b9', 'geometry_adapt': '#d56616'}
    panels = [('all_atom_lddt_mean', 'Mean all-atom lDDT'),
              ('tm_score_ca_observed_mean', 'Mean CA TM-score'),
              ('all_atom_lddt_worst5', 'Worst 5% mean lDDT'),
              ('tm_score_ca_observed_worst5', 'Worst 5% mean TM-score'),
              ('cn_mae', 'Mean consecutive C-N MAE (Angstrom)'),
              ('chirality', 'CA chirality agreement')]
    fig, axes = plt.subplots(3, 2, figsize=(12, 11), layout='constrained')
    for ax, (key, title) in zip(axes.flat, panels, strict=True):
        for label, curve in curves.items():
            ax.plot([p['step'] for p in curve], [p[key] for p in curve],
                    marker='.', ms=5, lw=1.5, color=colors[label], label=names[label])
        ax.axvline(8192, color='#aaaaaa', ls=':', lw=1)
        ax.set(title=title, xlabel='Additional optimizer updates', xlim=(0, 8350))
        ax.grid(alpha=.2)
        if key == 'chirality':
            ax.set_ylim(0, 1.02)
        ax.legend(fontsize=8)
    fig.suptitle('Raw-parent warm start: ESMC-600M, c1/s1/K1, fixed 128-target development set\n'
                 'Two fixed noises averaged per target; one training seed; primary endpoint = 8192 updates', fontsize=12)
    fig.savefig(output / 'learning_curves.png', dpi=180)
    fig.savefig(output / 'learning_curves.pdf')
    plt.close(fig)
    result = {'complete': True, 'source_sha256': sha256(Path(__file__)),
              'manifest_sha256': sha256(source / 'manifest.json'),
              'comparison_sha256': sha256(root / 'comparison.json'),
              'history_sha256': histories, 'curves': curves,
              'primary_status': final['primary_status'], 'matplotlib_version': matplotlib.__version__,
              'numpy_version': numpy.__version__, 'scalar_agreement_atol': 1e-12,
              'artifact_sha256': {n: sha256(output / n) for n in ('learning_curves.png', 'learning_curves.pdf')},
              'scope': 'Presentation of accepted histories; intermediate points remain worker-reported, not independently replayed checkpoints. No additional hypothesis test, checkpoint selection, or training.'}
    write_json(output / 'curves.json', result)
    (output / 'README.md').write_text('# Matched raw-parent adaptation curves\n\n'
        '![Quality, tails and chemistry](learning_curves.png)\n\n'
        'Points show every saved evaluation without smoothing or best-checkpoint selection. '
        'Tail subsets are recalculated separately for each checkpoint and arm. '
        'No confidence ribbon is shown; the predeclared paired intervals are in ../report.md. '
        'CA chirality and C-N MAE are partial chemistry summaries, not full chemistry acceptance. '
        'Both arms start from the same raw weights; geometry output already changes the step-zero quality. '
        'The plot does not change the predeclared 8192-update endpoint.\n')
    print(json.dumps({'complete': True, 'primary_status': final['primary_status']}), flush=True)


if __name__ == '__main__':
    main()
