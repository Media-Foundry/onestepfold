#!/usr/bin/env python3
"""Check a fixed-graph builder on accepted cached references, without fitting GT."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from collections import Counter
from pathlib import Path

import biotite
import numpy as np
import torch
from biotite.structure.io import pdbx

from fastglycan.articulated_reference import (
    articulate_reference,
    bridge_rotations,
    geometry_invariants,
)

AA = dict(
    zip(
        "ARNDCQEGHILKMFPSTWYV",
        "ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL".split(),
        strict=True,
    )
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--references", type=Path, required=True)
    parser.add_argument("--graphs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    args.output.mkdir(parents=True, exist_ok=False)
    report = json.loads((args.references / "report.json").read_text())
    qa = json.loads((args.references / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"]
    assert sha(args.references / "report.json") == (
        "40909d6dee6f23e5b8f2e0abb542922dafa97e3ff1068324c888e05c54f597e4"
    )
    manifest = json.loads((args.graphs / "manifest.json").read_text())
    assert sha(args.graphs / "standard_amino_acids.cif") == manifest["subset_sha256"]
    for name, expected in manifest["installed_source_sha256"].items():
        assert sha(args.graphs / "source" / name) == expected
    cif = pdbx.CIFFile.read(args.graphs / "standard_amino_acids.cif")
    components = {name: pdbx.get_component(cif, data_block=name) for name in AA.values()}
    rows, variants = [], {}
    maximum = Counter()
    handedness = {key: Counter() for key in ("CA", "ILE_CB", "THR_CB")}
    for case in report["cases"]:
        path = args.references / f"{case['group_id']}.npz"
        assert sha(path) == case["artifact_sha256"]
        with np.load(path, allow_pickle=False) as saved:
            data = dict(saved)
        sequence = case["provenance"]["sequence"]
        for residue in np.unique(data["residue_id"]):
            idx = np.flatnonzero(data["residue_id"] == residue)
            names = data["atom_name"][idx].tolist()
            kind = AA[sequence[int(residue) - 1]]
            comp = components[kind]
            by_name = {name: i for i, name in enumerate(comp.atom_name)}
            assert all(name in by_name for name in names)
            assert all(
                comp.element[by_name[name]] == element
                for name, element in zip(names, data["element"][idx], strict=True)
            )
            mapping = {by_name[name]: i for i, name in enumerate(names)}
            bonds = [
                (mapping[int(a)], mapping[int(b)], int(order))
                for a, b, order in comp.bonds.as_array()
                if a in mapping and b in mapping
            ]
            rotations = bridge_rotations(names, bonds)
            assert data["reference_mask"][idx].all()
            reference = torch.tensor(data["reference"][idx], dtype=torch.float64)
            angles = 0.37 * torch.arange(1, len(rotations) + 1, dtype=torch.float64)
            transformed = articulate_reference(reference, angles, rotations).numpy()
            assert torch.equal(articulate_reference(reference, angles * 0, rotations), reference)
            before = geometry_invariants(reference, bonds)
            after = geometry_invariants(transformed, bonds)
            for metric, a, b in zip(("bond_length", "bond_cosine"), before, after, strict=True):
                error = float(np.max(np.abs(a - b), initial=0))
                maximum[metric] = max(maximum[metric], error)
                assert error < 1e-10

            # Rigid components after removal of articulated bridges include every ring.
            cut = {frozenset((r.parent, r.child)) for r in rotations}
            neighbors = [set() for _ in names]
            for a, b, _ in bonds:
                if frozenset((a, b)) not in cut:
                    neighbors[a].add(b)
                    neighbors[b].add(a)
            unseen = set(range(len(names)))
            while unseen:
                group = [min(unseen)]
                unseen.remove(group[0])
                for a in group:
                    for b in sorted(neighbors[a] & unseen):
                        unseen.remove(b)
                        group.append(b)
                x = reference.numpy()[group]
                y = transformed[group]
                error = float(
                    np.max(
                        np.abs(
                            np.linalg.norm(x[:, None] - x[None], axis=-1)
                            - np.linalg.norm(y[:, None] - y[None], axis=-1)
                        )
                    )
                )
                maximum["rigid_component_distance"] = max(
                    maximum["rigid_component_distance"], error
                )
                assert error < 1e-10

            signatures = [("CA", ("N", "C", "CB", "CA"))]
            if kind == "ILE":
                signatures.append(("ILE_CB", ("CA", "CG1", "CG2", "CB")))
            if kind == "THR":
                signatures.append(("THR_CB", ("CA", "OG1", "CG2", "CB")))
            for key, atoms in signatures:
                if not all(a in names for a in atoms):
                    continue
                ids = [names.index(a) for a in atoms]

                def signed(x, ids=ids):
                    return float(np.linalg.det(x[ids[:3]] - x[ids[3]]))

                ref_sign, new_sign = signed(reference.numpy()), signed(transformed)
                assert abs(ref_sign - new_sign) < 1e-9
                if data["observed"][idx][ids].all():
                    gt_sign = signed(data["target"][idx].astype(np.float64))
                    if abs(gt_sign) > 1e-6:
                        handedness[key]["eligible"] += 1
                        handedness[key]["reference_matches_gt"] += int(ref_sign * gt_sign > 0)
            key = kind + ":" + ",".join(names)
            if key not in variants:
                angles.requires_grad_(True)
                weights = torch.tensor(np.random.default_rng(101).normal(size=reference.shape))
                scalar = (articulate_reference(reference, angles, rotations) * weights).sum()
                gradient = torch.autograd.grad(scalar, angles)[0]
                fd = []
                for j in range(len(angles)):
                    shift = torch.zeros_like(angles)
                    shift[j] = 1e-6
                    fd.append(
                        float(
                            (
                                (
                                    articulate_reference(
                                        reference, angles.detach() + shift, rotations
                                    )
                                    - articulate_reference(
                                        reference, angles.detach() - shift, rotations
                                    )
                                )
                                * weights
                            ).sum()
                            / 2e-6
                        )
                    )
                error = float(np.max(np.abs(gradient.numpy() - fd), initial=0))
                maximum["finite_difference"] = max(maximum["finite_difference"], error)
                assert error < 1e-7
                variants[key] = {
                    "residue": kind,
                    "atom_names": names,
                    "bonds": bonds,
                    "rotations": [
                        {
                            "axis": [names[r.parent], names[r.child]],
                            "moving": [names[i] for i in r.moving],
                        }
                        for r in rotations
                    ],
                    "finite_difference_max_absolute_error": error,
                    "gradient_norm": float(torch.linalg.vector_norm(gradient)),
                }
            rows.append(
                {
                    "group_id": case["group_id"],
                    "residue_id": int(residue),
                    "residue": kind,
                    "atoms": len(idx),
                    "rotation_count": len(rotations),
                }
            )
    source = Path(__file__).resolve().parents[1]
    sources = {}
    for name in (
        "scripts/diagnose_esmc_articulation.py",
        "src/fastglycan/articulated_reference.py",
        "tests/test_articulated_reference.py",
        "docs/esmc_articulated_reference_v1.md",
    ):
        dest = args.output / "source" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, dest)
        sources[name] = sha(dest)
    result = {
        "complete": True,
        "reference_report_sha256": sha(args.references / "report.json"),
        "reference_qa_sha256": sha(args.references / "independent_validation.json"),
        "graph_manifest_sha256": sha(args.graphs / "manifest.json"),
        "biotite_version": biotite.__version__,
        "torch_version": torch.__version__,
        "groups": len(report["cases"]),
        "residues": len(rows),
        "max_errors": dict(maximum),
        "handedness": handedness,
        "variants": variants,
        "cases": rows,
        "source_sha256": sources,
        "scope": "chemical-input reconstruction/derivative checks; no GT fit or learned model",
    }
    (args.output / "report.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("variants", "cases")}, indent=2))


if __name__ == "__main__":
    main()
