#!/usr/bin/env python3
"""Check the plot environment did not change scores or bootstrap summaries."""
import argparse
import importlib.util
import json
from pathlib import Path

import numpy as np
from fastglycan.paired_teacher_protocol import sha256, write_json


def compare(a, b):
    if isinstance(a, dict):
        assert a.keys() == b.keys()
        for k in a:
            compare(a[k], b[k])
    elif isinstance(a, (float, list)):
        assert np.allclose(a, b, rtol=0, atol=1e-12)
    else:
        assert a == b


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root
    source = root/'analysis_v2/report_endpoint_objective.py'
    spec = importlib.util.spec_from_file_location('analysis_source', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = json.loads((root/'analysis.json').read_text())
    assert result['complete'] and result['inputs_sha256']['analysis_source'] == sha256(source)
    for path, digest in result['inputs_sha256'].items():
        if path == 'analysis_source':
            continue
        assert sha256(root/path if not Path(path).is_absolute() else Path(path)) == digest
    lock = json.loads((root/'lock.json').read_text())
    reports = {arm: json.loads((Path(lock['experiment_root'])/arm/'report.json').read_text()) for arm in ('gt_only', 'endpoint')}
    for metric in module.METRICS:
        values = {arm: module.vectors(r['last_validation']['rows'],metric,result['targets']) for arm,r in reports.items()}
        repeated = module.comparison(values['endpoint'], values['gt_only'])
        compare(repeated, result['final_paired'][metric])
    # Degenerate identical/constant-offset paired samples have exact known tails.
    x = np.arange(128)/256
    for shift in (0., .125, -.125):
        comparison = module.comparison(x+shift,x)
        for stat in ('mean','p05','worst5_mean'):
            assert abs(comparison[stat]['delta']-shift) < 1e-12
            assert np.allclose(comparison[stat]['ci95'], [shift,shift], rtol=0,atol=1e-12)
    figures = {n: sha256(root/n) for n in ('figure.png','figure.pdf')}
    assert (root/'figure.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
    assert (root/'figure.pdf').read_bytes().startswith(b'%PDF')
    write_json(root/'report_validation.json', {'complete':True,
        'analysis_sha256':sha256(root/'analysis.json'), 'report_sha256':sha256(root/'report.md'),
        'figure_sha256':figures, 'validator_sha256':sha256(Path(__file__)),
        'native_numpy':np.__version__, 'plot_numpy':result['plot_runtime']['numpy'],
        'cross_runtime_atol':1e-12,'bootstrap_known_answer_checks':3,
        'scope':'Input hashes, recomputation in original numerical environment, paired-tail known answers, plot format checks; GPU evidence remains bound to zero-update worker reports'})
    print('Cross-runtime report verification passed',flush=True)


if __name__ == '__main__':
    main()
