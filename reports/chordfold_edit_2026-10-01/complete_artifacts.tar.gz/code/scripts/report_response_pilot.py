#!/usr/bin/env python3
"""Response-supervision curves and verified native-sampler comparison."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read(path):
    return json.loads(path.read_text())


def live_report(archive, prefix):
    history = read(archive / "training/history.json")
    contract = read(archive / "training/contract.json")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), layout="constrained")
    epochs = [r["epoch"] for r in history]
    axes[0].plot(
        epochs[1:],
        [r["train_online_response_mse"] for r in history[1:]],
        label="Train online",
        marker="o",
    )
    axes[0].plot(
        epochs, [r["validation"]["macro_mse"] for r in history], label="Validation", marker="o"
    )
    axes[0].set(ylabel="Denoised-coordinate MSE", title="Response loss")
    axes[0].legend()
    for key, label in (("macro_ratio", "Per-protein"), ("pooled_ratio", "Atom-coordinate pooled")):
        axes[1].plot(epochs, [r["validation"][key] for r in history], label=label, marker="o")
    axes[1].axhline(1, color="gray", ls="--")
    axes[1].set(ylabel="Response MSE / c1", title="Held-out response (structure QA pending)")
    axes[1].legend(fontsize=8)
    axes[2].plot(
        epochs[1:],
        [r["mean_gradient_norm"] for r in history[1:]],
        label="Mean before clip",
        marker="o",
    )
    axes[2].axhline(10, color="gray", ls="--", label="Clip threshold")
    axes[2].set(ylabel="Parameter gradient L2 norm", title="Optimization")
    axes[2].legend(fontsize=8)
    for ax in axes:
        ax.set_xlabel("Completed epoch")
        ax.set_xlim(-0.05, max(1, epochs[-1]) + 0.05)
    fig.suptitle(
        f"Preliminary response training — job {contract['runtime']['job_id']}, "
        f"{epochs[-1]}/20 epochs; no full-sampler quality claim"
    )
    fig.savefig(prefix.with_suffix(".png"), dpi=180)
    plt.close(fig)
    prefix.with_suffix(".json").write_text(
        json.dumps(
            {
                "complete": False,
                "training_job": contract["runtime"]["job_id"],
                "completed_epoch": epochs[-1],
                "latest": history[-1],
                "scope": "provisional response loss, final sampler and independent QA pending",
            },
            indent=2,
        )
        + "\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--baseline-archive", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args()
    if args.live:
        live_report(args.archive, args.prefix)
        return
    current = read(args.archive / "training/report.json")
    history = read(args.archive / "training/history.json")
    qa = read(args.archive / "decoded/independent_validation.json")
    baseline = read(args.baseline_archive / "training/report.json")
    old_qa = read(args.baseline_archive / "decoded/independent_validation.json")
    assert all(r["complete"] for r in (current, qa, baseline, old_qa))
    assert qa["checkpoint_validation_kind"] == "response"
    lineage = current["contract"]["matched_pointwise_baseline"]
    assert all(
        current["contract"][k] == baseline["contract"][k] for k in lineage["matching_fields"]
    )
    now, old = ({r["group_id"]: r for r in result["examples"]} for result in (qa, old_qa))
    assert set(now) == set(old) and len(now) == 64
    metrics = ("all_heavy_atom_rmsd", "ca_rmsd", "ca_pair_distance_rmse")
    for group, row in now.items():
        for label in ("c1", "c2"):
            for metric in metrics:
                assert math.isclose(
                    row["comparisons_to_c4"][label][metric],
                    old[group]["comparisons_to_c4"][label][metric],
                    abs_tol=2e-5,
                )
    epochs = [r["epoch"] for r in history]
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), layout="constrained")
    axes[0, 0].plot(
        epochs[1:], [r["train_online_response_mse"] for r in history[1:]], label="Train, online"
    )
    axes[0, 0].plot(
        epochs, [r["validation"]["macro_mse"] for r in history], label="Validation, macro"
    )
    axes[0, 0].set(
        xlabel="Epoch",
        ylabel="Denoised-coordinate MSE (angstrom squared)",
        title="Response-loss curves",
    )
    axes[0, 0].legend()
    for key, label in (("macro_ratio", "Per-protein"), ("pooled_ratio", "Atom-coordinate pooled")):
        axes[0, 1].plot(epochs, [r["validation"][key] for r in history], label=label)
    axes[0, 1].axhline(1, color="gray", ls="--")
    axes[0, 1].axvline(current["best_epoch"], color="gray", ls=":")
    axes[0, 1].set(
        xlabel="Epoch", ylabel="Response MSE / c1 response MSE", title="Checkpoint selection"
    )
    axes[0, 1].legend()
    summaries = [
        ("c1", qa["summary"]["c1"]),
        ("c2", qa["summary"]["c2"]),
        ("Raw-state loss", old_qa["summary"]["student"]),
        ("Response loss", qa["summary"]["student"]),
    ]
    for index, (label, summary) in enumerate(summaries):
        axes[1, 0].bar(
            np.arange(3) + (index - 1.5) * 0.2,
            [summary["pooled_" + key] for key in metrics],
            width=0.2,
            label=label,
        )
    axes[1, 0].set(
        xticks=np.arange(3),
        xticklabels=["All atoms", "CA", "CA distances"],
        ylabel="Pooled error to c4 (angstrom)",
        title="Complete native sampler, 64 proteins",
    )
    axes[1, 0].legend(fontsize=8)
    x = [old[g]["comparisons_to_c4"]["student"]["all_heavy_atom_rmsd"] for g in now]
    y = [now[g]["comparisons_to_c4"]["student"]["all_heavy_atom_rmsd"] for g in now]
    dots = axes[1, 1].scatter(x, y, c=[r["length"] for r in now.values()], s=24)
    top = max(x + y) * 1.05
    axes[1, 1].plot([0, top], [0, top], color="gray", ls="--")
    axes[1, 1].set(
        xlabel="Raw-state-loss all-atom RMSD (angstrom)",
        ylabel="Response-loss all-atom RMSD (angstrom)",
        title="Same pointwise architecture",
    )
    fig.colorbar(dots, ax=axes[1, 1], label="Residues")
    fig.suptitle("Frozen-decoder response supervision: 128 train / 64 validation")
    fig.savefig(args.prefix.with_suffix(".png"), dpi=180)
    plt.close(fig)
    ratios = {
        key: qa["summary"]["student"]["pooled_" + key]
        / old_qa["summary"]["student"]["pooled_" + key]
        for key in metrics
    }
    better = {
        key: sum(
            r["comparisons_to_c4"]["student"][key] < old[g]["comparisons_to_c4"]["student"][key]
            for g, r in now.items()
        )
        for key in metrics
    }
    response = current["selected_validation"]
    policy = qa.get("response_numeric_policy")
    precision_note = []
    if policy is not None and "response_precision_audit_sha256" in qa:
        precision_note = [
            "",
            "Actual response replay policy: matmul TF32 "
            f"**{policy['matmul_allow_tf32']}**, cuDNN TF32 "
            f"**{policy['cudnn_allow_tf32']}**. The original generic validator also "
            "disabled cuDNN TF32, changing the decoder's fused conv2d responses.",
            "A same-checkpoint policy toggle reproduced both saved results exactly; "
            "restoring the training policy makes all 64 response records exact. "
            "No retraining, coordinate regeneration or relaxed tolerance was used.",
        ]
    lines = [
        "# Response-supervised pair emulator — 2026-09-18",
        "",
        "The fixed 128/64 pilot and independent full-sampler validation are complete.",
        "The original 187,344-parameter pointwise model uses identical initial weights and",
        "optimizer schedule. Training/selection now use first denoiser response MSE with",
        "full predicted pair states, rather than sampled raw-state MSE; compute budgets differ.",
        "",
        f"Selected epoch **{current['best_epoch']}**; response-MSE macro/pooled ratios "
        f"**{response['macro_ratio']:.6f}/{response['pooled_ratio']:.6f}**. "
        "Epoch zero was eligible.",
        "",
        "| Pooled error | c1 | c2 | Raw-state loss | Response loss | Response/c1 | Response/raw |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for key in metrics:
        values = [summary["pooled_" + key] for _, summary in summaries]
        values += [qa["summary"]["student_to_c1_pooled_ratios"][key], ratios[key]]
        lines.append(f"| {key} (A) | " + " | ".join(f"{v:.6f}" for v in values) + " |")
    signal, parity = qa["summary"]["exploratory_learning_signal"], qa["summary"]["parity_with_c2"]
    harms = qa["summary"]["student"]
    atom_harm = harms["all_heavy_atom_rmsd_worse_than_c1_count"]
    distance_harm = harms["ca_pair_distance_rmse_worse_than_c1_count"]
    lines += [
        "",
        f"Joint <=0.95-of-c1 structure gate: **{signal}**. C2 quality parity: **{parity}**.",
        f"All-atom/CA-distance harms versus c1: **{atom_harm}/64** and **{distance_harm}/64**.",
        "",
        "Teacher weights remain unchanged. Longest 951-residue combined learner/decoder",
        "smoke passes identity, two backward/optimizer steps, context gradients and reload;",
        f"peak allocation **{current['gpu_checks']['peak_allocated_bytes'] / 2**30:.3f} GiB**.",
        "All 64 predicted pair tensors and c1 atom replays independently reproduce exactly,",
        "selected response validation repeats exactly and lineage/source/artifact checks pass.",
        *precision_note,
        "",
        "The target is a c1-single/c4-pair teacher response at fixed first noise 2560.",
        "The native sampler still uses two NFE. This is teacher-relative compatibility work,",
        "not experimental-GT accuracy, thermodynamic calibration or an end-to-end speed benchmark.",
        "Primary ESMC-600M adaptation, the formal 1,600 gate and eventual one-cycle/one-structure",
        "evaluation remain unfinished. No automatic full-data promotion follows.",
        "",
        f"![Response training and structural evaluation]({args.prefix.name}.png)",
        "",
    ]
    args.prefix.with_suffix(".md").write_text("\n".join(lines))
    args.prefix.with_suffix(".json").write_text(
        json.dumps(
            {
                "matched_initialization_and_declared_fields": True,
                "same_64_native_references": True,
                "response_summary": qa["summary"],
                "raw_state_summary": old_qa["summary"],
                "ratios_to_raw_state_model": ratios,
                "better_than_raw_state_count": better,
                "selected_response_validation": response,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
