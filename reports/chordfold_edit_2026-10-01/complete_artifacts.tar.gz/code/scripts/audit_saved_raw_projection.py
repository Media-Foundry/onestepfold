#!/usr/bin/env python3
"""One locked TRAIN-only CPU diagnostic; no folding network or coordinate optimization."""

import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.articulated_validation import numpy_project
from fastglycan.experimental_geometry import compare_local_geometry
from fastglycan.experimental_metrics import compare_experimental, prediction_atom37
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.raw_projection_diagnostic import summarize
from fastglycan.scaling_metrics import quality_metrics
from fastglycan.teacher_pairing import feature_digest
from validate_esmc_scaling import dense_lddt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    lock = json.loads((root / "lock.json").read_text())
    for name, digest in lock["inputs_sha256"].items():
        assert sha256(Path(name)) == digest, name
    source = root / "code_v1"
    manifest = json.loads((source / "diagnostic_manifest.json").read_text())
    assert sha256(source / "diagnostic_manifest.json") == lock["source_manifest_sha256"]
    for name, digest in manifest.items():
        assert sha256(source / name) == digest, name
    output = root / "result_v1"
    assert not output.exists(), "Do not overwrite or blindly restart partial diagnostics"
    output.mkdir()
    (output / "predictions").mkdir()
    torch.set_num_threads(1)
    assert not torch.cuda.is_available()
    raw_root = Path(lock["raw_root"])
    contract = json.loads((raw_root / "contract.json").read_text())
    report = json.loads((raw_root / "report.json").read_text())
    qa = json.loads((raw_root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"] and contract["arm"] == "raw"
    data = Path(contract["data_root"])
    acceptance = json.loads((data / "acceptance.json").read_text())
    assert sha256(data / "acceptance.json") == contract["data_acceptance_sha256"]
    records = contract["train_probe"]
    groups = {r["group_id"] for r in records}
    assert len(groups) == 32 and groups <= {r["group_id"] for r in contract["train"]}
    assert not groups.intersection(r["group_id"] for r in contract["validation"])
    old_rows = report["best_train_probe"]["rows"]
    assert len(old_rows) == 64 and {(r["group_id"], r["noise"]) for r in old_rows} == {
        (g, seed) for g in groups for seed in (12345, 54321)
    }
    rows = []
    for record in records:
        group, sequence = record["group_id"], record["sequence"]
        folder = data / "examples" / group
        assert sha256(folder / "prepared.json") == acceptance["prepared_sha256"][group]
        info = json.loads((folder / "prepared.json").read_text())
        for name, digest in info["files_sha256"].items():
            assert sha256(folder / name) == digest
        with np.load(folder / "inventory.npz") as handle:
            inventory = dict(handle)
        with np.load(folder / "reference.npz") as handle:
            reference = handle["reference"]
        variants = json.loads((folder / "articulation_report.json").read_text())["variants"]
        adapter = ArticulatedOutput(reference, inventory["atom_name"], inventory["residue_id"], sequence, variants).float()
        assert not list(adapter.parameters())
        assert feature_digest(adapter.state_dict()) == info["adapter_sha256"]
        adapter64 = ArticulatedOutput(reference, inventory["atom_name"], inventory["residue_id"], sequence, variants).float().double()
        ca = inventory["atom_name"] == "CA"
        for old in [r for r in old_rows if r["group_id"] == group]:
            path = raw_root / old["prediction_path"]
            assert sha256(path) == old["prediction_sha256"]
            with np.load(path) as handle:
                for name, value in inventory.items():
                    assert np.array_equal(handle[name], value)
                raw = handle["raw_coordinate"].copy()
                assert raw.dtype == np.float32 and np.array_equal(raw, handle["coordinate"])
            with torch.no_grad():
                start = time.perf_counter()
                projected = adapter(torch.from_numpy(raw))
                projection_seconds = time.perf_counter() - start
                x = projected["coordinate"].numpy()
                assert np.isfinite(x).all()
                assert np.array_equal(x, adapter(torch.from_numpy(raw))["coordinate"].numpy())
                native64 = adapter64(torch.from_numpy(raw.astype(np.float64)))
            oracle64, counts = numpy_project(raw.astype(np.float64), adapter64)
            formula_error = float(np.max(np.abs(native64["coordinate"].numpy() - oracle64)))
            assert formula_error <= 1e-8
            assert np.array_equal(counts, native64["fallback_counts"].numpy())
            # GT is loaded only after the projection is complete; never an adapter input.
            with np.load(folder / "gt.npz") as handle:
                arrays = dict(handle)
            evaluations = {}
            for arm, coordinate in (("raw", raw), ("projected", x), ("oracle64", oracle64)):
                pred = inventory | {"coordinate": coordinate}
                evaluations[arm] = {
                    "quality": quality_metrics(pred, arrays, sequence),
                    "geometry": compare_local_geometry(pred, arrays, sequence),
                    "metrics": compare_experimental(pred, arrays, sequence),
                }
            for key in ("quality", "geometry", "metrics"):
                assert evaluations["raw"][key] == old[key], (group, key)
            positions, mask = prediction_atom37(inventory | {"coordinate": x}, sequence)
            observed = mask & arrays["atom37_mask"] & arrays["residue_mask"][:, None]
            residues, _ = np.nonzero(observed)
            independent = dense_lddt(positions[observed].astype(np.float64), arrays["atom37_positions"][observed].astype(np.float64), residues)
            lddt_error = abs(independent - evaluations["projected"]["quality"]["all_atom_lddt"])
            assert lddt_error < 1e-12
            dest = output / "predictions" / f"{group}_{old['noise']}.npz"
            np.savez_compressed(dest, **inventory, raw_coordinate=raw, coordinate=x)
            row = {
                "group_id": group, "noise": old["noise"], **evaluations,
                "input_sha256": old["prediction_sha256"],
                "prediction_path": str(dest.relative_to(output)), "prediction_sha256": sha256(dest),
                "projection_seconds_cpu": projection_seconds,
                "ca_max_abs_displacement": float(np.max(np.abs(x[ca] - raw[ca]))),
                "all_atom_max_displacement": float(np.max(np.linalg.norm(x - raw, axis=-1))),
                "fallback_counts32": projected["fallback_counts"].tolist(),
                "fallback_counts64": counts.tolist(),
                "native_fp64_formula_error": formula_error,
                "saved32_vs_oracle64": float(np.max(np.abs(x - oracle64))),
                "independent_lddt_error": lddt_error,
            }
            rows.append(row)
            with (output / "rows.jsonl").open("a") as handle:
                handle.write(json.dumps(row, sort_keys=True) + "\n")
            print(json.dumps({"completed": len(rows), "total": 64}), flush=True)
    summary = summarize(rows)
    checks = {
        "max_ca_displacement": max(r["ca_max_abs_displacement"] for r in rows),
        "max_fp64_formula_error": max(r["native_fp64_formula_error"] for r in rows),
        "max_saved32_vs_oracle64": max(r["saved32_vs_oracle64"] for r in rows),
        "max_independent_lddt_error": max(r["independent_lddt_error"] for r in rows),
        "projection_cpu_seconds_total": sum(r["projection_seconds_cpu"] for r in rows),
        "max_tm_abs_change": max(abs(r["projected"]["quality"]["tm_score_ca_observed"] - r["raw"]["quality"]["tm_score_ca_observed"]) for r in rows),
        "max_precision_quality_change": {k: max(abs(r["oracle64"]["quality"][k] - r["projected"]["quality"][k]) for r in rows) for k in ("all_atom_lddt", "tm_score_ca_observed")},
    }
    result = {"complete": True, "lock_sha256": sha256(root / "lock.json"), "rows_sha256": sha256(output / "rows.jsonl"), "best_step": report["best_step"], "folding_network_calls": 0, "training_updates": 0, "summary": summary, "checks": checks, "scope": "32 historical TRAIN probes, two fixed noises, CPU32 projection; no generalization or deployment timing claim"}
    write_json(output / "report.json", result)
    lines = ["# Saved raw output projection: TRAIN diagnostic", "", result["scope"], "", "|Metric|Raw mean|Projected mean|Raw worst5%|Projected worst5%|Loss >0.05 targets|", "|---|---:|---:|---:|---:|---:|"]
    for metric, values in summary["quality"].items():
        lines.append(f"|{metric}|{values['raw']['mean']:.6f}|{values['projected']['mean']:.6f}|{values['raw']['worst5_mean']:.6f}|{values['projected']['worst5_mean']:.6f}|{values['loss_gt_005_count']}/32|")
    lines += ["", "Geometry (macro target/noise averages; not full chemistry acceptance):", "", "```json", json.dumps(summary["geometry"], indent=2), "```", "", "Validation and measured changes:", "", "```json", json.dumps(checks, indent=2), "```", "", "No bootstrap or seed-replication claim. Historical best checkpoint used development selection. No new development/test coordinates evaluated. All per-target means/deltas in report.json. Original c1/s1/K1 objective remains open."]
    (output / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"complete": True, "checks": checks}), flush=True)


if __name__ == "__main__":
    main()
