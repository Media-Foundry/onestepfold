#!/usr/bin/env python3
"""Spare-CPU rigid-reference lower bound; no model construction or inference."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.reference_shape import rigid_reference_floor
from fastglycan.teacher_pairing import feature_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--training-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
    torch.set_num_threads(1)
    started = time.monotonic()
    root, output = args.training_root, args.output
    output.mkdir(parents=True, exist_ok=False)
    report = json.loads((root / "report.json").read_text())
    contract = json.loads((root / "contract.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"] and qa["heavy_artifacts_checked"]
    assert (
        sha256(root / "report.json")
        == qa["report_sha256"]
        == "eb1ee70815f0b6c009879a1db6ea0f6f07c6c4d27b6549ca6928c7b81f746cbb"
    )
    assert sha256(root / "contract.json") == report["contract_sha256"]
    rows = []
    for provenance in contract["input_provenance"]:
        group = provenance["group_id"]
        assert provenance["split"] == "train"
        folder = root / group
        packet_path = Path(contract["baseline_root"]) / group / "inputs.pt"
        assert sha256(packet_path) == provenance["inputs_sha256"]
        packet = torch.load(packet_path, map_location="cpu", weights_only=True)
        features, labels = packet["features"], packet["labels"]
        assert feature_digest(features) == provenance["feature_sha256"]
        for name, key in (("gt.npz", "gt_npz_sha256"), ("gt.json", "gt_metadata_sha256")):
            assert sha256(folder / name) == provenance[key]
        with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
            inventory = dict(saved)
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        mapped = map_experimental_atoms(
            arrays,
            json.loads((folder / "gt.json").read_text()),
            provenance["sequence"],
            provenance["sample_id"],
            inventory,
        )
        assert feature_digest(mapped) == feature_digest(labels)
        reference = features["ref_pos"].numpy()
        available = features["ref_mask"].numpy().astype(bool)
        target = labels["coordinate"].numpy()
        observed = labels["coordinate_mask"].numpy()
        result, indices, fitted = rigid_reference_floor(
            reference, target, observed, available, inventory["residue_id"]
        )
        path = output / f"{group}.npz"
        np.savez_compressed(
            path,
            **inventory,
            reference=reference,
            reference_mask=available,
            target=target,
            observed=observed,
            fitted_observed_indices=indices,
            fitted_observed_coordinate=fitted,
        )
        rows.append(
            {
                "group_id": group,
                "provenance": provenance,
                "reference_available_count": int(available.sum()),
                "all_observed_reference_available": bool(available[observed].all()),
                "artifact_sha256": sha256(path),
                **result,
            }
        )
        assert feature_digest(features) == provenance["feature_sha256"]
        del packet, features, labels
    assert len(rows) == 32
    atoms = sum(r["observed_atoms"] for r in rows)
    summary = {
        "groups": len(rows),
        "observed_atoms": atoms,
        "pooled_rigid_residue_floor": float(np.sqrt(sum(r["sse"] for r in rows) / atoms)),
        "macro_rigid_residue_floor": float(np.mean([r["rmsd"] for r in rows])),
        "max_protein_floor": max(r["rmsd"] for r in rows),
        "proteins_floor_gt_1": sum(r["rmsd"] > 1 for r in rows),
        "proteins_floor_gt_2": sum(r["rmsd"] > 2 for r in rows),
        "observed_residues": sum(len(r["residues"]) for r in rows),
    }
    source = Path(__file__).resolve().parents[1]
    names = (
        "scripts/diagnose_esmc_reference_shape.py",
        "src/fastglycan/reference_shape.py",
        "src/fastglycan/experimental_training.py",
        "src/fastglycan/experimental_metrics.py",
        "src/onestepfold/data/gt_materializer.py",
        "docs/esmc_reference_shape_diagnostic_v1.md",
        "tests/test_reference_shape.py",
    )
    write_json(
        output / "report.json",
        {
            "complete": True,
            "training_report_sha256": sha256(root / "report.json"),
            "summary": summary,
            "cases": rows,
            "source_sha256": {name: sha256(source / name) for name in names},
            "runtime": {
                "job_id": os.environ.get("SLURM_JOB_ID"),
                "step_id": os.environ.get("SLURM_STEP_ID"),
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
                "elapsed_seconds": time.monotonic() - started,
            },
            "scope": "GT-dependent rigid-residue lower bound; not inference or trained quality",
        },
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
