#!/usr/bin/env python3
"""Diagnose the saved FP32 output versus independent FP64 projection discrepancy."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from fastglycan.articulated_output import ArticulatedOutput
from fastglycan.articulated_validation import numpy_project
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    c=json.loads((a.root/'contract.json').read_text())
    assert c['arm']=='raw' or torch.cuda.is_available()
    report=json.loads((a.root/'report.json').read_text())
    assert sha256(a.root/'contract.json')==report['contract_sha256']
    data=Path(c['data_root'])
    checked=set(); adapters={}; failures=[]; maximum=0.; max_fp64=0.; max_gpu=0.; total=0
    for view in ('initial_validation','initial_train_probe','last_validation','best_validation','best_train_probe','best_full_train'):
        for row in report[view]['rows']:
            g=row['group_id']; path=a.root/row['prediction_path']
            assert sha256(path)==row['prediction_sha256']
            if (g,row['prediction_sha256']) in checked: continue
            checked.add((g,row['prediction_sha256']))
            if c['arm']=='raw':
                with np.load(path) as raw_file:
                    assert np.array_equal(raw_file['coordinate'],raw_file['raw_coordinate'])
                assert row['fallback_counts']==[0,0,0]
                total+=1
                continue
            folder=data/'examples'/g
            if g not in adapters:
                info=json.loads((folder/'prepared.json').read_text())
                with np.load(folder/'inventory.npz') as d: inv=dict(d)
                with np.load(folder/'reference.npz') as d: ref=d['reference']
                variants=json.loads((folder/'articulation_report.json').read_text())['variants']
                adapter=ArticulatedOutput(ref,inv['atom_name'],inv['residue_id'],info['selection']['sequence'],variants).float()
                assert feature_digest(adapter.state_dict())==info['adapter_sha256']
                adapters[g]=(adapter,inv)
            adapter,inv=adapters[g]
            with np.load(path) as d:
                raw=d['raw_coordinate'].copy(); saved=d['coordinate'].copy()
            oracle,counts=numpy_project(raw.astype(np.float64),adapter.double())
            assert counts.tolist()==row['fallback_counts']
            error=float(np.max(np.abs(saved-oracle))); maximum=max(maximum,error)
            with torch.no_grad():
                gpu=adapter.float().cuda()(torch.tensor(raw,device='cuda'))
                gpu_x=gpu['coordinate'].cpu().numpy()
                adapter.cpu()
            gpu_error=float(np.max(np.abs(saved-gpu_x))); max_gpu=max(max_gpu,gpu_error)
            assert gpu['fallback_counts'].tolist()==row['fallback_counts']
            if error>1e-4:
                with torch.no_grad():
                    cpu64=adapter.double()(torch.tensor(raw,dtype=torch.float64))['coordinate'].numpy()
                    cpu32=adapter.float()(torch.tensor(raw))['coordinate'].numpy()
                e64=float(np.max(np.abs(cpu64-oracle))); max_fp64=max(max_fp64,e64)
                atom=int(np.unravel_index(np.abs(saved-oracle).argmax(),saved.shape)[0])
                residue=int(inv['residue_id'][atom]); indices=np.flatnonzero(inv['residue_id']==residue)
                names=inv['atom_name'][indices].tolist(); local=raw[indices].astype(float)
                first=local[names.index('C')]-local[names.index('CA')]
                firstnorm=float(np.linalg.norm(first)); first/=firstnorm
                second=local[names.index('N')]-local[names.index('CA')]
                second-=np.dot(second,first)*first
                smallest=[]
                for group in adapter.groups:
                    for ix in group.indices.numpy():
                        if atom not in ix: continue
                        r=raw[ix].astype(float)
                        for b0,b1,p0,p1 in group.probes:
                            axis=r[b1]-r[b0]; axis/=np.linalg.norm(axis)
                            u=r[p0]-r[b0]; v=r[p1]-r[b1]
                            smallest.append(float(min(np.linalg.norm(u-u.dot(axis)*axis),np.linalg.norm(v-v.dot(axis)*axis))))
                failures.append({'view':view,'group_id':g,'noise':row['noise'],'prediction_path':row['prediction_path'],
                    'prediction_sha256':row['prediction_sha256'],'fp32_saved_vs_numpy64':error,
                    'torch64_vs_numpy64':e64,'gpu32_replay_max_abs':gpu_error,
                    'cpu32_vs_saved':float(np.max(np.abs(cpu32-saved))),
                    'atom':str(inv['atom_name'][atom]),'residue':residue,
                    'raw_extent':float(np.max(np.abs(raw))),'raw_C_CA_norm':firstnorm,
                    'raw_N_perpendicular_norm':float(np.linalg.norm(second)),
                    'min_raw_torsion_perpendicular_norm':min(smallest) if smallest else None})
            total+=1
            if total%100==0: print(json.dumps({'checked':total,'failures':len(failures),'max_error':maximum,'max_gpu_error':max_gpu}),flush=True)
    result={'complete':True,'root':str(a.root),'report_sha256':sha256(a.root/'report.json'),
            'audit_source_sha256':sha256(Path(__file__)), 'checked':total,'failures':failures,
            'legacy_threshold':1e-4,'legacy_all_pass':not failures,'max_saved_vs_numpy64':maximum,
            'max_gpu32_replay_error':max_gpu,'max_torch64_vs_numpy64_on_outliers':max_fp64,
            'gpu':torch.cuda.get_device_name(0) if c['arm']!='raw' else None,
            'replay_kind':'GPU FP32 projection' if c['arm']!='raw' else 'saved raw identity; worker checked GPU model reload'}
    write_json(a.output,result)
    print(json.dumps({k:v for k,v in result.items() if k!='failures'}),flush=True)


if __name__=='__main__': main()
