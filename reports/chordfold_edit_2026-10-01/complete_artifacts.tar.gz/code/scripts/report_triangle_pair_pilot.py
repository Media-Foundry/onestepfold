#!/usr/bin/env python3
"""Report the matched pointwise/triangle pilot only after full independent QA."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--baseline-archive", type=Path, required=True)
    parser.add_argument("--report-base", type=Path, required=True)
    args = parser.parse_args()
    current = json.loads((args.archive / "training/report.json").read_text())
    previous = json.loads((args.baseline_archive / "training/report.json").read_text())
    qa = json.loads((args.archive / "decoded/independent_validation.json").read_text())
    old_qa = json.loads((args.baseline_archive / "decoded/independent_validation.json").read_text())
    history = json.loads((args.archive / "training/history.json").read_text())
    old_history = json.loads((args.baseline_archive / "training/history.json").read_text())
    assert qa["complete"] and old_qa["complete"] and current["complete"]
    contract = current["contract"]
    lineage = contract["matched_baseline"]
    assert lineage["shared_initial_weights_sha256"] == previous["contract"][
        "initial_weights_sha256"]
    assert all(contract[k] == previous["contract"][k] for k in lineage["matched_fields"])
    new_by_id = {r["group_id"]: r for r in qa["examples"]}
    old_by_id = {r["group_id"]: r for r in old_qa["examples"]}
    assert new_by_id.keys() == old_by_id.keys()
    for group, row in new_by_id.items():
        for baseline in ("c1", "c2"):
            assert row["comparisons_to_c4"][baseline] == old_by_id[group][
                "comparisons_to_c4"][baseline]
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    for label, entries, style in (("Pointwise", old_history, "--"), ("Triangle", history, "-")):
        epochs = [r["epoch"] for r in entries]
        axes[0, 0].plot(epochs, [r["validation"]["macro_ratio"] for r in entries],
                        ls=style, label=label)
        axes[0, 1].plot(epochs[1:], [r["train_sampled_online_mse"] for r in entries[1:]],
                        ls=style, label=label)
    axes[0, 0].axhline(1, color="gray", lw=1)
    axes[0, 0].set(xlabel="Epoch", ylabel="Validation macro state MSE / c1 MSE",
                    title="Same data, loss, schedule and shared initialization")
    axes[0, 1].set(xlabel="Epoch", ylabel="Sampled online training MSE", title="Training fit")
    axes[0, 0].legend()
    axes[0, 1].legend()
    metrics = ("all_heavy_atom_rmsd", "ca_rmsd", "ca_pair_distance_rmse")
    summaries = [("c1", qa["summary"]["c1"]), ("c2", qa["summary"]["c2"]),
                 ("Pointwise", old_qa["summary"]["student"]),
                 ("Triangle", qa["summary"]["student"])]
    for index, (label, summary) in enumerate(summaries):
        axes[1, 0].bar(np.arange(3) + (index - 1.5) * .2,
                       [summary["pooled_" + key] for key in metrics], width=.2, label=label)
    axes[1, 0].set(xticks=np.arange(3), xticklabels=["All atoms", "CA", "CA distances"],
                    ylabel="Pooled error to c4 (angstrom)", title="All 64 held-out structures")
    axes[1, 0].legend(fontsize=8)
    x = [old_by_id[g]["comparisons_to_c4"]["student"]["all_heavy_atom_rmsd"] for g in new_by_id]
    y = [new_by_id[g]["comparisons_to_c4"]["student"]["all_heavy_atom_rmsd"] for g in new_by_id]
    scatter = axes[1, 1].scatter(x, y, c=[new_by_id[g]["length"] for g in new_by_id], s=24)
    top = max(x + y) * 1.05
    axes[1, 1].plot([0, top], [0, top], ls="--", color="gray", lw=1)
    axes[1, 1].set(xlabel="Pointwise all-atom RMSD (angstrom)",
                    ylabel="Triangle all-atom RMSD (angstrom)", title="Per-protein comparison")
    fig.colorbar(scatter, ax=axes[1, 1], label="Residues")
    fig.suptitle("One 16-channel shared-neighbor branch: 128 train / 64 validation")
    fig.savefig(args.report_base.with_suffix(".png"), dpi=180)
    plt.close(fig)
    improvement_counts = {key: sum(
        row["comparisons_to_c4"]["student"][key] < old_by_id[group][
            "comparisons_to_c4"]["student"][key]
        for group, row in new_by_id.items()) for key in metrics}
    ratios_to_pointwise = {key: qa["summary"]["student"]["pooled_" + key] /
                          old_qa["summary"]["student"]["pooled_" + key] for key in metrics}
    result = {"matched_shared_initialization": True, "matched_training_contract": True,
              "identical_64_group_native_references": True,
              "pooled_ratios_to_pointwise": ratios_to_pointwise,
              "better_than_pointwise_count": improvement_counts,
              "triangle_summary": qa["summary"], "pointwise_summary": old_qa["summary"]}
    args.report_base.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# Matched triangle pair-state pilot — 2026-09-18", "",
             "The 195,568-parameter model adds one 16-channel outgoing triangle branch "
             "to the 187,344-parameter pointwise baseline. Both use the same accepted 128/64 "
             "groups, shared initial weights, raw loss, optimizer, schedule and selection rule.",
             "Full decoding and independent state/atom/coordinate/lineage QA are complete.",
             "", "| Metric | c1 | c2 | Pointwise | Triangle | Triangle/c1 | Triangle/pointwise |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for key in metrics:
        values = [summary["pooled_" + key] for _, summary in summaries]
        values += [qa["summary"]["student_to_c1_pooled_ratios"][key], ratios_to_pointwise[key]]
        numbers = " | ".join(f"{value:.6f}" for value in values)
        lines.append(f"| Pooled {key} (A) | {numbers} |")
    state = current["selected_validation"]
    peak_gib = current['gpu_checks']['peak_allocated_bytes'] / 2**30
    lines += ["", f"Selected epoch **{current['best_epoch']}**; state-MSE macro/pooled ratios "
              f"**{state['macro_ratio']:.6f}/{state['pooled_ratio']:.6f}**. "
              "Identity epoch 0 was eligible.",
              "Joint <=0.95-of-c1 structure criterion: "
              f"**{qa['summary']['exploratory_learning_signal']}**. "
              f"C2 quality parity: **{qa['summary']['parity_with_c2']}**.", "",
              "Decision: this matched branch does not establish a structural improvement. "
              "Stop extending the pointwise/triangle raw-MSE configurations. Next verify "
              "frozen-decoder output gradients on training-only examples before specifying "
              "any decoder-output-supervised training. No architectural or loss sweep follows.", "",
              "Longest-input BF16 identity/forward/backward, finite nonzero triangle gradients, "
              "chunk/reload checks and shared initialization matching passed before training. "
              f"GPU check peak allocation: {peak_gib:.3f} GiB. "
              "Independent final QA reproduced all 64 learned pair tensors and c1 atom replays "
              "exactly, repeated selected-checkpoint state metrics, and verified all sources, "
              "lineage and coordinates. Cached decoding used two NFE and zero trunk calls.",
              "", "This is a teacher-relative Mini-ESM compatibility pilot, not experimental-GT "
              "validation or a latency benchmark. The formal 1,600 gate, ESMC-600M adaptation "
              "and eventual one structure evaluation remain unfinished. Do not infer a successful "
              "cycle saving or launch full-data training from state loss alone.", "",
              "HPC3 jobs: training 630661, decoder 630663_[0-3], final QA 630664. "
              "Immutable source `code_triangle_pair_v1_20260918`; outputs "
              "`triangle_pair_emulator_128x64_v1` and `triangle_pair_decoded_64_v1` "
              "under `/data/user/shuang886/Folding/stage1b/coordinate_refiner/`.", "",
              f"![Matched training and structural validation]({args.report_base.name}.png)", ""]
    args.report_base.with_suffix(".md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
