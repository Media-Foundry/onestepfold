#!/usr/bin/env python3
"""Describe observed local GT distances in an already accepted TRAIN32 cohort."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from fastglycan.paired_teacher_protocol import sha256, write_json
from onestepfold.data.gt_materializer import ATOM37_INDEX


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    root = args.root
    contract = json.loads((root / "contract.json").read_text())
    report = json.loads((root / "report.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert report["complete"] and qa["complete"] and qa["heavy_artifacts_checked"]
    assert sha256(root / "report.json") == qa["report_sha256"]
    assert sha256(root / "contract.json") == report["contract_sha256"]
    kinds = (
        ("N_CA", "N", "CA", 0),
        ("CA_C", "CA", "C", 0),
        ("C_O", "C", "O", 0),
        ("consecutive_C_N", "C", "N", 1),
    )
    values = {name: [] for name, *_ in kinds}
    provenance = []
    for record, source in zip(contract["selection"], contract["input_provenance"], strict=True):
        assert record["split"] == "train" and record["group_id"] == source["group_id"]
        path = root / record["group_id"] / "gt.npz"
        assert sha256(path) == source["gt_npz_sha256"]
        with np.load(path, allow_pickle=False) as saved:
            xyz = saved["atom37_positions"].astype(np.float64)
            mask = saved["atom37_mask"] & saved["residue_mask"][:, None]
        for name, left, right, offset in kinds:
            a, b = ATOM37_INDEX[left], ATOM37_INDEX[right]
            indices = np.arange(len(xyz) - offset)
            indices = indices[mask[indices, a] & mask[indices + offset, b]]
            distances = np.linalg.norm(xyz[indices, a] - xyz[indices + offset, b], axis=1)
            assert np.isfinite(distances).all()
            values[name].extend(distances.tolist())
        provenance.append({"group_id": record["group_id"], "gt_npz_sha256": sha256(path)})
    summary = {
        name: {
            "count": len(v),
            "mean": float(np.mean(v)),
            "median": float(np.median(v)),
            "std": float(np.std(v)),
            "minimum": min(v),
            "maximum": max(v),
        }
        for name, v in values.items()
    }
    source = Path(__file__).resolve().parents[1]
    names = ("scripts/diagnose_esmc_gt_distances.py", "src/onestepfold/data/gt_materializer.py")
    result = {
        "complete": True,
        "groups": len(provenance),
        "summary": summary,
        "input_provenance": provenance,
        "contract_sha256": sha256(root / "contract.json"),
        "accepted_report_sha256": sha256(root / "report.json"),
        "source_sha256": {n: sha256(source / n) for n in names},
        "scope": "Observed TRAIN GT distances only; no prediction, model or gate change",
    }
    write_json(args.output, result)
    for name in names:
        destination = args.output.with_suffix("") / "source" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, destination)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
