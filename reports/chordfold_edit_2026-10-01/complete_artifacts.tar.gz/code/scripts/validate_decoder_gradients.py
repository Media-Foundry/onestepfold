#!/usr/bin/env python3
"""Independently recompute saved gradient-audit scalars and learner predictions."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import torch

from fastglycan.decoder_gradients import select_gradient_records
from fastglycan.models.pair_state_factory import build_pair_state_model
from fastglycan.pair_state_cache import read_cache
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest, tensor_digest
from onestepfold.training.coordinate_refiner import group_id_digest


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-10), (actual, expected)


def mse(a, b):
    return float(np.mean(np.square(a.numpy().astype(np.float64) - b.numpy().astype(np.float64))))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.audit_root.resolve()
    report = json.loads((root / "audit.json").read_text())
    assert report["complete"] and len(report["examples"]) == 4
    cache = Path(report["cache_root"])
    _, records = read_cache(cache, accepted=True)
    selected = select_gradient_records(records)
    assert report["selection"] == [record.to_dict() for record in selected]
    assert report["selection_sha256"] == group_id_digest(selected)
    assert sha256(cache / "control/acceptance.json") == report["cache_acceptance_sha256"]
    acceptance = json.loads((cache / "control/acceptance.json").read_text())
    assert sha256(Path(report["checkpoint_path"])) == report["checkpoint_sha256"]
    assert report["checkpoint_sha256"] == acceptance["checkpoint_sha256"]
    assert sha256(root / "work/input.json") == report["input_sha256"]
    for name, digest in report["source_sha256"].items():
        assert sha256(args.code_root / name) == digest, name
    for name, digest in report["runtime_source_sha256"].items():
        assert sha256(Path(name)) == digest, name
    assert report["teacher_weights_before_sha256"] == report["teacher_weights_after_sha256"]
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    learners = {}
    for label, spec in report["learners"].items():
        parent = Path(spec["root"])
        assert sha256(parent / "report.json") == spec["report_sha256"]
        assert sha256(parent / "best.pt") == spec["checkpoint_sha256"]
        checkpoint = torch.load(parent / "best.pt", map_location="cpu", weights_only=False)
        model = build_pair_state_model(checkpoint["config"]).cuda().eval()
        model.load_state_dict(checkpoint["model"])
        learners[label] = model
    rows = []
    for record, row in zip(selected, report["examples"], strict=True):
        group = record.group_id
        assert record.split == "train" and row["group_id"] == group
        folder, native_folder = root / "examples" / group, cache / "examples" / group
        assert json.loads((folder / "result.json").read_text()) == row
        assert sha256(native_folder / "trace.json") == row["cache_trace_sha256"]
        assert row["cache_trace_sha256"] == acceptance["trace_sha256"][group]
        native = json.loads((native_folder / "trace.json").read_text())
        states = {}
        for label in ("c1", "c4"):
            path = native_folder / f"{label}.pt"
            assert sha256(path) == native["states"][label]["sha256"]
            states[label] = torch.load(path, map_location="cpu", weights_only=True)
        c1, c4 = states["c1"], states["c4"]
        for name, digest in row["artifact_sha256"].items():
            assert sha256(folder / name) == digest, (group, name)

        def load(name, folder=folder):
            return torch.load(folder / name, map_location="cpu", weights_only=False)

        packet, responses, gradient = load("packet.pt"), load("responses.pt"), load("gradient.pt")
        assert feature_digest(packet) == row["packet_sha256"]
        assert feature_digest(packet["input_feature_dict"]) == row["feature_sha256"]
        assert torch.equal(packet["s_inputs"], c1[0])
        assert torch.equal(packet["s_trunk"], c1[1])
        assert packet["t_hat_noise_level"].tolist() == row["noise_level"]
        assert tuple(gradient.shape) == tuple(c1[2].shape)
        assert tensor_digest(gradient) == row["gradient"]["tensor_sha256"]
        assert torch.isfinite(gradient).all() and float(gradient.norm()) > 0
        # GPU float32 norm reduction may differ slightly; recompute in float64.
        assert math.isclose(float(gradient.double().norm()), row["gradient"]["norm"], rel_tol=1e-5)
        close(mse(load("gradient_response.pt"), responses["oracle_pair"]), row["gradient"]["loss"])
        torch.testing.assert_close(
            load("gradient_response.pt"), responses["c1"], atol=1e-5, rtol=1e-5
        )
        assert row["gradient"]["teacher_parameter_gradients_none"]
        for label, response in responses.items():
            assert torch.isfinite(response).all()
            capture = row["captures"][label]
            assert tensor_digest(response) == capture["response_sha256"]
            assert capture["decoder_nfe"] == 2 and capture["trunk_calls"] == 0
            assert capture["trace"][1]["explicit_seed"] == 12345
            assert (
                capture["trace"][1]["rng_at_sampler_entry"]
                == native["conditions"]["c1"]["trace"][1]["rng_at_sampler_entry"]
            )
            with (
                np.load(folder / f"{label}_sampler.npz") as saved,
                np.load(native_folder / "c1.npz") as original,
            ):
                assert saved["coordinate"].shape == (row["atom_count"], 3)
                assert np.isfinite(saved["coordinate"]).all()
                for key in ("atom_name", "residue_id", "element"):
                    assert np.array_equal(saved[key], original[key])
                if label == "c1":
                    assert np.array_equal(saved["coordinate"], original["coordinate"])
        predictions = load("learned_pairs.pt")
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            for label, learner in learners.items():
                predicted = learner.predict_full(c1[1].cuda(), c1[2].cuda()).cpu()
                assert torch.equal(predicted, predictions[label])
        updates = {"raw_state_target": c4[2].float() - c1[2].float()}
        updates.update({key: value.float() - c1[2].float() for key, value in predictions.items()})
        g = gradient.numpy().astype(np.float64)
        gnorm = np.linalg.norm(g.ravel())
        for label, update in updates.items():
            d = update.numpy().astype(np.float64)
            norm, dot = np.linalg.norm(d.ravel()), np.sum(g * d)
            spec = row["directions"][label]
            close(float(norm), spec["update_norm"])
            close(float(dot), spec["directional_derivative"])
            close(float(-dot / (gnorm * norm)), spec["cosine_with_negative_gradient"])
        for probe in row["finite_differences"]:
            step = probe["step"]
            values = load(f"probe_{step}.pt")
            losses = {key: mse(value, responses["oracle_pair"]) for key, value in values.items()}
            for key, value in losses.items():
                close(value, probe["losses"][key])
            direction = (-gradient.double() / gradient.double().norm()).float()
            analytic = float(np.sum(g * direction.numpy().astype(np.float64)))
            numerical = (losses["plus"] - losses["minus"]) / (2 * step)
            close(analytic, probe["analytic"])
            close(numerical, probe["numerical"])
            close(abs(numerical - analytic) / abs(analytic), probe["relative_error"])
            rounded = (c1[2].float() + step * direction).bfloat16()
            close(float((rounded != c1[2]).float().mean()), probe["rounded_changed_fraction"])
        if row["finite_differences"]:
            assert row["finite_difference_passed"]
            assert min(p["relative_error"] for p in row["finite_differences"]) <= 0.05
        rows.append(
            {
                "group_id": group,
                "length": record.sequence_length,
                "all_artifacts_and_scalars_pass": True,
                "learner_predictions_exact": True,
            }
        )
        print(json.dumps(rows[-1]), flush=True)
    write_json(
        root / "independent_validation.json",
        {
            "complete": True,
            "audit_sha256": sha256(root / "audit.json"),
            "validator_sha256": sha256(Path(__file__)),
            "examples": rows,
            "scope": "artifact and lineage checks, independent saved-scalar recomputation, "
            "exact learned pair recomputation; no second decoder backward",
        },
    )


if __name__ == "__main__":
    main()
