#!/usr/bin/env python3
"""Wait for the existing final report, then submit the separately locked CPU plot."""

import argparse
import fcntl
import json
import shlex
import subprocess
import time
from pathlib import Path


def ssh(args):
    return subprocess.check_output(["ssh", "hpc3", shlex.join(args)], text=True)


def state(job):
    output = ssh(["sacct", "-n", "-P", "-X", "-j", str(job), "--format=JobIDRaw,State,ExitCode"])
    rows = [line.split("|") for line in output.splitlines() if line.strip()]
    if not rows:
        return "MISSING"
    assert len(rows) == 1 and rows[0][0] == str(job)
    value = rows[0][1].split()[0].rstrip("+")
    if value == "COMPLETED":
        assert rows[0][2] == "0:0", output
    assert value in ("MISSING", "COMPLETED", "PENDING", "RUNNING", "CONFIGURING", "COMPLETING", "SUSPENDED"), output
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--preflight", type=int, required=True)
    parser.add_argument("--plot-script", default="plot.sh")
    args = parser.parse_args()
    root = "/data/user/shuang886/Folding/esmc_raw_warmstart_v1_20260926"
    guard = (args.archive / "plot_controller.lock").open("w")
    fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
    record = args.archive / "plot_jobs.json"
    jobs = json.loads(record.read_text()) if record.exists() else {"preflight": args.preflight}
    assert jobs["preflight"] == args.preflight
    while True:
        try:
            main_jobs = json.loads((args.archive / "jobs.json").read_text())
            lifecycle = json.loads((args.archive / "lifecycle_status.json").read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(45)
            continue
        assert not lifecycle.get("failed"), "Parent pipeline failed; inspect before proceeding"
        preflight_state = state(args.preflight)
        report = main_jobs.get("report")
        report_state = state(report) if report else "NOT_SUBMITTED"
        plot_state = state(jobs["plot"]) if "plot" in jobs else "NOT_SUBMITTED"
        jobs.update(preflight_state=preflight_state, report_job=report, report_state=report_state, plot_state=plot_state)
        record.write_text(json.dumps(jobs, indent=2) + "\n")
        print(json.dumps(jobs), flush=True)
        if plot_state == "COMPLETED":
            subprocess.run(["rsync", "-a", f"hpc3:{root}/curves_v1/", str(args.archive / "execution/curves_v1") + "/"], check=True)
            return
        if "plot" not in jobs and preflight_state == report_state == "COMPLETED":
            queue = ssh(["squeue", "-h", "-u", "shuang886", "-o", "%P"])
            if sum(line.strip() == "debug" for line in queue.splitlines()) < 5:
                prior = ssh(["sacct", "-n", "-P", "-X", "-u", "shuang886", "--starttime=2026-09-26", "--name=rwarm_final_curves", "--format=JobIDRaw,State"])
                assert not prior.strip(), "Ambiguous prior plot submission: " + prior
                jobs["plot"] = int(ssh(["sbatch", "--parsable", "--output=" + root + "/plot-%j.out", root + "/" + args.plot_script]).strip().split(";")[0])
                jobs["plot_script"] = args.plot_script
                record.write_text(json.dumps(jobs, indent=2) + "\n")
                print(json.dumps({"plot_submitted": jobs["plot"]}), flush=True)
        time.sleep(45)


if __name__ == "__main__":
    main()
