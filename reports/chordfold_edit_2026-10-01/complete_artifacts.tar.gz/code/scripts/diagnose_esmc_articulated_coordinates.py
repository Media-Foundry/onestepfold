#!/usr/bin/env python3
"""Separate remaining residue-shape error from GT-dependent pose correction."""

from __future__ import annotations

import argparse
import json
import shutil
from collections import defaultdict
from pathlib import Path

import numpy as np

from fastglycan.coordinate_diagnostics import residue_error_decomposition
from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.reference_shape import rigid_reference_floor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--references", type=Path, required=True)
    parser.add_argument("--inverse-fit", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    assert not (root / "articulated_shape_diagnostic.json").exists()
    report = json.loads((root / "report.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    contract = json.loads((root / "contract.json").read_text())
    assert report["complete"] and qa["complete"] and qa["heavy_artifacts_checked"]
    assert sha256(root / "report.json") == qa["report_sha256"]
    assert sha256(root / "contract.json") == report["contract_sha256"]
    assert contract["output_adapter"] == "articulated_output_v1"
    references = json.loads((args.references / "report.json").read_text())
    inverse_fit = json.loads((args.inverse_fit / "report.json").read_text())
    inverse_qa = json.loads((args.inverse_fit / "independent_validation.json").read_text())
    assert sha256(args.references / "report.json") == (
        "40909d6dee6f23e5b8f2e0abb542922dafa97e3ff1068324c888e05c54f597e4"
    )
    assert (
        sha256(args.inverse_fit / "report.json")
        == inverse_qa["report_sha256"]
        == ("8f3c5bb84e265641eb3649a1828b0f753d8f3173c9ffb13e06d0ba7b8ef640e8")
    )
    assert inverse_qa["complete"]
    original_refs = {r["group_id"]: r for r in references["cases"]}
    conditions = {}
    for seed in ("12345", "54321"):
        rows = []
        amino_acids = defaultdict(lambda: {"atoms": 0, "pose_adjusted_sse": 0.0})
        originals = report["best"]["conditions"][seed]["examples"]
        for provenance, row in zip(contract["input_provenance"], originals, strict=True):
            group = provenance["group_id"]
            assert group == row["group_id"] and provenance["split"] == "train"
            assert provenance == original_refs[group]["provenance"]
            folder = root / group
            path = folder / f"best_{seed}.npz"
            assert sha256(path) == row["prediction_sha256"]
            assert sha256(folder / "gt.npz") == provenance["gt_npz_sha256"]
            assert sha256(folder / "gt.json") == provenance["gt_metadata_sha256"]
            with np.load(path, allow_pickle=False) as data:
                predicted = data["coordinate"].astype(np.float64)
                inventory = {k: data[k] for k in ("atom_name", "residue_id", "element")}
            with np.load(folder / "inventory.npz", allow_pickle=False) as data:
                assert all(np.array_equal(data[k], v) for k, v in inventory.items())
            with np.load(folder / "gt.npz", allow_pickle=False) as data:
                arrays = dict(data)
            labels = map_experimental_atoms(
                arrays,
                json.loads((folder / "gt.json").read_text()),
                provenance["sequence"],
                provenance["sample_id"],
                inventory,
            )
            target, mask = labels["coordinate"].numpy(), labels["coordinate_mask"].numpy()
            shape = residue_error_decomposition(predicted, target, mask, inventory["residue_id"])
            fit, indices, fitted = rigid_reference_floor(
                predicted, target, mask, np.ones_like(mask), inventory["residue_id"]
            )
            assert fit["observed_atoms"] == shape["atoms"]
            actual = np.sqrt(shape["total_sse"] / shape["atoms"])
            assert abs(actual - row["metrics"]["all_heavy_atom_rmsd"]) <= 2e-5
            reduction = shape["total_sse"] - fit["sse"]
            assert reduction >= -1e-7
            artifact = folder / f"pose_adjusted_observed_{seed}.npz"
            np.savez_compressed(artifact, observed_indices=indices, coordinate=fitted)
            for residue in fit["residues"]:
                amino = provenance["sequence"][residue["residue_id"] - 1]
                amino_acids[amino]["atoms"] += residue["observed_atoms"]
                amino_acids[amino]["pose_adjusted_sse"] += residue["sse"]
            rows.append(
                {
                    "group_id": group,
                    "prediction_sha256": row["prediction_sha256"],
                    "diagnostic_coordinate_sha256": sha256(artifact),
                    "global_shape": shape,
                    "independent_residue_pose_fit": fit,
                    "sse_reduction_from_free_poses": reduction,
                }
            )
        count = sum(r["global_shape"]["atoms"] for r in rows)
        global_sse = sum(r["global_shape"]["total_sse"] for r in rows)
        local_sse = sum(r["independent_residue_pose_fit"]["sse"] for r in rows)
        assert count == references["summary"]["observed_atoms"] == 30437
        for values in amino_acids.values():
            values["pose_adjusted_rmsd"] = float(
                np.sqrt(values["pose_adjusted_sse"] / values["atoms"])
            )
        conditions[seed] = {
            "summary": {
                "observed_atoms": count,
                "pooled_atom_rmsd": float(np.sqrt(global_sse / count)),
                "pooled_pose_adjusted_residue_rmsd": float(np.sqrt(local_sse / count)),
                "fraction_sse_remaining_after_free_poses": local_sse / global_sse
                if global_sse
                else 0.0,
                "pooled_centroid_error": float(
                    np.sqrt(sum(r["global_shape"]["centroid_error_sse"] for r in rows) / count)
                ),
                "pooled_centered_internal_error": float(
                    np.sqrt(
                        sum(r["global_shape"]["internal_shape_error_sse"] for r in rows) / count
                    )
                ),
            },
            "by_amino_acid": dict(amino_acids),
            "examples": rows,
        }
    source = Path(__file__).resolve().parents[1]
    sources = {}
    for name in (
        "scripts/diagnose_esmc_articulated_coordinates.py",
        "src/fastglycan/reference_shape.py",
        "src/fastglycan/coordinate_diagnostics.py",
        "src/fastglycan/experimental_training.py",
        "docs/esmc_articulated_shape_diagnostic_v1.md",
    ):
        dest = root / "source/shape_diagnostic" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, dest)
        sources[name] = sha256(dest)
    result = {
        "complete": True,
        "training_report_sha256": sha256(root / "report.json"),
        "training_qa_sha256": sha256(root / "independent_validation.json"),
        "reference_report_sha256": sha256(args.references / "report.json"),
        "inverse_fit_report_sha256": sha256(args.inverse_fit / "report.json"),
        "reference_rigid_floor": references["summary"]["pooled_rigid_residue_floor"],
        "reference_articulated_attained_fit": inverse_fit["summary"]["pooled_attained_rmsd"],
        "conditions": conditions,
        "source_sha256": sources,
        "scope": "GT-dependent pose correction of final predictions; no inference/gradient claim",
    }
    write_json(root / "articulated_shape_diagnostic.json", result)
    lines = [
        "# Selected articulated-output coordinate diagnosis",
        "",
        f"Selected epoch: {report['best_epoch']}. Training and independent heavy CPU QA "
        "are complete. These are 32 training proteins, not a held-out evaluation.",
        "",
        "Each predicted residue is fitted independently to its observed experimental atoms "
        "using a proper rigid transform. This changes its pose while preserving its internal "
        "shape. The resulting error is a GT-dependent diagnostic, not a folding prediction.",
        "",
        "| Metric | Seed 12345 | Seed 54321 |",
        "| --- | ---: | ---: |",
    ]
    for label, key in (
        ("Global atom RMSD (Å)", "pooled_atom_rmsd"),
        ("Residue centroid error after global alignment (Å)", "pooled_centroid_error"),
        ("Centered internal error after global alignment (Å)", "pooled_centered_internal_error"),
        ("Residual RMSD after independent residue poses (Å)", "pooled_pose_adjusted_residue_rmsd"),
        (
            "Fraction of global SSE remaining after independent poses",
            "fraction_sse_remaining_after_free_poses",
        ),
    ):
        values = [conditions[seed]["summary"][key] for seed in ("12345", "54321")]
        lines.append(f"| {label} | {values[0]:.6f} | {values[1]:.6f} |")
    lines.extend(
        [
            "",
            "Centered internal error includes orientation error; it is different from the "
            "residual after fitting each residue's orientation. The SSE reduction from free "
            "poses measures available pose correction, not a physical energy decomposition "
            "or attribution of model gradients. Independent poses do not enforce "
            "chain connectivity.",
            "",
            f"For the same observed atoms, the accepted cached rigid-reference floor is "
            f"{result['reference_rigid_floor']:.6f} Å. The articulated numerical inverse fit "
            f"attained {result['reference_articulated_attained_fit']:.6f} Å; that attained "
            "error is not a proven global lower bound. Neither result establishes learnability.",
            "",
            "| Amino acid | Observed atoms | Pose-adjusted RMSD, seed 12345 (Å) | "
            "Pose-adjusted RMSD, seed 54321 (Å) |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    for amino in sorted(conditions["12345"]["by_amino_acid"]):
        first = conditions["12345"]["by_amino_acid"][amino]
        second = conditions["54321"]["by_amino_acid"][amino]
        assert first["atoms"] == second["atoms"]
        lines.append(
            f"| {amino} | {first['atoms']} | {first['pose_adjusted_rmsd']:.6f} | "
            f"{second['pose_adjusted_rmsd']:.6f} |"
        )
    lines.extend(
        [
            "",
            "Per-protein results, coordinate hashes and actual source hashes: "
            "[diagnostic JSON](articulated_shape_diagnostic.json). "
            "Only observed atoms are saved in the pose-adjusted coordinate artifacts.",
        ]
    )
    (root / "articulated_shape_diagnostic.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({seed: r["summary"] for seed, r in conditions.items()}, indent=2))


if __name__ == "__main__":
    main()
