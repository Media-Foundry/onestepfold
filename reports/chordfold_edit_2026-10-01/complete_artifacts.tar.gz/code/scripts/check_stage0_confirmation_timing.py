#!/usr/bin/env python3
"""Compare baseline replay variation with instrumentation without changing the sampler."""

import argparse
import copy
import json
from pathlib import Path

import numpy as np
import torch

from fastglycan.paired_teacher_protocol import write_json
from fastglycan.stage0_confirm_runtime import SETTINGS, Trace, predict, runner_setup


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    prep = json.loads((root / "repeat/preparation.json").read_text())
    group = min(prep["packets"], key=lambda g: prep["packets"][g]["length"])
    packet = torch.load(root / "repeat/packets" / (group + ".pt"), weights_only=False)
    runner = runner_setup(root / "timing_diagnostic_work")
    report = {"group_id": group, "settings": {}}
    for setting in SETTINGS:
        coords = {}
        for label in ("warmup", "plain1", "plain2", "hook1", "hook2"):
            if label.startswith("hook"):
                with Trace(runner.model) as trace:
                    pred, xyz, record = predict(runner, packet["data"], setting, 103, trace)
            else:
                pred, xyz, record = predict(runner, packet["data"], setting, 103, None)
            coords[label] = xyz.copy()
            del pred
        comparisons = {}
        for x, y in (("plain1", "plain2"), ("plain2", "hook1"), ("hook1", "hook2")):
            delta = coords[x] - coords[y]
            comparisons[x + "_" + y] = {
                "max_abs": float(np.abs(delta).max()),
                "rms": float(np.sqrt((delta * delta).mean())),
                "exact": bool(np.array_equal(coords[x], coords[y])),
            }
        report["settings"][setting] = {"comparisons": comparisons, "trace": copy.deepcopy(record)}
        np.savez_compressed(root / ("timing_diagnostic_" + setting + ".npz"), **coords)
        write_json(root / "timing_diagnostic.json", report)
        print(json.dumps(report["settings"][setting]), flush=True)


if __name__ == "__main__":
    main()
