#!/usr/bin/env python3
"""Plot independently validated training-only component interventions."""
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-root", type=Path, required=True)
    parser.add_argument("--report-base", type=Path, required=True)
    args = parser.parse_args()
    report = json.loads((args.audit_root / "independent_validation.json").read_text())
    assert report["complete"]
    rows, summary = report["examples"], report["summary"]
    labels = ["identity", "student", "oracle_pair", "oracle_global", "oracle_additive",
              "oracle_interaction", "student_additive", "student_interaction",
              "oracle_interaction_student_additive", "oracle_additive_student_interaction"]
    names = ["c1", "Learned", "Oracle pair", "Oracle global", "Oracle A", "Oracle I",
             "Learned A", "Learned I", "Learned A + oracle I", "Oracle A + learned I"]
    components = ("global", "row", "column", "interaction")
    diagnostics = {
        "median_target_energy_fraction": {key: statistics.median(
            r["components"][key]["target_fraction"] for r in rows) for key in components},
        "median_component_error_ratio": {key: statistics.median(
            r["components"][key]["error_ratio"] for r in rows) for key in components},
        "median_component_cosine": {key: statistics.median(
            r["components"][key]["cosine"] for r in rows) for key in components},
    }
    args.report_base.with_suffix(".json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    fig, axes = plt.subplots(2, 2, figsize=(14, 10), constrained_layout=True)
    x = np.arange(len(labels))
    for offset, metric, name in ((-0.18, "raw_pair_mse", "Raw z MSE"),
                                 (0.18, "conditioned_pair_mse", "Decoder pair_z MSE")):
        axes[0, 0].barh(x + offset, [summary[k]["macro_ratio_" + metric] for k in labels],
                        height=0.35, label=name)
    axes[0, 0].set(yticks=x, yticklabels=names, xlabel="Mean per-protein error ratio to c1",
                    title="State error and actual decoder conditioning")
    axes[0, 0].invert_yaxis()
    axes[0, 0].axvline(1, color="gray", ls="--", lw=1)
    axes[0, 0].legend(fontsize=8)
    for offset, metric, name in ((-0.18, "all_heavy_atom_rmsd", "All-atom RMSD"),
                                 (0.18, "ca_pair_distance_rmse", "CA-distance RMSE")):
        baseline = summary["identity"]["pooled_" + metric]
        axes[0, 1].barh(x + offset, [summary[k]["pooled_" + metric] / baseline for k in labels],
                        height=0.35, label=name)
    axes[0, 1].set(yticks=x, yticklabels=names, xlabel="Pooled structure error ratio to c1",
                    title="Frozen-decoder all-atom and internal geometry")
    axes[0, 1].invert_yaxis()
    axes[0, 1].axvline(1, color="gray", ls="--", lw=1)
    axes[0, 1].legend(fontsize=8)
    positions = np.arange(len(rows))
    bottom = np.zeros(len(rows))
    for component in components:
        values = np.array([r["components"][component]["target_fraction"] for r in rows])
        axes[1, 0].bar(positions, values, bottom=bottom, label=component)
        bottom += values
    axes[1, 0].set(xticks=positions, xticklabels=[r["length"] for r in rows],
                    xlabel="Training protein length", ylabel="Fraction of target residual energy",
                    title="Where c4-c1 pair-state change resides")
    axes[1, 0].legend(fontsize=8)
    for index, key in enumerate(components):
        values = [r["components"][key]["error_ratio"] for r in rows]
        axes[1, 1].scatter(np.full(len(values), index), values, s=25)
    axes[1, 1].axhline(1, color="gray", ls="--", lw=1)
    axes[1, 1].set(xticks=np.arange(4), xticklabels=components,
                    ylabel="Learned component error / c1 component error",
                    title="Remaining component error on training examples")
    fig.suptitle("Training-only component controls; oracle interventions are not learned models")
    fig.savefig(args.report_base.with_suffix(".png"), dpi=160)
    plt.close(fig)
    lines = ["# Pair-component and decoder-response audit — 2026-09-18", "",
             "Eight fixed training-only examples; eleven conditions and independent "
             "component/cache/atom validation are complete. No new model was trained.", "",
             "The learned correction lowers both raw state error and actual decoder-conditioning "
             "error, while its pooled all-atom improvement is small. Replacing only the target "
             "interaction component yields a much larger structural change. This argues against "
             "treating decoder normalization alone as the missing fix; it motivates testing "
             "pair-specific relational information without establishing a learnable remedy.", "",
             "A is the global + row + column additive residual; I is the remaining "
             "ordered-pair interaction. Conditions retain c1 singles except native c4 replay.",
             "Oracle and hybrid conditions use target information and are diagnostic only.", "",
             "| Condition | Raw state MSE ratio* | Decoder pair_z MSE ratio* | "
             "Pooled all-atom RMSD (A) | Pooled CA-distance error (A) | All-atom improves / 8 |",
             "|---|---:|---:|---:|---:|---:|"]
    for label, name in zip(labels, names, strict=True):
        s = summary[label]
        lines.append(f"| {name} | {s['macro_ratio_raw_pair_mse']:.4f} | "
                     f"{s['macro_ratio_conditioned_pair_mse']:.4f} | "
                     f"{s['pooled_all_heavy_atom_rmsd']:.4f} | "
                     f"{s['pooled_ca_pair_distance_rmse']:.4f} | "
                     f"{s['better_than_c1_all_heavy_atom_rmsd_count']} |")
    lines += ["", "*Mean of per-protein MSE ratios relative to c1; structure columns are pooled.",
              f"Native c2 reference: all-atom {summary['c2']['pooled_all_heavy_atom_rmsd']:.4f} A, "
              f"CA-distance {summary['c2']['pooled_ca_pair_distance_rmse']:.4f} A.", "",
              "| Component | Median target energy fraction | Median remaining MSE ratio | "
              "Median predicted/target cosine |", "|---|---:|---:|---:|"]
    for key in components:
        lines.append(f"| {key} | {diagnostics['median_target_energy_fraction'][key]:.4f} | "
                     f"{diagnostics['median_component_error_ratio'][key]:.4f} | "
                     f"{diagnostics['median_component_cosine'][key]:.4f} |")
    lines += ["", "The frozen conditioning operation was reconstructed independently from "
              "the same deterministic features. All 88 actual `pair_z` cache hashes match, "
              "all eight learned pair predictions and component compositions match, and "
              "native c1/c4 coordinates replay exactly. All conditions use two decoder NFE "
              "and zero trunk-stack calls; all atom identities/source/artifact hashes and "
              "coordinate metrics pass QA.", "",
              "This diagnostic does not establish a learnable remedy or a quality/latency "
              "gain. It uses eight training examples and target-aware state replacements. "
              "Keep the earlier 64-validation negative result and the temporal test frozen. "
              "The original ESMC-600M, MSA-free all-heavy-atom, eventual one-cycle and "
              "one-structure-evaluation objective remains unfinished.", "",
              "HPC3: audit 630609_[0-3], independent validation 630632. The initial QA 630623 "
              "stopped because relp must be generated inside the model preprocessing; the "
              "corrected independent validator uses the same generate_relp function. Predictions "
              "were not rerun or overwritten. Immutable sources "
              "`code_pair_components_v1_20260918` / `code_pair_components_validation_v2_20260918`; "
              "output `pair_component_audit_v1_20260918`, all under coordinate_refiner.", "",
              f"![Component and decoder audit]({args.report_base.name}.png)", ""]
    args.report_base.with_suffix(".md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
