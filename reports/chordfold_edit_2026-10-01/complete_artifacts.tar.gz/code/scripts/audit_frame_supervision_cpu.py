#!/usr/bin/env python3
"""CPU loss/gradient audit on already accepted capacity predictions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from fastglycan.experimental_training import map_experimental_atoms
from fastglycan.frame_supervision import build_frame_labels, local_frame_mse, training_sampler_seed
from fastglycan.paired_teacher_protocol import sha256, write_json
from fastglycan.teacher_pairing import feature_digest


def numpy_frame_loss(prediction, supervision):
    indices = supervision["frame_atoms"].numpy()
    rows, points = supervision["frame_rows"].numpy(), supervision["point_indices"].numpy()
    x = np.asarray(prediction, np.float64)
    n, ca, c = [x[indices[:, j]] for j in range(3)]
    e1 = c - ca
    e1 /= np.maximum(np.linalg.norm(e1, axis=-1, keepdims=True), supervision["epsilon"])
    e2 = n - ca
    e2 -= (e2 * e1).sum(-1, keepdims=True) * e1
    e2 /= np.maximum(np.linalg.norm(e2, axis=-1, keepdims=True), supervision["epsilon"])
    axes = np.stack([e1, e2, np.cross(e1, e2)], axis=1)
    local = np.einsum("pij,pj->pi", axes[rows], x[points] - ca[rows])
    return float(np.mean(np.sum((local - supervision["target_local"].numpy()) ** 2, axis=-1)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--capacity-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    torch.set_num_threads(1)
    root = args.capacity_root
    contract = json.loads((root / "contract.json").read_text())
    report = json.loads((root / "report.json").read_text())
    qa = json.loads((root / "independent_validation.json").read_text())
    assert qa["complete"] and qa["report_sha256"] == sha256(root / "report.json")
    selected = contract["selection"]
    seeds = [
        training_sampler_seed(r["group_id"], epoch) for r in selected for epoch in range(1, 101)
    ]
    assert len(seeds) == len(set(seeds)) == 3200
    assert not set(seeds).intersection((12345, 54321))
    rows, max_error = [], 0.0
    for i, (record, provenance) in enumerate(
        zip(selected, contract["input_provenance"], strict=True)
    ):
        group = record["group_id"]
        folder = root / group
        assert sha256(folder / "gt.npz") == provenance["gt_npz_sha256"]
        assert sha256(folder / "gt.json") == provenance["gt_metadata_sha256"]
        with np.load(folder / "gt.npz", allow_pickle=False) as saved:
            arrays = dict(saved)
        with np.load(folder / "inventory.npz", allow_pickle=False) as saved:
            inventory = dict(saved)
        metadata = json.loads((folder / "gt.json").read_text())
        labels = map_experimental_atoms(
            arrays, metadata, record["sequence"], record["sample_id"], inventory
        )
        supervision = build_frame_labels(labels, inventory)
        result = {
            "group_id": group,
            "frames": len(supervision["frame_atoms"]),
            "frame_point_pairs": len(supervision["frame_rows"]),
            "supervision_sha256": feature_digest(supervision),
            "conditions": {},
        }
        for condition in ("initial", "best", "second_seed"):
            path = folder / f"{condition}_prediction.npz"
            assert sha256(path) == report[condition]["examples"][i]["prediction_sha256"]
            with np.load(path, allow_pickle=False) as saved:
                xyz = saved["coordinate"].astype(np.float64)
            prediction = torch.from_numpy(xyz).requires_grad_()
            loss = local_frame_mse(prediction, supervision)
            (gradient,) = torch.autograd.grad(loss, prediction)
            assert torch.isfinite(gradient).all() and gradient.norm() > 0
            assert gradient[~labels["coordinate_mask"]].count_nonzero() == 0
            independent = numpy_frame_loss(xyz, supervision)
            error = abs(float(loss) - independent)
            max_error = max(max_error, error)
            assert error < 1e-8
            values = {
                "frame_mse": float(loss),
                "coordinate_gradient_norm": float(gradient.norm()),
                "numpy_fp64_mse": independent,
                "prediction_sha256": sha256(path),
            }
            if i == 0 and condition == "best":
                direction = -gradient / gradient.square().sum(-1).mean().sqrt()
                epsilon = 1e-5
                plus = local_frame_mse(prediction.detach() + epsilon * direction, supervision)
                minus = local_frame_mse(prediction.detach() - epsilon * direction, supervision)
                finite_difference = float((plus - minus) / (2 * epsilon))
                exact = float((gradient * direction).sum())
                relative = abs(finite_difference - exact) / max(abs(exact), 1e-10)
                assert relative < 1e-3 and plus < loss
                values["directional_derivative"] = {
                    "epsilon_rms_angstrom": epsilon,
                    "autograd": exact,
                    "finite_difference": finite_difference,
                    "relative_error": relative,
                    "negative_gradient_step_decreases_scalar": True,
                }
            result["conditions"][condition] = values
        rows.append(result)
    source = Path(__file__).resolve().parents[1]
    names = (
        "scripts/audit_frame_supervision_cpu.py",
        "src/fastglycan/frame_supervision.py",
        "docs/esmc_frame_supervision_audit_v1.md",
    )
    write_json(
        args.output,
        {
            "complete": True,
            "groups": 32,
            "conditions": 3,
            "examples": rows,
            "max_numpy_absolute_error": max_error,
            "unique_training_seeds": len(set(seeds)),
            "training_seed_sha256": feature_digest(seeds),
            "capacity_report_sha256": sha256(root / "report.json"),
            "source_sha256": {n: sha256(source / n) for n in names},
            "scope": "CPU proposed loss/gradient/RNG audit; no training or new GPU forwards",
        },
    )
    print(
        json.dumps(
            {
                "complete": True,
                "max_numpy_absolute_error": max_error,
                "short_best": rows[0]["conditions"]["best"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
