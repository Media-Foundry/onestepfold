import os,subprocess,time,json,hashlib
from pathlib import Path
base=Path('/media/IntelSSD/onestepfold/hpc3_mirror_20261001/Folding')
root=base/'chordfold_edit_pilot_v1_20261001';virtual=Path('/data/user/shuang886/Folding')/root.name
py='/home/pc/anaconda3/envs/fold/bin/python'
proot='/media/IntelSSD/onestepfold/diamondhill_migration_20261001/tools/proot/usr/bin/proot'
def write(name,value):(root/name).write_text(json.dumps(value,indent=2)+'\n')
# Add finalized CPU scoring code to the pre-inference lock; preserve earlier preparation manifest.
lock=json.loads((root/'lock.json').read_text());write('preparation_lock.json',lock)
for p in (root/'code').rglob('*'):
 if p.is_file() and p.suffix in ['.py','.json','.md']:
  lock['code_hashes'][str(virtual/'code'/p.relative_to(root/'code'))]=hashlib.sha256(p.read_bytes()).hexdigest()
write('lock.json',lock)
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LAYERNORM_TYPE='torch',PROTENIX_ROOT_DIR='/data/user/shuang886/Folding/protenix_stage0_pkg/v1_1/runtime',PYTHONPATH=f'{virtual}/code/src:{virtual}/code/scripts')
prefix=[proot,'-b',str(base)+':/data/user/shuang886/Folding',py,'-u']
handles=[];processes=[];started=time.time()
for i,gpu in enumerate([0,2,4,6]):
 e=dict(env,HIP_VISIBLE_DEVICES=str(gpu),CUDA_VISIBLE_DEVICES=str(gpu))
 log=open(root/f'worker_{i}.log','w')
 p=subprocess.Popen(prefix+[str(virtual/'code/scripts/run_chordfold_edit_pilot.py'),'--root',str(virtual),'--mode','run','--index',str(i)],env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 processes.append(p);handles.append(dict(index=i,gcd=gpu,pid=p.pid))
write('handles.json',dict(controller_pid=os.getpid(),workers=handles,started=started,lock_sha256=hashlib.sha256((root/'lock.json').read_bytes()).hexdigest()))
while any(p.poll() is None for p in processes):
 if time.time()-started>1800:
  import signal
  for p in processes:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
  time.sleep(2)
  for p in processes:
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
  break
 time.sleep(2)
exits=[p.wait() for p in processes];write('execution.json',dict(worker_exits=exits,seconds=time.time()-started,complete=all(x==0 for x in exits)))
if not all(x==0 for x in exits):raise SystemExit(1)
with open(root/'score.log','w') as log:
 r=subprocess.run(prefix+[str(virtual/'code/scripts/score_chordfold_edit_pilot.py'),'--root',str(virtual)],env=dict(env,CUDA_VISIBLE_DEVICES='',HIP_VISIBLE_DEVICES=''),stdout=log,stderr=subprocess.STDOUT,timeout=600)
write('controller_execution.json',dict(complete=r.returncode==0,score_exit=r.returncode,seconds=time.time()-started))
raise SystemExit(r.returncode)
