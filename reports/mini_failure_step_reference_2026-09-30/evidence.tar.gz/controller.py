import os,sys,json,time,subprocess,traceback
from pathlib import Path
root=Path('/media/PM982/onestepfold/failure_step_reference_v1_20260930')
py='/home/pc/anaconda3/envs/fold/bin/python'
env=os.environ.copy();env.update(PROTENIX_ROOT_DIR='/media/PM982/onestepfold/protenix_stage0_pkg/v1_1/runtime',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LAYERNORM_TYPE='torch',PYTHONPATH=f'{root}/code/scripts:{root}/code:{root}/code/src:/media/PM982/onestepfold/independent32_v2_20260930/deps_offline')
start=time.monotonic();result={'complete':False,'commands':[],'returncodes':[]}
try:
 command=[py,str(root/'code/scripts/run_failure_step_reference.py'),'--root',str(root),'--previous',str(root.parent/'fresh_contact_predictions_v1_1_20260930'),'--mode','prepare']
 result['commands'].append(command)
 with (root/'prepare.log').open('w') as f:r=subprocess.run(command,env=dict(env,ROCR_VISIBLE_DEVICES=''),stdout=f,stderr=subprocess.STDOUT,timeout=600)
 result['returncodes'].append(r.returncode);assert r.returncode==0
 jobs=[]
 for i in range(2):
  command=[py,str(root/'code/scripts/run_failure_step_reference.py'),'--root',str(root),'--mode','case','--index',str(i)]
  result['commands'].append(command)
  with (root/f'worker_{i}.log').open('w') as f:p=subprocess.Popen(command,env=dict(env,ROCR_VISIBLE_DEVICES=str(i)),stdout=f,stderr=subprocess.STDOUT)
  jobs.append(p)
 (root/'worker_pids.json').write_text(json.dumps([p.pid for p in jobs]))
 for p in jobs:
  try:rc=p.wait(timeout=5400)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=30);raise
  result['returncodes'].append(rc)
 assert all(rc==0 for rc in result['returncodes'])
 command=[py,str(root/'code/scripts/audit_failure_step_reference.py'),'--root',str(root)]
 result['commands'].append(command)
 with (root/'audit.log').open('w') as f:r=subprocess.run(command,env=dict(env,ROCR_VISIBLE_DEVICES=''),stdout=f,stderr=subprocess.STDOUT,timeout=600)
 result['returncodes'].append(r.returncode);assert r.returncode==0
 result['complete']=True
except Exception:result['error']=traceback.format_exc()
finally:
 result['seconds']=time.monotonic()-start;(root/'execution.json').write_text(json.dumps(result,indent=2))
