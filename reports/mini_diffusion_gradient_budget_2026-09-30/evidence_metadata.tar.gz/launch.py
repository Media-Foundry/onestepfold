import json,os,subprocess,time
from pathlib import Path
r=Path('/media/PM982/onestepfold/diffusion_gradient_budget_v1_20260930')
assert (r/'lock.json').exists() and not (r/'execution.json').exists()
env=dict(os.environ,PROTENIX_ROOT_DIR=str(r.parent/'protenix_stage0_pkg/v1_1/runtime'),LAYERNORM_TYPE='torch',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=f'{r}/code/scripts:{r}/code:{r}/code/src:{r.parent}/independent32_v2_20260930/deps_offline')
records=[];processes=[];start=time.time()
for i in range(8):
 f=open(r/f'worker_{i}.log','w')
 p=subprocess.Popen(['/home/pc/anaconda3/envs/fold/bin/python',str(r/'code/scripts/probe_diffusion_gradient_budget.py'),'--root',str(r),'--mode','worker','--index',str(i)],env=dict(env,ROCR_VISIBLE_DEVICES=str(i)),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 records.append(dict(index=i,pid=p.pid));processes.append(p)
(r/'execution.json').write_text(json.dumps(dict(controller=os.getpid(),started=start,workers=records),indent=2))
for p,v in zip(processes,records):v['exit_code']=p.wait()
(r/'execution.json').write_text(json.dumps(dict(controller=os.getpid(),started=start,seconds=time.time()-start,workers=records,complete=all(v['exit_code']==0 for v in records)),indent=2))
